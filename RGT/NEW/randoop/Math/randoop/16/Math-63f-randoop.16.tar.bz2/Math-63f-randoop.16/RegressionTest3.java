import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1076101120);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1076101120L + "'", long1 == 1076101120L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10L, (long) 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5364902654041583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.648247493320879d + "'", double1 == 4.648247493320879d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(5234637581152761600L, (long) 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5234637581152761636L + "'", long2 == 5234637581152761636L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1076101120));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.015573447697767695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015572818255850327d + "'", double1 == 0.015572818255850327d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.1179547182231304E-29d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-622554214) + "'", int1 == (-622554214));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(3.8834864931005E-310d, 87, 1024);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.015573447697767695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.tan(53.84955592153876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4738147204144501d + "'", double1 == 0.4738147204144501d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        try {
            double double9 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4142135623730951d + "'", double6 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 974002049 + "'", int7 == 974002049);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.944515159673473E42d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, 1033);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 17310309456439L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.73103099E13f + "'", float1 == 1.73103099E13f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 974002048, (int) '#', 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 311, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 99, 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.0d + "'", double2 == 99.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(17310309456439L, 17310309456440L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1033, 622);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 642526 + "'", int2 == 642526);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-172L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-171.99999999999997d) + "'", double1 == (-171.99999999999997d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0037615454006175186d, (double) 131385937L, (-0.07837917208558982d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(50.26548245743669d, (double) (short) 10, 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 36L, (-1694164182), 467396991);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.lang.Class<?> wildcardClass5 = bigInteger4.getClass();
        try {
            java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number16, (java.lang.Number) (-1.7463811409905557E7d), (int) (short) 0, orderDirection24, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection24, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 > -101)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 974002049 + "'", number23.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1037659958), (float) 36L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.03765997E9f) + "'", float2 == (-1.03765997E9f));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1024, 87);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 294.5904234163377d + "'", double2 == 294.5904234163377d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9640275800758169d + "'", double1 == 0.9640275800758169d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10, 0.0d };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray12);
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray24 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 10);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 974002048);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.6275174755083712d);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray45);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray28);
        double[] doubleArray53 = new double[] { (byte) 10, 0.0d };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray59 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 10);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray69 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray77 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 974002048);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, 0.6275174755083712d);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray80);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1000602687) + "'", int7 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1000602687) + "'", int19 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.4142135623730951d + "'", double25 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10.0d + "'", double29 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1760676956 + "'", int46 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1000602687) + "'", int54 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.4142135623730951d + "'", double60 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 10.0d + "'", double64 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.4142135623730951d + "'", double70 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1760676956 + "'", int81 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray21 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray29 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 974002048);
        double[] doubleArray37 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray45 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray45);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 974002048);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray60);
        double[] doubleArray69 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray77 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 974002048);
        double[] doubleArray85 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        double[] doubleArray93 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray85, doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray93);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray93);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray93);
        double double98 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray93);
        int int99 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.4142135623730951d + "'", double38 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.6881171418161356E43d + "'", double47 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.4142135623730951d + "'", double70 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.4142135623730951d + "'", double86 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 2.6881171418161356E43d + "'", double94 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 2.6881171418161356E43d + "'", double95 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 2.6881171418161356E43d + "'", double98 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1182127744 + "'", int99 == 1182127744);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7345175425633101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.55072930127869d + "'", double1 == 0.55072930127869d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        java.lang.Class<?> wildcardClass34 = doubleArray12.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 974002048);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray26);
        double[] doubleArray33 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 974002048);
        double[] doubleArray49 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray57 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray57);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray44);
        double[] doubleArray61 = null;
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4142135623730951d + "'", double16 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.6881171418161356E43d + "'", double24 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1760676956 + "'", int27 == 1760676956);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 9.740020500000001E8d + "'", double28 == 9.740020500000001E8d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.4142135623730951d + "'", double34 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.6881171418161356E43d + "'", double42 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4142135623730951d + "'", double50 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.6881171418161356E43d + "'", double58 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 2.6881171418161356E43d + "'", double59 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double2 = org.apache.commons.math.util.FastMath.max(5557.690612768986d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5557.690612768986d + "'", double2 == 5557.690612768986d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int16 = nonMonotonousSequenceException15.getIndex();
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        int int19 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-101L) + "'", number17.equals((-101L)));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 0, 73287569);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(44563605345385459L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1694164083));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.694164084E9d) + "'", double1 == (-1.694164084E9d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(31, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray26 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 974002048);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray37);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray37, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4142135623730951d + "'", double27 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double2 = org.apache.commons.math.util.MathUtils.log(21.163416425466703d, 0.9075712110370515d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.031774095263808644d) + "'", double2 == (-0.031774095263808644d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 257L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14725.015334862157d + "'", double1 == 14725.015334862157d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 7752, (int) (byte) -1, 5044);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.8520158336976604d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 123, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 132L + "'", long2 == 132L);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.14168768474935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1085543041, 1085544065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int int2 = org.apache.commons.math.util.FastMath.max((-1435984768), 642526);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 642526 + "'", int2 == 642526);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744345d + "'", double1 == 1.6929693744345d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.tanh(132059.36709719698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414213562373095d + "'", double1 == 1.414213562373095d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray18 = new double[] { (byte) 10, 0.0d };
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray22 = new double[] { (byte) 10, 0.0d };
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray28 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray28);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1000602687) + "'", int19 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1000602687) + "'", int23 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.4142135623730951d + "'", double29 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 35, (long) (-1925533311));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        long long1 = org.apache.commons.math.util.FastMath.abs(10090L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10090L + "'", long1 == 10090L);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        int int1 = org.apache.commons.math.util.FastMath.round(5.06605056E8f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 506605056 + "'", int1 == 506605056);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.9227673888116062d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-965354440) + "'", int1 == (-965354440));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-0.0036817297247214165d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1563278539, 7752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1563286291 + "'", int2 == 1563286291);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1085518848);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1085518848 + "'", int1 == 1085518848);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray18);
        try {
            double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 1.4516688444297455E-4d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 974002049 + "'", int20 == 974002049);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(12L, (long) 5044);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5032L) + "'", long2 == (-5032L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 172L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.147494476813453d + "'", double1 == 5.147494476813453d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-506605058), 10.0d, (double) 1313859370L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 9.740020480000001E8d + "'", double34 == 9.740020480000001E8d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double2 = org.apache.commons.math.util.MathUtils.log(35.0d, (-0.09698324645938282d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double2 = org.apache.commons.math.util.FastMath.min(11013.232874703393d, (double) 34620618912942L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232874703393d + "'", double2 == 11013.232874703393d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (-1313859370L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1760676992);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.76067699E9f + "'", float1 == 1.76067699E9f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 96, (double) (-6823928892563009503L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection10, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection10, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection10, true);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException16.getClass();
        java.lang.String str18 = nonMonotonousSequenceException16.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException16.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (974,002,049 >= -204)" + "'", str18.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (974,002,049 >= -204)"));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.9999999999999996d, 2.223626578289051E21d, 152);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10L, 622, 1313859328);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 2.0d, (int) (byte) 100);
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 5.288241522117258d, 35, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number11 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 5.288241522117258d + "'", number11.equals(5.288241522117258d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.FastMath.acos(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17260374626909167d) + "'", double1 == (-0.17260374626909167d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double double1 = org.apache.commons.math.util.FastMath.exp(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 1694164083L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.6941641E9f + "'", float2 == 1.6941641E9f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.signum(22025.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1435984768), 8094831265704971301L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8094831267140956069L) + "'", long2 == (-8094831267140956069L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, 1085518848);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.8520158336976604d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8520158336976607d + "'", double1 == 1.8520158336976607d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection10, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection10, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (1 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.7463811409905557E7d), (int) (short) 0, orderDirection8, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        int int13 = nonMonotonousSequenceException10.getIndex();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException10.getSuppressed();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-17,463,811.41 > null)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-17,463,811.41 > null)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.7463811409905557E7d) + "'", number12.equals((-1.7463811409905557E7d)));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.0E104d, 8.999999999999998d, (double) 52.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(74.54992027339121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37357877856093286d, number1, 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable throwable6 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.37357877856093286d + "'", number5.equals(0.37357877856093286d));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        int int1 = org.apache.commons.math.util.FastMath.abs(1552941056);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1552941056 + "'", int1 == 1552941056);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 101.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.00000000000001d + "'", double1 == 101.00000000000001d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1760676956L, (long) 257);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10090L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 87, (float) 123);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 123.0f + "'", float2 == 123.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-172.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.840650107780075d) + "'", double1 == (-5.840650107780075d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10, 0.0d };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray12);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 974002048);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray20);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray53 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray60 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray68 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 974002048);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray77 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double[] doubleArray85 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray77, doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) 974002048);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray88);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray71);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1000602687) + "'", int7 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.4142135623730951d + "'", double48 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.4142135623730951d + "'", double54 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 974002049 + "'", int55 == 974002049);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.4142135623730951d + "'", double61 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.6881171418161356E43d + "'", double69 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1760676956 + "'", int72 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.4142135623730951d + "'", double78 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 2.6881171418161356E43d + "'", double86 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1760676956 + "'", int89 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.FastMath.rint(11.7910068511973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-2059546114), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2L, 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1L, 34620618912942L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34620618912943L + "'", long2 == 34620618912943L);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.9877735581754346d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03469319337424438d + "'", double1 == 0.03469319337424438d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        int int2 = org.apache.commons.math.util.FastMath.max(5044, (-204));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5044 + "'", int2 == 5044);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-101L) + "'", number6.equals((-101L)));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1563278539);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (-1435984768));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 8.065817517094495E67d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-52), (-1037659958), 1552941056);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double2 = org.apache.commons.math.util.FastMath.min((-3.2362366308997543E35d), (-0.9632260215147505d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.2362366308997543E35d) + "'", double2 == (-3.2362366308997543E35d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 0, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9632260215147505d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4382106949345017d) + "'", double1 == (-1.4382106949345017d));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.atanh(132059.36709719698d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.1622776601683795d, (double) 9.7400205E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.16227766016838d + "'", double2 == 3.16227766016838d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double2 = org.apache.commons.math.util.FastMath.max(7.043958477050381d, (double) 5044);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5044.0d + "'", double2 == 5044.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 132L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 132 + "'", int1 == 132);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-974002048L), 10, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-9.7400205E8f) + "'", float3 == (-9.7400205E8f));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 123);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 123.0d + "'", double1 == 123.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.694164183E9d, 0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8400139808654785d + "'", double2 == 0.8400139808654785d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        java.lang.Number number0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 5.288241522117258d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (short) 100, (int) (short) 100, orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection11, true);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 3.9512437185814275d + "'", number16.equals(3.9512437185814275d));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 974002048);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.74002048E8d + "'", double1 == 9.74002048E8d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-506605058));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3149206527444455424L, (float) 6L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.8414709848078965d, (double) 1.6941641E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6941640950368629E9d + "'", double2 == 1.6941640950368629E9d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1033);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1563286291);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1563286272 + "'", int1 == 1563286272);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(31L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3007L + "'", long2 == 3007L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.731030945644E13d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.030032437811794512d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.029585945070514374d) + "'", double1 == (-0.029585945070514374d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 0, 32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 10);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.651351181973492E30d, 0.0d, (-0.9227673888116062d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray28);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray18);
        int[] intArray35 = new int[] { (byte) 0, 100, 0 };
        int[] intArray40 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray40);
        int[] intArray45 = new int[] { (byte) 0, 100, 0 };
        int[] intArray50 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray50);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray40);
        java.lang.Class<?> wildcardClass54 = intArray18.getClass();
        java.lang.Class<?> wildcardClass55 = intArray18.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 99 + "'", int31 == 99);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 152 + "'", int41 == 152);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 152 + "'", int51 == 152);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(wildcardClass54);
        org.junit.Assert.assertNotNull(wildcardClass55);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 0, 100, 0 };
        int[] intArray9 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray14 = new int[] { (byte) 0, 100, 0 };
        int[] intArray19 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray19);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray29);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray29);
        int[] intArray47 = new int[] { (byte) 0, 100, 0 };
        int[] intArray52 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray47, intArray52);
        int[] intArray57 = new int[] { (byte) 0, 100, 0 };
        int[] intArray62 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray62);
        int[] intArray67 = new int[] { (byte) 0, 100, 0 };
        int[] intArray72 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray72);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray62);
        int[] intArray79 = new int[] { (byte) 0, 100, 0 };
        int[] intArray84 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int85 = org.apache.commons.math.util.MathUtils.distance1(intArray79, intArray84);
        int[] intArray89 = new int[] { (byte) 0, 100, 0 };
        int[] intArray94 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray89, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray84, intArray94);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray84);
        int int98 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray84);
        try {
            double double99 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 152 + "'", int10 == 152);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 152 + "'", int20 == 152);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 99 + "'", int42 == 99);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 111.83022847155415d + "'", double43 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 152 + "'", int53 == 152);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 152 + "'", int63 == 152);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 152 + "'", int73 == 152);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 99 + "'", int75 == 99);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 152 + "'", int85 == 152);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 152 + "'", int95 == 152);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 152 + "'", int98 == 152);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1552941056L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7985974558093126d) + "'", double1 == (-0.7985974558093126d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double2 = org.apache.commons.math.util.FastMath.max(74.54992027339121d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 74.54992027339121d + "'", double2 == 74.54992027339121d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 10);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray27 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray35 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 974002048);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 0.6275174755083712d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray38);
        double[] doubleArray47 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 974002048);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1000602687) + "'", int12 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.4142135623730951d + "'", double28 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.6881171418161356E43d + "'", double36 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1760676956 + "'", int39 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.4142135623730951d + "'", double48 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 2.6881171418161356E43d + "'", double56 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 9.740020480000001E8d + "'", double60 == 9.740020480000001E8d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3628800L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        int int2 = org.apache.commons.math.util.FastMath.min(1694164182, (-1076101120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1076101120) + "'", int2 == (-1076101120));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Class<?> wildcardClass11 = number10.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-101L) + "'", number10.equals((-101L)));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray53 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray61 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray61);
        java.lang.Class<?> wildcardClass63 = doubleArray53.getClass();
        try {
            double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1182127744 + "'", int47 == 1182127744);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1182127744 + "'", int48 == 1182127744);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.4142135623730951d + "'", double54 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.6881171418161356E43d + "'", double62 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(wildcardClass63);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1085543041, 1694164182);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.14168768474935d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 122.7096653712825d + "'", double1 == 122.7096653712825d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37357877856093286d, number9, 10);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 974002049 + "'", number6.equals(974002049));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(number12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.37357877856093286d + "'", number13.equals(0.37357877856093286d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        java.lang.Number number30 = nonMonotonousSequenceException27.getPrevious();
        java.lang.Class<?> wildcardClass31 = nonMonotonousSequenceException27.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 3.9512437185814275d + "'", number30.equals(3.9512437185814275d));
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.746527088821798E29d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.746527088821798E29d + "'", double1 == 3.746527088821798E29d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(304.6868567656687d, 3.831008000716577E22d, 132);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0E104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6415888336127785E34d + "'", double1 == 4.6415888336127785E34d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-101L) + "'", number6.equals((-101L)));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.565119738485518E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.008102542649369713d + "'", double1 == 0.008102542649369713d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-101L) + "'", number5.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 974002049 + "'", number6.equals(974002049));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        boolean boolean12 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException3.getSuppressed();
        int int14 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 10);
        double[] doubleArray41 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray26);
        double[] doubleArray53 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray61 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 974002048);
        double[] doubleArray69 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray77 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray77);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray77);
        double[] doubleArray82 = null;
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1000602687) + "'", int27 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4142135623730951d + "'", double33 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.4142135623730951d + "'", double42 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 974002049 + "'", int43 == 974002049);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.4142135623730951d + "'", double54 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.6881171418161356E43d + "'", double62 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.4142135623730951d + "'", double70 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 2.6881171418161356E43d + "'", double79 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1182127744 + "'", int80 == 1182127744);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1760676956, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.76067712E9f + "'", float2 == 1.76067712E9f);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 10, (long) 1085544065);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2171088130L + "'", long2 == 2171088130L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1313859370L, 6.346863764025602E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.346863764025602E8d + "'", double2 == 6.346863764025602E8d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1760676966, 7752);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1694164182));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1694164224) + "'", int1 == (-1694164224));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.740020490000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1563286272);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        java.lang.Class<?> wildcardClass34 = doubleArray29.getClass();
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 9.740020480000001E8d + "'", double35 == 9.740020480000001E8d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.log10(11.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0413926851582251d + "'", double1 == 1.0413926851582251d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1224L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray21 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray29 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 974002048);
        double[] doubleArray37 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray45 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray45);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 974002048);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray60);
        double[] doubleArray69 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray77 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 974002048);
        double[] doubleArray85 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        double[] doubleArray93 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray85, doubleArray93);
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray80, doubleArray93);
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray93);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray93);
        double double98 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.4142135623730951d + "'", double38 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.6881171418161356E43d + "'", double47 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.4142135623730951d + "'", double70 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 1.4142135623730951d + "'", double86 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 2.6881171418161356E43d + "'", double94 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 2.6881171418161356E43d + "'", double95 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + true + "'", boolean96 == true);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + double98 + "' != '" + 9.740020480000001E8d + "'", double98 == 9.740020480000001E8d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.12431705617945586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49908774483254326d + "'", double1 == 0.49908774483254326d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.01394084841975E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.486676113234076d + "'", double1 == 36.486676113234076d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.1214480546016465E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.8520158336976607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.46170327862784d) + "'", double1 == (-3.46170327862784d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37357877856093286d, number1, 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1033);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.4563606E16f + "'", float1 == 4.4563606E16f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) '#');
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 10);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 10);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) '#');
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (short) 10);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 2);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 10);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, (long) 0);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 10);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger39);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 10);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, (long) 1563278539);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, bigInteger47);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger48);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-9.7400205E8f), 1.5860134523134308E15d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1000602687));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.00060269E9f) + "'", float2 == (-1.00060269E9f));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 506605056, (long) 1182127744);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-675522688L) + "'", long2 == (-675522688L));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 5044, 467396991, 96);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 1, 1760676992);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double1 = org.apache.commons.math.util.FastMath.log(104.9439511105971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.653426408689451d + "'", double1 == 4.653426408689451d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1760676992);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray34 = new double[] { (byte) 10, 0.0d };
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) 10, 0.0d };
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray44 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray44);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray44);
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray56 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 10);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray66 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray74 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 974002048);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, 0.6275174755083712d);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray77);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray60);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1000602687) + "'", int35 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1000602687) + "'", int39 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.4142135623730951d + "'", double45 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1000602687) + "'", int51 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.4142135623730951d + "'", double57 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 10.0d + "'", double61 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.4142135623730951d + "'", double67 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 2.6881171418161356E43d + "'", double75 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1760676956 + "'", int78 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-506605058), (double) (-6823928891127024735L), (double) 5.06605056E8f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(100, (-205));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20500) + "'", int2 == (-20500));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.1635067818046204E61d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1635067818046204E61d + "'", double1 == 2.1635067818046204E61d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        int int1 = org.apache.commons.math.util.FastMath.abs(1024);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024 + "'", int1 == 1024);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 9700, 506605058);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.16227766016838d, (java.lang.Number) 31L, 1563286272);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-20500), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-20500L) + "'", long2 == (-20500L));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(506605056, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double1 = org.apache.commons.math.util.FastMath.asinh(11013.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.99997885478613d + "'", double1 == 9.99997885478613d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { (-1.5707963258311899d) };
        try {
            double double3 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-131385937), 99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0037615454006175186d, 1024.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.673384180274023E-6d + "'", double2 == 3.673384180274023E-6d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NEGATIVE_INFINITY, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-3.46170327862784d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.919919798039993d) + "'", double1 == (-15.919919798039993d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.17260374626909167d), (double) 204.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2816256531990586E-156d + "'", double2 == 2.2816256531990586E-156d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-622554214));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.cos(37.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.765414051945348d + "'", double1 == 0.765414051945348d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-204));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 506605058);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.043242279690457d + "'", double1 == 20.043242279690457d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 0, 100, 0 };
        int[] intArray9 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray14 = new int[] { (byte) 0, 100, 0 };
        int[] intArray19 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray19);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray29);
        int[] intArray46 = new int[] { (byte) 0, 100, 0 };
        int[] intArray51 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray61);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray51);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray29);
        int[] intArray69 = new int[] { (byte) 0, 100, 0 };
        int[] intArray74 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray29, intArray74);
        try {
            double double77 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 152 + "'", int10 == 152);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 152 + "'", int20 == 152);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 99 + "'", int42 == 99);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 152 + "'", int52 == 152);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 99 + "'", int65 == 99);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 152 + "'", int75 == 152);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double double1 = org.apache.commons.math.util.FastMath.asin(88.03440747059399d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(974002079L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.6275174755083712d);
        java.lang.Class<?> wildcardClass19 = doubleArray18.getClass();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int int2 = org.apache.commons.math.util.FastMath.min(1410065408, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.000000000000002d + "'", double1 == 9.000000000000002d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(974002049L, (long) 257);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 250318526593L + "'", long2 == 250318526593L);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10, 0.0d };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray12);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 974002048);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray20);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray66 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray74 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 974002048);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray82 = new double[] { (byte) 10, 0.0d };
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray82);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray82);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1000602687) + "'", int7 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.4142135623730951d + "'", double67 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 2.6881171418161356E43d + "'", double75 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.4142135623730951d + "'", double79 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1000602687) + "'", int83 == (-1000602687));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1000602687) + "'", int84 == (-1000602687));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.6929693744345d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(73287569);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.29554887507230054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 12L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81377.39570642984d + "'", double1 == 81377.39570642984d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.1808787385219026E67d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-20500L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.rint(2304.870763945954d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2305.0d + "'", double1 == 2305.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 36.0f, (double) 5234637581152761600L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.2346375811527619E18d + "'", double2 == 5.2346375811527619E18d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        float float2 = org.apache.commons.math.util.FastMath.max(123.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.716462070079908d), (double) (-1.03765997E9f), 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1563286272, 125994627894135L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-125993064607863L) + "'", long2 == (-125993064607863L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 17310309456475L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.17636355065571846d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.17260374626909167d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-100L), (double) (-1076101120));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.1415925606617234d) + "'", double2 == (-3.1415925606617234d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.833435927100678E-9d, (java.lang.Number) (-160.23289169960583d), 99);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1563278539);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 10);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 123);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1000602687), (double) 73287569);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 12L, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 9700);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1760676956 + "'", int33 == 1760676956);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1076101120, 1.470436647668219d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9088322778658855E13d + "'", double2 == 1.9088322778658855E13d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 5.06605056E8f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1.31385933E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.313859328E9d + "'", double1 == 1.313859328E9d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 1563278539);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger17);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        long long2 = org.apache.commons.math.util.FastMath.max((-131385973L), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(32, (-1435984768));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1435984768 + "'", int2 == 1435984768);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.FastMath.acosh(105.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.347084854209185d + "'", double1 == 5.347084854209185d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 10, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-205));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.4738147204144501d, (-1), 1760676956);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 34620618912943L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 974002048, (long) 1563286291);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2537288339L + "'", long2 == 2537288339L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1224L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(11013.2329201034d, (double) 8666494886269307273L, 96.99999999999999d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(99.30685281944005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.720292854540327E42d + "'", double1 == 6.720292854540327E42d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0f + "'", float2 == 9.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1760676956L, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double2 = org.apache.commons.math.util.FastMath.max(11.0d, 8.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.0d + "'", double2 == 11.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.003761536530132509d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1925533311), 257L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int16 = nonMonotonousSequenceException15.getIndex();
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number19 = nonMonotonousSequenceException15.getArgument();
        boolean boolean20 = nonMonotonousSequenceException15.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-101L) + "'", number17.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-101L) + "'", number19.equals((-101L)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-205));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 'a', (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.05586001084178062d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 974002049);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4258676810713935d) + "'", double1 == (-0.4258676810713935d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) -1, 3.8834864931005E-310d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        long long1 = org.apache.commons.math.util.MathUtils.sign(17310309456439L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948823d + "'", double1 == 1.5707963267948823d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2171088130L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326334298d + "'", double1 == 1.570796326334298d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number14 = nonMonotonousSequenceException8.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException8.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-101L) + "'", number14.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-101L) + "'", number15.equals((-101L)));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 34620618912943L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection9, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException15.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1000602687), (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(3628800L, (long) (-204));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3629004L + "'", long2 == 3629004L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 10);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.exp(105.35837144511169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.7089907708238345E45d + "'", double1 == 5.7089907708238345E45d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 10, 123);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.717016880593469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6355760292581734d) + "'", double1 == (-0.6355760292581734d));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 132, (long) (-205));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 31, (long) 1435984768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0333147966386297E40d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        long long1 = org.apache.commons.math.util.MathUtils.sign(9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 97.0f, 9700);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.697398869552681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1101.3058544644568d + "'", double1 == 1101.3058544644568d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-506605058), (-1694164224), 1182127744);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1033);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.9640275800758169d, 1024);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7330257625202276E308d + "'", double2 == 1.7330257625202276E308d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(363.7393755555636d, 9.740020500000001E8d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1085518848, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double2 = org.apache.commons.math.util.FastMath.min((-3.46170327862784d), 1.1447298374954387d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.46170327862784d) + "'", double2 == (-3.46170327862784d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.0d), (double) 467396991);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.6739699311691153E8d + "'", double2 == 4.6739699311691153E8d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 311);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 9.706845743083347E10d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1037659958), 12L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 827133952 + "'", int2 == 827133952);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number8 = nonMonotonousSequenceException7.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        java.lang.Number number15 = nonMonotonousSequenceException12.getPrevious();
        int int16 = nonMonotonousSequenceException12.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number18 = nonMonotonousSequenceException12.getArgument();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 974002049 + "'", number8.equals(974002049));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 974002049 + "'", number15.equals(974002049));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-101L) + "'", number18.equals((-101L)));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-52), 96, 1410065408);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1694164182, (double) 1410065408, (double) (-52));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.FastMath.acosh(53.84955592153876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.679255112799385d + "'", double1 == 4.679255112799385d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(53.84955592153876d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-44563605345380446L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 10090L, 6.339045318021367d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.487581976763977d + "'", double2 == 5.487581976763977d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-205.0d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1066819584) + "'", int1 == (-1066819584));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double[] doubleArray2 = new double[] { 7.043958477050381d, 1.4645918639552502d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 418509424 + "'", int3 == 418509424);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 827133952);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-131385940), (float) 131385937L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.31385936E8f) + "'", float2 == (-1.31385936E8f));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-131385940), 310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-131385630) + "'", int2 == (-131385630));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        int int1 = org.apache.commons.math.util.MathUtils.sign(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6420149920119999d + "'", double1 == 0.6420149920119999d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.1556157735575975E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        long long2 = org.apache.commons.math.util.FastMath.max((-2L), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.0758352738682991d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0013235752181534359d) + "'", double1 == (-0.0013235752181534359d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.8744856511179626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7036460122696877d + "'", double1 == 0.7036460122696877d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(5624L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5614L + "'", long2 == 5614L);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 123);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 123L + "'", long1 == 123L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1313859328, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1313859328 + "'", int2 == 1313859328);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 9.999999999999998d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1224L, (long) 1410065408);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1725920059392L + "'", long2 == 1725920059392L);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 123L, 87);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int23 = nonMonotonousSequenceException22.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException17.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 974002049 + "'", number18.equals(974002049));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int[] intArray5 = new int[] { (short) 1, 152, 1182127744, (-131385630), 418509424 };
        int[] intArray9 = new int[] { (byte) 0, 100, 0 };
        int[] intArray14 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray14);
        int[] intArray19 = new int[] { (byte) 0, 100, 0 };
        int[] intArray24 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray24);
        int[] intArray30 = new int[] { (byte) 0, 100, 0 };
        int[] intArray35 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray35);
        int[] intArray40 = new int[] { (byte) 0, 100, 0 };
        int[] intArray45 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray45);
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray35);
        try {
            int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 152 + "'", int15 == 152);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 152 + "'", int25 == 152);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 152 + "'", int36 == 152);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 152 + "'", int46 == 152);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        double double1 = org.apache.commons.math.util.FastMath.ceil(21.863198261002008d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.0d + "'", double1 == 22.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 10);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray27 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray35 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 974002048);
        double[] doubleArray43 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray51 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray51);
        double[] doubleArray60 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray68 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 974002048);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray77 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double[] doubleArray85 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray77, doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) 974002048);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray71);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray71);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1000602687) + "'", int12 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.4142135623730951d + "'", double28 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.6881171418161356E43d + "'", double36 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.6881171418161356E43d + "'", double52 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.4142135623730951d + "'", double61 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.6881171418161356E43d + "'", double69 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1760676956 + "'", int72 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.4142135623730951d + "'", double78 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 2.6881171418161356E43d + "'", double86 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1760676956 + "'", int89 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.6881171418161356E43d + "'", double91 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 9.740020480000001E8d + "'", double92 == 9.740020480000001E8d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(17310309456475L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, (-1000602687));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-52.00000000000001d), (-0.17636355065571846d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.192092895507818E-7d + "'", double1 == 1.192092895507818E-7d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1901415581956121743L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2059546114), 974002048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.8520158336976607d, (int) '4', 9700);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2.1635067818046204E61d, (double) 1725920059392L, 2.6768077905644576d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6783606624401571d, (java.lang.Number) 3.6625219529419444d, (int) '#');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number8 = nonMonotonousSequenceException7.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        java.lang.Number number15 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int26 = nonMonotonousSequenceException25.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number16, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection27, true);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.String str33 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 974002049 + "'", number8.equals(974002049));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 974002049 + "'", number15.equals(974002049));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(99.0d, 0.10774568011245209d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5309649148733797d) + "'", double2 == (-1.5309649148733797d));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1694164182, 1563286272);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.7853981633974482d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.332621544395465E155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.089263465579822E-4d) + "'", double1 == (-5.089263465579822E-4d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 1182127744);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-131385937), 125994627894135L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        double[] doubleArray38 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray38, doubleArray42);
        try {
            double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.4142135623730951d + "'", double39 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 974002049 + "'", int40 == 974002049);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.4142135623730951d + "'", double41 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int int2 = org.apache.commons.math.util.FastMath.min((-1066819584), (-131385630));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1066819584) + "'", int2 == (-1066819584));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-205.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(17310309456475L, (long) 1760676966);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-506605058), (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1760676966, (long) 1694164182);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 497145975311605302L + "'", long2 == 497145975311605302L);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        long long2 = org.apache.commons.math.util.MathUtils.pow(100L, 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray10 = null;
        try {
            double double11 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-100L), (-101L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10100L + "'", long2 == 10100L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.3383347192042695E42d, (double) 1024L, (-0.4614191792528529d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 622);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 622 + "'", int1 == 622);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        int int2 = org.apache.commons.math.util.FastMath.min((-52), 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 37L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-521357855) + "'", int2 == (-521357855));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 2.14168768474935d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.33680329744389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 10);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 10);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 10);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger24);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) '#');
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger28);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 122.7096653712825d, (java.lang.Number) bigInteger31, 31);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.740020500000011E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.697398869552681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2201.611254922335d + "'", double1 == 2201.611254922335d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7330257625202276E308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.45523680707379d + "'", double1 == 31.45523680707379d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        java.lang.Number number30 = nonMonotonousSequenceException27.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number35 = nonMonotonousSequenceException34.getPrevious();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException34);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 3.9512437185814275d + "'", number30.equals(3.9512437185814275d));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 974002049 + "'", number35.equals(974002049));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) 2.8544953854119198E45d, 87);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 86 and 87 are not strictly increasing (2,854,495,385,411,919,800,000,000,000,000,000,000,000,000,000 >= 26,881,171,418,161,356,000,000,000,000,000,000,000,000,000)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 86 and 87 are not strictly increasing (2,854,495,385,411,919,800,000,000,000,000,000,000,000,000,000 >= 26,881,171,418,161,356,000,000,000,000,000,000,000,000,000)"));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int10 = nonMonotonousSequenceException9.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection11, true);
        java.lang.String str16 = nonMonotonousSequenceException15.toString();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.951 >= null)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (3.951 >= null)"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.3915798710256516d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.435873952046947d + "'", double1 == 22.435873952046947d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 497145975311605302L, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-20500), 1760676956);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(5.267831587699267d, 0.0d, 132);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1000602687) + "'", int47 == (-1000602687));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.615120516841261d + "'", double1 == 4.615120516841261d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 8666494886269307273L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1925533311), 52, (-521357855));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 36, (long) (-1076101120));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double2 = org.apache.commons.math.util.MathUtils.log((-3.5779249665883754d), 1.8520158336976604d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.03469319337424438d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.5707963267948966d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3012989023072947d) + "'", double1 == (-2.3012989023072947d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(97);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.6941640950368629E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.16350678180462E61d, (java.lang.Number) 0, 99);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 99 + "'", int10 == 99);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        int int1 = org.apache.commons.math.util.FastMath.round(1.73103099E13f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray28);
        int[] intArray46 = new int[] { (byte) 0, 100, 0 };
        int[] intArray51 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray61);
        int[] intArray67 = new int[] { (byte) 0, 100, 0 };
        int[] intArray72 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray72);
        int[] intArray77 = new int[] { (byte) 0, 100, 0 };
        int[] intArray82 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray82);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray72);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray51);
        int[] intArray87 = null;
        try {
            int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 111.83022847155415d + "'", double42 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 152 + "'", int52 == 152);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 152 + "'", int73 == 152);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 152 + "'", int83 == 152);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38905609893065d + "'", double1 == 6.38905609893065d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        int int2 = org.apache.commons.math.util.FastMath.max(506605058, 1182127744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1182127744 + "'", int2 == 1182127744);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-506605058));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.06605059E8d) + "'", double1 == (-5.06605059E8d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        long long2 = org.apache.commons.math.util.MathUtils.pow(36L, 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5430806348152442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 22025.465794806718d, (java.lang.Number) 467396991, 1552941056);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.694164084E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1435984768));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        int int2 = org.apache.commons.math.util.MathUtils.pow(5044, 1033);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 73287569);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.803048742311635d + "'", double1 == 18.803048742311635d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.017921032008744623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.469446951953614E-18d + "'", double1 == 3.469446951953614E-18d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (-20500));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20500) + "'", int2 == (-20500));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1760676966, 132);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2294.2524464610515d + "'", double2 == 2294.2524464610515d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 9, 1.8520158336976607d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7168146928204138d + "'", double2 == 2.7168146928204138d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.7814031344344955d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.076030225056872E37d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int23 = nonMonotonousSequenceException22.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        java.lang.Number number27 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 974002049 + "'", number18.equals(974002049));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 974002049 + "'", number27.equals(974002049));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1182127744, (java.lang.Number) 152, 1760676992);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1760676992 + "'", int4 == 1760676992);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.1214480546016465E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double1 = org.apache.commons.math.util.FastMath.log(10.752220392306214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3751122813670538d + "'", double1 == 2.3751122813670538d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double double1 = org.apache.commons.math.util.FastMath.rint(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.570796326334298d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.810477378749653d + "'", double1 == 3.810477378749653d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) 2.8544953854119198E45d, 87);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(32, 310);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 342 + "'", int2 == 342);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1.00060269E9f), (double) 1552941056L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.000602688E9d) + "'", double2 == (-1.000602688E9d));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray11 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray19 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 974002048);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray28 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray36 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 974002048);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray22);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.4142135623730951d + "'", double12 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.6881171418161356E43d + "'", double20 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1760676956 + "'", int23 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.4142135623730951d + "'", double29 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.6881171418161356E43d + "'", double37 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1760676956 + "'", int40 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.4142135623730951d + "'", double43 == 1.4142135623730951d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-204), 974002049);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 974001845 + "'", int2 == 974001845);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1694164183, 1L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1694164183 + "'", int2 == 1694164183);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.610125138662288d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1009.2655867757023d + "'", double1 == 1009.2655867757023d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 974001845, 0.017921032008744623d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.74001845E8d + "'", double2 == 9.74001845E8d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2, 1182127744);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1076101120, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(19788, 1760676992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760696780 + "'", int2 == 1760696780);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        double double1 = org.apache.commons.math.util.FastMath.cosh(28.031624894526136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.463628507205461E11d + "'", double1 == 7.463628507205461E11d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray28);
        int[] intArray46 = new int[] { (byte) 0, 100, 0 };
        int[] intArray51 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray61);
        int[] intArray67 = new int[] { (byte) 0, 100, 0 };
        int[] intArray72 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray72);
        int[] intArray77 = new int[] { (byte) 0, 100, 0 };
        int[] intArray82 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray82);
        double double85 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray72);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray51);
        int[] intArray87 = null;
        try {
            int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 111.83022847155415d + "'", double42 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 152 + "'", int52 == 152);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 152 + "'", int73 == 152);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 152 + "'", int83 == 152);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-20500));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.5440618722340037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.575270619101565d) + "'", double1 == (-0.575270619101565d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1085544065), (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 7752, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9700, (java.lang.Number) 0.7615941559557649d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 9700 + "'", number4.equals(9700));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6783606624401571d, (java.lang.Number) 3.6625219529419444d, (int) '#');
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number8 = nonMonotonousSequenceException7.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.String str14 = nonMonotonousSequenceException12.toString();
        java.lang.Number number15 = nonMonotonousSequenceException12.getPrevious();
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int26 = nonMonotonousSequenceException25.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException25.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number16, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection27, true);
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.String str33 = nonMonotonousSequenceException12.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 974002049 + "'", number8.equals(974002049));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 974002049 + "'", number15.equals(974002049));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 100 + "'", int26 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1076101120, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076101120L + "'", long2 == 1076101120L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 36);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 10L, 1.3113358856836756E267d, 9.740020500000011E8d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number12 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 974002049 + "'", number12.equals(974002049));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1085543041, 257);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 497145975311605302L, (-205));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.667959374035306E-45d + "'", double2 == 9.667959374035306E-45d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.9251475365964192d), 3348802.852664884d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double double1 = org.apache.commons.math.util.FastMath.acosh(5.69349861963412d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4246690739257266d + "'", double1 == 2.4246690739257266d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException8.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8623188722876839d, (java.lang.Number) 1.4210854715202004E-14d, (int) '4');
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.4210854715202004E-14d + "'", number4.equals(1.4210854715202004E-14d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        int int1 = org.apache.commons.math.util.MathUtils.sign(974001845);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1694164224), (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.69416422E9f) + "'", float2 == (-1.69416422E9f));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.6941641E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.6941641E9f + "'", float1 == 1.6941641E9f);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        long long2 = org.apache.commons.math.util.MathUtils.pow(5624L, (long) 36);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-131385630), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(4.524244356327114E15d, 311);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.887446736807238E109d + "'", double2 == 1.887446736807238E109d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(13.228920847762078d, (double) 5044, 204);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 96);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        int[] intArray45 = new int[] { (byte) 0, 100, 0 };
        int[] intArray50 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray55 = new int[] { (byte) 0, 100, 0 };
        int[] intArray60 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray50);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray68 = new int[] { (byte) 0, 100, 0 };
        int[] intArray73 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray73);
        int[] intArray76 = null;
        try {
            int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 152 + "'", int51 == 152);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152 + "'", int61 == 152);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 99 + "'", int64 == 99);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 152 + "'", int74 == 152);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.762747174039086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(5044, 342);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1085543041);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5707963267948823d, (double) 44563605345385459L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948826d + "'", double2 == 1.5707963267948826d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        int int2 = org.apache.commons.math.util.FastMath.min(87, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(132);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.16227766016838d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.868551121099462d + "'", double1 == 1.868551121099462d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        double double1 = org.apache.commons.math.util.FastMath.rint(19.466902669414953d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.0d + "'", double1 == 19.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(132059.36709719698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.7463811409905557E7d), (-1066819584));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        long long2 = org.apache.commons.math.util.FastMath.min(17310309456475L, (long) 622);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 622L + "'", long2 == 622L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.7253825588523148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1435984768));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        int[] intArray3 = new int[] { (-205), (short) -1, 1 };
        int[] intArray7 = new int[] { (byte) 0, 100, 0 };
        int[] intArray12 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray12);
        int[] intArray17 = new int[] { (byte) 0, 100, 0 };
        int[] intArray22 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray22);
        int[] intArray27 = new int[] { (byte) 0, 100, 0 };
        int[] intArray32 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray32);
        int[] intArray37 = new int[] { (byte) 0, 100, 0 };
        int[] intArray42 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray42);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray32);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray32);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray32);
        java.lang.Class<?> wildcardClass48 = intArray3.getClass();
        int[] intArray52 = new int[] { (byte) 0, 100, 0 };
        int[] intArray57 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray57);
        int[] intArray62 = new int[] { (byte) 0, 100, 0 };
        int[] intArray67 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray67);
        int[] intArray72 = new int[] { (byte) 0, 100, 0 };
        int[] intArray77 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray72, intArray77);
        int[] intArray82 = new int[] { (byte) 0, 100, 0 };
        int[] intArray87 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray82, intArray87);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray87);
        int int90 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray77);
        double double91 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray77);
        int int92 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray77);
        java.lang.Class<?> wildcardClass93 = intArray77.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 152 + "'", int13 == 152);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 152 + "'", int23 == 152);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 152 + "'", int33 == 152);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 152 + "'", int43 == 152);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 99 + "'", int45 == 99);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 111.83022847155415d + "'", double46 == 111.83022847155415d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 257 + "'", int47 == 257);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 152 + "'", int58 == 152);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 152 + "'", int68 == 152);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 152 + "'", int78 == 152);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 152 + "'", int88 == 152);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 99 + "'", int90 == 99);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 111.83022847155415d + "'", double91 == 111.83022847155415d);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 257 + "'", int92 == 257);
        org.junit.Assert.assertNotNull(wildcardClass93);
    }
}

