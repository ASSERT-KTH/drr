import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Throwable[] throwableArray29 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Class<?> wildcardClass30 = nonMonotonousSequenceException8.getClass();
        int int31 = nonMonotonousSequenceException8.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 100 + "'", int31 == 100);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(37L, (long) (-204));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 241L + "'", long2 == 241L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1076101120));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 760074269L, (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.3383347192042695E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2147483647, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 2171088130L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.17108813E9d + "'", double1 == 2.17108813E9d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 506605058, 622L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 506604436L + "'", long2 == 506604436L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1925533311), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        int int2 = org.apache.commons.math.util.FastMath.min((-131385937), 1760676956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-131385937) + "'", int2 == (-131385937));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3132616875182228d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.796745936845351d + "'", double1 == 3.796745936845351d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 52, (long) 7752);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8813735870195429d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.1415925016813464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210803761155406d + "'", double1 == 1.4210803761155406d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5403023093369417d, 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1694164182);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1694164083), 132);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 81377.39570642984d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 2304.870763945954d, (int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) ' ', (long) 73287569);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2345202208L + "'", long2 == 2345202208L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1024.0d, (java.lang.Number) 1L, 7752, orderDirection8, true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-204));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 204.0f + "'", float1 == 204.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        double double1 = org.apache.commons.math.util.FastMath.rint(122.7096653712825d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 123.0d + "'", double1 == 123.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 974001845, (-125993064607863L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-125993064607863L) + "'", long2 == (-125993064607863L));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(53.84955592153876d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 55141.94526365569d + "'", double2 == 55141.94526365569d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 132);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0613084341780446E57d + "'", double1 == 1.0613084341780446E57d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double2 = org.apache.commons.math.util.MathUtils.log(5.347084854209185d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1206315509867d + "'", double2 == 2.1206315509867d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.4210803761155406d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9500697429099638d + "'", double1 == 1.9500697429099638d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(572.2646479502633d, 0.0d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1066819584));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1066819584 + "'", int1 == 1066819584);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (-1925533311));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.015572818255850338d, 0.4738147204144501d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.13916081945116796d + "'", double2 == 0.13916081945116796d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5426074954923101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8563651598092406d + "'", double1 == 0.8563651598092406d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(96);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 34620618922968L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4620618922968E13d + "'", double1 == 3.4620618922968E13d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        int int2 = org.apache.commons.math.util.FastMath.min(9700, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.7463811409905557E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-304801.00905020506d) + "'", double1 == (-304801.00905020506d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1435984768));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 10, 0.0d };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 10);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray19 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) 974002048);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 0.6275174755083712d);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray30);
        double[] doubleArray39 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray47);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 974002048);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1000602687) + "'", int4 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.6881171418161356E43d + "'", double28 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1760676956 + "'", int31 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.4142135623730951d + "'", double40 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.6881171418161356E43d + "'", double48 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0037615454006175186d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1881312269 + "'", int1 == 1881312269);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.6768077905644576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2132717767763983d + "'", double1 == 1.2132717767763983d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 10);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 0);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 10);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger22);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 0);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 10);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 0);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 10);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, (long) '#');
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger36);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 0);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 10);
        java.math.BigInteger bigInteger43 = null;
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 0);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 10);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger47);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) '#');
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 1024);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger52);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number60 = nonMonotonousSequenceException59.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException64 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException59.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException64);
        java.lang.String str66 = nonMonotonousSequenceException64.toString();
        java.lang.Number number67 = nonMonotonousSequenceException64.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int72 = nonMonotonousSequenceException71.getIndex();
        java.lang.Number number73 = nonMonotonousSequenceException71.getArgument();
        nonMonotonousSequenceException64.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException71);
        boolean boolean75 = nonMonotonousSequenceException64.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection76 = nonMonotonousSequenceException64.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger52, (java.lang.Number) 1760676966, (int) (byte) 100, orderDirection76, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection76, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (10 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 974002049 + "'", number60.equals(974002049));
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str66.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 974002049 + "'", number67.equals(974002049));
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 100 + "'", int72 == 100);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + (-101L) + "'", number73.equals((-101L)));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
        org.junit.Assert.assertTrue("'" + orderDirection76 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection76.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 1033);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.015573447697767695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998787363142952d + "'", double1 == 0.9998787363142952d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 9.7400205E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        long long1 = org.apache.commons.math.util.MathUtils.sign(36L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int int2 = org.apache.commons.math.util.MathUtils.pow(204, 7752);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 497145975311605302L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9700, (java.lang.Number) 0.7615941559557649d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.7615941559557649d + "'", number5.equals(0.7615941559557649d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int int2 = org.apache.commons.math.util.FastMath.min(7752, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 9.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4121184852417566d + "'", double1 == 0.4121184852417566d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 1.76067699E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray20 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray20);
        double[] doubleArray28 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray28);
        double[] doubleArray30 = null;
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray12);
        double[] doubleArray35 = new double[] { (byte) 10, 0.0d };
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray41 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        double[] doubleArray50 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        double[] doubleArray54 = null;
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray50);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray35);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 3.9512437185814275d);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 1.9155040003582885E22d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.6881171418161356E43d + "'", double21 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 204.0d + "'", double29 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1000602687) + "'", int36 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.4142135623730951d + "'", double42 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.4142135623730951d + "'", double51 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 974002049 + "'", int52 == 974002049);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double double1 = org.apache.commons.math.util.FastMath.sin(6.720292854540327E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9951621879001481d + "'", double1 == 0.9951621879001481d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2345202208L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.345202208E9d + "'", double1 == 2.345202208E9d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1552941056L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 36, (-44563605345380515L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1604289792433698540L + "'", long2 == 1604289792433698540L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1085543041);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, (-1313859370L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1313859370L) + "'", long2 == (-1313859370L));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(99.30685281944005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.30685281944007d + "'", double1 == 99.30685281944007d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double1 = org.apache.commons.math.util.FastMath.expm1(7.01394084841975E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        double double1 = org.apache.commons.math.util.MathUtils.sign(55141.94526365569d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(87, 1085544065);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2171088130L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2439418679995021E11d + "'", double1 == 1.2439418679995021E11d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.624619224577892d + "'", double1 == 7.624619224577892d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        int int2 = org.apache.commons.math.util.FastMath.min(1313859328, 1760676992);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1313859328 + "'", int2 == 1313859328);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        double double1 = org.apache.commons.math.util.FastMath.tanh(9.0871877068532768E16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1024, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        double double1 = org.apache.commons.math.util.FastMath.log(0.015573447697767695d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.162187885550581d) + "'", double1 == (-4.162187885550581d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        long long2 = org.apache.commons.math.util.FastMath.min(1925533408L, (-6823928891127024735L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6823928891127024735L) + "'", long2 == (-6823928891127024735L));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double1 = org.apache.commons.math.util.FastMath.log(1.5606956602095747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4451316578933017d + "'", double1 == 0.4451316578933017d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) '#');
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 10);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 0);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 10);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger34);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) '#');
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, (long) 1024);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger39);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) 0);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, 10);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(125994627894135L, (long) (-205));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3132616875182228d, (java.lang.Number) 1.9877735581754346d, 1694164183);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1694164183 + "'", int4 == 1694164183);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.9877735581754346d + "'", number5.equals(1.9877735581754346d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,694,164,182 and 1,694,164,183 are not strictly increasing (1.988 >= 1.313)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,694,164,182 and 1,694,164,183 are not strictly increasing (1.988 >= 1.313)"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(572.2646479502633d, (double) 32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 467396991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int23 = nonMonotonousSequenceException22.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException17.getDirection();
        java.lang.Number number28 = nonMonotonousSequenceException17.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 974002049 + "'", number18.equals(974002049));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 974002049 + "'", number28.equals(974002049));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-5786.873730821314d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray13);
        double[] doubleArray19 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray35 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray35);
        double[] doubleArray43 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray43);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray27);
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray56 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 10);
        double[] doubleArray65 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray65);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray50);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 3.9512437185814275d);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 974002049 + "'", int21 == 974002049);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.4142135623730951d + "'", double28 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.6881171418161356E43d + "'", double36 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 204.0d + "'", double44 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1000602687) + "'", int51 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.4142135623730951d + "'", double57 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.4142135623730951d + "'", double66 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 974002049 + "'", int67 == 974002049);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.4142135623730951d + "'", double68 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1770355762 + "'", int76 == 1770355762);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(34620618922968L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34620618922969L + "'", long2 == 34620618922969L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-20500L), (float) 974002048L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-20500.0f) + "'", float2 == (-20500.0f));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.0036817214070489815d), 3.970291913552122d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 1725920059392L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1313859328);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        int int1 = org.apache.commons.math.util.FastMath.abs((-204));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 204 + "'", int1 == 204);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(9.0f, (-1435984768), 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.2346375811527619E18d, 5.487581976763977d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double2 = org.apache.commons.math.util.FastMath.max(1.414213562373095d, (double) (-1435984768));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.414213562373095d + "'", double2 == 1.414213562373095d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.7463811409905557E7d), (int) (short) 0, orderDirection8, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        java.lang.Number number13 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-17,463,811.41 > null)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-17,463,811.41 > null)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.7463811409905557E7d) + "'", number12.equals((-1.7463811409905557E7d)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.7463811409905557E7d) + "'", number13.equals((-1.7463811409905557E7d)));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(97, 96);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-506605058), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4033429968428506d, 5.288241522117258d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.288241522117258d + "'", double2 == 5.288241522117258d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-5.089263465579822E-4d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.089263685271184E-4d) + "'", double1 == (-5.089263685271184E-4d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 35);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1770355762);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.080594601624405E-9d + "'", double1 == 2.080594601624405E-9d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 8666494886269307273L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.6664947E18f + "'", float1 == 8.6664947E18f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1085518848, 1435984768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 10090L, 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray13);
        double[] doubleArray19 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray35 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray35);
        double[] doubleArray43 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray43);
        double[] doubleArray45 = null;
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray27, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray27);
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray56 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 10);
        double[] doubleArray65 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray69 = null;
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray65, doubleArray69);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray65);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray50);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 3.9512437185814275d);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray74);
        double[] doubleArray80 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray80);
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 974002049 + "'", int21 == 974002049);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.4142135623730951d + "'", double28 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.6881171418161356E43d + "'", double36 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 204.0d + "'", double44 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1000602687) + "'", int51 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.4142135623730951d + "'", double57 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.4142135623730951d + "'", double66 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 974002049 + "'", int67 == 974002049);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.4142135623730951d + "'", double68 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.4142135623730951d + "'", double81 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 974002049 + "'", int82 == 974002049);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.4142135623730951d + "'", double83 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.4142135623730951d + "'", double84 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 2.951243718581428d + "'", double85 == 2.951243718581428d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 3.951243718581428d + "'", double86 == 3.951243718581428d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1085543041);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.085543041E9d + "'", double1 == 1.085543041E9d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        double double2 = org.apache.commons.math.util.FastMath.min(74.54992027339121d, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 37L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 37 + "'", int1 == 37);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        int int2 = org.apache.commons.math.util.FastMath.max(1066819584, (-965354440));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1066819584 + "'", int2 == 1066819584);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', 974002048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-622554214), 1925533408L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2548087622L) + "'", long2 == (-2548087622L));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2, (double) 2345202208L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double1 = org.apache.commons.math.util.FastMath.atan(14725.015334862157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707284151509546d + "'", double1 == 1.5707284151509546d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(506605058L, (long) 1881312269);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1374707211L) + "'", long2 == (-1374707211L));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        int[] intArray45 = new int[] { (byte) 0, 100, 0 };
        int[] intArray50 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray55 = new int[] { (byte) 0, 100, 0 };
        int[] intArray60 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray50);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray68 = new int[] { (byte) 0, 100, 0 };
        int[] intArray73 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray28, intArray73);
        java.lang.Class<?> wildcardClass76 = intArray73.getClass();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 152 + "'", int51 == 152);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152 + "'", int61 == 152);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 99 + "'", int64 == 99);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 152 + "'", int74 == 152);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass76);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10100.0f + "'", float1 == 10100.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1694164182, (double) 73287569);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 204.0f, 4.615120516841261d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2875711686728629d + "'", double2 == 0.2875711686728629d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.944515159673473E42d + "'", double1 == 4.944515159673473E42d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.383198930911336d, 73287569);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.327888480173107E-34d) + "'", double2 == (-5.327888480173107E-34d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.982441812995697E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40350239691417605d + "'", double1 == 0.40350239691417605d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.7575935506050455d, 5.342747781256308E22d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(12L, 172L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 516L + "'", long2 == 516L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 2.0d, (int) (byte) 100);
        java.lang.Number number7 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) 5.288241522117258d, 35, orderDirection10, false);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number14 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.57235190491251E-6d, (java.lang.Number) 1.3754263876807227d, 152, orderDirection15, true);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2.0d + "'", number14.equals(2.0d));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1563278539, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1563278439L + "'", long2 == 1563278439L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.697398869552681d, 0.0d, (-0.030032437811794512d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.99997885478613d, (double) 2.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray18);
        try {
            double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 0.5403023058681398d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 974002049 + "'", int20 == 974002049);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9873536182198484d + "'", double1 == 0.9873536182198484d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        double double1 = org.apache.commons.math.util.FastMath.ulp(111.83022847155415d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 5624L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5624.0d + "'", double1 == 5624.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 10100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.227966323305175d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0708504384871045d + "'", double1 == 1.0708504384871045d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.8623188722876839d, (double) (byte) 0, 2.6768077905644576d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-307.6526555685888d), 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5610453792112515d) + "'", double2 == (-1.5610453792112515d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) -1, 4.325022432875689E-133d, (-0.0036817214070489815d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        double double1 = org.apache.commons.math.util.FastMath.floor((-4.162187885550581d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.0d) + "'", double1 == (-5.0d));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 2.0d, (int) (byte) 100);
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 5.288241522117258d, 35, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str11 = nonMonotonousSequenceException9.toString();
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not increasing (5.288 > null)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not increasing (5.288 > null)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not increasing (5.288 > null)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not increasing (5.288 > null)"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(572.9577951308232d, (double) '4', 5.9718699132790505d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        long long2 = org.apache.commons.math.util.MathUtils.pow(497145975311605302L, (long) 87);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.1206315509867d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1206315509867d + "'", double1 == 2.1206315509867d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(342, 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 158625578809472060L + "'", long2 == 158625578809472060L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1.31385936E8f), (-0.5440618722340037d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5440618722340037d) + "'", double2 == (-0.5440618722340037d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.07837917208558982d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9246137723361751d + "'", double1 == 0.9246137723361751d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) '#');
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger23);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 10);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 1563278539);
        java.math.BigInteger bigInteger32 = null;
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 10);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, (long) 0);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 10);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, bigInteger41);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, bigInteger42);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 0);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger46, 10);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger50);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-44563605345380515L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1037659958), 1085518848);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) 10, 0.0d };
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray9 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray9);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 10);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1000602687) + "'", int4 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.0d + "'", double14 == 10.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        double[] doubleArray49 = new double[] { (byte) 10, 0.0d };
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray55 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 10);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray65 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray73 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) 974002048);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, 0.6275174755083712d);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray76);
        java.lang.Class<?> wildcardClass81 = doubleArray76.getClass();
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1000602687) + "'", int50 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.4142135623730951d + "'", double56 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 10.0d + "'", double60 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.4142135623730951d + "'", double66 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.6881171418161356E43d + "'", double74 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1760676956 + "'", int77 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 9.740020480000001E8d + "'", double82 == 9.740020480000001E8d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray26 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 974002048);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray37);
        double[] doubleArray43 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray43, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4142135623730951d + "'", double27 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 974002049 + "'", int45 == 974002049);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.4142135623730951d + "'", double46 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.4142135623730951d + "'", double49 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 5234637581152761600L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 0);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 10);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 0);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 10);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 10);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger24);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) '#');
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger27);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (long) (byte) 1);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger28);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number37 = nonMonotonousSequenceException36.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int42 = nonMonotonousSequenceException41.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException41.getDirection();
        nonMonotonousSequenceException36.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException41);
        boolean boolean45 = nonMonotonousSequenceException41.getStrict();
        java.lang.Throwable[] throwableArray46 = nonMonotonousSequenceException41.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = nonMonotonousSequenceException41.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2666779012127305d, (java.lang.Number) bigInteger3, 1760676966, orderDirection47, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 974002049 + "'", number37.equals(974002049));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 100 + "'", int42 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1694164183, (-44563605345380515L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44563605345380515L) + "'", long2 == (-44563605345380515L));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 8094831265704971301L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1563278539);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 0);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 10);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger16);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger17);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 0);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 10);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 257);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(257, 9700);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.6275174755083712d);
        double[] doubleArray19 = null;
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.615120516841261d, (java.lang.Number) 99.0f, 342, orderDirection3, false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 0.37357877856093286d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        double double2 = org.apache.commons.math.util.FastMath.atan2(22383.41708588723d, 3.796745936845351d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570626703636562d + "'", double2 == 1.570626703636562d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1604289792433698540L, (long) 1085543041);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray18);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray29);
        int[] intArray46 = new int[] { (byte) 0, 100, 0 };
        int[] intArray51 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray51, intArray61);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray61);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 152 + "'", int52 == 152);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.lang.Class<?> wildcardClass5 = bigInteger4.getClass();
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 1768575524);
        java.lang.Class<?> wildcardClass10 = bigInteger9.getClass();
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) 'a');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-965354440));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 974002049L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 123L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        double double1 = org.apache.commons.math.util.FastMath.signum(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(99);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 345.3794070622669d + "'", double1 == 345.3794070622669d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.16350678180462E61d, (java.lang.Number) 0, 99);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2147483647, (-1066819584));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1694164083), (long) 257);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 435400169331L + "'", long2 == 435400169331L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray13 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray21 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray21);
        double[] doubleArray29 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray29);
        double[] doubleArray31 = null;
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray13);
        try {
            double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4142135623730951d + "'", double6 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 974002049 + "'", int7 == 974002049);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.4142135623730951d + "'", double14 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.6881171418161356E43d + "'", double22 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 204.0d + "'", double30 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1552941056, 2345202208L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113811274794532864L + "'", long2 == 113811274794532864L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2758547353515625L, 1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5395564933646284d + "'", double2 == 1.5395564933646284d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1033);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.08281907607655d, 1.4210803761155406d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47895151890724985d + "'", double2 == 0.47895151890724985d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        double double1 = org.apache.commons.math.util.FastMath.log(9.740020480000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.696923964274003d + "'", double1 == 20.696923964274003d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        long long2 = org.apache.commons.math.util.FastMath.min((-2L), (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(9, 1033);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, (-131385630));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.8414709848078965d), (double) 642526);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.309629469947388E-6d) + "'", double2 == (-1.309629469947388E-6d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-2059546114));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        try {
            double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 2.6881171418161356E43d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2L, (java.lang.Number) 2L, (int) ' ');
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2 >= 2)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2 >= 2)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2 >= 2)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 31 and 32 are not strictly increasing (2 >= 2)"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1563278439L, 34620618922968L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-34619055644529L) + "'", long2 == (-34619055644529L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1085543041);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1085543041L + "'", long1 == 1085543041L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 34620618912942L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.46206199E13f + "'", float1 == 3.46206199E13f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        int int1 = org.apache.commons.math.util.MathUtils.sign(36);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double double1 = org.apache.commons.math.util.FastMath.cos(5.288241522117258d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5445500394194355d + "'", double1 == 0.5445500394194355d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int[] intArray43 = new int[] { (byte) 0, 100, 0 };
        int[] intArray48 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray48);
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray48);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray38);
        int[] intArray55 = new int[] { (byte) 0, 100, 0 };
        int[] intArray60 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int[] intArray65 = new int[] { (byte) 0, 100, 0 };
        int[] intArray70 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray70);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray70);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray60);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray38);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray38);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 152 + "'", int49 == 152);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 99 + "'", int51 == 99);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152 + "'", int61 == 152);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 152 + "'", int71 == 152);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 99 + "'", int74 == 99);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 111.83022847155415d + "'", double75 == 111.83022847155415d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.347084854209185d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 306.3653948445114d + "'", double1 == 306.3653948445114d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 974002049 + "'", int9 == 974002049);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1694164182));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3132616875182228d, (java.lang.Number) 1.9877735581754346d, 1694164183);
        int int7 = nonMonotonousSequenceException6.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3628800L, (java.lang.Number) 3.9512437185814275d, 0, orderDirection9, true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1694164183 + "'", int7 == 1694164183);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.9877735581754346d + "'", number8.equals(1.9877735581754346d));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5624.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1085518848, (long) (-205));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 222531363840L + "'", long2 == 222531363840L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-521357855), 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.0036817214070489815d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.996325047819194d + "'", double1 == 0.996325047819194d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(105.35837144511169d, (-0.031774095263808644d), (double) (-205));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-205.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9951621879001481d, (double) 418509424);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1.31385936E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.31385936E8d + "'", double1 == 1.31385936E8d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(642526, 1760676956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        int[] intArray45 = new int[] { (byte) 0, 100, 0 };
        int[] intArray50 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray50);
        int[] intArray55 = new int[] { (byte) 0, 100, 0 };
        int[] intArray60 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray60);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray60);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray50);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray28);
        int[] intArray68 = new int[] { (byte) 0, 100, 0 };
        int[] intArray73 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray73);
        int[] intArray78 = new int[] { (byte) 0, 100, 0 };
        int[] intArray83 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray83);
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray73, intArray83);
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray83);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 152 + "'", int51 == 152);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 152 + "'", int61 == 152);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 99 + "'", int64 == 99);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 152 + "'", int74 == 152);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 152 + "'", int84 == 152);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6568738401580307d + "'", double1 == 1.6568738401580307d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(10.067661995777765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11784.198666665105d + "'", double1 == 11784.198666665105d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        double double1 = org.apache.commons.math.util.FastMath.log10(22.435873952046947d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3509429914157356d + "'", double1 == 1.3509429914157356d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1076101120), 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1694164083), 1694164183);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1552941056);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.85656360602665d + "'", double1 == 21.85656360602665d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5.288241522117258d, 35, orderDirection3, false);
        boolean boolean6 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double2 = org.apache.commons.math.util.MathUtils.round(7.225342994858729E-12d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        double double2 = org.apache.commons.math.util.FastMath.min(1.694164183E9d, (double) 506604436L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.06604436E8d + "'", double2 == 5.06604436E8d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1214480546016465E13d, (double) 342);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1214480546016463E13d + "'", double2 == 1.1214480546016463E13d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.6275174755083712d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (974,002,048 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 10, (double) 1066819584, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.5309649148733797d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2L) + "'", long1 == (-2L));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= -101)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1182127744 + "'", int31 == 1182127744);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1770355762);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.9572960942883878E11d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9572960942883878E11d + "'", double2 == 1.9572960942883878E11d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-9.7400205E8f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.39007114483395d) + "'", double1 == (-21.39007114483395d));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37357877856093286d, number1, 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (null >= 0.374)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (null >= 0.374)"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray18);
        double[] doubleArray29 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = null;
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray29);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 974002049 + "'", int20 == 974002049);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.4142135623730951d + "'", double30 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 974002049 + "'", int31 == 974002049);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.4142135623730951d + "'", double32 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.673384180274023E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1046941005982506E-4d + "'", double1 == 2.1046941005982506E-4d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        double double2 = org.apache.commons.math.util.FastMath.min((-797.1802070118957d), 5.2346375811527619E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-797.1802070118957d) + "'", double2 == (-797.1802070118957d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        double double1 = org.apache.commons.math.util.FastMath.abs(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1000602687), 1694164083L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1695185133668691021L) + "'", long2 == (-1695185133668691021L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 35L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int16 = nonMonotonousSequenceException15.getIndex();
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean19 = nonMonotonousSequenceException8.getStrict();
        int int20 = nonMonotonousSequenceException8.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-101L) + "'", number17.equals((-101L)));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 100 + "'", int20 == 100);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.000602688E9d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1000602688L) + "'", long1 == (-1000602688L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        double double2 = org.apache.commons.math.util.FastMath.min(3.16227766016838d, 1.762747174039086d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.762747174039086d + "'", double2 == 1.762747174039086d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1182127744);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.072664410146427d + "'", double1 == 9.072664410146427d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1694164224));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.694164224E9d) + "'", double1 == (-1.694164224E9d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1085544065, (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.694164183E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.694164183E9d + "'", double1 == 1.694164183E9d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1694164183, (long) 974002049);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1694164183L + "'", long2 == 1694164183L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1925533408L, (long) (-204));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1925533204L + "'", long2 == 1925533204L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.565119738485518E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.00000000215504d + "'", double1 == 1.00000000215504d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 2.534694904308355E-89d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        long long1 = org.apache.commons.math.util.FastMath.abs(1760676956L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1760676956L + "'", long1 == 1760676956L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.40356321578642596d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39408842595596894d) + "'", double1 == (-0.39408842595596894d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        long long1 = org.apache.commons.math.util.MathUtils.sign(172L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(172L, (long) 1435984768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 4.524244356327114E15d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8623188722876839d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 516L, (-506605058));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) '#');
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2599210498948732d, 1009.2655867757023d, 99);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        int int1 = org.apache.commons.math.util.FastMath.abs(1563286272);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1563286272 + "'", int1 == 1563286272);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(100L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 197L + "'", long2 == 197L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-172L), (float) (-131385940));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.31385936E8f) + "'", float2 == (-1.31385936E8f));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1102230246251565E-16d, (double) 1552941056);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.149163970748653E-26d + "'", double2 == 7.149163970748653E-26d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int11 = nonMonotonousSequenceException10.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number15 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 974002049 + "'", number15.equals(974002049));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        int int2 = org.apache.commons.math.util.FastMath.max(506605058, 1085543041);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085543041 + "'", int2 == 1085543041);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 204L, 1694164183);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1066819584), 506605058);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.15051499783199063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.623874129193798d + "'", double1 == 8.623874129193798d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test277");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test278");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 5044);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test279");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 5.288241522117258d, 35, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 5.288241522117258d + "'", number6.equals(5.288241522117258d));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test280");
        int int2 = org.apache.commons.math.util.FastMath.max(9, 37);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 37 + "'", int2 == 37);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test281");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1694164182, (-1085544065));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test282");
        long long2 = org.apache.commons.math.util.FastMath.min(125994627894135L, (long) 310);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310L + "'", long2 == 310L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test283");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 10100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test284");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.760676956E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test285");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test286");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test287");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray20 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 974002048);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 974002048);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray23);
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray66 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray74 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 974002048);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray52);
        double double80 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray52);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4142135623730951d + "'", double6 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 974002049 + "'", int7 == 974002049);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.6881171418161356E43d + "'", double21 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1760676956 + "'", int24 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.4142135623730951d + "'", double30 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.6881171418161356E43d + "'", double38 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1760676956 + "'", int41 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1000602687) + "'", int47 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.4142135623730951d + "'", double67 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 2.6881171418161356E43d + "'", double75 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 9.0d + "'", double79 == 9.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test288");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 73287569);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.3287568E7f + "'", float1 == 7.3287568E7f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test289");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        boolean boolean13 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-101L) + "'", number5.equals((-101L)));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test290");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 34620618922968L, 31, (-1694164224));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test291");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 516L, 1.31385936E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.31385936E8f + "'", float2 == 1.31385936E8f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test292");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 8094831265704971301L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test293");
        double double1 = org.apache.commons.math.util.FastMath.exp(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test294");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 197L, 9.99997885478613d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 196.99999999999997d + "'", double2 == 196.99999999999997d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test295");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test296");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test297");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-204.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test298");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.1808787385219026E67d, (double) 974002048L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test299");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1563286291, 1085543041, (-2059546114));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test300");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1881312269, (float) 17310309456475L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.73103099E13f + "'", float2 == 1.73103099E13f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test301");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6483608274590866d, 1085543041);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.916215548148946E192d + "'", double2 == 5.916215548148946E192d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test302");
        long long2 = org.apache.commons.math.util.FastMath.min((-974002048L), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-974002048L) + "'", long2 == (-974002048L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test303");
        double double1 = org.apache.commons.math.util.FastMath.sin(5557.690612768986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21159690074834392d) + "'", double1 == (-0.21159690074834392d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test304");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3007L, (double) 34620618922969L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4620618922969E13d + "'", double2 == 3.4620618922969E13d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test305");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.2439418679995021E11d, 0.015572818255850327d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.243941867999502E11d + "'", double2 == 1.243941867999502E11d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test306");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1760676966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test307");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-131385937), (long) (-2059546114));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test308");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1760676956);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test309");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) -1, 1563286291);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1563286290 + "'", int2 == 1563286290);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test310");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 32, 1881312269);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test311");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1760676966, 311);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test312");
        double double1 = org.apache.commons.math.util.FastMath.asin((-172.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test313");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray29);
        double[] doubleArray33 = new double[] { (byte) 10, 0.0d };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray39 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray46 = new double[] { (byte) 10, 0.0d };
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray46);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1000602687) + "'", int34 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.4142135623730951d + "'", double40 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1000602687) + "'", int47 == (-1000602687));
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1000602687) + "'", int48 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test314");
        double double1 = org.apache.commons.math.util.FastMath.log(2.08281907607655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7337223011260774d + "'", double1 == 0.7337223011260774d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test315");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-131385630));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test316");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.951243718581428d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.951243718581428d + "'", double1 == 3.951243718581428d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test317");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 204L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.886765316883336d + "'", double1 == 5.886765316883336d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test318");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        double[] doubleArray28 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray36 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 974002048);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 0.6275174755083712d);
        double[] doubleArray47 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray55 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray47, doubleArray55);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 974002048);
        double[] doubleArray63 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray71 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray71);
        double[] doubleArray78 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double[] doubleArray86 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray86);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray86, (double) 974002048);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray71, doubleArray86);
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray86);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray86);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray86);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.4142135623730951d + "'", double29 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.6881171418161356E43d + "'", double37 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1760676956 + "'", int40 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.4142135623730951d + "'", double48 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 2.6881171418161356E43d + "'", double56 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.4142135623730951d + "'", double64 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 2.6881171418161356E43d + "'", double72 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.6881171418161356E43d + "'", double73 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.4142135623730951d + "'", double79 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 2.6881171418161356E43d + "'", double87 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.6881171418161356E43d + "'", double91 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 2.6881171418161356E43d + "'", double93 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test319");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1925533408L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9627667040L + "'", long2 == 9627667040L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test320");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 73287569, (long) 1033);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1033L + "'", long2 == 1033L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test321");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 9, (-204), 2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test322");
        double double1 = org.apache.commons.math.util.FastMath.log(1.085543041E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.805346197348687d + "'", double1 == 20.805346197348687d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test323");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-6823928892563009503L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test324");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1563286272, 1085544065);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test325");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1925533311), (double) (-44563605345380515L), (double) 1.31385936E8f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test326");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10, 0.0d };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray12);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 974002048);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray20);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        java.lang.Class<?> wildcardClass62 = doubleArray52.getClass();
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1000602687) + "'", int7 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 974002049 + "'", int63 == 974002049);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test327");
        double double2 = org.apache.commons.math.util.FastMath.min(4.679255112799385d, (double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test328");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test329");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (long) 257);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-70098847) + "'", int2 == (-70098847));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test330");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, 5044);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test331");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1313859370L), 3149206527444455424L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test332");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        java.lang.Throwable[] throwableArray29 = nonMonotonousSequenceException8.getSuppressed();
        int int30 = nonMonotonousSequenceException8.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test333");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(6.720292854540327E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test334");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(6.346863764025602E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test335");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1), 1076101120);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test336");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.309629469947388E-6d), (-1.5707963258311899d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.141591819853778d) + "'", double2 == (-3.141591819853778d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test337");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1085544065, 132);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1188488703) + "'", int2 == (-1188488703));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test338");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1694164183, (-1085544065));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test339");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 10);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray36);
        double[] doubleArray41 = new double[] { (byte) 10, 0.0d };
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray47 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 10);
        double[] doubleArray56 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray60 = null;
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray56, doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray56);
        double[] doubleArray65 = new double[] { (byte) 10, 0.0d };
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double[] doubleArray71 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray71);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 10);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray41);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 9.74002048E8d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1000602687) + "'", int27 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4142135623730951d + "'", double33 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1000602687) + "'", int42 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.4142135623730951d + "'", double48 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.4142135623730951d + "'", double57 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 974002049 + "'", int58 == 974002049);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.4142135623730951d + "'", double59 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1000602687) + "'", int66 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.4142135623730951d + "'", double72 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 10.0d + "'", double76 == 10.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test340");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 2.0d, (int) (byte) 100);
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 5.288241522117258d, 35, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean13 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.0d + "'", number11.equals(2.0d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.0d + "'", number12.equals(2.0d));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test341");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.5440618722340037d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test342");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3348802.852664884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3348803.0d + "'", double1 == 3348803.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test343");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1694164182));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.69416422E9f + "'", float1 == 1.69416422E9f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test344");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray13);
        double[] doubleArray19 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray27 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray27);
        double[] doubleArray33 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 974002048);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 9700);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.6881171418161356E43d + "'", double28 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.4142135623730951d + "'", double34 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.6881171418161356E43d + "'", double42 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test345");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-70098847), 1.3237787393690108d, 3.673384180274023E-6d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test346");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.201575293031599E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2015752930316E13d + "'", double1 == 2.2015752930316E13d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test347");
        long long2 = org.apache.commons.math.util.FastMath.min(1552941056L, (long) 1313859328);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1313859328L + "'", long2 == 1313859328L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test348");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(17310309456475L, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17310309456465L + "'", long2 == 17310309456465L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test349");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-2L), 158625578809472060L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 158625578809472060L + "'", long2 == 158625578809472060L);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test350");
        double double2 = org.apache.commons.math.util.FastMath.pow(204.0d, (-0.7853981633974482d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.015346901593765894d + "'", double2 == 0.015346901593765894d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test351");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection12, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 34620618912878L, number1, (int) (byte) -1, orderDirection12, false);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test352");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-622554214), 1552941056);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test353");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-131385940));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 131385940L + "'", long1 == 131385940L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test354");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(9.223372036854776E18d, (double) 9700, (double) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test355");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 204.0d + "'", number6.equals(204.0d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 10 + "'", number8.equals((byte) 10));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test356");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(100.0f, 32, 974001845);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test357");
        double double1 = org.apache.commons.math.util.FastMath.tan(11784.198666665105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08482562700503567d + "'", double1 == 0.08482562700503567d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test358");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (byte) 0, 100, 0 };
        int[] intArray9 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray9);
        int[] intArray14 = new int[] { (byte) 0, 100, 0 };
        int[] intArray19 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray19);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray39);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray29);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray29);
        int[] intArray47 = new int[] { (-205), (short) -1, 1 };
        int[] intArray51 = new int[] { (byte) 0, 100, 0 };
        int[] intArray56 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray51, intArray56);
        int[] intArray61 = new int[] { (byte) 0, 100, 0 };
        int[] intArray66 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray66);
        int[] intArray71 = new int[] { (byte) 0, 100, 0 };
        int[] intArray76 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray76);
        int[] intArray81 = new int[] { (byte) 0, 100, 0 };
        int[] intArray86 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int87 = org.apache.commons.math.util.MathUtils.distance1(intArray81, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray86);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray76);
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray51, intArray76);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray47, intArray76);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray76);
        try {
            int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 152 + "'", int10 == 152);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 152 + "'", int20 == 152);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 99 + "'", int42 == 99);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 111.83022847155415d + "'", double43 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 152 + "'", int57 == 152);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 152 + "'", int67 == 152);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 152 + "'", int77 == 152);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 152 + "'", int87 == 152);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 99 + "'", int89 == 99);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 111.83022847155415d + "'", double90 == 111.83022847155415d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 257 + "'", int91 == 257);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test359");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray29);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray49 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray57 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray57);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 974002048);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 9700);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray76 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray76);
        double[] doubleArray82 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray82);
        double[] doubleArray90 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray82, doubleArray90);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, (double) 974002048);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray93);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray93, (double) 9700);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray96);
        java.lang.Class<?> wildcardClass98 = doubleArray63.getClass();
        double double99 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4142135623730951d + "'", double50 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.6881171418161356E43d + "'", double58 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 2.6881171418161356E43d + "'", double77 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.4142135623730951d + "'", double83 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.6881171418161356E43d + "'", double91 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertNotNull(wildcardClass98);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 9.739923480000001E8d + "'", double99 == 9.739923480000001E8d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test360");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1076101120, 17310309456475L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test361");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 31L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.441695568020698d) + "'", double1 == (-0.441695568020698d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test362");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(497145975311605302L, 1694164183L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 497145977005769485L + "'", long2 == 497145977005769485L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test363");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(204.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9726239996384714E88d + "'", double1 == 1.9726239996384714E88d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test364");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-44563605345380446L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test365");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 4.4563606E16f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4563605705719808E16d + "'", double1 == 4.4563605705719808E16d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test366");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.896296018267969E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.69314718055993d + "'", double1 == 32.69314718055993d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test367");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray43);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number52 = nonMonotonousSequenceException51.getPrevious();
        java.lang.Throwable[] throwableArray53 = nonMonotonousSequenceException51.getSuppressed();
        boolean boolean54 = nonMonotonousSequenceException51.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int59 = nonMonotonousSequenceException58.getIndex();
        java.lang.Number number60 = nonMonotonousSequenceException58.getArgument();
        nonMonotonousSequenceException51.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = nonMonotonousSequenceException51.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection62, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= -101)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 974002049 + "'", number52.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 100 + "'", int59 == 100);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (-101L) + "'", number60.equals((-101L)));
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test368");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-44563605345380515L), 1768575524, (-205));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test369");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test370");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 2758547353515625L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test371");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(10.864073558457564d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test372");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray16 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray20 = null;
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray20);
        double[] doubleArray26 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double[] doubleArray34 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray34);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 974002048);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray43 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray51 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 974002048);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray16);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1000602687) + "'", int11 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.4142135623730951d + "'", double17 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 974002049 + "'", int18 == 974002049);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.4142135623730951d + "'", double27 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1760676956 + "'", int38 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.6881171418161356E43d + "'", double52 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1760676956 + "'", int55 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test373");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray29);
        double[] doubleArray33 = new double[] { (byte) 10, 0.0d };
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray43 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray43);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray43);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1000602687) + "'", int34 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1000602687) + "'", int38 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test374");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.6881171418161356E43d, (java.lang.Number) 2.8544953854119198E45d, 87);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-205.0f), (java.lang.Number) 2.2621221781635855E15d, (-205), orderDirection13, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number18 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 10 + "'", number18.equals((byte) 10));
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test375");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1085544065));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1085544065 + "'", int1 == 1085544065);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test376");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-20500));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20501.0d) + "'", double1 == (-20501.0d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test377");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1768575524, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test378");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-100L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test379");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.524244356327114E15d, (java.lang.Number) (-1000602687), 123);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 122 and 123 are not strictly increasing (-1,000,602,687 >= 4,524,244,356,327,114)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 122 and 123 are not strictly increasing (-1,000,602,687 >= 4,524,244,356,327,114)"));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test380");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int17 = nonMonotonousSequenceException16.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException16.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number7, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection18, true);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException22.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 3.9512437185814275d + "'", number23.equals(3.9512437185814275d));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test381");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.760676956E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test382");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.05424317840547E111d, 96);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.627539123825275E140d + "'", double2 == 1.627539123825275E140d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test383");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.1635067818046204E61d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1635067818046206E61d + "'", double1 == 2.1635067818046206E61d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test384");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.3877787807814457E-17d, 5.9718699132790505d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179586d + "'", double2 == 6.283185307179586d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test385");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test386");
        long long1 = org.apache.commons.math.util.FastMath.abs(1085543041L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1085543041L + "'", long1 == 1085543041L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test387");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1563286291);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test388");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 9.7400205E8f, (-0.06199777340989434d), 13.228920847762078d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test389");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.332621544395465E155d, (double) 974002048L, (-0.9251475365964192d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test390");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707284151509546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027414382499016544d + "'", double1 == 0.027414382499016544d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test391");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(2171088130L, 1725920059392L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1723748971262L) + "'", long2 == (-1723748971262L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test392");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.2816256531990586E-156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test393");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 5.2346375811527619E18d, 0.7141664558621691d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test394");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1563278439L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test395");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-131385973L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test396");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(13.539334827618724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.539334827618726d + "'", double1 == 13.539334827618726d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test397");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.441695568020698d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1022903103) + "'", int1 == (-1022903103));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test398");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 2.0d, (int) (byte) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test399");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.6275174755083712d);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray49);
        double[] doubleArray53 = new double[] { (byte) 10, 0.0d };
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double[] doubleArray59 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray59);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 10);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray68);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray68);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1760676956 + "'", int47 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1000602687) + "'", int54 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 1.4142135623730951d + "'", double60 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 974002049 + "'", int70 == 974002049);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.4142135623730951d + "'", double71 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 73287569 + "'", int76 == 73287569);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test400");
        double double1 = org.apache.commons.math.util.FastMath.log1p(11013.2329201034d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.306943617238495d + "'", double1 == 9.306943617238495d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test401");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 306.3653948445114d, (java.lang.Number) 1.3269398314827012d, 52, orderDirection7, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int14 = nonMonotonousSequenceException13.getIndex();
        java.lang.Number number15 = nonMonotonousSequenceException13.getArgument();
        int int16 = nonMonotonousSequenceException13.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.String str21 = nonMonotonousSequenceException20.toString();
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-101L) + "'", number15.equals((-101L)));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)" + "'", str21.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)"));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test402");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.015572818255850338d, (double) 974002048, 1024.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test403");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test404");
        int int1 = org.apache.commons.math.util.FastMath.abs(642526);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 642526 + "'", int1 == 642526);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test405");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.679255112799385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test406");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0613084341780446E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0200321770504298E19d + "'", double1 == 1.0200321770504298E19d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test407");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1760676956, 974002049);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test408");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-20500));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-357.79249665883754d) + "'", double1 == (-357.79249665883754d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test409");
        int int2 = org.apache.commons.math.util.FastMath.max(1033, 1760696780);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760696780 + "'", int2 == 1760696780);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test410");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.345202208E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.76837158203125E-7d + "'", double1 == 4.76837158203125E-7d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test411");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1901415581956121743L), (double) 5234637581152761600L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test412");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3585963300614061d + "'", double1 == 1.3585963300614061d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test413");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1085518848, 1563286291);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test414");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test415");
        double double2 = org.apache.commons.math.util.FastMath.min(7.57235190491251E-6d, 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.57235190491251E-6d + "'", double2 == 7.57235190491251E-6d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test416");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3132616875182228d, (java.lang.Number) 1.9877735581754346d, 1694164183);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,694,164,182 and 1,694,164,183 are not strictly increasing (1.988 >= 1.313)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,694,164,182 and 1,694,164,183 are not strictly increasing (1.988 >= 1.313)"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test417");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 1, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test418");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.6420149920119999d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 967048662 + "'", int1 == 967048662);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test419");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.810477378749653d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test420");
        double double1 = org.apache.commons.math.util.MathUtils.sign(9.74002048E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test421");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-131385630));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.31385631E8d) + "'", double1 == (-1.31385631E8d));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test422");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1374707211L), (long) 506605056);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6042911806178859007L) + "'", long2 == (-6042911806178859007L));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test423");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1076101120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.07610112E9d + "'", double1 == 1.07610112E9d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test424");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.9512437185814275d, (java.lang.Number) 0.8744856511179626d, (int) (byte) 0, orderDirection3, true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test425");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 152, 196.99999999999997d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test426");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6783606624401571d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test427");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 418509424, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test428");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 9700);
        double[] doubleArray37 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray39 = null;
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray39);
        double[] doubleArray45 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray54 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray62 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray54, doubleArray62);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = null;
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray68, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray68);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray54);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray54);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.4142135623730951d + "'", double38 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.4142135623730951d + "'", double46 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 974002049 + "'", int47 == 974002049);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.4142135623730951d + "'", double48 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.4142135623730951d + "'", double49 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.4142135623730951d + "'", double55 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.6881171418161356E43d + "'", double63 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 974002049 + "'", int70 == 974002049);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.4142135623730951d + "'", double71 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + true + "'", boolean74 == true);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test429");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 0, 9.223372036854778E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.223372036854778E18d + "'", double2 == 9.223372036854778E18d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test430");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3348803.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1052144479) + "'", int1 == (-1052144479));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test431");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-6042911806178859007L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test432");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.3019272488946267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test433");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(21.863198261002008d, 37.00000000000001d, 2.477888730288475d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test434");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 1563278539);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 2);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 87);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test435");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        boolean boolean9 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int14 = nonMonotonousSequenceException13.getIndex();
        java.lang.Number number15 = nonMonotonousSequenceException13.getArgument();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 9.332621544395286E157d, (-1085544065), orderDirection17, false);
        java.lang.String str20 = nonMonotonousSequenceException19.toString();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 100 + "'", int14 == 100);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (-101L) + "'", number15.equals((-101L)));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,085,544,066 and -1,085,544,065 are not increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 > null)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,085,544,066 and -1,085,544,065 are not increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 > null)"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test436");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.16350678180462E61d, 20.655836722867562d, (double) 3629004L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test437");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.716462070079908d), (java.lang.Number) (-0.716462070079908d), (int) (short) 100, orderDirection8, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number15 = nonMonotonousSequenceException14.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException14.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number21 = nonMonotonousSequenceException14.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 974002049 + "'", number15.equals(974002049));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (-101L) + "'", number21.equals((-101L)));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test438");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test439");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-20500));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test440");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(257, 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 344 + "'", int2 == 344);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test441");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-101L) + "'", number5.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 974002049 + "'", number6.equals(974002049));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test442");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, (long) 974002048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test443");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, 1066819584);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test444");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray16 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray24 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray24);
        double[] doubleArray30 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray38 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 974002048);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 9700);
        double[] doubleArray49 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray57 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray57);
        double[] doubleArray63 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray71 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 974002048);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 9700);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1000602687) + "'", int11 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.4142135623730951d + "'", double17 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.6881171418161356E43d + "'", double25 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.4142135623730951d + "'", double31 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 2.6881171418161356E43d + "'", double39 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4142135623730951d + "'", double50 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.6881171418161356E43d + "'", double58 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.4142135623730951d + "'", double64 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 2.6881171418161356E43d + "'", double72 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 9700.005154637805d + "'", double79 == 9700.005154637805d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test445");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(10, 506605058);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test446");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1925533311), (long) 1760676966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 646609153 + "'", int2 == 646609153);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test447");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray11 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray19 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 974002048);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray28 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray36 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 974002048);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray22);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.4142135623730951d + "'", double12 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.6881171418161356E43d + "'", double20 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1760676956 + "'", int23 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.4142135623730951d + "'", double29 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.6881171418161356E43d + "'", double37 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1760676956 + "'", int40 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.740020480000001E8d + "'", double43 == 9.740020480000001E8d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test448");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.309629469947388E-6d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3096294699473877E-6d) + "'", double1 == (-1.3096294699473877E-6d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test449");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-506605058), (-204));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test450");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        java.lang.String str8 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-3.46170327862784d), (-20500), orderDirection9, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test451");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-622554214), 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 622554214 + "'", int2 == 622554214);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test452");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.4786498617723036d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4993216308656763d + "'", double1 == 1.4993216308656763d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test453");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-52));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.053272382792838d + "'", double1 == 6.053272382792838d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test454");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray15 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 974002048);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray26);
        double[] doubleArray33 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray41 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 974002048);
        double[] doubleArray49 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray57 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray57);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray44);
        double[] doubleArray65 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray73 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) 974002048);
        double[] doubleArray81 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double double84 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray81);
        double[] doubleArray85 = null;
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray81, doubleArray85);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray81);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray73);
        double[] doubleArray89 = null;
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4142135623730951d + "'", double16 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.6881171418161356E43d + "'", double24 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1760676956 + "'", int27 == 1760676956);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 9.740020500000001E8d + "'", double28 == 9.740020500000001E8d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.4142135623730951d + "'", double34 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.6881171418161356E43d + "'", double42 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.4142135623730951d + "'", double50 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.6881171418161356E43d + "'", double58 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 2.6881171418161356E43d + "'", double59 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.4142135623730951d + "'", double66 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.6881171418161356E43d + "'", double74 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.4142135623730951d + "'", double82 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 974002049 + "'", int83 == 974002049);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 1.4142135623730951d + "'", double84 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 2.6881171418161356E43d + "'", double88 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test455");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-2059546114), 1.31385936E8d, 7.572351904912511E-6d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test456");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.0013235752181534359d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000000875925807d + "'", double1 == 1.000000875925807d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test457");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(9.223372036854778E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2097152.0d + "'", double1 == 2097152.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test458");
        double double1 = org.apache.commons.math.util.FastMath.tan(196.99999999999997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3141827972412692d) + "'", double1 == (-1.3141827972412692d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test459");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-44563605345380515L), 1760676966);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2569682771521993E-261d) + "'", double2 == (-1.2569682771521993E-261d));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test460");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1037659958), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test461");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray16 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray16);
        double[] doubleArray22 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray30 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 974002048);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray8);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 20.805346197348687d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.4142135623730951d + "'", double23 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 9.0d + "'", double35 == 9.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test462");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.31385936E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.693649626322983d + "'", double1 == 18.693649626322983d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test463");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-521357855), 2171088130L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1131913850472761150L) + "'", long2 == (-1131913850472761150L));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test464");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (short) 0, 0.0d, 6.34960155562218d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test465");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test466");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(974002048L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test467");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(125994627894135L, (long) 974002049);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test468");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.lang.Class<?> wildcardClass5 = bigInteger4.getClass();
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) 'a');
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 0);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 10);
        java.lang.Class<?> wildcardClass13 = bigInteger12.getClass();
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger12);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) 0);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 10);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 10);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger24);
        java.math.BigInteger bigInteger26 = null;
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 0);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 10);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 1563278539);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger32);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, bigInteger33);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (byte) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test469");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.868551121099462d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test470");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 0);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 10);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 1563278539);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger28);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger20);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (int) (byte) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test471");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray20 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 974002048);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray29 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray37 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 974002048);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray23);
        try {
            double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4142135623730951d + "'", double6 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 974002049 + "'", int7 == 974002049);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.6881171418161356E43d + "'", double21 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1760676956 + "'", int24 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.4142135623730951d + "'", double30 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.6881171418161356E43d + "'", double38 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1760676956 + "'", int41 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test472");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948823d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test473");
        double double2 = org.apache.commons.math.util.MathUtils.round(20.043242279690457d, 7752);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.043242279690457d + "'", double2 == 20.043242279690457d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test474");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1760696780, 1760676956);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test475");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.441695568020698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0991437556220036d + "'", double1 == 1.0991437556220036d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test476");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test477");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(152);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 615.061266207085d + "'", double1 == 615.061266207085d);
    }
}

