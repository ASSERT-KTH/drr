import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(310, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 311 + "'", int2 == 311);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 87);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.1635067818046204E61d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.651351181973492E30d + "'", double1 == 4.651351181973492E30d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.log(3.1415925016813464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1447298374954387d + "'", double1 == 1.1447298374954387d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 17310309456440L, 5.06605056E8f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.06605056E8f + "'", float2 == 5.06605056E8f);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.552941156E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1760676956);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.760676956E9d + "'", double1 == 1.760676956E9d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-205), (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-205.0f) + "'", float3 == (-205.0f));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1563278539);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.863198261002008d + "'", double1 == 21.863198261002008d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int1 = org.apache.commons.math.util.FastMath.abs(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int int1 = org.apache.commons.math.util.FastMath.abs(1410065408);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1410065408 + "'", int1 == 1410065408);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1552941056L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7814031344344955d) + "'", double1 == (-0.7814031344344955d));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-1925533311));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 10, 1760676956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760676966 + "'", int2 == 1760676966);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.acosh(9.740020500000001E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.390071146887333d + "'", double1 == 21.390071146887333d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-506605058));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1552941056L, 4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 974002048L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.8544953854119172E45d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 467396991);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double2 = org.apache.commons.math.util.FastMath.atan2(5557.690612768986d, 11013.026041820607d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.46735829884662616d + "'", double2 == 0.46735829884662616d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-204.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.534694904308355E-89d + "'", double1 == 2.534694904308355E-89d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 204, (double) 974002049, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double2 = org.apache.commons.math.util.FastMath.min(363.7393755555636d, (double) (-172L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-172.0d) + "'", double2 == (-172.0d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1760676956L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.6783606624401571d, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.atanh(88.03440747059399d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 974002049);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 974002049L + "'", long1 == 974002049L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1694164083), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) 'a', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.725290298461914E-9d, 9.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1760676966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-506605058), 974002048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int16 = nonMonotonousSequenceException15.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 100 + "'", int16 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection9, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection9, true);
        java.lang.Class<?> wildcardClass16 = nonMonotonousSequenceException15.getClass();
        java.lang.Number number17 = nonMonotonousSequenceException15.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (-203.99999999999997d) + "'", number17.equals((-203.99999999999997d)));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(37L, 37L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 37L + "'", long2 == 37L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1552941056L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.85656360602665d + "'", double1 == 21.85656360602665d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1313859370L), (-1000602687));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.asin((-82.45803655637981d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0000000000000002d, 0.0d, 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1760676966, (float) 6L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 6.0f + "'", float2 == 6.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = nonMonotonousSequenceException8.getArgument();
        int int11 = nonMonotonousSequenceException8.getIndex();
        boolean boolean12 = nonMonotonousSequenceException8.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-101L) + "'", number10.equals((-101L)));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 467396991);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.655836722867562d + "'", double1 == 20.655836722867562d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number10 = nonMonotonousSequenceException8.getArgument();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.String str12 = nonMonotonousSequenceException8.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-101L) + "'", number10.equals((-101L)));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.apache.commons.math.util.FastMath.max((-2L), (long) 257);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 257L + "'", long2 == 257L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1694164083));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1694164083L + "'", long1 == 1694164083L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.896296018267969E13d, (java.lang.Number) 6.565119738485518E-5d, 99, orderDirection8, false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1694164182), (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        java.lang.Class<?> wildcardClass30 = orderDirection29.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 9, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 311, 0.0d, 1.2666779012127305d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.sin((-6.805422216363571E242d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0758352738682991d) + "'", double1 == (-0.0758352738682991d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(87, 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(132059.36709719698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2304.870763945954d + "'", double1 == 2304.870763945954d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.6275174755083712d, (-204), 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E204d + "'", double3 == 1.0E204d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(97, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1552941056, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(31);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) 1313859370L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.31385933E9f + "'", float2 == 1.31385933E9f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(132059.36709719698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.3997345860299d + "'", double1 == 363.3997345860299d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.08281907607655d + "'", double1 == 2.08281907607655d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-205), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-205.0f) + "'", float2 == (-205.0f));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        double[] doubleArray38 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray46 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 974002048);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray49);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (974,002,048 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.4142135623730951d + "'", double39 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.6881171418161356E43d + "'", double47 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8834864931005E-310d + "'", double1 == 3.8834864931005E-310d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        long long2 = org.apache.commons.math.util.MathUtils.pow(37L, 257);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8094831265704971301L + "'", long2 == 8094831265704971301L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray43);
        double[] doubleArray52 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray60 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, (double) 974002048);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray76 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray76);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection83 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException85 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection83, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray76, orderDirection83, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= -101)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.4142135623730951d + "'", double53 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 2.6881171418161356E43d + "'", double77 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + true + "'", boolean79 == true);
        org.junit.Assert.assertTrue("'" + orderDirection83 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection83.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        long long1 = org.apache.commons.math.util.FastMath.round(0.40356321578642596d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.FastMath.atan((-2.968123235826276E-35d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.968123235826276E-35d) + "'", double1 == (-2.968123235826276E-35d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(5044);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.223626578289051E21d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9941809498881117d + "'", double1 == 0.9941809498881117d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) 10, 0.0d };
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray12 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray12);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray12);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 974002048);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray20);
        double[] doubleArray48 = null;
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1000602687) + "'", int7 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4142135623730951d + "'", double13 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double1 = org.apache.commons.math.util.FastMath.ulp(8.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(10, (-1037659958));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        int int1 = org.apache.commons.math.util.MathUtils.hash(31.41592653589793d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1768575524 + "'", int1 == 1768575524);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 5044, (-44563605345380415L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44563605345385459L + "'", long2 == 44563605345385459L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.FastMath.min(5.717016880593469d, 5044.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.717016880593469d + "'", double2 == 5.717016880593469d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) '#', (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 53.84955592153876d + "'", double2 == 53.84955592153876d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1182127744, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.223372036854776E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 257);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.05424317840547E111d + "'", double1 == 2.05424317840547E111d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-131385937), 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-131385973L) + "'", long2 == (-131385973L));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.5996388013001026d, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5996388013001026d + "'", double2 == 1.5996388013001026d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1037659958));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number10 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) (-1.7463811409905557E7d), (int) (short) 0, orderDirection11, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.026041820607d, (java.lang.Number) 0.6440288952968115d, 1552941056, orderDirection11, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 974002049 + "'", number10.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.6440288952968115d + "'", number16.equals(0.6440288952968115d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1694164083));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.570796326204635d) + "'", double1 == (-1.570796326204635d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0038848218538872d, (-1.2982325897788716d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1694164083));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19849053248497409d + "'", double1 == 0.19849053248497409d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int2 = org.apache.commons.math.util.MathUtils.pow(52, 1563278539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-101L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.05424317840547E111d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 257L, 9);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 257.0f + "'", float2 == 257.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-506605058), 1552941056);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2059546114) + "'", int2 == (-2059546114));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.477888730288475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7877158799310174d) + "'", double1 == (-0.7877158799310174d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.7253825588523148d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 974002048, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 974002048L + "'", long2 == 974002048L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        long long1 = org.apache.commons.math.util.FastMath.abs(6L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.45593812776599624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1057528913188142d + "'", double1 == 1.1057528913188142d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.9846263768078726d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int int1 = org.apache.commons.math.util.MathUtils.sign(204);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.tan(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4830062883006265d + "'", double1 == 2.4830062883006265d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 'a', 467396991);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6823928891127024735L) + "'", long2 == (-6823928891127024735L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (-1.00060269E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.00060269E9f) + "'", float2 == (-1.00060269E9f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 204, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-205), 44563605345385459L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 44563605345385459L, 1.9877735581754346d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017921032008744623d + "'", double2 == 0.017921032008744623d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int2 = org.apache.commons.math.util.FastMath.max(1694164183, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1694164183 + "'", int2 == 1694164183);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.1073424338879928E-8d, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 0.6275174755083712d);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray49);
        double[] doubleArray55 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        double[] doubleArray63 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray55, doubleArray63);
        double[] doubleArray69 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray69);
        double[] doubleArray77 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 974002048);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray55, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray80);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1760676956 + "'", int47 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.4142135623730951d + "'", double56 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.4142135623730951d + "'", double70 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 9.740020473724827E8d + "'", double82 == 9.740020473724827E8d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.6275174755083712d + "'", double83 == 0.6275174755083712d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 257, (long) 974002048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 257L + "'", long2 == 257L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-131385937), (float) 974002048);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.7400205E8f + "'", float2 == 9.7400205E8f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.log10(9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.964889726830815d + "'", double1 == 18.964889726830815d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-2059546114), 10100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(100.0d, 3.982441812995697E30d, (double) 36.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) -1, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long2 = org.apache.commons.math.util.FastMath.min(204L, 974002049L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 204L + "'", long2 == 204L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double2 = org.apache.commons.math.util.FastMath.pow(132059.36709719698d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.57235190491251E-6d + "'", double2 == 7.57235190491251E-6d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2059546114), 974002049);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1085544065) + "'", int2 == (-1085544065));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 257L, (float) 99);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.0f + "'", float2 == 99.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 1760676966);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5044.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1085518848 + "'", int1 == 1085518848);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) '#');
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger23);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 1);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (-6823928891127024735L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 4.651351181973492E30d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5606956602095747d + "'", double1 == 1.5606956602095747d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.7615941559557649d, 1.4524424832623713E13d, (double) (-205.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-44563605345380415L), (long) 31);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44563605345380446L) + "'", long2 == (-44563605345380446L));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int1 = org.apache.commons.math.util.MathUtils.hash(20.655836722867562d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1435984768) + "'", int1 == (-1435984768));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double2 = org.apache.commons.math.util.FastMath.max(5.9718699132790505d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.9718699132790505d + "'", double2 == 5.9718699132790505d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        long long2 = org.apache.commons.math.util.FastMath.max(44563605345385459L, (-131385973L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44563605345385459L + "'", long2 == 44563605345385459L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.5440618722340037d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int9 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        boolean boolean12 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 100 + "'", int9 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-101L) + "'", number13.equals((-101L)));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) -1, (-1037659958));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2, 311);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 622 + "'", int2 == 622);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-205.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(52.0d, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 31.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9048849665247426E13d + "'", double1 == 2.9048849665247426E13d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double2 = org.apache.commons.math.util.FastMath.max(4.524244356327114E15d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.524244356327114E15d + "'", double2 == 4.524244356327114E15d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double2 = org.apache.commons.math.util.FastMath.atan2(52.0d, 4.651351181973492E30d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1179547182231304E-29d + "'", double2 == 1.1179547182231304E-29d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.FastMath.acos(50.33529562751647d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 35, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1563278539);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 760074269L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.14168768474935d + "'", double1 == 2.14168768474935d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1410065408, 1.760676956E9d, (double) (-1435984768));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 99.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 310, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310L + "'", long2 == 310L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double1 = org.apache.commons.math.util.FastMath.sinh(21.390071146887333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.740020500000011E8d + "'", double1 == 9.740020500000011E8d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.015572818255850338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.015573447697767695d + "'", double1 == 0.015573447697767695d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1, 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.Number number3 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 5.288241522117258d, 35, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0f, (java.lang.Number) 42901.69723267129d, (int) (short) 100, orderDirection6, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (42,901.697 > 1)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (42,901.697 > 1)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.0f + "'", number12.equals(1.0f));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 10.864073558457564d, 4.524244356327114E15d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 0, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094495E67d + "'", double1 == 8.065817517094495E67d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-506605058));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-797.1802070118957d) + "'", double1 == (-797.1802070118957d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-102400.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.201575293031599E13d, (double) 31L, 311);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.534694904308355E-89d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100.0f, 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0842021724855044E-17d + "'", double2 == 1.0842021724855044E-17d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(4L, 17310309456475L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-17310309456471L) + "'", long2 == (-17310309456471L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.log1p(31.41592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4786498617723036d + "'", double1 == 3.4786498617723036d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        try {
            double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 1.505149978319906d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 257, (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.3877787807814457E-17d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.7853981633974483d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-205.0f), (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-205.0d) + "'", double2 == (-205.0d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.524244356327114E15d, 1.5395564933646284d, 2.1073424338879928E-8d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-6823928891127024735L), (long) (-1435984768));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6823928892563009503L) + "'", long2 == (-6823928892563009503L));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292447995462d + "'", double1 == 0.017453292447995462d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray43);
        double[] doubleArray50 = new double[] { (byte) 10, 0.0d };
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray54 = new double[] { (byte) 10, 0.0d };
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray60 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray50, doubleArray60);
        double[] doubleArray66 = new double[] { (byte) 10, 0.0d };
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray72 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 10);
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray82 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray82);
        double[] doubleArray90 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray82, doubleArray90);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray90, (double) 974002048);
        int int94 = org.apache.commons.math.util.MathUtils.hash(doubleArray93);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray93, 0.6275174755083712d);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray93);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray76);
        try {
            double double99 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1000602687) + "'", int51 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1000602687) + "'", int55 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.4142135623730951d + "'", double61 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1000602687) + "'", int67 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.4142135623730951d + "'", double73 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 10.0d + "'", double77 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.4142135623730951d + "'", double83 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.6881171418161356E43d + "'", double91 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1760676956 + "'", int94 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        double[] doubleArray20 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray28 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray28);
        double[] doubleArray35 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray43 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray35, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 974002048);
        double[] doubleArray51 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray59 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray59);
        double[] doubleArray66 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double[] doubleArray74 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray74);
        double[] doubleArray77 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 974002048);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray74);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray74);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.4142135623730951d + "'", double21 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.4142135623730951d + "'", double36 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.4142135623730951d + "'", double52 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.4142135623730951d + "'", double67 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 2.6881171418161356E43d + "'", double75 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 2.6881171418161356E43d + "'", double79 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1760676956 + "'", int80 == 1760676956);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int int2 = org.apache.commons.math.util.FastMath.max((-1085544065), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 974002048L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 97, 10100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        int int7 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        try {
            double double8 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4142135623730951d + "'", double6 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 974002049 + "'", int7 == 974002049);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection8, true);
        boolean boolean11 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1552941056L, 2.477888730288475d, (-1.7463811409905557E7d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        long long2 = org.apache.commons.math.util.FastMath.min((-44563605345380446L), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44563605345380446L) + "'", long2 == (-44563605345380446L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.FastMath.sin(42901.69723267129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10774568011245209d + "'", double1 == 0.10774568011245209d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1694164183, 1.371184979049348E80d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.694164183E9d + "'", double2 == 1.694164183E9d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.23774391214507304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.23774391214507304d + "'", double1 == 0.23774391214507304d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-100L), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1694164182));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1694164182 + "'", int1 == 1694164182);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-44563605345380515L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 36L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = null;
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray13);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        float float1 = org.apache.commons.math.util.MathUtils.sign(97.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        double[] doubleArray51 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray59 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray59);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 974002048);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray76 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray76);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) 974002048);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray79);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray62);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection86 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection86, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection86, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (974,002,048 >= -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.4142135623730951d + "'", double52 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1760676956 + "'", int63 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 2.6881171418161356E43d + "'", double77 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1760676956 + "'", int80 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 2.6881171418161356E43d + "'", double82 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + orderDirection86 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection86.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, (long) (-1925533311));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1925533408L + "'", long2 == 1925533408L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (double) 4L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.util.FastMath.exp(631011.7625152355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3237787393690108d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7575935506050455d + "'", double1 == 3.7575935506050455d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        java.lang.Class<?> wildcardClass9 = orderDirection8.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) 5624L, (-506605058), orderDirection8, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -506,605,059 and -506,605,058 are not increasing (5,624 > 97)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -506,605,059 and -506,605,058 are not increasing (5,624 > 97)"));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1556157735575975E15d + "'", double1 == 2.1556157735575975E15d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.tan(105.35837144511169d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.655952316688715d) + "'", double1 == (-8.655952316688715d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-44563605345380415L), (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.4563605345380416E16d) + "'", double2 == (-4.4563605345380416E16d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1024, (-1037659958));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 0L, 1760676956);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(204L, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1224L + "'", long2 == 1224L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        long long1 = org.apache.commons.math.util.FastMath.abs(10100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10100L + "'", long1 == 10100L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, (long) 974002048);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-974002048L) + "'", long2 == (-974002048L));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-101L) + "'", number12.equals((-101L)));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(31L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(204, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19788 + "'", int2 == 19788);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 974002079L, (-0.9251475365964192d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.833435927100678E-9d + "'", double2 == 4.833435927100678E-9d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 96);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 204, 974002048L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 974002048L + "'", long2 == 974002048L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 9.740020500000001E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.740020500000001E8d + "'", double2 == 9.740020500000001E8d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611504d + "'", double1 == 81.55795945611504d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1024);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1024L + "'", long1 == 1024L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5606956602095747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.227966323305175d + "'", double1 == 1.227966323305175d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        int int2 = org.apache.commons.math.util.FastMath.max((-506605058), 1768575524);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1768575524 + "'", int2 == 1768575524);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.69349861963412d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.46364255723321d + "'", double1 == 148.46364255723321d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-6823928891127024735L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0842021724855044E-17d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.764725154011207d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8744856511179626d + "'", double1 == 0.8744856511179626d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray28);
        int[] intArray46 = new int[] { (byte) 0, 100, 0 };
        int[] intArray51 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray66 = new int[] { (byte) 0, 100, 0 };
        int[] intArray71 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray71);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray61);
        int[] intArray78 = new int[] { (byte) 0, 100, 0 };
        int[] intArray83 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray83);
        int[] intArray88 = new int[] { (byte) 0, 100, 0 };
        int[] intArray93 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray93);
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray83, intArray93);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray83);
        double double97 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray83);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 111.83022847155415d + "'", double42 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 152 + "'", int52 == 152);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 152 + "'", int72 == 152);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 99 + "'", int74 == 99);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 152 + "'", int84 == 152);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 152 + "'", int94 == 152);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 111.83022847155415d + "'", double97 == 111.83022847155415d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 64.01562118716426d + "'", double1 == 64.01562118716426d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 10 + "'", number5.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5044 + "'", int6 == 5044);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1085544065));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085544065 + "'", int2 == 1085544065);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.003761536530132509d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0037615454006175186d + "'", double1 == 0.0037615454006175186d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(34620618912878L, 10090L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34620618922968L + "'", long2 == 34620618922968L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1925533311));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        int int1 = org.apache.commons.math.util.FastMath.abs(257);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 257 + "'", int1 == 257);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number5 = nonMonotonousSequenceException4.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException4.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str11 = nonMonotonousSequenceException9.toString();
        java.lang.Number number12 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int17 = nonMonotonousSequenceException16.getIndex();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean20 = nonMonotonousSequenceException9.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException9.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection21, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 974002049 + "'", number5.equals(974002049));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 974002049 + "'", number12.equals(974002049));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 100 + "'", int17 == 100);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (-101L) + "'", number18.equals((-101L)));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) 2.0d, (int) (byte) 100);
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number4, (java.lang.Number) 5.288241522117258d, 35, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int11 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 35 + "'", int11 == 35);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2621221781635855E15d + "'", double1 == 2.2621221781635855E15d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1000602687), 974002049);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1435984768));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        float float2 = org.apache.commons.math.util.FastMath.max(9.7400205E8f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6783606624401571d, (java.lang.Number) 3.6625219529419444d, (int) '#');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray21 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray29 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray21, doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 974002048);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray32);
        double[] doubleArray37 = new double[] { (byte) 10, 0.0d };
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray43 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray43);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 10);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1760676956 + "'", int33 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1000602687) + "'", int38 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 10.0d + "'", double48 == 10.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.49714987269413385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5426074954923101d + "'", double1 == 0.5426074954923101d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.740020473724827E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.390071144189683d + "'", double1 == 21.390071144189683d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 31L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 257);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 257.0f + "'", float1 == 257.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1085544065, 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085543041 + "'", int2 == 1085543041);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.384017341061263E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12431705617945586d + "'", double1 == 0.12431705617945586d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-131385937), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 131385937L + "'", long2 == 131385937L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double2 = org.apache.commons.math.util.FastMath.min(2.1556157735575975E15d, 22383.41708588723d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22383.41708588723d + "'", double2 == 22383.41708588723d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double2 = org.apache.commons.math.util.FastMath.min((double) '#', (-82.45803655637981d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-82.45803655637981d) + "'", double2 == (-82.45803655637981d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1085518848);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) 1.5707963267948966d, (-131385940));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(52, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 125994627894135L + "'", long2 == 125994627894135L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.1073424338879928E-8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4516688444297455E-4d + "'", double1 == 1.4516688444297455E-4d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(22026.465794806718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.031624894526136d + "'", double1 == 28.031624894526136d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long1 = org.apache.commons.math.util.FastMath.abs(5624L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5624L + "'", long1 == 5624L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int13 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.9512437185814275d, (java.lang.Number) 36L, (int) '#', orderDirection14, true);
        boolean boolean21 = nonMonotonousSequenceException20.getStrict();
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 100 + "'", int13 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-205));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.exp(105.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.989519570547216E45d + "'", double1 == 3.989519570547216E45d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(20.448926710154215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-131385940));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.31385936E8f + "'", float1 == 1.31385936E8f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 622);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.8110582783206075E7d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3348802.852664884d, (-131385937));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0330043544256398E-172d) + "'", double2 == (-1.0330043544256398E-172d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-0.5440618722340037d), 2.319776824715853d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray15 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray23 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 974002048);
        double[] doubleArray31 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray39 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray39);
        double[] doubleArray46 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double[] doubleArray54 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 974002048);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray39, doubleArray54);
        double[] doubleArray63 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray71 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray63, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 974002048);
        double[] doubleArray79 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        double[] doubleArray87 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray79, doubleArray87);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray87);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray87);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray87);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.4142135623730951d + "'", double10 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.4142135623730951d + "'", double16 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 2.6881171418161356E43d + "'", double24 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.4142135623730951d + "'", double32 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.6881171418161356E43d + "'", double40 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.6881171418161356E43d + "'", double41 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.4142135623730951d + "'", double47 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.4142135623730951d + "'", double64 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 2.6881171418161356E43d + "'", double72 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.4142135623730951d + "'", double80 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 2.6881171418161356E43d + "'", double88 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.6881171418161356E43d + "'", double89 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.6881171418161356E43d + "'", double91 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 2.6881171418161356E43d + "'", double92 == 2.6881171418161356E43d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 974002048L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 974002048 + "'", int1 == 974002048);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, 1760676956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.384017341061263E11d, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.225342994858729E-12d + "'", double2 == 7.225342994858729E-12d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.0036817214070489815d), (-1244.0858352682665d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1244.0858352682665d) + "'", double2 == (-1244.0858352682665d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-2059546114), 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.384017341061263E11d, 6.34960155562218d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3840173410612628E11d + "'", double2 == 1.3840173410612628E11d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int int2 = org.apache.commons.math.util.FastMath.min(467396991, 1760676966);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 467396991 + "'", int2 == 467396991);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.FastMath.expm1(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042505E42d + "'", double1 == 1.3383347192042505E42d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int7 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 100 + "'", int7 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + Double.NEGATIVE_INFINITY + "'", number12.equals(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long2 = org.apache.commons.math.util.MathUtils.pow(35L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2758547353515625L + "'", long2 == 2758547353515625L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5044, number1, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 974002048, (java.lang.Number) (-1435984768), (-1694164182));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double double1 = org.apache.commons.math.util.FastMath.ulp(13.228920847762078d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', 1410065408);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2264289884328505343L) + "'", long2 == (-2264289884328505343L));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1925533408L, (java.lang.Number) 8.881784197001252E-16d, (int) '#');
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1925533408L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17636355065571846d) + "'", double1 == (-0.17636355065571846d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1760676966, 12L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3149206527444455424L + "'", long2 == 3149206527444455424L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-2059546114), 1182127744);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 9.740020490000001E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.015573447697767695d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double1 = org.apache.commons.math.util.FastMath.expm1(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134298E15d + "'", double1 == 1.5860134523134298E15d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.4142135623730951d, 5.267831587699267d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2622779521594298d + "'", double2 == 0.2622779521594298d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        long long1 = org.apache.commons.math.util.FastMath.round(3.8834864931005E-310d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        try {
            double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (-0.7877158799310174d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.log10((-2.968123235826276E-35d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        int int2 = org.apache.commons.math.util.FastMath.max(1085544065, 974002048);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1085544065 + "'", int2 == 1085544065);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1410065408, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-506605058));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.062077391215993656d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.06199777340989434d) + "'", double1 == (-0.06199777340989434d));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.7253825588523148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.85713866772001d + "'", double1 == 98.85713866772001d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(34620618912878L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray42 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray51 = new double[] { (byte) 10, 0.0d };
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray57 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray57);
        double[] doubleArray64 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray72 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray64, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, (double) 974002048);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray75);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 2.6881171418161356E43d + "'", double43 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 2.6881171418161356E43d + "'", double45 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 2.6881171418161356E43d + "'", double46 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1182127744 + "'", int47 == 1182127744);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1182127744 + "'", int48 == 1182127744);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1000602687) + "'", int52 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.4142135623730951d + "'", double58 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.4142135623730951d + "'", double65 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 2.6881171418161356E43d + "'", double73 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1760676956 + "'", int76 == 1760676956);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 9.740020500000001E8d + "'", double77 == 9.740020500000001E8d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int1 = org.apache.commons.math.util.FastMath.round(1.31385933E9f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1313859328 + "'", int1 == 1313859328);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1024L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double2 = org.apache.commons.math.util.MathUtils.log(99.30685281944005d, 18.964889726830815d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6399417229019823d + "'", double2 == 0.6399417229019823d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31570342489615477d + "'", double1 == 0.31570342489615477d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-2L), (-17310309456471L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34620618912942L + "'", long2 == 34620618912942L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray18);
        int[] intArray24 = new int[] { (byte) 0, 100, 0 };
        int[] intArray29 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray29);
        int[] intArray34 = new int[] { (byte) 0, 100, 0 };
        int[] intArray39 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray39);
        int[] intArray44 = new int[] { (byte) 0, 100, 0 };
        int[] intArray49 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray49);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray39);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray66 = new int[] { (byte) 0, 100, 0 };
        int[] intArray71 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray71);
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray61);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray39);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 152 + "'", int30 == 152);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 152 + "'", int40 == 152);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 152 + "'", int50 == 152);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 99 + "'", int52 == 99);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 152 + "'", int72 == 152);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 257, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 257L + "'", long2 == 257L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1024L, (long) 1024);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1024L + "'", long2 == 1024L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.003761536530132509d, (-0.17636355065571846d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6768077905644576d + "'", double2 == 2.6768077905644576d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10100L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10100L + "'", long2 == 10100L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1563278539);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray22 = null;
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray22);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1760676966);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.288964211814285d + "'", double1 == 21.288964211814285d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1760676966, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760676966 + "'", int2 == 1760676966);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(257, 974002048);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 100.0f, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E104d + "'", double2 == 1.0E104d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 0);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger14);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger7);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 0);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-17310309456471L), 760074269L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8666494886269307273L + "'", long2 == 8666494886269307273L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray15 = new double[] { (byte) 10, 0.0d };
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray15);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1000602687) + "'", int16 == (-1000602687));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1000602687) + "'", int17 == (-1000602687));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 10.0d + "'", double19 == 10.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1000602687) + "'", int20 == (-1000602687));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-205));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(9.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.08281907607655d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.443197518039908d + "'", double1 == 1.443197518039908d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 87, 1694164183);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.07821925899367385d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07837917208558982d) + "'", double1 == (-0.07837917208558982d));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number12 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException11.getSuppressed();
        boolean boolean14 = nonMonotonousSequenceException11.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int19 = nonMonotonousSequenceException18.getIndex();
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException11.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4, orderDirection22, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 974002049 + "'", number12.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 100 + "'", int19 == 100);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-101L) + "'", number20.equals((-101L)));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2, (long) 1313859328);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.06199777340989434d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray11 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray19 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray19);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 974002048);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray28 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray36 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 974002048);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray39);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray4, doubleArray22);
        double[] doubleArray45 = new double[] { (byte) 10, 0.0d };
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray51 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray59 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray59);
        double[] doubleArray65 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray73 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray65, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) 974002048);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray45, doubleArray51);
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray51);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.4142135623730951d + "'", double12 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.6881171418161356E43d + "'", double20 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1760676956 + "'", int23 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.4142135623730951d + "'", double29 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.6881171418161356E43d + "'", double37 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1760676956 + "'", int40 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1000602687) + "'", int46 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.4142135623730951d + "'", double52 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.4142135623730951d + "'", double66 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.6881171418161356E43d + "'", double74 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 9.0d + "'", double78 == 9.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.4142135623730951d + "'", double80 == 1.4142135623730951d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6783606624401571d, (java.lang.Number) 3.6625219529419444d, (int) '#');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray21 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = null;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray25);
        double[] doubleArray31 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray39 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray47 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray47);
        double[] doubleArray55 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray55);
        double[] doubleArray57 = null;
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray39);
        double[] doubleArray62 = new double[] { (byte) 10, 0.0d };
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray68 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray68);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 10);
        double[] doubleArray77 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double[] doubleArray81 = null;
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray77, doubleArray81);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray77);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray31, doubleArray77);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray31);
        try {
            double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.4142135623730951d + "'", double22 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 974002049 + "'", int23 == 974002049);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.4142135623730951d + "'", double24 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.4142135623730951d + "'", double32 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 974002049 + "'", int33 == 974002049);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.4142135623730951d + "'", double34 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.4142135623730951d + "'", double40 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 2.6881171418161356E43d + "'", double48 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 204.0d + "'", double56 == 204.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1000602687) + "'", int63 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.4142135623730951d + "'", double69 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.4142135623730951d + "'", double78 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 974002049 + "'", int79 == 974002049);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.4142135623730951d + "'", double80 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        int[] intArray3 = new int[] { (byte) 0, 100, 0 };
        int[] intArray8 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray8);
        int[] intArray13 = new int[] { (byte) 0, 100, 0 };
        int[] intArray18 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray18);
        int[] intArray23 = new int[] { (byte) 0, 100, 0 };
        int[] intArray28 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray28);
        int[] intArray33 = new int[] { (byte) 0, 100, 0 };
        int[] intArray38 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray38);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        double double42 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray28);
        int[] intArray46 = new int[] { (byte) 0, 100, 0 };
        int[] intArray51 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray51);
        int[] intArray56 = new int[] { (byte) 0, 100, 0 };
        int[] intArray61 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray61);
        int[] intArray66 = new int[] { (byte) 0, 100, 0 };
        int[] intArray71 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray71);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray61);
        int[] intArray78 = new int[] { (byte) 0, 100, 0 };
        int[] intArray83 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int84 = org.apache.commons.math.util.MathUtils.distance1(intArray78, intArray83);
        int[] intArray88 = new int[] { (byte) 0, 100, 0 };
        int[] intArray93 = new int[] { '4', (short) 1, (byte) -1, (byte) 10 };
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray93);
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray83, intArray93);
        int int96 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray83);
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray83);
        int[] intArray98 = null;
        try {
            int int99 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray98);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 152 + "'", int9 == 152);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 152 + "'", int19 == 152);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 152 + "'", int29 == 152);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 152 + "'", int39 == 152);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 99 + "'", int41 == 99);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 111.83022847155415d + "'", double42 == 111.83022847155415d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 152 + "'", int52 == 152);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 152 + "'", int62 == 152);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 152 + "'", int72 == 152);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 99 + "'", int74 == 99);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 152 + "'", int84 == 152);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 152 + "'", int94 == 152);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 152 + "'", int97 == 152);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1694164182));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray28 = new double[] { (byte) 10, 0.0d };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray34);
        java.lang.Number number40 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.37357877856093286d, number40, 10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException42.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection43, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (1 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1000602687) + "'", int25 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1000602687) + "'", int29 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1563278539);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1563278539 + "'", int2 == 1563278539);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.3383347192042695E42d, (double) (-1000602687));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str10 = nonMonotonousSequenceException8.toString();
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        int int22 = nonMonotonousSequenceException21.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException21.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 0.0f, (int) (byte) 1, orderDirection23, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number12, (java.lang.Number) 3.9512437185814275d, (int) (short) 100, orderDirection23, true);
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        int int30 = nonMonotonousSequenceException27.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not strictly increasing (974,002,049 >= -101)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 974002049 + "'", number11.equals(974002049));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 100 + "'", int22 == 100);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 100 + "'", int30 == 100);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        int int1 = org.apache.commons.math.util.FastMath.abs((-506605058));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 506605058 + "'", int1 == 506605058);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 0);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 10);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 0);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 0);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 10);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 10);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger20);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) '#');
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger23);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) (byte) 1);
        java.math.BigInteger bigInteger27 = null;
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.7853981633974482d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.5440618722340037d), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-557.1193571676198d) + "'", double2 == (-557.1193571676198d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.223372036854778E18d + "'", double1 == 9.223372036854778E18d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-2059546114));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4614191792528529d) + "'", double1 == (-0.4614191792528529d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.4315840772398932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6569505896487903d + "'", double1 == 0.6569505896487903d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 31, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1760676956, (double) 36L, 1.4524424832623713E13d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', (-131385940));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(19788, (-204));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 19788 + "'", int2 == 19788);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-101L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5786.873730821314d) + "'", double1 == (-5786.873730821314d));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(36, 1760676956);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1760676992 + "'", int2 == 1760676992);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-52), (double) (-1085544065));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-52.00000000000001d) + "'", double2 == (-52.00000000000001d));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 11.7910068511973d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.7910068511973d + "'", double2 == 11.7910068511973d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(572.9577951308232d, 0.0d, (double) Float.NaN);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.57235190491251E-6d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.572351904912511E-6d + "'", double1 == 7.572351904912511E-6d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-131385973L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 96);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray20 = new double[] { (-100L), 1.0d, 100L, (byte) 1, (-1000602687), 0L };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray20);
        double[] doubleArray24 = new double[] { (byte) 10, 0.0d };
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray28 = new double[] { (byte) 10, 0.0d };
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        double[] doubleArray34 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray34);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray34);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 204.0d + "'", double21 == 204.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1000602687) + "'", int25 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1000602687) + "'", int29 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.4142135623730951d + "'", double35 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 974002049 + "'", int39 == 974002049);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 974002079L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.05586001084178062d, 7.610125138662288d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.339045318021367d + "'", double2 == 6.339045318021367d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 204.0d, (java.lang.Number) (byte) 10, 5044);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 10 + "'", number4.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 5,043 and 5,044 are not strictly increasing (10 >= 204)"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray12 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray12);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 974002048);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.6275174755083712d);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1760676956 + "'", int16 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 73287569 + "'", int19 == 73287569);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-204));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        long long2 = org.apache.commons.math.util.FastMath.max(44563605345385459L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44563605345385459L + "'", long2 == 44563605345385459L);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.tanh(155.74607629780772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(9.223372036854776E18d, (double) 32.0f, 2.4830062883006265d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.FastMath.rint(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1037659958));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963258311899d) + "'", double1 == (-1.5707963258311899d));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number7 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-1.7463811409905557E7d), (int) (short) 0, orderDirection8, false);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getPrevious();
        int int13 = nonMonotonousSequenceException10.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 974002049 + "'", number7.equals(974002049));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-17,463,811.41 > null)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (-17,463,811.41 > null)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.7463811409905557E7d) + "'", number12.equals((-1.7463811409905557E7d)));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0038848218538872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0038848218538874d + "'", double1 == 1.0038848218538874d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 310, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 310L + "'", long2 == 310L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.rint(11013.026041820607d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.0d + "'", double1 == 11013.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5860134523134298E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0871877068532768E16d + "'", double1 == 9.0871877068532768E16d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1313859370L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-797.1802070118957d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(22025.465794806718d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double[] doubleArray4 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        double[] doubleArray11 = new double[] { (byte) 10, 0.0d };
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 10);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray27 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double[] doubleArray35 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray35);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 974002048);
        double[] doubleArray43 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray51 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray51);
        double[] doubleArray60 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray68 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 974002048);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double[] doubleArray77 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double[] doubleArray85 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray77, doubleArray85);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray85, (double) 974002048);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray88);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray71);
        double double92 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray71);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.4142135623730951d + "'", double5 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 974002049 + "'", int6 == 974002049);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.4142135623730951d + "'", double7 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4142135623730951d + "'", double8 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1000602687) + "'", int12 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.4142135623730951d + "'", double28 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.6881171418161356E43d + "'", double36 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.4142135623730951d + "'", double44 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.6881171418161356E43d + "'", double52 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.4142135623730951d + "'", double61 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 2.6881171418161356E43d + "'", double69 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1760676956 + "'", int72 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.4142135623730951d + "'", double78 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 2.6881171418161356E43d + "'", double86 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 1760676956 + "'", int89 == 1760676956);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 2.6881171418161356E43d + "'", double91 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 9.740020480000001E8d + "'", double92 == 9.740020480000001E8d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 9.740020480000001E8d + "'", double93 == 9.740020480000001E8d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection7, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection7, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.atan(10.067661995777765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.471793136883215d + "'", double1 == 1.471793136883215d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(204, 152);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7752 + "'", int2 == 7752);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1024, 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1033 + "'", int2 == 1033);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.acos((-8.655952316688715d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(15.104412573075516d, 363.7393755555636d, 572.2646479502633d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.8110582783206075E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 506605058, (long) 7752);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 506605058L + "'", long2 == 506605058L);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 1313859328);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1694164182);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.706845743083347E10d + "'", double1 == 9.706845743083347E10d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, (long) 0);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 10);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 10);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger10);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) '#');
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double2 = org.apache.commons.math.util.FastMath.min((-1244.0858352682665d), (double) 204L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1244.0858352682665d) + "'", double2 == (-1244.0858352682665d));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1076101120);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07610112E9f + "'", float1 == 1.07610112E9f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 34620618922968L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.539334827618724d + "'", double1 == 13.539334827618724d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 99);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 99.0f + "'", float1 == 99.0f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(87, 36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 123 + "'", int2 == 123);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(97, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1694164182));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 6.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.atanh(52.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        int int1 = org.apache.commons.math.util.MathUtils.hash(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1076101120) + "'", int1 == (-1076101120));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.067661995777765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.0d + "'", double1 == 11.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(52.0d, (-0.4614191792528529d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7345175425633101d + "'", double2 == 1.7345175425633101d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1556157735575975E15d + "'", double1 == 2.1556157735575975E15d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1760676992);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        long long1 = org.apache.commons.math.util.MathUtils.sign(17310309456440L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-17310309456471L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        long long2 = org.apache.commons.math.util.MathUtils.pow(37L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1901415581956121743L) + "'", long2 == (-1901415581956121743L));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        int int2 = org.apache.commons.math.util.FastMath.min((-204), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-204) + "'", int2 == (-204));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.227966323305175d, 7752);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.325022432875689E-133d + "'", double2 == 4.325022432875689E-133d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int1 = org.apache.commons.math.util.MathUtils.sign(152);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(32.415926531775625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.984502088362243E13d + "'", double1 == 5.984502088362243E13d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 5.06605056E8f, 1.5430256902014756d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02164047197504836d + "'", double2 == 0.02164047197504836d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(204, 1085544065);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2599210498948732d + "'", double1 == 1.2599210498948732d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(87);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 304.6868567656687d + "'", double1 == 304.6868567656687d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.0036817214070489815d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0036817297247214165d) + "'", double1 == (-0.0036817297247214165d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        long long1 = org.apache.commons.math.util.FastMath.round(0.764725154011207d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.371184979049348E80d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.371184979049348E80d + "'", double1 == 1.371184979049348E80d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1552941056, 974002048);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray18 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray26 = new double[] { 10.0d, 2.6881171418161356E43d, (-101L), ' ', '4', 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 974002048);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.6275174755083712d);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray29);
        java.lang.Class<?> wildcardClass34 = doubleArray29.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52, (java.lang.Number) 1760676956, 0, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5403023093369417d, (java.lang.Number) (short) 100, 974002048, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-203.99999999999997d), (java.lang.Number) 9.740020490000001E8d, (int) (short) 0, orderDirection44, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray29, orderDirection44, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (974,002,048 > -0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.4142135623730951d + "'", double19 == 1.4142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.6881171418161356E43d + "'", double27 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1760676956 + "'", int30 == 1760676956);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-101L), (java.lang.Number) 974002049, (int) (short) 100);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        boolean boolean8 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 974002049 + "'", number4.equals(974002049));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-101L) + "'", number6.equals((-101L)));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-101L) + "'", number7.equals((-101L)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.383198930911336d + "'", double1 == 1.383198930911336d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-205), 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        int int1 = org.apache.commons.math.util.FastMath.abs(1760676966);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1760676966 + "'", int1 == 1760676966);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0038848218538874d, 2.0d, 31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double2 = org.apache.commons.math.util.FastMath.pow(22026.465794806718d, 1.4524424832623713E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3915798710256516d + "'", double1 == 0.3915798710256516d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.1214480546016465E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1214480546016465E13d + "'", double1 == 1.1214480546016465E13d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(34620618922968L, 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5234637581152761600L + "'", long2 == 5234637581152761600L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.9704140549294856d, (double) 123);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-160.23289169960583d) + "'", double2 == (-160.23289169960583d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        double double1 = org.apache.commons.math.util.FastMath.tan(132059.36709719698d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.716462070079908d) + "'", double1 == (-0.716462070079908d));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double[] doubleArray2 = new double[] { (byte) 10, 0.0d };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray17 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = null;
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray17);
        double[] doubleArray26 = new double[] { (byte) 10, 0.0d };
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray32 = new double[] { 1, 0.0d, 0L, (byte) -1 };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray32);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 10);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray36);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1000602687) + "'", int3 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.4142135623730951d + "'", double9 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.4142135623730951d + "'", double18 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 974002049 + "'", int19 == 974002049);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.4142135623730951d + "'", double20 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1000602687) + "'", int27 == (-1000602687));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.4142135623730951d + "'", double33 == 1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 10.0d + "'", double37 == 10.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1552941056L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.163416425466703d + "'", double1 == 21.163416425466703d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(97, (-1694164083));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(10, 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }
}

