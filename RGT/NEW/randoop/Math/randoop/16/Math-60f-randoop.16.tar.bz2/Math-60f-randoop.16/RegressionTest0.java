import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1.0f, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.09966865249116202d + "'", double2 == 0.09966865249116202d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Throwable throwable5 = null;
        try {
            numberIsTooSmallException4.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999546000702375d + "'", double2 == 0.9999546000702375d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8426819462428745d + "'", double1 == 0.8426819462428745d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.String str5 = outOfRangeException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test016");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.07608266144434628d + "'", double0 == 0.07608266144434628d);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextSecureLong((-1L), (long) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: -1 is larger than, or equal to, the maximum (-1): lower bound (-1) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.141592653589793d, 10.000000000000002d, 0.8426819462428745d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.003404141117823663d + "'", double4 == 0.003404141117823663d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.07608266144434628d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 10, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("hi!", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9999546000702375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.54009603704951E-5d) + "'", double1 == (-4.54009603704951E-5d));
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test028");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        try {
//            long long6 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test029");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        try {
//            java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 10);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextUniform((double) 100, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8426819462428745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.28211899158683d + "'", double1 == 48.28211899158683d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test036");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        try {
//            java.lang.String str6 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test037");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        try {
//            long long17 = randomDataImpl1.nextPoisson((double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 95.4645010699613d + "'", double14 == 95.4645010699613d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 89.87008107302397d + "'", double15 == 89.87008107302397d);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100, (-0.9036922050915067d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.904 is smaller than, or equal to, the minimum (0): standard deviation (-0.904)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.tan(100.88832094586432d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37338728152646206d + "'", double1 == 0.37338728152646206d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.9036922050915067d), (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9036922050915067d) + "'", double2 == (-0.9036922050915067d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 1, 0.0d, 1.0E-9d, 35);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test047");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) 10);
//        try {
//            int int11 = randomDataImpl1.nextSecureInt((int) (short) 1, (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.6321205588285577d), 1.0d, (double) 'a', (int) (short) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.acosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.special.Erf.erf(0.8426819462428745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7666337465818244d + "'", double1 == 0.7666337465818244d);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test054");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta(48.28211899158683d, (double) (short) 1);
//        try {
//            double double6 = randomDataImpl1.nextExponential((double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9764764321578567d + "'", double4 == 0.9764764321578567d);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 10, (double) 1, 1.5707963267948966d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.999999898622288d + "'", double4 == 0.999999898622288d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 10, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9036922050915067d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double7 = normalDistributionImpl3.cumulativeProbability((double) (byte) 1, (double) (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test069");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta(48.28211899158683d, (double) (short) 1);
//        try {
//            double double6 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9869559051546833d + "'", double4 == 0.9869559051546833d);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Object[] objArray13 = numberIsTooSmallException11.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray13);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray24 = convergenceException23.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable22, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, objArray24);
        java.lang.Throwable[] throwableArray27 = mathIllegalArgumentException26.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(throwableArray27);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0f);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.9792394759119608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6118933276547492d) + "'", double1 == (-0.6118933276547492d));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.141592653589793d, (java.lang.Number) (byte) 0, true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 'a', (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.9075712110370514d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06071540131037745d + "'", double1 == 0.06071540131037745d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.asinh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        float float2 = org.apache.commons.math.util.FastMath.max((-1.0f), (float) 3L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextSecureLong((long) 100, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (0): lower bound (100) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9792394759119608d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6962822528931225d + "'", double1 == 1.6962822528931225d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray18 = convergenceException17.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable16, objArray18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { maxIterationsExceededException19, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray21);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable9, objArray23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6449340668481562d + "'", double1 == 1.6449340668481562d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number1, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) (short) 10);
        java.lang.Number number7 = notStrictlyPositiveException6.getMin();
        outOfRangeException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(96.10253420893275d, 0.0d, (double) 32.0f, 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 180.0d + "'", double1 == 180.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(4.9E-324d, 96.10253420893275d, 6.691673596021348E41d, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 96.103 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long1 = org.apache.commons.math.util.FastMath.round((-1.0d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        randomDataImpl0.reSeedSecure((long) (-1));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "cde946c2d7b318cb4e1afd8f1781491cb63312932790d919ac77b3483460678afc3a19bbe10de71800026a78b84624e1d6da" + "'", str2.equals("cde946c2d7b318cb4e1afd8f1781491cb63312932790d919ac77b3483460678afc3a19bbe10de71800026a78b84624e1d6da"));
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double6 = normalDistributionImpl3.inverseCumulativeProbability((double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 32 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.37338728152646206d, (-0.8414709848078965d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double2 = org.apache.commons.math.util.FastMath.max(0.5403023058681398d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5403023058681398d + "'", double2 == 0.5403023058681398d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(98.95946939207121d, 99.26982479992046d, (double) (byte) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.04005020606749013d + "'", double4 == 0.04005020606749013d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.6118933276547492d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        try {
//            double double8 = normalDistributionImpl3.cumulativeProbability((double) (byte) 10, 0.09966865249116202d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 101.35270930428084d + "'", double4 == 101.35270930428084d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 96.53858331624996d + "'", double5 == 96.53858331624996d);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double[] doubleArray17 = normalDistributionImpl13.sample((int) '4');
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 114.61324636976765d + "'", double14 == 114.61324636976765d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.14377302291854d + "'", double15 == 100.14377302291854d);
//        org.junit.Assert.assertNotNull(doubleArray17);
//    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        try {
//            double double5 = randomDataImpl0.nextF((double) 0, 108.77840576420837d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "efdc8fb486d51780bb07bb21173859c1429e3ad2523264138e169b83fa97e76a5b285f293332a6033d4bf4787269be1bf23a" + "'", str2.equals("efdc8fb486d51780bb07bb21173859c1429e3ad2523264138e169b83fa97e76a5b285f293332a6033d4bf4787269be1bf23a"));
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 91.91207251291225d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.6962822528931225d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09657753859415763d) + "'", double1 == (-0.09657753859415763d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100.0f, 1.3862943611198906d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        randomDataImpl1.reSeedSecure(0L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution18 = null;
//        try {
//            int int19 = randomDataImpl1.nextInversionDeviate(integerDistribution18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 112.89640833592452d + "'", double14 == 112.89640833592452d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 112.89640833592452d + "'", double15 == 112.89640833592452d);
//    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number1, (java.lang.Number) (byte) -1);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 52.0f, 90.67603130189458d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 90.67603130189458d + "'", double2 == 90.67603130189458d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test128");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        try {
//            int int8 = randomDataImpl1.nextZipf((int) (short) -1, 180.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7659613425401111d) + "'", double1 == (-0.7659613425401111d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        int int1 = org.apache.commons.math.util.FastMath.abs(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long1 = org.apache.commons.math.util.FastMath.round(94.58560008099309d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 95L + "'", long1 == 95L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99627207622075d + "'", double1 == 0.99627207622075d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.6449340668481562d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6449340668481565d + "'", double2 == 1.6449340668481565d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.999999898622288d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5703460430760796d + "'", double1 == 1.5703460430760796d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number13 = numberIsTooSmallException12.getMin();
        java.lang.Object[] objArray14 = numberIsTooSmallException12.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, "org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range", objArray14);
        java.lang.Number number16 = outOfRangeException4.getHi();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.9036922050915067d) + "'", number16.equals((-0.9036922050915067d)));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.6962822528931225d, 103.53479945840866d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.04005020606749013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.19579804156935d + "'", double1 == 3.19579804156935d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test145");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        try {
//            int int6 = randomDataImpl0.nextSecureInt(6, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than, or equal to, the maximum (1): lower bound (6) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 86.72679146783962d + "'", double3 == 86.72679146783962d);
//    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.signum((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.ulp(93.1334434155544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.special.Erf.erf(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9709085856446726d + "'", double1 == 0.9709085856446726d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.tan(89.22059212019667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.071002453969906d + "'", double1 == 3.071002453969906d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.09966865249116202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.001739546146996826d + "'", double1 == 0.001739546146996826d);
    }

//    @Test
//    public void test154() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test154");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double10 = randomDataImpl1.nextF(0.09966865249116202d, 98.48832680232762d);
//        try {
//            double double13 = randomDataImpl1.nextUniform((double) (byte) 100, 1.6962822528931225d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1.696): lower bound (100) must be strictly less than upper bound (1.696)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "f646cd64e8" + "'", str7.equals("f646cd64e8"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.07981461768671518d + "'", double10 == 0.07981461768671518d);
//    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test155");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta(48.28211899158683d, (double) (short) 1);
//        double double7 = randomDataImpl1.nextGamma(98.48832680232762d, 1.0d);
//        double double10 = randomDataImpl1.nextF((double) (short) 1, (double) (short) 100);
//        try {
//            java.lang.String str12 = randomDataImpl1.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.994789789318746d + "'", double4 == 0.994789789318746d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 93.3514698505647d + "'", double7 == 93.3514698505647d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.18398999140439787d + "'", double10 == 0.18398999140439787d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test157");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta(48.28211899158683d, (double) (short) 1);
//        double double7 = randomDataImpl1.nextGamma(98.48832680232762d, 1.0d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution8 = null;
//        try {
//            double double9 = randomDataImpl1.nextInversionDeviate(continuousDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9951267297245677d + "'", double4 == 0.9951267297245677d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 83.98991346170851d + "'", double7 == 83.98991346170851d);
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        double double5 = normalDistributionImpl3.getMean();
        double double7 = normalDistributionImpl3.density((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0811768202028248E-23d + "'", double7 == 2.0811768202028248E-23d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.asin(100.88832094586432d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.asin(101.37859561714563d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(122.5042597109431d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7018.97705381157d + "'", double1 == 7018.97705381157d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.String str5 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray6);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray22 = convergenceException21.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable20, objArray22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { maxIterationsExceededException23, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.Object[] objArray39 = numberIsTooSmallException37.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable32, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46);
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException47.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray50 = convergenceException49.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable48, objArray50);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7, localizable13, objArray50);
        java.lang.Throwable[] throwableArray54 = mathException53.getSuppressed();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(96.73501783446021d, 106.85988529538214d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8483011693542782d + "'", double2 == 0.8483011693542782d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.log1p(48.28211899158683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8975613173184227d + "'", double1 == 3.8975613173184227d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test170");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextHexString(3);
//        try {
//            double double5 = randomDataImpl0.nextGamma((double) 2, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "26f" + "'", str2.equals("26f"));
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray6);
        java.lang.Object[] objArray8 = mathException7.getArguments();
        java.lang.String str9 = mathException7.getPattern();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)" + "'", str9.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.ulp(95.51416029381322d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test173");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double18 = randomDataImpl1.nextUniform((double) (short) 1, 100.88832094586432d);
//        try {
//            long long21 = randomDataImpl1.nextLong((long) 6, 3L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than, or equal to, the maximum (3): lower bound (6) must be strictly less than upper bound (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 90.64288141849491d + "'", double14 == 90.64288141849491d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 95.99122593436977d + "'", double15 == 95.99122593436977d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 44.12376160097773d + "'", double18 == 44.12376160097773d);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)", "bf6d1");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: bf6d1");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 82.45812189510337d + "'", double16 == 82.45812189510337d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 82.45812189510337d + "'", double17 == 82.45812189510337d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 110.93008302161559d + "'", double18 == 110.93008302161559d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 94.28760322565529d + "'", double21 == 94.28760322565529d);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6253600733206826E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0315754653989584E-5d + "'", double1 == 4.0315754653989584E-5d);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        try {
//            int int18 = randomDataImpl1.nextBinomial((int) (byte) 10, (double) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 9 + "'", int4 == 9);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 102.7421348708614d + "'", double14 == 102.7421348708614d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 107.07325017285991d + "'", double15 == 107.07325017285991d);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = convergenceException13.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable12, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { maxIterationsExceededException15, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray17);
        java.lang.Class<?> wildcardClass19 = mathIllegalArgumentException18.getClass();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(101.37859561714563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.662821141332062d + "'", double1 == 4.662821141332062d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        randomDataImpl0.reSeed((long) (short) 10);
//        try {
//            java.lang.String str7 = randomDataImpl0.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 142.79216851693292d + "'", double3 == 142.79216851693292d);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.sinh(15.341372134320396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2299552.171183986d + "'", double1 == 2299552.171183986d);
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta(2.220446049250313E-16d, (double) (byte) 100);
//        randomDataImpl0.reSeedSecure(0L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution6 = null;
//        try {
//            int int7 = randomDataImpl0.nextInversionDeviate(integerDistribution6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.5340154994029163E-9d + "'", double3 == 1.5340154994029163E-9d);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta(48.28211899158683d, (double) (short) 1);
//        try {
//            long long7 = randomDataImpl1.nextSecureLong(0L, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9960191568126926d + "'", double4 == 0.9960191568126926d);
//    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextGaussian(101.23139097877929d, 110.69838008200007d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 103.1886756269692d + "'", double16 == 103.1886756269692d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 98.8832895193695d + "'", double17 == 98.8832895193695d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 108.99379530244953d + "'", double18 == 108.99379530244953d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 105.53451078593605d + "'", double21 == 105.53451078593605d);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.atan(98.87038924080616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5606824199881275d + "'", double1 == 1.5606824199881275d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 3L, (-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9036922050915067d) + "'", double2 == (-0.9036922050915067d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Object[] objArray13 = numberIsTooSmallException11.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException(localizable16, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray21 = outOfRangeException20.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 104.30264934376666d, (java.lang.Number) 104.88637389663414d, false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 98.48832680232762d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.88832094586432d, 94.04815398114476d, 86.2522636056895d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Object[] objArray12 = numberIsTooSmallException10.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable5, objArray12);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 100);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) 103.63345634712675d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) 29);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2227587494850775E-162d + "'", double1 == 2.2227587494850775E-162d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.asinh(98.72913154209108d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.285552882622063d + "'", double1 == 5.285552882622063d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int2 = org.apache.commons.math.util.FastMath.max(5, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        long long1 = org.apache.commons.math.util.FastMath.round(98.87038924080616d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027181892591221314d + "'", double1 == 0.027181892591221314d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(98.85329861584762d, (double) 32, 0.0d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.1411200080598672d, (java.lang.Number) 1.5606824199881275d, (java.lang.Number) 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9092974268256817d + "'", double1 == 0.9092974268256817d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.expm1(96.05691662292291d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.211813157863026E41d + "'", double1 == 5.211813157863026E41d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.746501045726147d + "'", double1 == 4.746501045726147d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.285552882622063d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long2 = org.apache.commons.math.util.FastMath.min(3L, 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.exp(98.87038924080616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.686892974894768E42d + "'", double1 == 8.686892974894768E42d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.special.Gamma.digamma(105.2717054070584d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.651787544441292d + "'", double1 == 4.651787544441292d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray7 = outOfRangeException6.getSuppressed();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Object[] objArray23 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable16, objArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = convergenceException30.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray40 = convergenceException39.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable38, objArray40);
        java.lang.Object[] objArray43 = new java.lang.Object[] { maxIterationsExceededException41, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, objArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException55);
        java.lang.Object[] objArray57 = numberIsTooSmallException55.getArguments();
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray57);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable50, objArray57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException64);
        org.apache.commons.math.exception.util.Localizable localizable66 = convergenceException65.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray68 = convergenceException67.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable66, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, objArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException25, localizable31, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, "a65f76c177", objArray68);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray68);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizable66 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable66.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Object[] objArray12 = numberIsTooSmallException10.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable5, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = convergenceException28.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable27, objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { maxIterationsExceededException30, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44);
        java.lang.Object[] objArray46 = numberIsTooSmallException44.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable39, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray57 = convergenceException56.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable55, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray57);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable20, objArray57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) (-0.8414709848078965d), (java.lang.Number) 8, false);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray57);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed();
//        long long24 = randomDataImpl1.nextPoisson((double) 4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 20 + "'", int11 == 20);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 88.75620980050206d + "'", double16 == 88.75620980050206d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 117.6101128309024d + "'", double17 == 117.6101128309024d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 117.89454517635374d + "'", double18 == 117.89454517635374d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 96.97276911081677d + "'", double21 == 96.97276911081677d);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3L + "'", long24 == 3L);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.log(101.18841336952065d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.616984257902569d + "'", double1 == 4.616984257902569d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.special.Erf.erf(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test219");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double20 = normalDistributionImpl15.density((double) 29);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 86.21824623500918d + "'", double16 == 86.21824623500918d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 86.21824623500918d + "'", double17 == 86.21824623500918d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 89.90122293555837d + "'", double18 == 89.90122293555837d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.513543677205518E-13d + "'", double20 == 4.513543677205518E-13d);
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test220");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal(10, 0.999999898622288d);
//        double double6 = randomDataImpl0.nextGaussian(103.63345634712675d, (double) '4');
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 64.246770768467d + "'", double6 == 64.246770768467d);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.rint(104.88637389663414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105.0d + "'", double1 == 105.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.11164249569688664d), (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.646306286048102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 384.9682226831401d + "'", double1 == 384.9682226831401d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.3100744865539534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3051295716429426d + "'", double1 == 0.3051295716429426d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray7 = outOfRangeException6.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException(localizable8, (java.lang.Number) 0.1411200080598672d, (java.lang.Number) 1.5606824199881275d, (java.lang.Number) 1.0d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        convergenceException17.addSuppressed((java.lang.Throwable) numberIsTooSmallException22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray32 = convergenceException31.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable30, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45);
        java.lang.Object[] objArray47 = numberIsTooSmallException45.getArguments();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable40, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException33, "874d9298f1", objArray47);
        org.apache.commons.math.exception.util.Localizable localizable51 = maxIterationsExceededException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable53, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number58 = numberIsTooSmallException57.getMin();
        java.lang.Object[] objArray59 = numberIsTooSmallException57.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException65);
        org.apache.commons.math.exception.util.Localizable localizable67 = convergenceException66.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray69 = convergenceException68.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable67, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException57, "874d9298f1", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException33, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)", objArray69);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray75 = mathException74.getArguments();
        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException6, 1.0d, convergenceException17, convergenceException72, 32, mathException74 };
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException77 = new org.apache.commons.math.MaxIterationsExceededException(32, "a65f76c177", objArray76);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 0L + "'", number58.equals(0L));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number13 = numberIsTooSmallException12.getMin();
        java.lang.Object[] objArray14 = numberIsTooSmallException12.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, "org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getSpecificPattern();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        java.lang.Object[] objArray7 = numberIsTooSmallException5.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray7);
        convergenceException0.addSuppressed((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.rint(97.99166523593858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.0d + "'", double1 == 98.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.abs(93.1334434155544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 93.1334434155544d + "'", double1 == 93.1334434155544d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = convergenceException13.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable12, objArray14);
        java.lang.Object[] objArray17 = new java.lang.Object[] { maxIterationsExceededException15, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNull(localizable19);
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test236");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        try {
//            double double5 = randomDataImpl0.nextGamma(80.0064206060725d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "8e5c8b0431bdc2a42177df44c4ac3b714308c331c3cc25a2686f09fa2b44f2c4f8912ca5016e4031883b65ac6509565cb130" + "'", str2.equals("8e5c8b0431bdc2a42177df44c4ac3b714308c331c3cc25a2686f09fa2b44f2c4f8912ca5016e4031883b65ac6509565cb130"));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.09657753859415763d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.09672774196643863d) + "'", double1 == (-0.09672774196643863d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(30.831374951828842d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03296617629596984d + "'", double1 == 0.03296617629596984d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5729.5779513082325d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test243() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test243");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed(3L);
//        randomDataImpl1.reSeedSecure();
//        try {
//            long long26 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 95.61607815458521d + "'", double16 == 95.61607815458521d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 95.61607815458521d + "'", double17 == 95.61607815458521d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 115.10693406242883d + "'", double18 == 115.10693406242883d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 96.64539920479355d + "'", double21 == 96.64539920479355d);
//    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100L + "'", number4.equals(100L));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (-1L), 96.97276911081677d, 0.0d, (int) (short) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray15 = convergenceException14.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable13, objArray15);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException22.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        java.lang.Object[] objArray30 = numberIsTooSmallException28.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray30);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable23, objArray30);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException16, "874d9298f1", objArray30);
        org.apache.commons.math.exception.util.Localizable localizable34 = maxIterationsExceededException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number41 = numberIsTooSmallException40.getMin();
        java.lang.Object[] objArray42 = numberIsTooSmallException40.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException48);
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray52 = convergenceException51.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable50, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException40, "874d9298f1", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException16, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray52);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 0L + "'", number41.equals(0L));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414213562373095d + "'", double1 == 1.414213562373095d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 5, 0.9828486384357583d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.863867293499003d + "'", double2 == 4.863867293499003d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        java.lang.Number number8 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed(1L);
//        try {
//            double double12 = randomDataImpl1.nextT((-4.54009603704951E-5d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0 is smaller than, or equal to, the minimum (0): degrees of freedom (-0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "d716b6b16e" + "'", str7.equals("d716b6b16e"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable6, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Object[] objArray23 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable16, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException9, "874d9298f1", objArray23);
        org.apache.commons.math.exception.util.Localizable localizable27 = maxIterationsExceededException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray34 = outOfRangeException33.getSuppressed();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable28, (java.lang.Object[]) throwableArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, (java.lang.Object[]) throwableArray34);
        java.lang.Class<?> wildcardClass37 = mathIllegalArgumentException36.getClass();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(wildcardClass37);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 104.0888593931747d, (java.lang.Number) (-1L), (java.lang.Number) 98.48832680232762d);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        java.lang.Number number7 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 10.0f + "'", number7.equals(10.0f));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 23L, 103.63345634712675d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.3203389930892622d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 97.99166523593858d, (java.lang.Number) 5729.5779513082325d, true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.special.Erf.erf(89.22059212019667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number1, (java.lang.Number) (byte) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15);
        java.lang.Object[] objArray17 = numberIsTooSmallException15.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable10, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 100);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray36 = convergenceException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable34, objArray36);
        java.lang.Object[] objArray39 = new java.lang.Object[] { maxIterationsExceededException37, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable10, objArray39);
        outOfRangeException3.addSuppressed((java.lang.Throwable) convergenceException41);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray39);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 8, (double) 8, 86.2522636056895d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.13958653195059692d + "'", double4 == 0.13958653195059692d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9869681962677315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Object[] objArray12 = numberIsTooSmallException10.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable5, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray23 = convergenceException22.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException24 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable21, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray34 = convergenceException33.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable32, objArray34);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        java.lang.Object[] objArray49 = numberIsTooSmallException47.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable42, objArray49);
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException35, "874d9298f1", objArray49);
        org.apache.commons.math.exception.util.Localizable localizable53 = maxIterationsExceededException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable55, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number60 = numberIsTooSmallException59.getMin();
        java.lang.Object[] objArray61 = numberIsTooSmallException59.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67);
        org.apache.commons.math.exception.util.Localizable localizable69 = convergenceException68.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray71 = convergenceException70.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable69, objArray71);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException59, "874d9298f1", objArray71);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException35, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)", objArray71);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable5, objArray71);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 0L + "'", number60.equals(0L));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray71);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Object[] objArray13 = numberIsTooSmallException11.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable6, objArray13);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException20);
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray24 = convergenceException23.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable22, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, objArray24);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.8426819462428745d, (java.lang.Number) 1.5703460430760796d, true);
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(number31, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str39 = numberIsTooLargeException38.toString();
        boolean boolean40 = numberIsTooLargeException38.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooLargeException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException46);
        org.apache.commons.math.exception.util.Localizable localizable48 = convergenceException47.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray50 = convergenceException49.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable48, objArray50);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.exception.util.Localizable localizable58 = convergenceException57.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException63);
        java.lang.Object[] objArray65 = numberIsTooSmallException63.getArguments();
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable58, objArray65);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException51, "874d9298f1", objArray65);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException34, localizable41, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray65);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str39.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) (short) 10);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) notStrictlyPositiveException13);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException13);
        java.lang.Number number16 = notStrictlyPositiveException13.getMin();
        java.lang.Number number17 = notStrictlyPositiveException13.getMin();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0L + "'", number10.equals(0L));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0 + "'", number16.equals(0));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0 + "'", number17.equals(0));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.abs(96.99964959250173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 96.99964959250173d + "'", double1 == 96.99964959250173d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test272() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test272");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double11 = randomDataImpl1.nextT(94.56776430529261d);
//        int int14 = randomDataImpl1.nextInt((int) (short) 0, 3);
//        try {
//            long long17 = randomDataImpl1.nextLong(100L, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (-1): lower bound (100) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 94.15012641344917d + "'", double9 == 94.15012641344917d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.2691381822960574d) + "'", double11 == (-0.2691381822960574d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
//    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int int3 = randomDataImpl0.nextPascal(10, 0.999999898622288d);
        try {
            int int7 = randomDataImpl0.nextHypergeometric((int) (byte) -1, 3, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.log1p(114.61324636976765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.750250537647346d + "'", double1 == 4.750250537647346d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (-0.09672774196643863d), 48.28211899158683d, 5);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) '#', 4.440892098500626E-16d, (double) (short) 0);
        try {
            double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.99627207622075d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: 35 is larger than, or equal to, the maximum (35): endpoints do not specify an interval: [35, 35]");
        } catch (org.apache.commons.math.MathException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Object[] objArray8 = numberIsTooSmallException6.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(6, "", objArray8);
        int int11 = maxIterationsExceededException10.getMaxIterations();
        java.lang.Throwable[] throwableArray12 = maxIterationsExceededException10.getSuppressed();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9772968000788622d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.482280921851396d + "'", double1 == 1.482280921851396d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2130532941206642d + "'", double1 == 1.2130532941206642d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.863867293499003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08489049865162299d + "'", double1 == 0.08489049865162299d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.99822295029797d, (java.lang.Number) (byte) -1, number2);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.atanh(90.67603130189458d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        try {
//            int int21 = randomDataImpl1.nextPascal(2, 1.6449340668481565d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.645 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.16646864257655d + "'", double16 == 100.16646864257655d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.16646864257655d + "'", double17 == 100.16646864257655d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 97.682404599911d + "'", double18 == 97.682404599911d);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(97.32100969214372d, 4.662821141332062d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10471975511965978d + "'", double1 == 0.10471975511965978d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.special.Erf.erf(0.08489049865162299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09555906970756005d + "'", double1 == 0.09555906970756005d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.8426819462428745d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(29);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double2 = org.apache.commons.math.util.FastMath.pow(94.25880042226363d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.010609088971217198d + "'", double2 == 0.010609088971217198d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.cos(116.43740743515626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9803675703591535d) + "'", double1 == (-0.9803675703591535d));
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test293");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextWeibull(1.5703460430760796d, 89.22059212019667d);
//        try {
//            int[] intArray6 = randomDataImpl0.nextPermutation(1, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1): permutation size (10) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 49.85781584562524d + "'", double3 == 49.85781584562524d);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.616984257902569d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2344157932901663d + "'", double1 == 2.2344157932901663d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.ulp(117.6101128309024d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 1 + "'", number5.equals((byte) 1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.ulp(117.28704851075513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.expm1(110.85305377669681d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3895352142420738E48d + "'", double1 == 1.3895352142420738E48d);
    }

//    @Test
//    public void test301() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test301");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double18 = randomDataImpl1.nextUniform((double) (short) 1, 100.88832094586432d);
//        double double21 = randomDataImpl1.nextGamma((double) 99L, (double) (short) 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 102.58815734270136d + "'", double14 == 102.58815734270136d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 102.58815734270136d + "'", double15 == 102.58815734270136d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 14.528153679994157d + "'", double18 == 14.528153679994157d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 9174.24714042624d + "'", double21 == 9174.24714042624d);
//    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        randomDataImpl0.reSeed((long) (short) 10);
//        try {
//            double double7 = randomDataImpl0.nextChiSquare((-1.3203389930892622d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.66 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 64.10456497019302d + "'", double3 == 64.10456497019302d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 96.73501783446021d, (-0.9999999999999999d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(98.95946939207121d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5669.959939019731d + "'", double1 == 5669.959939019731d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.414213562373095d + "'", double1 == 2.414213562373095d);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double11 = randomDataImpl1.nextT(94.56776430529261d);
//        try {
//            double double14 = randomDataImpl1.nextF(1.414213562373095d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 98.0630855613712d + "'", double9 == 98.0630855613712d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.31293846874285197d + "'", double11 == 0.31293846874285197d);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 104.68261590166522d, (java.lang.Number) 0.07608266144434628d, true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int1 = org.apache.commons.math.util.FastMath.abs(19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 19 + "'", int1 == 19);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0L, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7018.97705381157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.549519943057032d + "'", double1 == 9.549519943057032d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6750663910725149d) + "'", double1 == (-0.6750663910725149d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(93.402801731112d, 0.08489049865162299d, 80.0064206060725d, 29);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Object[] objArray14 = numberIsTooSmallException12.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable7, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException22.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray25 = convergenceException24.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable23, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable7, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number33 = numberIsTooSmallException32.getMin();
        java.lang.Object[] objArray34 = numberIsTooSmallException32.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException(19, localizable7, objArray34);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 94.25880042226363d, (java.lang.Number) 117.89454517635374d, false);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 0L + "'", number33.equals(0L));
        org.junit.Assert.assertNotNull(objArray34);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3051295716429426d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9869681962677315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7560665848291341d + "'", double1 == 0.7560665848291341d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 101.98096936685236d, (java.lang.Number) 0.1411200080598672d, false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.0d, 97.22393257284696d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.441207513427252E46d + "'", double2 == 2.441207513427252E46d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        java.lang.Object[] objArray14 = numberIsTooSmallException12.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable7, objArray14);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray22 = outOfRangeException21.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable7, (java.lang.Object[]) throwableArray22);
        java.lang.Throwable[] throwableArray24 = mathIllegalArgumentException23.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", (java.lang.Object[]) throwableArray24);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 16, 95L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl1.getClass();
//        double double11 = randomDataImpl1.nextWeibull(0.9792394759119608d, (double) ' ');
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double15 = randomDataImpl1.nextGaussian((double) 5, (-57.29577951308232d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -57.296 is smaller than, or equal to, the minimum (0): standard deviation (-57.296)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "de5760f89c" + "'", str7.equals("de5760f89c"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 12.598217232167608d + "'", double11 == 12.598217232167608d);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.acos(98.96751045425805d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.027181892591221314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99963059510315d + "'", double1 == 0.99963059510315d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5730.0d + "'", double1 == 5730.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) (short) 0, true);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 20, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double10 = normalDistributionImpl8.sample();
//        double double12 = normalDistributionImpl8.cumulativeProbability(95.04360775167872d);
//        double double14 = normalDistributionImpl8.cumulativeProbability(115.6184208536714d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 110.9669670443555d + "'", double9 == 110.9669670443555d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 96.22844209218708d + "'", double10 == 96.22844209218708d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.3100744865539534d + "'", double12 == 0.3100744865539534d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.9408374026723004d + "'", double14 == 0.9408374026723004d);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double2 = org.apache.commons.math.util.FastMath.atan2(98.23397671247328d, (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2285270156055852d + "'", double2 == 1.2285270156055852d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(64.246770768467d, 0.003404141117823663d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.2130532941206642d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7943731430747654d + "'", double1 == 0.7943731430747654d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.14377302291854d, 0.8426819462428745d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.4711276743037347d, 114.81009190647389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4575940860624544E-49d + "'", double2 == 1.4575940860624544E-49d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.Object[] objArray12 = numberIsTooSmallException10.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException(localizable5, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = convergenceException28.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable27, objArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] { maxIterationsExceededException30, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException44);
        java.lang.Object[] objArray46 = numberIsTooSmallException44.getArguments();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable39, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = convergenceException54.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray57 = convergenceException56.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable55, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray57);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException14, localizable20, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable61 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable61, (java.lang.Number) 1.5574077246549023d, (java.lang.Number) 10, false);
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number67, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException74);
        org.apache.commons.math.exception.util.Localizable localizable76 = convergenceException75.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray78 = convergenceException77.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable76, objArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray81 = convergenceException80.getArguments();
        org.apache.commons.math.MathException mathException82 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException69, localizable76, objArray81);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable61, objArray81);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizable61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable61.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNotNull(objArray81);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6449340668481565d, 1.5430806348152437d);
    }

//    @Test
//    public void test343() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test343");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double11 = normalDistributionImpl8.cumulativeProbability(0.0d);
//        try {
//            double double14 = normalDistributionImpl8.cumulativeProbability(1.3877787807814457E-17d, (double) 0);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 96.59886980544d + "'", double9 == 96.59886980544d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 95.04360775167872d, (java.lang.Number) 0.9408374026723004d, (java.lang.Number) 96.22844209218708d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NEGATIVE_INFINITY, (double) 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.009815746845134038d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009864079298467167d + "'", double1 == 0.009864079298467167d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        java.lang.Class<?> wildcardClass8 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed(1L);
//        try {
//            java.lang.String str12 = randomDataImpl1.nextHexString((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "215d552a38" + "'", str7.equals("215d552a38"));
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(110.9669670443555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.805418750868741d + "'", double1 == 4.805418750868741d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double2 = randomDataImpl0.nextT((-1.5707963267948966d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.571 is smaller than, or equal to, the minimum (0): degrees of freedom (-1.571)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(99.26982479992046d, 103.53479945840866d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.26982479992047d + "'", double2 == 99.26982479992047d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9828486384357583d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long1 = org.apache.commons.math.util.FastMath.round(102.30333457672478d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 102L + "'", long1 == 102L);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int int13 = randomDataImpl1.nextHypergeometric(6, (int) (byte) 0, 5);
//        randomDataImpl1.reSeedSecure(3L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 93.7695170159583d + "'", double9 == 93.7695170159583d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double2 = org.apache.commons.math.util.FastMath.max(101.87176305644743d, 0.003404141117823663d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.87176305644743d + "'", double2 == 101.87176305644743d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.1411200080598672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1406557591404105d + "'", double1 == 0.1406557591404105d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Object[] objArray8 = numberIsTooSmallException6.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(6, "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        java.lang.Throwable[] throwableArray12 = maxIterationsExceededException10.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException17);
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException24);
        java.lang.Object[] objArray26 = numberIsTooSmallException24.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable19, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException10, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)", objArray26);
        java.lang.String str30 = mathException29.getPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str30.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 1.4179552690742248E-9d, (java.lang.Number) 0.9709085856446726d);
        java.lang.Class<?> wildcardClass4 = outOfRangeException3.getClass();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        long long1 = org.apache.commons.math.util.FastMath.round(5.285552882622063d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double1 = org.apache.commons.math.util.FastMath.atan(108.3433959203032d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5615666769776089d + "'", double1 == 1.5615666769776089d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double1 = org.apache.commons.math.util.FastMath.ceil(111.6701264432292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 112.0d + "'", double1 == 112.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.log(116.43740743515626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.757353853386988d + "'", double1 == 4.757353853386988d);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test365");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed(3L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.1731111490062d + "'", double16 == 100.1731111490062d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 95.8032486203611d + "'", double17 == 95.8032486203611d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 104.23735569709537d + "'", double18 == 104.23735569709537d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 96.202367877251d + "'", double21 == 96.202367877251d);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.special.Erf.erf(98.96751045425805d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test367() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test367");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        java.lang.String str2 = randomDataImpl0.nextSecureHexString((int) (byte) 100);
//        long long5 = randomDataImpl0.nextSecureLong((long) 10, (long) 29);
//        try {
//            int int8 = randomDataImpl0.nextSecureInt((int) '#', 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (35): lower bound (35) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "9e49dcd6d719e16fe7b8b57784d3589ec8b48d65752940ac292fe26d8143b07ed0a5b31535ea7b711c61d0bc688169f8f5a0" + "'", str2.equals("9e49dcd6d719e16fe7b8b57784d3589ec8b48d65752940ac292fe26d8143b07ed0a5b31535ea7b711c61d0bc688169f8f5a0"));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 21L + "'", long5 == 21L);
//    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) (short) 10);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        java.lang.Number number11 = notStrictlyPositiveException8.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 16L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 16.0f + "'", float1 == 16.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.6118933276547492d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextBinomial(29, 89.90122293555837d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 89.901 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 100);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number7 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable6, objArray8);
        java.lang.Number number10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, number10, (java.lang.Number) 1.6962822528931225d, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 7.597067861833704d, (java.lang.Number) 98.95946939207121d, (java.lang.Number) 5L);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(2);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta(2.220446049250313E-16d, (double) (byte) 100);
//        double double6 = randomDataImpl0.nextGamma(100.0d, 15.341372134320396d);
//        try {
//            double double9 = randomDataImpl0.nextBeta(0.0d, 114.10287567084337d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.911");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.127895840325991E-9d + "'", double3 == 1.127895840325991E-9d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1421.8437943187862d + "'", double6 == 1421.8437943187862d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable6, objArray8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Object[] objArray23 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable16, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException9, "874d9298f1", objArray23);
        java.lang.Throwable[] throwableArray27 = convergenceException26.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException32);
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray36 = convergenceException35.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable34, objArray36);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException42);
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException49);
        java.lang.Object[] objArray51 = numberIsTooSmallException49.getArguments();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable44, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException37, "874d9298f1", objArray51);
        org.apache.commons.math.exception.util.Localizable localizable55 = maxIterationsExceededException37.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException60);
        org.apache.commons.math.exception.util.Localizable localizable62 = convergenceException61.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray64 = convergenceException63.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable62, objArray64);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException70 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException70);
        org.apache.commons.math.exception.util.Localizable localizable72 = convergenceException71.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException77);
        java.lang.Object[] objArray79 = numberIsTooSmallException77.getArguments();
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable72, objArray79);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException65, "874d9298f1", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException(localizable55, objArray79);
        convergenceException26.addSuppressed((java.lang.Throwable) convergenceException83);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 97.0f, 95.37655109504237d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray10 = convergenceException9.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable8, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = convergenceException17.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        java.lang.Object[] objArray25 = numberIsTooSmallException23.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException(localizable18, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException11, "874d9298f1", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable29 = maxIterationsExceededException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable31, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray36 = outOfRangeException35.getSuppressed();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable30, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(0, "f17231d8539930d4f3db9e0fcea6d3f53abb87b667b5d32f46ac4995ccaacf9c97f63b52cc852b45cef5a822995bcdd104c6", (java.lang.Object[]) throwableArray36);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray36);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.expm1(14.439291055976375d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1865968.0164224785d + "'", double1 == 1865968.0164224785d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.sinh(37.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.859571186401306E15d + "'", double1 == 5.859571186401306E15d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 123.31814879619301d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-0.9999999999999999d), 93.93521237597699d, 101.18841336952065d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double2 = org.apache.commons.math.util.FastMath.pow(98.72913154209108d, 7.597067861833704d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4188497845252515E15d + "'", double2 == 1.4188497845252515E15d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.floor(118.96854919413832d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 118.0d + "'", double1 == 118.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.exp(15.341372134320396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4599104.34236819d + "'", double1 == 4599104.34236819d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.7964772915954081d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0283605149516701d + "'", double1 == 1.0283605149516701d);
    }

//    @Test
//    public void test394() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test394");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        double double6 = randomDataImpl0.nextBeta(97.99166523593858d, 2.220446049250313E-16d);
//        try {
//            double double9 = randomDataImpl0.nextUniform(93.93521237597699d, 7.597067861833704d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 93.935 is larger than, or equal to, the maximum (7.597): lower bound (93.935) must be strictly less than upper bound (7.597)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 61.96127127687888d + "'", double3 == 61.96127127687888d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9999999989229488d + "'", double6 == 0.9999999989229488d);
//    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number1, (java.lang.Number) (byte) -1);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 13.0f + "'", float1 == 13.0f);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(4.757353853386988d, 111.6701264432292d, 0.6829129965667574d, 5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException(localizable2, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = convergenceException16.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable15, objArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException23);
        org.apache.commons.math.exception.util.Localizable localizable25 = convergenceException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException30);
        java.lang.Object[] objArray32 = numberIsTooSmallException30.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable25, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException18, "874d9298f1", objArray32);
        org.apache.commons.math.exception.util.Localizable localizable36 = maxIterationsExceededException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException(localizable38, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray43 = outOfRangeException42.getSuppressed();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable37, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException6, localizable8, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable1, (java.lang.Object[]) throwableArray43);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray43);
    }

//    @Test
//    public void test399() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test399");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        double double10 = randomDataImpl1.nextF(0.09966865249116202d, 98.48832680232762d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2313c313c6" + "'", str7.equals("2313c313c6"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.003704240824932957d + "'", double10 == 0.003704240824932957d);
//    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 93.55510556243662d, (java.lang.Number) 103.63345634712675d, true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.08489049865162299d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.acosh(97.22393257284696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.270137632506118d + "'", double1 == 5.270137632506118d);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        try {
//            long long5 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 170.5446006067936d + "'", double3 == 170.5446006067936d);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray8 = convergenceException7.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable6, objArray8);
        int int10 = maxIterationsExceededException9.getMaxIterations();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException9);
        java.lang.String str12 = mathException11.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 32 + "'", int10 == 32);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{0}" + "'", str12.equals("{0}"));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double2 = org.apache.commons.math.util.FastMath.pow(95.51416029381322d, 35.62934742622575d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.536081112931281E70d + "'", double2 == 3.536081112931281E70d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0283605149516701d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextBeta(48.28211899158683d, (double) (short) 1);
//        double double7 = randomDataImpl1.nextGamma(98.48832680232762d, 1.0d);
//        java.lang.String str9 = randomDataImpl1.nextSecureHexString(100);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9986529189326178d + "'", double4 == 0.9986529189326178d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 99.31663451903154d + "'", double7 == 99.31663451903154d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "59decfb634999d1f3bba910817e69cc4f36031d873e89f0fba3cc38b8543bfbc89226dd0a433f3ecc5c05ee36a080218b0ac" + "'", str9.equals("59decfb634999d1f3bba910817e69cc4f36031d873e89f0fba3cc38b8543bfbc89226dd0a433f3ecc5c05ee36a080218b0ac"));
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double12 = normalDistributionImpl11.getStandardDeviation();
//        double double13 = normalDistributionImpl11.getMean();
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "facdefc69d" + "'", str7.equals("facdefc69d"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 115.46099786457187d + "'", double14 == 115.46099786457187d);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(101.98096936685236d, 7018.97705381157d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(105.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 382.25858877305996d + "'", double1 == 382.25858877305996d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.log(93.93521237597699d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.542605314598987d + "'", double1 == 4.542605314598987d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(52.01192824816565d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.exp(103.53479945840866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.217053105365088E44d + "'", double1 == 9.217053105365088E44d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double2 = org.apache.commons.math.util.FastMath.atan2(8.686892974894768E42d, 0.8483011693542782d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray9 = convergenceException8.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable7, objArray9);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22);
        java.lang.Object[] objArray24 = numberIsTooSmallException22.getArguments();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable17, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException10, "874d9298f1", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable28 = maxIterationsExceededException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException33);
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray37 = convergenceException36.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable35, objArray37);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = convergenceException44.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException50 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException50);
        java.lang.Object[] objArray52 = numberIsTooSmallException50.getArguments();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable45, objArray52);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException38, "874d9298f1", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable28, objArray52);
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number58, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException65 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException65);
        org.apache.commons.math.exception.util.Localizable localizable67 = convergenceException66.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray69 = convergenceException68.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable67, objArray69);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray72 = convergenceException71.getArguments();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException60, localizable67, objArray72);
        java.lang.Class<?> wildcardClass74 = localizable67.getClass();
        java.lang.Object[] objArray75 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable67, objArray75);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException81);
        java.lang.Object[] objArray83 = numberIsTooSmallException81.getArguments();
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray83);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException85 = new org.apache.commons.math.MaxIterationsExceededException(3, localizable28, objArray83);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(wildcardClass74);
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 8, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.min(102.58815734270136d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) 10);
//        try {
//            double double11 = randomDataImpl1.nextWeibull((-181.0d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -181 is smaller than, or equal to, the minimum (0): shape (-181)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        long long1 = org.apache.commons.math.util.FastMath.round(10.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 20, 0.3051295716429426d, 3.8975613173184227d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Object[] objArray9 = numberIsTooSmallException7.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException(6, "", objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = maxIterationsExceededException11.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException(localizable12, (java.lang.Number) 100.88832094586432d, (java.lang.Number) (-4.54009603704951E-5d), (java.lang.Number) 1.6962822528931225d);
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number18, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = convergenceException28.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable27, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray32 = convergenceException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException20, localizable27, objArray32);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(32, localizable12, objArray32);
        int int35 = maxIterationsExceededException34.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 32 + "'", int35 == 32);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = convergenceException15.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable14, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "874d9298f1", objArray16);
        java.lang.String str19 = convergenceException18.getPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException25);
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray29 = convergenceException28.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable27, objArray29);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException42);
        java.lang.Object[] objArray44 = numberIsTooSmallException42.getArguments();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable37, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException30, "874d9298f1", objArray44);
        java.lang.Throwable[] throwableArray48 = convergenceException47.getSuppressed();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException18, "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)", (java.lang.Object[]) throwableArray48);
        java.lang.String str50 = convergenceException18.getPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "874d9298f1" + "'", str19.equals("874d9298f1"));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "874d9298f1" + "'", str50.equals("874d9298f1"));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(98.95946939207121d, 1.6962822528931225d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.sinh(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6916735960212525E41d + "'", double1 == 6.6916735960212525E41d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9803675703591535d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017110641982544396d) + "'", double1 == (-0.017110641982544396d));
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        double double6 = randomDataImpl0.nextBeta(97.99166523593858d, 2.220446049250313E-16d);
//        long long8 = randomDataImpl0.nextPoisson(103.63345634712675d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 139.4408121499155d + "'", double3 == 139.4408121499155d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9999999988545367d + "'", double6 == 0.9999999988545367d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 98L + "'", long8 == 98L);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 91.91207251291225d, (java.lang.Number) 1.5574077246549023d, false);
        java.lang.Number number10 = numberIsTooSmallException9.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 91.91207251291225d + "'", number10.equals(91.91207251291225d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number3, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray14 = convergenceException13.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable12, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray17 = convergenceException16.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException(6, "a65f76c177", objArray17);
        int int20 = maxIterationsExceededException19.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.466711037884725d + "'", double1 == 3.466711037884725d);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double11 = randomDataImpl1.nextT(94.56776430529261d);
//        int int14 = randomDataImpl1.nextInt((int) (short) 0, 3);
//        try {
//            double double17 = randomDataImpl1.nextGamma((double) 0L, 108.3433959203032d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 90.64316694888525d + "'", double9 == 90.64316694888525d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.5744891937885004d + "'", double11 == 1.5744891937885004d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(95.37655109504237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.76609190490456d + "'", double1 == 9.76609190490456d);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        randomDataImpl1.reSeed((-1L));
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 97.81007756165205d + "'", double9 == 97.81007756165205d);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3100744865539534d, 110.3534309428449d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.612582570464919E-57d + "'", double2 == 7.612582570464919E-57d);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed();
//        java.lang.String str24 = randomDataImpl1.nextHexString(5);
//        double double27 = randomDataImpl1.nextWeibull(96.01443777356859d, 94.56776430529261d);
//        double double30 = randomDataImpl1.nextF(101.18841336952065d, 2.0811768202028248E-23d);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 114.40101097080965d + "'", double16 == 114.40101097080965d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 114.40101097080965d + "'", double17 == 114.40101097080965d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 107.67215043696048d + "'", double18 == 107.67215043696048d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 94.78636366686185d + "'", double21 == 94.78636366686185d);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "9968d" + "'", str24.equals("9968d"));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 93.89122369317954d + "'", double27 == 93.89122369317954d);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.4280448826188107E-9d + "'", double30 == 3.4280448826188107E-9d);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        randomDataImpl0.reSeed((long) (short) 10);
//        try {
//            int int8 = randomDataImpl0.nextInt((int) '#', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (0): lower bound (35) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 143.90733517217427d + "'", double3 == 143.90733517217427d);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test437");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed();
//        java.lang.String str24 = randomDataImpl1.nextHexString(5);
//        double double27 = randomDataImpl1.nextWeibull(96.01443777356859d, 94.56776430529261d);
//        int int30 = randomDataImpl1.nextZipf(100, 1.6449340668481565d);
//        try {
//            int[] intArray33 = randomDataImpl1.nextPermutation((int) '4', (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 83.31565262127269d + "'", double16 == 83.31565262127269d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 111.65394520087528d + "'", double17 == 111.65394520087528d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 108.4522750372065d + "'", double18 == 108.4522750372065d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 96.75221659256874d + "'", double21 == 96.75221659256874d);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "2c7e8" + "'", str24.equals("2c7e8"));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 95.6141234253985d + "'", double27 == 95.6141234253985d);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        long long1 = org.apache.commons.math.util.FastMath.round(99.31663451903154d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(Double.NEGATIVE_INFINITY, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Object[] objArray8 = numberIsTooSmallException6.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray8);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(6, "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = maxIterationsExceededException10.getGeneralPattern();
        java.lang.Throwable[] throwableArray12 = maxIterationsExceededException10.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable13 = maxIterationsExceededException10.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNull(localizable13);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double18 = randomDataImpl1.nextUniform((double) (short) 1, 100.88832094586432d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("facdefc69d", "38ee962b29");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 38ee962b29");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 92.85777757435542d + "'", double14 == 92.85777757435542d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 85.0915035177506d + "'", double15 == 85.0915035177506d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 77.15364817744295d + "'", double18 == 77.15364817744295d);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.acos(118.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.special.Gamma.digamma(96.10253420893275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.560203886678789d + "'", double1 == 4.560203886678789d);
    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        long long9 = randomDataImpl1.nextPoisson(0.8483011693542782d);
//        int int12 = randomDataImpl1.nextBinomial((int) '4', 1.0E-323d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "ae3cf4d470" + "'", str7.equals("ae3cf4d470"));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int int13 = randomDataImpl1.nextHypergeometric(6, (int) (byte) 0, 5);
//        try {
//            int int17 = randomDataImpl1.nextHypergeometric((int) (byte) -1, 18, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 104.06533463785996d + "'", double9 == 104.06533463785996d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.5772156649015329d, (java.lang.Number) 98.96751045425805d, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.Object[] objArray13 = numberIsTooSmallException11.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray13);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(6, "", objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        java.lang.Object[] objArray23 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray39 = convergenceException38.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable37, objArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { maxIterationsExceededException40, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray42);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = convergenceException48.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException54);
        java.lang.Object[] objArray56 = numberIsTooSmallException54.getArguments();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable49, objArray56);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException63);
        org.apache.commons.math.exception.util.Localizable localizable65 = convergenceException64.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray67 = convergenceException66.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable65, objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray67);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException24, localizable30, objArray67);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable16, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException("44e4c9f10c", objArray67);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizable65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable65.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        convergenceException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException4);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.03296617629596984d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.0811768202028248E-23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        long long8 = randomDataImpl1.nextLong((long) (-1), (long) 10);
//        int int11 = randomDataImpl1.nextPascal(100, 1.3877787807814457E-17d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 19 + "'", int4 == 19);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 10L + "'", long8 == 10L);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
//    }

//    @Test
//    public void test451() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test451");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double11 = randomDataImpl1.nextChiSquare(6.646306286048102d);
//        long long13 = randomDataImpl1.nextPoisson(98.87038924080616d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 23 + "'", int4 == 23);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 111.68656908994745d + "'", double9 == 111.68656908994745d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.246871377515902d + "'", double11 == 4.246871377515902d);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 88L + "'", long13 == 88L);
//    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(35.62934742622575d, 180.0d, 4.440892098500626E-16d);
        double double4 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.62934742622575d + "'", double4 == 35.62934742622575d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 52.0f, 98.23397671247328d);
        normalDistributionImpl2.reseedRandomGenerator((long) 32);
        normalDistributionImpl2.reseedRandomGenerator(3L);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int int3 = randomDataImpl0.nextPascal(10, 0.999999898622288d);
//        int int6 = randomDataImpl0.nextSecureInt(10, 35);
//        try {
//            int int9 = randomDataImpl0.nextBinomial(29, 1.5606824199881275d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.561 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 20 + "'", int6 == 20);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.07608266144434628d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07622980546052151d + "'", double1 == 0.07622980546052151d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(105.53451078593605d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double17 = normalDistributionImpl13.inverseCumulativeProbability(0.0d);
//        try {
//            double double20 = normalDistributionImpl13.cumulativeProbability(5669.959939019731d, 4.440892098500626E-16d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 26 + "'", int4 == 26);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 26 + "'", int9 == 26);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 91.99045799591012d + "'", double14 == 91.99045799591012d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 82.72452426410831d + "'", double15 == 82.72452426410831d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + Double.NEGATIVE_INFINITY + "'", double17 == Double.NEGATIVE_INFINITY);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 20, 119.99385063254827d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.0d + "'", double2 == 20.0d);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test463");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed();
//        java.lang.String str24 = randomDataImpl1.nextHexString((int) (short) 100);
//        try {
//            double double27 = randomDataImpl1.nextUniform(117.28704851075513d, 0.1406557591404105d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 117.287 is larger than, or equal to, the maximum (0.141): lower bound (117.287) must be strictly less than upper bound (0.141)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 98.53918959473188d + "'", double16 == 98.53918959473188d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 98.53918959473188d + "'", double17 == 98.53918959473188d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 94.21674993432052d + "'", double18 == 94.21674993432052d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 94.86955659567914d + "'", double21 == 94.86955659567914d);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "e55991c8706d7715e437d39a4f89655e6b2da368ff49bbf5b16a0754be47703f65059663c1f3c2a954605f8d558c5b8a862a" + "'", str24.equals("e55991c8706d7715e437d39a4f89655e6b2da368ff49bbf5b16a0754be47703f65059663c1f3c2a954605f8d558c5b8a862a"));
//    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.270137632506118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0919812537204907d + "'", double1 == 0.0919812537204907d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.3862943611198906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.875d + "'", double1 == 1.875d);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        int[] intArray8 = randomDataImpl1.nextPermutation(100, (int) '#');
//        double double11 = randomDataImpl1.nextGamma(0.3051295716429426d, (double) 10);
//        try {
//            double double13 = randomDataImpl1.nextExponential((-0.9803675703591535d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.98 is smaller than, or equal to, the minimum (0): mean (-0.98)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertNotNull(intArray8);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.054351680673142035d + "'", double11 == 0.054351680673142035d);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.log(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed();
//        double double25 = randomDataImpl1.nextBeta(95.37655109504237d, 2.718281828459045d);
//        int int28 = randomDataImpl1.nextZipf(32, 0.3100744865539534d);
//        int int31 = randomDataImpl1.nextZipf(5, 24.391618954720006d);
//        double double33 = randomDataImpl1.nextExponential((double) 20);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 96.3810754811746d + "'", double16 == 96.3810754811746d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 96.3810754811746d + "'", double17 == 96.3810754811746d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 94.14227096886397d + "'", double18 == 94.14227096886397d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 97.62340450270275d + "'", double21 == 97.62340450270275d);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.9652282523132357d + "'", double25 == 0.9652282523132357d);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 13.220570549930937d + "'", double33 == 13.220570549930937d);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.0E-323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-323d + "'", double2 == 1.0E-323d);
    }

//    @Test
//    public void test470() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test470");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta(2.220446049250313E-16d, (double) (byte) 100);
//        double double6 = randomDataImpl0.nextGamma(100.0d, 15.341372134320396d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1576.024721944808d + "'", double6 == 1576.024721944808d);
//    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.tanh(98.02793393297866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Object[] objArray6 = numberIsTooSmallException4.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray16 = convergenceException15.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable14, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException4, "874d9298f1", objArray16);
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(number19, (java.lang.Number) 10.0f, false);
        java.lang.Number number23 = numberIsTooSmallException22.getArgument();
        java.lang.Throwable[] throwableArray24 = numberIsTooSmallException22.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable26, (java.lang.Number) (short) 100);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException42);
        java.lang.Object[] objArray44 = numberIsTooSmallException42.getArguments();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable37, objArray44);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str52 = numberIsTooLargeException51.toString();
        boolean boolean53 = numberIsTooLargeException51.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException51.getGeneralPattern();
        java.lang.Object[] objArray55 = new java.lang.Object[] { "org.apache.commons.math.exception.OutOfRangeException: 100 out of [1, -0.904] range", 97.99166523593858d, objArray44, 3.141592653589793d, localizable54 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException28, "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0)", objArray44);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, localizable25, objArray44);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 9.76609190490456d);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str52.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray55);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.7943731430747654d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8805944468153895d + "'", double1 == 0.8805944468153895d);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(100.0d, (double) 'a');
//        randomDataImpl1.reSeed();
//        java.lang.String str24 = randomDataImpl1.nextHexString(5);
//        double double27 = randomDataImpl1.nextWeibull(96.01443777356859d, 94.56776430529261d);
//        try {
//            int int30 = randomDataImpl1.nextBinomial((int) ' ', 9.549519943057032d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 9.55 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 120.86562111037189d + "'", double16 == 120.86562111037189d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 120.86562111037189d + "'", double17 == 120.86562111037189d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 90.50048972738041d + "'", double18 == 90.50048972738041d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 95.26088967575608d + "'", double21 == 95.26088967575608d);
//        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "424b2" + "'", str24.equals("424b2"));
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 94.60949649684828d + "'", double27 == 94.60949649684828d);
//    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        double double7 = normalDistributionImpl3.cumulativeProbability(114.61324636976765d);
//        double double8 = normalDistributionImpl3.getMean();
//        double double11 = normalDistributionImpl3.cumulativeProbability(0.9828486384357583d, 102.13604969293748d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 87.29848580611423d + "'", double4 == 87.29848580611423d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 96.39682817867701d + "'", double5 == 96.39682817867701d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9280368141061136d + "'", double7 == 0.9280368141061136d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5845724380489857d + "'", double11 == 0.5845724380489857d);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.cos(96.04390339096003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.22342555280302118d) + "'", double1 == (-0.22342555280302118d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.7666337465818244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0442986324957508d) + "'", double1 == (-1.0442986324957508d));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 88L, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double double1 = org.apache.commons.math.util.FastMath.tanh(90.67603130189458d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1865968.0164224785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.507727997313818E7d + "'", double1 == 2.507727997313818E7d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(7018.97705381157d, 139.0512498029074d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        boolean boolean7 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) (short) 10);
        java.lang.String str11 = notStrictlyPositiveException10.toString();
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException10.getGeneralPattern();
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(number13, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str21 = numberIsTooLargeException20.toString();
        boolean boolean22 = numberIsTooLargeException20.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray32 = convergenceException31.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable30, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException45);
        java.lang.Object[] objArray47 = numberIsTooSmallException45.getArguments();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable40, objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException33, "874d9298f1", objArray47);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException16, localizable23, objArray47);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(1, localizable12, objArray47);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException57);
        org.apache.commons.math.exception.util.Localizable localizable59 = convergenceException58.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray61 = convergenceException60.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable59, objArray61);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException67);
        org.apache.commons.math.exception.util.Localizable localizable69 = convergenceException68.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException74);
        java.lang.Object[] objArray76 = numberIsTooSmallException74.getArguments();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable69, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException62, "874d9298f1", objArray76);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException62.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException(localizable82, (java.lang.Number) 100L, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.9036922050915067d));
        java.lang.Throwable[] throwableArray87 = outOfRangeException86.getSuppressed();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException(localizable81, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable80, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable12, (java.lang.Object[]) throwableArray87);
        org.apache.commons.math.exception.util.Localizable localizable91 = mathIllegalArgumentException90.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)" + "'", str11.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str21.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(throwableArray87);
        org.junit.Assert.assertTrue("'" + localizable91 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable91.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        org.apache.commons.math.random.RandomGenerator randomGenerator2 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl3 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator2);
//        int int6 = randomDataImpl3.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator7 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl8 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator7);
//        int int11 = randomDataImpl8.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl15 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double16 = randomDataImpl8.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double17 = randomDataImpl3.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double18 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl15);
//        double double21 = randomDataImpl1.nextWeibull(6.646306286048102d, (double) (byte) 10);
//        try {
//            randomDataImpl1.setSecureAlgorithm("188ebc5ee0", "874d9298f1");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 874d9298f1");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 14 + "'", int6 == 14);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 14 + "'", int11 == 14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 105.66845785074152d + "'", double16 == 105.66845785074152d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 101.13154860002889d + "'", double17 == 101.13154860002889d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 114.65920666828866d + "'", double18 == 114.65920666828866d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 9.716920221676009d + "'", double21 == 9.716920221676009d);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double2 = org.apache.commons.math.util.FastMath.min(1.6253600733206826E-9d, (double) 99L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6253600733206826E-9d + "'", double2 == 1.6253600733206826E-9d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.5772156649015329d, (java.lang.Number) 98.96751045425805d, (java.lang.Number) 0.5403023058681398d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) 100L, false);
        java.lang.String str8 = numberIsTooLargeException7.toString();
        boolean boolean9 = numberIsTooLargeException7.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException7.getGeneralPattern();
        java.lang.Number number11 = numberIsTooLargeException7.getMax();
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException7);
        java.lang.Number number13 = numberIsTooLargeException7.getMax();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100L + "'", number11.equals(100L));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 100L + "'", number13.equals(100L));
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform(0.0d, 180.0d);
//        randomDataImpl0.reSeed((long) (short) 10);
//        java.lang.String str7 = randomDataImpl0.nextHexString(29);
//        double double9 = randomDataImpl0.nextChiSquare(1.3862943611198906d);
//        double double11 = randomDataImpl0.nextChiSquare(0.04005020606749013d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution12 = null;
//        try {
//            int int13 = randomDataImpl0.nextInversionDeviate(integerDistribution12);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 165.74073900782787d + "'", double3 == 165.74073900782787d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "52fa7d3a789695f2badd7fc134253" + "'", str7.equals("52fa7d3a789695f2badd7fc134253"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.02970133318441104d + "'", double9 == 0.02970133318441104d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0E-323d + "'", double11 == 1.0E-323d);
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        randomDataImpl1.reSeed();
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double12 = normalDistributionImpl11.getStandardDeviation();
//        double double13 = normalDistributionImpl11.getMean();
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double15 = normalDistributionImpl11.getMean();
//        double double16 = normalDistributionImpl11.sample();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "84e62ec1ae" + "'", str7.equals("84e62ec1ae"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 110.24649100101153d + "'", double14 == 110.24649100101153d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 109.37560423277218d + "'", double16 == 109.37560423277218d);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) -1, number7, (java.lang.Number) (byte) -1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray18 = convergenceException17.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable16, objArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray21 = convergenceException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException9, localizable16, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 0.0f, (java.lang.Number) 0L, true);
        java.lang.Number number28 = numberIsTooSmallException27.getMin();
        java.lang.Object[] objArray29 = numberIsTooSmallException27.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray39 = convergenceException38.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable37, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException27, "874d9298f1", objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3, localizable16, objArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0L + "'", number28.equals(0L));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray39);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.random.RandomGenerator randomGenerator5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator5);
//        int int9 = randomDataImpl6.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double14 = randomDataImpl6.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double18 = randomDataImpl1.nextUniform((double) (short) 1, 100.88832094586432d);
//        try {
//            int int21 = randomDataImpl1.nextPascal(2147483647, 1.0283605149516701d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.028 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 8 + "'", int4 == 8);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 75.86467477828576d + "'", double14 == 75.86467477828576d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.41452816836764d + "'", double15 == 100.41452816836764d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 85.67065938790483d + "'", double18 == 85.67065938790483d);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 35.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 34.99999999999999d + "'", double2 == 34.99999999999999d);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextBeta(2.220446049250313E-16d, (double) (byte) 100);
//        randomDataImpl0.reSeedSecure(0L);
//        double double7 = randomDataImpl0.nextChiSquare(0.9828486384357583d);
//        try {
//            long long9 = randomDataImpl0.nextPoisson((-1.3203389930892622d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.32 is smaller than, or equal to, the minimum (0): mean (-1.32)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6450094669420808E-9d + "'", double3 == 1.6450094669420808E-9d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0110113033479498d + "'", double7 == 1.0110113033479498d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("c51cac2336", objArray1);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException13);
        java.lang.Object[] objArray15 = numberIsTooSmallException13.getArguments();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable8, objArray15);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException21);
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException22.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28);
        org.apache.commons.math.exception.util.Localizable localizable30 = convergenceException29.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray32 = convergenceException31.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable30, objArray32);
        java.lang.Object[] objArray35 = new java.lang.Object[] { maxIterationsExceededException33, (short) 100 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = convergenceException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException47);
        java.lang.Object[] objArray49 = numberIsTooSmallException47.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray49);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable42, objArray49);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException56);
        org.apache.commons.math.exception.util.Localizable localizable58 = convergenceException57.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray60 = convergenceException59.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) ' ', localizable58, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, objArray60);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, localizable23, objArray60);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 139.0512498029074d, (java.lang.Number) Double.NEGATIVE_INFINITY, false);
        java.lang.Number number69 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException71 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 100.14377302291854d, number69, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException75 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException75);
        org.apache.commons.math.exception.util.Localizable localizable77 = convergenceException76.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math.ConvergenceException convergenceException83 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException82);
        java.lang.Object[] objArray84 = numberIsTooSmallException82.getArguments();
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)", objArray84);
        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException(localizable77, objArray84);
        java.lang.Object[] objArray87 = convergenceException86.getArguments();
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable23, objArray87);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(objArray87);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.signum(114.81009190647389d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test498");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextZipf((int) ' ', 1.5430806348152437d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.99822295029797d);
//        double double13 = normalDistributionImpl8.cumulativeProbability(5729.5779513082325d);
//        double double14 = normalDistributionImpl8.sample();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 88.25336010754276d + "'", double9 == 88.25336010754276d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 105.36782774982015d + "'", double14 == 105.36782774982015d);
//    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.536081112931281E70d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.536081112931281E70d + "'", double1 == 3.536081112931281E70d);
    }

//    @Test
//    public void test500() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test500");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, (double) 10, 0.0d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        double double7 = normalDistributionImpl3.cumulativeProbability(114.61324636976765d);
//        normalDistributionImpl3.reseedRandomGenerator((long) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.93083949315454d + "'", double4 == 103.93083949315454d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 114.9947755185382d + "'", double5 == 114.9947755185382d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9280368141061136d + "'", double7 == 0.9280368141061136d);
//    }
//}

