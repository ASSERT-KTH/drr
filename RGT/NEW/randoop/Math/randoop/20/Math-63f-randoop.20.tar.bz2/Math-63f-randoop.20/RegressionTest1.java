import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.7853981633974483d, (double) '#', (double) 84);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.ceil(8.911264043408805E95d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.911264043408805E95d + "'", double1 == 8.911264043408805E95d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3850L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray3 = new double[] { 351.00000000000006d, 0.04684485418779906d, 1.5440680443502757d };
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (351 >= 0.047)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = null;
        int int5 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray15 = new int[] { 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray15);
        int[] intArray20 = new int[] { ' ', (-1), (short) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray20);
        int[] intArray23 = new int[] {};
        int[] intArray28 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray28);
        int[] intArray31 = new int[] { 0 };
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray31);
        int[] intArray36 = new int[] { ' ', (-1), (short) 0 };
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray36);
        int[] intArray38 = new int[] {};
        int[] intArray43 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray43);
        int[] intArray46 = new int[] { 0 };
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray46);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray46);
        try {
            int int49 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(32, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.ceil(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 93.0d + "'", double1 == 93.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 11L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1100L, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1100.0f + "'", float2 == 1100.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.math.util.MathUtils.pow(457133415, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.3370716677274175d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1304428544);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(9.9498743710662d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10188.671355971788d + "'", double2 == 10188.671355971788d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.acosh(107.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.365954178338396d + "'", double1 == 5.365954178338396d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1304428543), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(6.283185307179586d, (double) 34.0f, (-0.920144121650263d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double2 = org.apache.commons.math.util.FastMath.min(35.0d, 1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        long long2 = org.apache.commons.math.util.MathUtils.pow(351L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '#', 42);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998140668686113d + "'", double1 == 0.9998140668686113d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.4946286503353052d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-106.0d), (java.lang.Number) (-0.920144121650263d), (int) '#');
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 457133415, (long) (-106));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 457133309L + "'", long2 == 457133309L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-48456141990L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-613773204) + "'", int1 == (-613773204));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9409 + "'", int2 == 9409);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1078034432L, 0.0d, 2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.apache.commons.math.util.FastMath.min(840L, 1100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 840L + "'", long2 == 840L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-613773204), 5.123999408359393d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 34);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 34L + "'", long1 == 34L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.6637263492000496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.544756829410314d + "'", double1 == 2.544756829410314d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1078034432, (-48456141990L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-613773204), 7.105427357601002E-15d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-471273129), 34L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-471273163L) + "'", long2 == (-471273163L));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, 1078034432L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-3));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection41, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (1 < 52)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.57133415E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5713341500000006E8d + "'", double1 == 4.5713341500000006E8d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5350567286626973d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        long long2 = org.apache.commons.math.util.FastMath.max(1100L, 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1100L + "'", long2 == 1100L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 9409);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-471273163L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.5713341500000006E8d, 360.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 34L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(32, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6536664338884767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6536664338884767d + "'", double1 == 0.6536664338884767d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-48456141990L), 457133415);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0791492469707313E8d + "'", double1 == 2.0791492469707313E8d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1304428544, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.930428393448897E84d + "'", double2 == 3.930428393448897E84d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1078034538L), (float) (-1417987263));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.4179872E9f) + "'", float2 == (-1.4179872E9f));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(34, 34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.ceil(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.0d + "'", double1 == 36.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 6939238083912138753L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.84131178830531d + "'", double1 == 18.84131178830531d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 457133309L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 770.3373509139153d + "'", double1 == 770.3373509139153d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.FastMath.pow(100.0d, 0.8745129512124437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 56.10814393552831d + "'", double2 == 56.10814393552831d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.7182818284590453d, (double) 3628800.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(100.0d, 770.3373509139153d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 840L, 0.04684485418779906d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.093102195050827d + "'", double1 == 3.093102195050827d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double3 = org.apache.commons.math.util.MathUtils.round((-0.0d), (int) '#', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.cos(8.911264043408805E95d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9995746166794132d + "'", double1 == 0.9995746166794132d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.0456935028300002E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray26);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = null;
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = null;
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray14);
        int[] intArray17 = new int[] {};
        int[] intArray22 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray25 = new int[] { 0 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray25);
        int[] intArray30 = new int[] { ' ', (-1), (short) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray30);
        try {
            double double33 = org.apache.commons.math.util.MathUtils.distance(intArray8, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-1L), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.6637263492000496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.signum(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int int2 = org.apache.commons.math.util.FastMath.min(1, 457133415);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 11L, 0, 97);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 2.59068859007500672E17d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1304428544, (-1905511648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-601083104) + "'", int2 == (-601083104));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        float float2 = org.apache.commons.math.util.MathUtils.round(10.0f, (-1304428544));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-90L), (-1.30442854E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.30442854E9f) + "'", float2 == (-1.30442854E9f));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(3628800L, (long) (-471273129));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, (-1304428543));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-9));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.15707963267948966d) + "'", double1 == (-0.15707963267948966d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.2438899565964023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3211147776427881d + "'", double1 == 0.3211147776427881d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1078034539, (long) (-471273129));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 508048710364602531L + "'", long2 == 508048710364602531L);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-3.5786221431902547E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.76837158203125E-7d + "'", double1 == 4.76837158203125E-7d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 9.9498743710662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.078034432E9d, 42);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.741245572507582E21d + "'", double2 == 4.741245572507582E21d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3628800L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 42);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(21.216678938818404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.189484999845426E8d + "'", double1 == 8.189484999845426E8d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[] doubleArray3 = new double[] { 107, 4.57133415E8d, (-3.5786221431902547E9d) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1417987263L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 0, 10, orderDirection9, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection9, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (107 < 457,133,415)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (byte) 1, (long) 457133415);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 8625328718985906577L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(93.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.225622771460043E40d + "'", double1 == 1.225622771460043E40d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 36L, (float) (-1304428544));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.30442854E9f) + "'", float2 == (-1.30442854E9f));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.093102195050827d, 97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.051376329449926d + "'", double2 == 4.051376329449926d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass10 = throwableArray9.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1417987263) + "'", int7 == (-1417987263));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 9409, 360.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 360.0d + "'", double2 == 360.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.lang.Class<?> wildcardClass19 = bigInteger10.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.sinh(60.619082682338295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0604815357003929E26d + "'", double1 == 1.0604815357003929E26d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 508048710364602531L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        int int2 = org.apache.commons.math.util.FastMath.max(9409, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9409 + "'", int2 == 9409);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        double[] doubleArray18 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 100.0d);
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray37 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 100.0d);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray47 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray57 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 100.0d);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray57);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray47);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray47);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray20);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray64);
        try {
            double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1417987263) + "'", int50 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 51.54639175257732d + "'", double63 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.asinh(99.47180355817409d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.2930466684875075d + "'", double1 == 5.2930466684875075d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        int int13 = nonMonotonousSequenceException9.getIndex();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException9.getArgument();
        int int17 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1417987263) + "'", int11 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1417987263) + "'", int12 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1417987263) + "'", int13 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 100 + "'", number16.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1417987263) + "'", int17 == (-1417987263));
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.568018556161576d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 9409);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9409 + "'", int1 == 9409);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 0.0f, 99.47180355817409d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-106));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 36L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6109179126442243d + "'", double1 == 3.6109179126442243d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0413926851582251d + "'", double1 == 1.0413926851582251d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5440680443502757d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 97);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger10);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int1 = org.apache.commons.math.util.MathUtils.hash(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-72925529) + "'", int1 == (-72925529));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        double[] doubleArray17 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 100.0d);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 0.0d);
        double[] doubleArray29 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray38 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 100.0d);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray48 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray48);
        double[] doubleArray58 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray68 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 100.0d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray68);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray58);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray58);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray31);
        double[] doubleArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray22);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1417987263) + "'", int20 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1417987263) + "'", int61 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 51.54639175257732d + "'", double74 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 196.0d + "'", double77 == 196.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.76837158203125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.768372718899808E-7d + "'", double1 == 4.768372718899808E-7d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.024701097142274d, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.616107644349854d + "'", double2 == 6.616107644349854d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.FastMath.pow(36.0d, 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0538095915721569E183d + "'", double2 == 1.0538095915721569E183d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(99L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.2438899565964023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.947040284032006d + "'", double1 == 0.947040284032006d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        float float2 = org.apache.commons.math.util.FastMath.min(34.0f, (float) 1078034432);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6536664338884767d, (double) (-90.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-9));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1100L, 9409);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-48456141990L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-613773204), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.13773204E8d) + "'", double2 == (-6.13773204E8d));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (97 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (97 >= null)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 5.2930466684875075d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 0, (float) 350L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 350.0f + "'", float2 == 350.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.tan(770.3373509139153d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7557182959940781d + "'", double1 == 0.7557182959940781d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1074790400), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1074790400L) + "'", long2 == (-1074790400L));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 457133415);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1905511648));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(97.0d, 2.947878391455509E46d, (-0.8332128969929774d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-90L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray9 = new int[] { 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray9);
        int[] intArray14 = new int[] { ' ', (-1), (short) 0 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray14);
        int[] intArray16 = new int[] {};
        int[] intArray21 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray24 = new int[] { 0 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray24);
        try {
            int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 9409, 0.37686770463809427d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5545968900472659d) + "'", double1 == (-0.5545968900472659d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.acosh(22.827621579236496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8206383563552078d + "'", double1 == 3.8206383563552078d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) -1, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(99.47180355817409d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7361104849871487d + "'", double1 == 1.7361104849871487d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8332128969929774d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.434650553076867d + "'", double1 == 0.434650553076867d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) -1, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double2 = org.apache.commons.math.util.FastMath.max(1.024701097142274d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (byte) 100);
        double[] doubleArray19 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 100.0d);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray19);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection25, false);
        double[] doubleArray34 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 100.0d);
        double[] doubleArray43 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 100.0d);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray53 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 100.0d);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray53);
        double[] doubleArray63 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 100.0d);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray73 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 100.0d);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray73);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray53, doubleArray63);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray63);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray36);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray24);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 117.6010204037363d + "'", double10 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1417987263) + "'", int22 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1417987263) + "'", int46 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1417987263) + "'", int66 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 51.54639175257732d + "'", double79 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 51.54639175257732d + "'", double80 == 51.54639175257732d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1304428544), 0.0d, 84);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.76837158203125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7683715820308884E-7d + "'", double1 == 4.7683715820308884E-7d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.605170185988092d, 1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.570522787271504d + "'", double2 == 10.570522787271504d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 10, 1078034432, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1417987263));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.247833728790283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 100 + "'", number8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 100L + "'", number9.equals(100L));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-90L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 508048710364602531L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.1102230246251565E-16d, (-3.5786221431902547E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1102230246251564E-16d + "'", double2 == 1.1102230246251564E-16d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 0.0f, (-7.089936315E8d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(84);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.314240134565475E126d + "'", double1 == 3.314240134565475E126d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.7683715820308884E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.905339660024616E-4d + "'", double1 == 6.905339660024616E-4d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-3), 4521604579065856L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4521604579065853L + "'", long2 == 4521604579065853L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.032632632268895d + "'", double1 == 9.032632632268895d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 2, (int) (short) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.07803456E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1078034560) + "'", int1 == (-1078034560));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(36.0d, 0.04684485418779906d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 457133405);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.util.FastMath.max(7.105427357601002E-15d, (double) 4.83811676E17f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.8381167629919846E17d + "'", double2 == 4.8381167629919846E17d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.ceil(351.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 351.0d + "'", double1 == 351.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1304428544, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1304428444L + "'", long2 == 1304428444L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 10, (double) (-457133315L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) (-1304428543));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1078034432, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078034431 + "'", int2 == 1078034431);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(9409);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 76683.40485184503d + "'", double1 == 76683.40485184503d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1417987263L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5989247477196274d + "'", double1 == 0.5989247477196274d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(8625328718985906577L, (long) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.0d), 1.0604815357003929E26d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1905511648), (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.90551168E9f) + "'", float2 == (-1.90551168E9f));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1074790400), (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        int int1 = org.apache.commons.math.util.FastMath.abs(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 99 + "'", int1 == 99);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.atan(21.216678938818404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5236984520405024d + "'", double1 == 1.5236984520405024d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(457133415, 457133405);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.947040284032006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9470402840320061d + "'", double1 == 0.9470402840320061d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.089936315E8d), (java.lang.Number) 84, (int) (byte) -1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 84 + "'", number4.equals(84));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (84 >= -708,993,631.5)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (84 >= -708,993,631.5)"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double2 = org.apache.commons.math.util.FastMath.max((double) '#', 97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.00000000000001d + "'", double2 == 97.00000000000001d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1304428544, (-1), 9409);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.04684485418779906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 2, (-1), 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.434650553076867d, (double) 32, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 100.0d);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray46 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 100.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray46);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray26, doubleArray36);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray36);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        try {
            double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1417987263) + "'", int19 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1417987263) + "'", int39 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 117.6010204037363d + "'", double52 == 117.6010204037363d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray13 = new int[] { ' ', (-1), (short) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray23 = new int[] { 0 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray31 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray31);
        int[] intArray34 = new int[] { 0 };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray34);
        int[] intArray39 = new int[] { ' ', (-1), (short) 0 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray39);
        int[] intArray41 = new int[] {};
        int[] intArray46 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int[] intArray49 = new int[] { 0 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray49);
        int[] intArray52 = new int[] {};
        int[] intArray57 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray57);
        int[] intArray60 = new int[] { 0 };
        int int61 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray60);
        int[] intArray65 = new int[] { ' ', (-1), (short) 0 };
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray72 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray67, intArray72);
        int[] intArray75 = new int[] { 0 };
        int int76 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray75);
        int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray49);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        float float3 = org.apache.commons.math.util.MathUtils.round(3628800.0f, (-9), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.0E9f + "'", float3 == 1.0E9f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1304428544));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2766572949795723E7d) + "'", double1 == (-2.2766572949795723E7d));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 100);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (26.804 >= -0.515)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double2 = org.apache.commons.math.util.MathUtils.round(97.00000000000001d, 84);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.00000000000001d + "'", double2 == 97.00000000000001d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1304428444L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int2 = org.apache.commons.math.util.FastMath.min(1304428544, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(3.6109179126442243d, 1.0604815357003929E26d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0604815357003929E26d + "'", double2 == 1.0604815357003929E26d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 48.45360824742268d, 1.225622771460043E40d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int2 = org.apache.commons.math.util.FastMath.max(457133405, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 457133405 + "'", int2 == 457133405);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-471273163L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.37976447980876005d) + "'", double1 == (-0.37976447980876005d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double[] doubleArray59 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray69 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 100.0d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray69);
        double[] doubleArray79 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, 100.0d);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray89 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, 100.0d);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray89);
        double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray79);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray79);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray79);
        java.lang.Class<?> wildcardClass96 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1417987263) + "'", int62 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1417987263) + "'", int82 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass96);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.log(5.365954178338396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6800742127083808d + "'", double1 == 1.6800742127083808d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.57133415E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.660042967996203d + "'", double1 == 8.660042967996203d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1304428544), (-1078034560));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-90.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.192987713658941d) + "'", double1 == (-5.192987713658941d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 100.0d);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 0.0d);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1417987263) + "'", int10 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(10188.671355971788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10188.67135597179d + "'", double1 == 10188.67135597179d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1074790400L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-601083104), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-601083094) + "'", int2 == (-601083094));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.2930466684875075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.23879450315858d + "'", double1 == 2.23879450315858d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.2438899565964023d, (-0.9117339147869651d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2438899565964021d + "'", double2 == 1.2438899565964021d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1074790400));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-3), (long) (-1304428543));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-3));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1411200080598672d) + "'", double1 == (-0.1411200080598672d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 457133415, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray13 = new int[] { ' ', (-1), (short) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray20);
        int[] intArray23 = new int[] {};
        int[] intArray24 = null;
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = null;
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray38 = new int[] { 0 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray38);
        int[] intArray43 = new int[] { ' ', (-1), (short) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray43);
        try {
            int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 47.43416490252569d + "'", double22 == 47.43416490252569d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 6939238083912138753L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.383723656204786d + "'", double1 == 43.383723656204786d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.asinh(350.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.5510823758534835d + "'", double1 == 6.5510823758534835d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0780344320000002E9d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(8.911264043408805E95d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.105778198140094E97d + "'", double1 == 5.105778198140094E97d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray9 = new int[] { 0 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray9);
        int[] intArray14 = new int[] { ' ', (-1), (short) 0 };
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray14);
        try {
            int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1078034432, 350.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.28165299618869083d + "'", double2 == 0.28165299618869083d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        double[] doubleArray30 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray40 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray40);
        double[] doubleArray50 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray60 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray50);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray50);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray23);
        double[] doubleArray73 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 100.0d);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray75);
        double[] doubleArray77 = null;
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray75, doubleArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1417987263) + "'", int33 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1417987263) + "'", int53 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 51.54639175257732d + "'", double66 == 51.54639175257732d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(8.911264043408805E95d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.947878391455509E46d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6890099034821463E48d + "'", double1 == 1.6890099034821463E48d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-72925529), 351.00000000000006d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.2925529E7d) + "'", double2 == (-7.2925529E7d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 6939238083912138753L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.9392380839121388E18d + "'", double1 == 6.9392380839121388E18d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.093102195050827d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.04536101718726d + "'", double1 == 21.04536101718726d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-32.57791748631743d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) (-1074790400));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.log(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9512437185814275d + "'", double1 == 3.9512437185814275d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) -1, (long) (-1304428544));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.log10(351.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.545307116465824d + "'", double1 == 2.545307116465824d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 107, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 107L + "'", long2 == 107L);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-48456141990L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-106), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-106) + "'", int2 == (-106));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 457133405, (int) '#', 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 457133415);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1078034432L, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 106725408768L + "'", long2 == 106725408768L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1304428543));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1304428543 + "'", int1 == 1304428543);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1L), 1, (-1905511648));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1074790400), (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-72925529), (float) (-72925529));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.2925528E7f) + "'", float2 == (-7.2925528E7f));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        double[] doubleArray15 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 100.0d);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray25 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 100.0d);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray45 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 100.0d);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray45);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray35);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray8, doubleArray35);
        double[] doubleArray51 = null;
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1417987263) + "'", int18 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1417987263) + "'", int38 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.314240134565475E126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1074790400), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-106));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.1752011936438014d, (int) (byte) 0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 483811689960046592L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1078034432);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.605170186d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, (float) 350L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 11L, (float) 1078034431);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(351L, 8625328718985906577L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 1.024701097142274d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (0.275 >= -0.005)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 117.6010204037363d + "'", double10 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        double[] doubleArray38 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 100.0d);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray48 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray48);
        double[] doubleArray58 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray68 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 100.0d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray68);
        double[] doubleArray78 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 100.0d);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double[] doubleArray88 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, 100.0d);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray88);
        double double92 = org.apache.commons.math.util.MathUtils.distance(doubleArray68, doubleArray78);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray78);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray38);
        double double95 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1417987263) + "'", int61 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1417987263) + "'", int81 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 117.6010204037363d + "'", double95 == 117.6010204037363d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(107.0d, (double) 42, 21.216678938818404d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        int int2 = org.apache.commons.math.util.FastMath.max(99, (-601083104));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 99 + "'", int2 == 99);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 483811689960046592L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 483811689960046592L + "'", long1 == 483811689960046592L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        long long1 = org.apache.commons.math.util.FastMath.round(4.247833728790283d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 8625328718985906480L);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (-1304428543L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1074790400L), (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 457133415);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 457133415, (java.lang.Number) 0.0d, (int) (short) 10, orderDirection23, true);
        boolean boolean26 = nonMonotonousSequenceException25.getStrict();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 4521604579065856L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.74079050168738d + "'", double1 == 36.74079050168738d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(350.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 350.00000000000006d + "'", double1 == 350.00000000000006d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1), 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 9409);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.149421957006766d + "'", double1 == 9.149421957006766d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(35.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        double[] doubleArray11 = null;
        try {
            double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-457133315L), 4.57133415E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.57133315E8d) + "'", double2 == (-4.57133315E8d));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) (-1304428544));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) 'a', (-1417987263));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 34);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(457133415, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 457133415L + "'", long2 == 457133415L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        int int13 = nonMonotonousSequenceException9.getIndex();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException9.getArgument();
        int int17 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1417987263) + "'", int11 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1417987263) + "'", int12 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1417987263) + "'", int13 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 100 + "'", number16.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1417987263) + "'", int17 == (-1417987263));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (short) 100 + "'", number20.equals((short) 100));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray15 = new int[] { 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray15);
        int[] intArray20 = new int[] { ' ', (-1), (short) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray30 = new int[] { 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray30);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray30);
        int[] intArray34 = new int[] {};
        int[] intArray39 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray39);
        int[] intArray42 = new int[] { 0 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray42);
        int[] intArray47 = new int[] { ' ', (-1), (short) 0 };
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray47);
        int[] intArray49 = new int[] {};
        int[] intArray54 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray54);
        int[] intArray58 = null;
        try {
            int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 47.43416490252569d + "'", double56 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(42);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.605170186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.145966026292122d + "'", double1 == 2.145966026292122d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-601083094), 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-601083058L) + "'", long2 == (-601083058L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 0);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 0 + "'", byte1 == (byte) 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.rint((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.0d) + "'", double1 == (-57.0d));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.04684485418779906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.225622771460043E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.225622771460043E40d + "'", double1 == 1.225622771460043E40d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        int int2 = org.apache.commons.math.util.FastMath.min((-106), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-106) + "'", int2 == (-106));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.07803456E9f), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07803456E9f) + "'", float2 == (-1.07803456E9f));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray15 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray15);
        int[] intArray18 = new int[] { 0 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray18);
        int[] intArray20 = new int[] {};
        int[] intArray25 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray25);
        int[] intArray27 = new int[] {};
        int[] intArray32 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray32);
        int[] intArray35 = new int[] { 0 };
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray35);
        int[] intArray40 = new int[] { ' ', (-1), (short) 0 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray40);
        int[] intArray42 = new int[] {};
        int[] intArray47 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray47);
        int[] intArray50 = new int[] { 0 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray50);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray50);
        int[] intArray54 = new int[] {};
        int[] intArray59 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray54, intArray59);
        int[] intArray62 = new int[] { 0 };
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray62);
        int[] intArray67 = new int[] { ' ', (-1), (short) 0 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray67);
        int[] intArray69 = new int[] {};
        int[] intArray74 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray74);
        int int77 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray74);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray74);
        try {
            int int79 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 47.43416490252569d + "'", double76 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.acosh(9.290956022182348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9192798361641765d + "'", double1 == 2.9192798361641765d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8575532158463934d, 36.0d, 48.45360824742268d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 84, 11.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 0, 34, 1078034539);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1304428543L), (-1304428544));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.304428543E9d) + "'", double2 == (-1.304428543E9d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 9409);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray26);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(3.7168146928204138d, 1.1309659398685306d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7168146928204138d + "'", double2 == 3.7168146928204138d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 8625328718985906577L, (-1304428544));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) 100, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 200L + "'", long2 == 200L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(43.383723656204786d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2485.704265062403d + "'", double1 == 2485.704265062403d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 97.00000000000001d + "'", number5.equals(97.00000000000001d));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0413926851582251d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1304428543));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.105778198140094E97d, (double) 3628800L, (-1.3370716677274175d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-3));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.3978952727983707d, 4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-1905511648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4521604579065856L, (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1078034539);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8815252155769218E7d + "'", double1 == 1.8815252155769218E7d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.6109179126442243d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6109179126442243d + "'", double1 == 3.6109179126442243d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        long long1 = org.apache.commons.math.util.FastMath.abs((-601083058L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 601083058L + "'", long1 == 601083058L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double2 = org.apache.commons.math.util.FastMath.max(1.5350567286626973d, 92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 92.13617560368711d + "'", double2 == 92.13617560368711d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100L + "'", number11.equals(100L));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-106), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-2.2766572949795723E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        java.lang.Class<?> wildcardClass10 = doubleArray6.getClass();
        double[] doubleArray17 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 100.0d);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 0.0d);
        double[] doubleArray29 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 100.0d);
        double[] doubleArray38 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 100.0d);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray48 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray48);
        double[] doubleArray58 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray68 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 100.0d);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray68);
        double double72 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray58);
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray58);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray31);
        double[] doubleArray75 = null;
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray22);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection84 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException86 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 0, 10, orderDirection84, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) 2.2250738585072014E-308d, (int) (byte) 0, orderDirection84, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection84, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (0 <= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1417987263) + "'", int20 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1417987263) + "'", int61 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 51.54639175257732d + "'", double74 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 196.0d + "'", double77 == 196.0d);
        org.junit.Assert.assertTrue("'" + orderDirection84 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection84.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double3 = org.apache.commons.math.util.MathUtils.round(1.024701097142274d, 84, 2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.024701097142274d + "'", double3 == 1.024701097142274d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.99499987499378d + "'", double1 == 99.99499987499378d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1078034432, (-601083094));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.434650553076867d, 1304428543);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2173252765384335d + "'", double2 == 0.2173252765384335d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.22181105023335512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 100.0d);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray17 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 100.0d);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray27);
        java.lang.Class<?> wildcardClass33 = doubleArray7.getClass();
        double[] doubleArray40 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double[] doubleArray50 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray50);
        double[] doubleArray60 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray60);
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray40);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1417987263) + "'", int10 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 117.6010204037363d + "'", double31 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1417987263) + "'", int43 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1417987263) + "'", int63 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 117.6010204037363d + "'", double64 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.6253287189859062E18d, 43.383723656204786d, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.5510823758534835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5595082292998166d + "'", double1 == 2.5595082292998166d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.730093305612845d + "'", double1 == 1.730093305612845d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        long long2 = org.apache.commons.math.util.MathUtils.pow(3628800L, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray26);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        double[] doubleArray48 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 1.024701097142274d);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray54);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1417987263) + "'", int51 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 117.6010204037363d + "'", double52 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 99.47180355817409d + "'", double55 == 99.47180355817409d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) '4', 107);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 159 + "'", int2 == 159);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(100.0d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 200.0d + "'", double2 == 200.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 100 + "'", number7.equals((short) 100));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 106725408768L, (double) (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        float float1 = org.apache.commons.math.util.MathUtils.sign((-90.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.00397413672268d + "'", double1 == 7.00397413672268d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7612001156935624d + "'", double1 == 3.7612001156935624d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray13 = new int[] { ' ', (-1), (short) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray23 = new int[] { 0 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray31 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray38 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray38);
        int[] intArray41 = new int[] { 0 };
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray41);
        int[] intArray46 = new int[] { ' ', (-1), (short) 0 };
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray53 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray53);
        int[] intArray56 = new int[] { 0 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray56);
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray56);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray56);
        int[] intArray60 = new int[] {};
        int[] intArray65 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray60, intArray65);
        int[] intArray68 = new int[] { 0 };
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray68);
        int[] intArray73 = new int[] { ' ', (-1), (short) 0 };
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray60, intArray73);
        int[] intArray75 = new int[] {};
        int[] intArray80 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray80);
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray80);
        try {
            int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 47.43416490252569d + "'", double82 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray15 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray15);
        int[] intArray17 = new int[] {};
        int[] intArray22 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray25 = new int[] { 0 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray25);
        int[] intArray30 = new int[] { ' ', (-1), (short) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray37 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray37);
        int[] intArray40 = new int[] { 0 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray40);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray40);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray52 = new int[] { 0 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray52);
        int[] intArray57 = new int[] { ' ', (-1), (short) 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray57);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray64);
        int[] intArray69 = null;
        try {
            int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 47.43416490252569d + "'", double66 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.5510823758534835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 350.001428568513d + "'", double1 == 350.001428568513d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.log(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        long long2 = org.apache.commons.math.util.MathUtils.pow(840L, (int) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1905511648), 159);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(58.80051020186815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8886038169617962d + "'", double1 == 3.8886038169617962d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double1 = org.apache.commons.math.util.FastMath.signum(58.80051020186815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double1 = org.apache.commons.math.util.FastMath.abs((-57.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.0d + "'", double1 == 57.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-106), 1740689953);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1740690059) + "'", int2 == (-1740690059));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 457133415L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3714608759301317d + "'", double1 == 1.3714608759301317d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1304428543), 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) 52, 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.3978952727983707d, 1.6800742127083808d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3978952727983707d + "'", double2 == 2.3978952727983707d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.53096491487338d + "'", double2 == 100.53096491487338d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-613773204));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        long long1 = org.apache.commons.math.util.FastMath.abs(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100, (long) 107);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.0d, (java.lang.Number) 0, 10, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 97.0d, (java.lang.Number) 2.2250738585072014E-308d, (int) (byte) 0, orderDirection6, false);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 2.2250738585072014E-308d + "'", number11.equals(2.2250738585072014E-308d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0 < 97)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not decreasing (0 < 97)"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (97 >= null)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (97 >= null)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 97.00000000000001d + "'", number6.equals(97.00000000000001d));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1304428544, 601083058L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double2 = org.apache.commons.math.util.FastMath.atan2(100.0d, 1.2438899565964021d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5583580687106948d + "'", double2 == 1.5583580687106948d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.0354544351403985E151d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-58132355) + "'", int1 == (-58132355));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray26);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (int) (short) 100);
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 840L);
        java.math.BigInteger bigInteger51 = null;
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, 0L);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 0L);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, bigInteger56);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 97);
        java.math.BigInteger bigInteger62 = null;
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 0L);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, 0L);
        java.math.BigInteger bigInteger68 = org.apache.commons.math.util.MathUtils.pow(bigInteger64, (int) (short) 100);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, bigInteger64);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, bigInteger64);
        java.lang.Number number75 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number82 = nonMonotonousSequenceException81.getArgument();
        int int83 = nonMonotonousSequenceException81.getIndex();
        int int84 = nonMonotonousSequenceException81.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = nonMonotonousSequenceException81.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException87 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number75, (java.lang.Number) (-0.5063656411097588d), (int) (short) 10, orderDirection85, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.298292365610485d, (java.lang.Number) (-1304428544), (int) (short) -1, orderDirection85, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException91 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 457133415, (java.lang.Number) bigInteger70, (-471273129), orderDirection85, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection85, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger68);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + (short) 100 + "'", number82.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1417987263) + "'", int83 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1417987263) + "'", int84 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-57.29577951308232d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1304428543), (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        double[] doubleArray18 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 100.0d);
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray37 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 100.0d);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray47 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray57 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 100.0d);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray57);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray47);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray47);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection64, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (0.515 <= 26.804)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1417987263) + "'", int50 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 51.54639175257732d + "'", double63 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 10, (-1078034538L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1078034528L) + "'", long2 == (-1078034528L));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        int int13 = nonMonotonousSequenceException9.getIndex();
        java.lang.Number number14 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number15 = nonMonotonousSequenceException9.getArgument();
        java.lang.Number number16 = nonMonotonousSequenceException9.getArgument();
        int int17 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean19 = nonMonotonousSequenceException9.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1417987263) + "'", int11 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1417987263) + "'", int12 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1417987263) + "'", int13 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 100 + "'", number14.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) 100 + "'", number16.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1417987263) + "'", int17 == (-1417987263));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 97);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger30);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger31);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 457133405);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray15 = new int[] { 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray15);
        int[] intArray20 = new int[] { ' ', (-1), (short) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray30 = new int[] { 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray30);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray30);
        int[] intArray34 = new int[] {};
        int[] intArray35 = null;
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray35);
        int[] intArray37 = new int[] {};
        int[] intArray38 = null;
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray41 = new int[] {};
        int[] intArray46 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int[] intArray49 = new int[] { 0 };
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray49);
        int[] intArray54 = new int[] { ' ', (-1), (short) 0 };
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray54);
        try {
            double double57 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5545968900472659d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5545968900472659d + "'", double1 == 0.5545968900472659d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        long long1 = org.apache.commons.math.util.MathUtils.sign(840L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-601083058L), (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707962402843898d) + "'", double2 == (-1.5707962402843898d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1078034560), 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1078034560) + "'", int2 == (-1078034560));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-471273129));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963246729848d) + "'", double1 == (-1.5707963246729848d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1.4179872E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.689277748317553d) + "'", double1 == (-0.689277748317553d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 97, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 96.99999999999999d + "'", double2 == 96.99999999999999d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double[] doubleArray59 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray69 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 100.0d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray69);
        double[] doubleArray79 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, 100.0d);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray89 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, 100.0d);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray89);
        double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray69, doubleArray79);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray79);
        double double95 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray79);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, (double) (-1078034538L));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1417987263) + "'", int62 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1417987263) + "'", int82 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + true + "'", boolean94 == true);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray97);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1078034560));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9550576461963562d + "'", double1 == 0.9550576461963562d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.211102550927978d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 350.64726522133026d + "'", double1 == 350.64726522133026d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(4521604579065853L, 840L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3798147846415316520L + "'", long2 == 3798147846415316520L);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.5510823758534835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8711316870742094d + "'", double1 == 1.8711316870742094d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(21.216678938818404d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.189484999845426E8d + "'", double1 == 8.189484999845426E8d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.6890099034821463E48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 104569350283L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double[] doubleArray12 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 100.0d);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray17, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 4521604579065856L, 84, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.283185307179586d, (java.lang.Number) 4.741245572507582E21d, 1304428544, orderDirection18, true);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1417987263) + "'", int15 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(99.47180355817409d, 48.45360824742268d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 49.2063211007374d + "'", double2 == 49.2063211007374d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(457133415, (-1304428544));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (byte) 1, (-601083104));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.668014432879854E240d + "'", double2 == 6.668014432879854E240d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 52, 9409, (-601083094));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int1 = org.apache.commons.math.util.FastMath.abs((-9));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 9 + "'", int1 == 9);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.2438899565964023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02170997527509658d + "'", double1 == 0.02170997527509658d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int1 = org.apache.commons.math.util.FastMath.abs((-58132355));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 58132355 + "'", int1 == 58132355);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.3211147776427881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32666190909894177d + "'", double1 == 0.32666190909894177d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray15 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray15);
        int[] intArray17 = new int[] {};
        int[] intArray22 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray25 = new int[] { 0 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray25);
        int[] intArray30 = new int[] { ' ', (-1), (short) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray37 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray37);
        int[] intArray40 = new int[] { 0 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray40);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray40);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray52 = new int[] { 0 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray52);
        int[] intArray57 = new int[] { ' ', (-1), (short) 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray57);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray64);
        int[] intArray69 = new int[] {};
        int[] intArray70 = null;
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray70);
        int[] intArray72 = new int[] {};
        int[] intArray73 = null;
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray73);
        int[] intArray76 = new int[] {};
        int[] intArray81 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int82 = org.apache.commons.math.util.MathUtils.distanceInf(intArray76, intArray81);
        int[] intArray84 = new int[] { 0 };
        int int85 = org.apache.commons.math.util.MathUtils.distance1(intArray76, intArray84);
        int[] intArray89 = new int[] { ' ', (-1), (short) 0 };
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray76, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray89);
        int[] intArray92 = null;
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray92);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray92);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 47.43416490252569d + "'", double66 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 0 + "'", int82 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        try {
            double double8 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        int int2 = org.apache.commons.math.util.FastMath.min(84, 1304428543);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 84 + "'", int2 == 84);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1078034538L), (java.lang.Number) 6.283185307179586d, 84);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 6.283185307179586d + "'", number4.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 6.283185307179586d + "'", number5.equals(6.283185307179586d));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5278888682247537d) + "'", double1 == (-0.5278888682247537d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.18866643501183092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18978769308393018d + "'", double1 == 0.18978769308393018d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1078034560), (double) (-106));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0780345599999998E9d) + "'", double2 == (-1.0780345599999998E9d));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-601083094), (double) 457133405);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.01083094E8d) + "'", double2 == (-6.01083094E8d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1078034539, (-601083104), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray13 = new int[] { ' ', (-1), (short) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray23 = new int[] { 0 };
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray31 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray31);
        int[] intArray34 = new int[] { 0 };
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray34);
        try {
            int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.9392380839121388E18d, (-1.3370716677274175d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double[] doubleArray59 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray59);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray39);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1417987263) + "'", int62 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 117.6010204037363d + "'", double63 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        long long1 = org.apache.commons.math.util.FastMath.abs(36L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 36L + "'", long1 == 36L);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '4', 9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 468 + "'", int2 == 468);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(84, 58132355);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.signum(56.10814393552831d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray15 = new int[] { 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray15);
        int[] intArray20 = new int[] { ' ', (-1), (short) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray30 = new int[] { 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray30);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray30);
        int[] intArray34 = new int[] {};
        int[] intArray39 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray39);
        int[] intArray42 = new int[] { 0 };
        int int43 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray42);
        int[] intArray47 = new int[] { ' ', (-1), (short) 0 };
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray47);
        int[] intArray49 = new int[] {};
        int[] intArray54 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray54);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray54);
        int[] intArray58 = null;
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray58);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 47.43416490252569d + "'", double56 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.944515159673473E42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3915798710256516d + "'", double1 == 0.3915798710256516d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.9117339147869651d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8175632803535192d) + "'", double1 == (-0.8175632803535192d));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 1, 159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 159 + "'", int2 == 159);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 34, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 34L + "'", long2 == 34L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.365954178338396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 107.00000000000003d + "'", double1 == 107.00000000000003d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.32666190909894177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3155181722633267d + "'", double1 == 0.3155181722633267d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-9));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int2 = org.apache.commons.math.util.FastMath.min(2, (-72925529));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-72925529) + "'", int2 == (-72925529));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1304428543), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.acosh(350.64726522133026d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.552925923048147d + "'", double1 == 6.552925923048147d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(4L, (long) (-1905511648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1905511644L) + "'", long2 == (-1905511644L));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(99);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-90L), (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-90.0d) + "'", double2 == (-90.0d));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6655280485429236d) + "'", double1 == (-0.6655280485429236d));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        int int2 = org.apache.commons.math.util.FastMath.max(1078034431, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078034431 + "'", int2 == 1078034431);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.093102195050827d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04847145797183872d + "'", double1 == 0.04847145797183872d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int2 = org.apache.commons.math.util.MathUtils.pow(99, (long) 34);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1701847863) + "'", int2 == (-1701847863));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.768372718899808E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999998863d + "'", double1 == 0.9999999999998863d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1701847863));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1701847863L + "'", long1 == 1701847863L);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) 9409);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9409.0f + "'", float2 == 9409.0f);
    }
}

