import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 99L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double2 = org.apache.commons.math.util.FastMath.max(0.7185540823899328d, (double) (-1740690059));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7185540823899328d + "'", double2 == 0.7185540823899328d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-7.089936315E8d), (java.lang.Number) 84, (int) (byte) -1);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number8 = nonMonotonousSequenceException7.getArgument();
        int int9 = nonMonotonousSequenceException7.getIndex();
        int int10 = nonMonotonousSequenceException7.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException7.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException7.toString();
        boolean boolean13 = nonMonotonousSequenceException7.getStrict();
        java.lang.String str14 = nonMonotonousSequenceException7.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 100 + "'", number8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1417987263) + "'", int10 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 100);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number22, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray26 = nonMonotonousSequenceException25.getSuppressed();
        java.lang.Number number27 = nonMonotonousSequenceException25.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException25.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray21, orderDirection28, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (26.804 >= -0.515)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 97.00000000000001d + "'", number27.equals(97.00000000000001d));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.0456935028300002E11d, 690655340, (-876364669));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9753901144082441d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017023768987828043d) + "'", double1 == (-0.017023768987828043d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.229031730666748d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5094.335727060004d + "'", double1 == 5094.335727060004d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.947878391455509E46d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 107.0d + "'", double1 == 107.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.3866548812443612d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3866548812443612d + "'", double2 == 0.3866548812443612d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 8148, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2913434119236626d) + "'", double2 == (-1.2913434119236626d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 898016436698906592L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.0d + "'", double1 == 128.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(468, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 433 + "'", int2 == 433);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1417987263), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0456935028300002E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0456935028300002E11d + "'", double1 == 1.0456935028300002E11d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1701847863));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.244082897055604d + "'", double1 == 4.244082897055604d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.04684485418779906d, 14.154262241479262d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.046844854187799066d + "'", double2 == 0.046844854187799066d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1078034560));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034560 + "'", int1 == 1078034560);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.017023768987828043d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1940631391 + "'", int1 == 1940631391);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1078034431);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double[] doubleArray9 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9470402840320061d, (java.lang.Number) 351.0d, (-613773204), orderDirection15, false);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1417987263) + "'", int12 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-471273129), (long) (-1740689485));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2211962614L) + "'", long2 == (-2211962614L));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.189484999845426E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.189484999845427E8d + "'", double1 == 8.189484999845427E8d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.947040284032006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.016528971105380784d + "'", double1 == 0.016528971105380784d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1078034538L), (java.lang.Number) 6.283185307179586d, 84);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 6.283185307179586d + "'", number6.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) (-1), (-976792756));
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        int int2 = org.apache.commons.math.util.FastMath.max(9409, 733817339);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 733817339 + "'", int2 == 733817339);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 733817339);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8633687239111696d) + "'", double1 == (-1.8633687239111696d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.5574077246549023d), (double) 1304428544);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.557407724654902d) + "'", double2 == (-1.557407724654902d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        long long1 = org.apache.commons.math.util.MathUtils.sign(32L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1100 + "'", int1 == 1100);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        long long2 = org.apache.commons.math.util.FastMath.max((-48456141990L), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-976792756), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-1740690059), (-1058216373L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1842026720752136007L + "'", long2 == 1842026720752136007L);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.22363438573837524d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(42, (-613773255));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-690655340), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-690655338L) + "'", long2 == (-690655338L));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) 9L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 4.8381167629919846E17d, (-72925529));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double2 = org.apache.commons.math.util.MathUtils.log(8.913256591777792d, (double) 52L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8062500840336857d + "'", double2 == 1.8062500840336857d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1058216373L), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.FastMath.sin(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9589242746631385d) + "'", double1 == (-0.9589242746631385d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 97, (long) 1078034539);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 36L, (-0.689277748317553d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 703345450);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.029872582472967E10d + "'", double1 == 4.029872582472967E10d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(97.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7522203923062136d + "'", double2 == 2.7522203923062136d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.9999999999998863d, 1421110.2055328279d, 8.913256591777792d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.244082897055604d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.124495273311907d + "'", double1 == 2.124495273311907d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.3211147776427881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.052001902496457d + "'", double1 == 1.052001902496457d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        long long2 = org.apache.commons.math.util.FastMath.max(104569350283L, (-1074790507L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104569350283L + "'", long2 == 104569350283L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2.0f, 2.631308369767271E35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.600781508466421E-36d + "'", double2 == 7.600781508466421E-36d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (-1304428544));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1, 84);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(107, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 107 + "'", int2 == 107);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', 468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) '4', 1905511648);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 8625328720403893743L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 58132355, 52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 457133309L, (double) 690655340, (double) (-3));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1881832321521423d) + "'", double1 == (-0.1881832321521423d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 84681, (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6132885228381951233L + "'", long2 == 6132885228381951233L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-1304428543));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1078034560);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        boolean boolean9 = nonMonotonousSequenceException8.getStrict();
        java.lang.Number number10 = nonMonotonousSequenceException8.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number15 = nonMonotonousSequenceException14.getArgument();
        int int16 = nonMonotonousSequenceException14.getIndex();
        int int17 = nonMonotonousSequenceException14.getIndex();
        int int18 = nonMonotonousSequenceException14.getIndex();
        java.lang.Number number19 = nonMonotonousSequenceException14.getArgument();
        java.lang.Number number20 = nonMonotonousSequenceException14.getArgument();
        java.lang.Number number21 = nonMonotonousSequenceException14.getArgument();
        int int22 = nonMonotonousSequenceException14.getIndex();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number25 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException3.getDirection();
        int int27 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + (short) 100 + "'", number15.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1417987263) + "'", int16 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1417987263) + "'", int17 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1417987263) + "'", int18 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 100 + "'", number19.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (short) 100 + "'", number20.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) 100 + "'", number21.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1417987263) + "'", int22 == (-1417987263));
        org.junit.Assert.assertNull(number25);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        float float2 = org.apache.commons.math.util.FastMath.min(2.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-1078034560), (-106));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        double[] doubleArray30 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray40 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray40);
        double[] doubleArray50 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray60 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray50);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray50);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray23);
        double[] doubleArray73 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 100.0d);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray75);
        try {
            double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 7.930067261567154E14d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1417987263) + "'", int33 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1417987263) + "'", int53 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 51.54639175257732d + "'", double66 == 51.54639175257732d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-976792756), (long) (-1905511648));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 928718892L + "'", long2 == 928718892L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 3492L, 9, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3492.0f + "'", float3 == 3492.0f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(36.74079050168738d, (-0.44802536211003324d), 50.005000000000024d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 0, 508048710364602531L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(58132355);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.811714395674443E8d + "'", double1 == 9.811714395674443E8d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 97);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 97);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger40);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger29);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger42, (java.lang.Number) 97.0f, 58132355);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 9409, 106725408768L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8746120048581541887L) + "'", long2 == (-8746120048581541887L));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1417987263), (-1078034528L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 8625328718985906480L, (-1.3370716677274175d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.6253287189859062E18d + "'", double2 == 8.6253287189859062E18d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-58132390), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1074790400), (-58132390));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1417987263) + "'", int7 == (-1417987263));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35L, 200.0d, (double) 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3628800.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(50.005000000000024d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0714213564176776d + "'", double1 == 7.0714213564176776d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1137241857, (long) 84681);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1137241857L + "'", long2 == 1137241857L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.902956571239661E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000002382540565d + "'", double1 == 1.0000002382540565d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1304428543, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1842026720752136007L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13221876050231868d + "'", double1 == 0.13221876050231868d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.631308369767271E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.420171747150924d + "'", double1 == 35.420171747150924d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.605170186d, 630.2535746439055d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0073067229081486395d + "'", double2 == 0.0073067229081486395d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        long long2 = org.apache.commons.math.util.MathUtils.pow(8625328718985906577L, (long) 433);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4083192706288532335L) + "'", long2 == (-4083192706288532335L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', (long) 468);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1789532287) + "'", int2 == (-1789532287));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1701847863), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.0d, (java.lang.Number) 48.45360824742268d, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (48.454 >= 35)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (48.454 >= 35)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray15 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray15);
        int[] intArray17 = new int[] {};
        int[] intArray22 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray25 = new int[] { 0 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray25);
        int[] intArray30 = new int[] { ' ', (-1), (short) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray37 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray37);
        int[] intArray40 = new int[] { 0 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray40);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray40);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray52 = new int[] { 0 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray52);
        int[] intArray57 = new int[] { ' ', (-1), (short) 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray57);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray64);
        int[] intArray69 = new int[] {};
        int[] intArray74 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray74);
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray64, intArray74);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 47.43416490252569d + "'", double66 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray13 = new int[] { ' ', (-1), (short) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = null;
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray16);
        int[] intArray18 = new int[] {};
        int[] intArray19 = null;
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray30 = new int[] { 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray30);
        int[] intArray35 = new int[] { ' ', (-1), (short) 0 };
        int int36 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray35);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray35);
        int[] intArray39 = null;
        try {
            int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger10);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 97);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        try {
            java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (long) (-613773204));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06896221243799017d + "'", double1 == 0.06896221243799017d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        int int2 = org.apache.commons.math.util.FastMath.max(1304428543, (-601083104));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1304428543 + "'", int2 == 1304428543);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-1417987263L), (-601083058L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = null;
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = null;
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = null;
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int[] intArray16 = new int[] {};
        int[] intArray21 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray24 = new int[] { 0 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray24);
        int[] intArray29 = new int[] { ' ', (-1), (short) 0 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray29);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0000002382540565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931472996869664d + "'", double1 == 0.6931472996869664d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1078034538L), (java.lang.Number) 6.283185307179586d, 84);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1078034538L) + "'", number5.equals((-1078034538L)));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 84 + "'", int6 == 84);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1789532287));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.123323047889412E7d) + "'", double1 == (-3.123323047889412E7d));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 100, 0.08101100767034625d, (-0.9117339147869651d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray26);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 457133309L);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(97L, (long) 457133408);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 457133505L + "'", long2 == 457133505L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int2 = org.apache.commons.math.util.FastMath.max(1905511648, 1100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1905511648 + "'", int2 == 1905511648);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1.07803456E9f), (-3));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.3475432E8d) + "'", double2 == (-1.3475432E8d));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1, 32, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.04684485418779906d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9989029804520734d + "'", double1 == 0.9989029804520734d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double double1 = org.apache.commons.math.util.FastMath.tan(115.32101539575581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3075922879550428d) + "'", double1 == (-1.3075922879550428d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double[] doubleArray59 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray69 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 100.0d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray69);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray59);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1417987263) + "'", int32 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1417987263) + "'", int62 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1417987263) + "'", int74 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 117.6010204037363d + "'", double75 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, 100.0d);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray17 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 100.0d);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray17);
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray27);
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        double[] doubleArray48 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray58 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray58);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray58);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray58);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, (double) '#');
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray65);
        double[] doubleArray73 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 100.0d);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 1.024701097142274d);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray79);
        java.lang.Class<?> wildcardClass81 = doubleArray79.getClass();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1417987263) + "'", int10 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 117.6010204037363d + "'", double31 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1417987263) + "'", int51 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 48.45360824742268d + "'", double62 == 48.45360824742268d);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1417987263) + "'", int76 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 117.6010204037363d + "'", double77 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 17.513040671576146d + "'", double80 == 17.513040671576146d);
        org.junit.Assert.assertNotNull(wildcardClass81);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-2211962614L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        boolean boolean9 = nonMonotonousSequenceException3.getStrict();
        boolean boolean10 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-106));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1905511648);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 6939238083912138753L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int1 = org.apache.commons.math.util.FastMath.abs(1940631391);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1940631391 + "'", int1 == 1940631391);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-58132390));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        float float2 = org.apache.commons.math.util.FastMath.max(100.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double1 = org.apache.commons.math.util.FastMath.atan(9.290956022182348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4635775324102063d + "'", double1 == 1.4635775324102063d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9550576461963562d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 1, (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9645439376170786d) + "'", double1 == (-0.9645439376170786d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.005000000000024d + "'", double1 == 50.005000000000024d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1304428543L, (long) (-72925529));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1377354072L + "'", long2 == 1377354072L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double[] doubleArray59 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double[] doubleArray69 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 100.0d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray69);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray49, doubleArray59);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray59);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1417987263) + "'", int62 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 117.6010204037363d + "'", double75 == 117.6010204037363d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.298292365610486d, (java.lang.Number) 74.20321057778875d, 0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(9.149421957006766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4704.50005314061d + "'", double1 == 4704.50005314061d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1304428544, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double double1 = org.apache.commons.math.util.FastMath.atanh(56.98193772139799d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(468);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.4120078232813d + "'", double1 == 88.4120078232813d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-6.13773204E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray36 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray36);
        double[] doubleArray46 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, 100.0d);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray56 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 100.0d);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray46);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray46);
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number62, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray66 = nonMonotonousSequenceException65.getSuppressed();
        java.lang.Number number67 = nonMonotonousSequenceException65.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = nonMonotonousSequenceException65.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection68, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1417987263) + "'", int49 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 97.00000000000001d + "'", number67.equals(97.00000000000001d));
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.616107644349854d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 746.0317177084761d + "'", double1 == 746.0317177084761d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-57.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 8625328718985906577L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.625329E18f + "'", float1 == 8.625329E18f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        int int2 = org.apache.commons.math.util.FastMath.min(99, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray15 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray15);
        int[] intArray17 = new int[] {};
        int[] intArray22 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int23 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray22);
        int[] intArray25 = new int[] { 0 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray25);
        int[] intArray30 = new int[] { ' ', (-1), (short) 0 };
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray37 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray37);
        int[] intArray40 = new int[] { 0 };
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray40);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray40);
        int[] intArray44 = new int[] {};
        int[] intArray49 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int50 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray49);
        int[] intArray52 = new int[] { 0 };
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray52);
        int[] intArray57 = new int[] { ' ', (-1), (short) 0 };
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray57);
        int[] intArray59 = new int[] {};
        int[] intArray64 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray59, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray64);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray64);
        int[] intArray69 = new int[] {};
        int[] intArray74 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray69, intArray74);
        int[] intArray77 = new int[] { 0 };
        int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray69, intArray77);
        try {
            double double79 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 47.43416490252569d + "'", double66 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(6.902956571239661E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.22084707418515226d, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.636773610083083d + "'", double2 == 31.636773610083083d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7557182959940781d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7140460924220989d + "'", double1 == 0.7140460924220989d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1074790400), (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.FastMath.signum(630.2535746439055d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.2438899565964023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (-0.04814388543315018d));
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number40 = nonMonotonousSequenceException39.getArgument();
        int int41 = nonMonotonousSequenceException39.getIndex();
        int int42 = nonMonotonousSequenceException39.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException39.getDirection();
        int int44 = nonMonotonousSequenceException39.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException39.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection45, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 117.6010204037363d + "'", double33 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (short) 100 + "'", number40.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1417987263) + "'", int44 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 928718892L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 572L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 572.0f + "'", float1 == 572.0f);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0718591357822942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03013771392746352d + "'", double1 == 0.03013771392746352d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9995746166794132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.541627388435633d + "'", double1 == 1.541627388435633d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 1, 6132885228381951233L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6132885228381951234L + "'", long2 == 6132885228381951234L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.7361104849871487d, (-1), orderDirection3, true);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertNull(orderDirection8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.521604579065856E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        int int8 = nonMonotonousSequenceException6.getIndex();
        int int9 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-0.5063656411097588d), (int) (short) 10, orderDirection10, true);
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        java.lang.Number number14 = nonMonotonousSequenceException12.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number19 = nonMonotonousSequenceException18.getArgument();
        int int20 = nonMonotonousSequenceException18.getIndex();
        int int21 = nonMonotonousSequenceException18.getIndex();
        int int22 = nonMonotonousSequenceException18.getIndex();
        java.lang.Number number23 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number24 = nonMonotonousSequenceException18.getArgument();
        java.lang.Number number25 = nonMonotonousSequenceException18.getArgument();
        int int26 = nonMonotonousSequenceException18.getIndex();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException18);
        boolean boolean28 = nonMonotonousSequenceException18.getStrict();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 100 + "'", number7.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1417987263) + "'", int8 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNull(number13);
        org.junit.Assert.assertNull(number14);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 100 + "'", number19.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1417987263) + "'", int20 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1417987263) + "'", int21 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1417987263) + "'", int22 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 100 + "'", number23.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) 100 + "'", number24.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (short) 100 + "'", number25.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1417987263) + "'", int26 == (-1417987263));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-876364669));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-613773204));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-134020259), 1, 107);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) -1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-11) + "'", int2 == (-11));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        long long2 = org.apache.commons.math.util.FastMath.max((-1074790400L), 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1304428544L, (long) 613773256);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100077919333777408L + "'", long2 == 100077919333777408L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number13 = nonMonotonousSequenceException12.getArgument();
        int int14 = nonMonotonousSequenceException12.getIndex();
        int int15 = nonMonotonousSequenceException12.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number6, (java.lang.Number) (-0.5063656411097588d), (int) (short) 10, orderDirection16, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.298292365610485d, (java.lang.Number) (-1304428544), (int) (short) -1, orderDirection16, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 21.216678938818404d, (java.lang.Number) 97, (int) '4', orderDirection16, false);
        java.lang.Number number23 = nonMonotonousSequenceException22.getPrevious();
        java.lang.Number number24 = nonMonotonousSequenceException22.getPrevious();
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1417987263) + "'", int14 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1417987263) + "'", int15 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 97 + "'", number23.equals(97));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 97 + "'", number24.equals(97));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1905511648, (int) (byte) 0, 107);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-3798147846415316521L), (double) 100, (double) 703345450);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35.420171747150924d, (java.lang.Number) 483811689960046592L, 8268);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) ' ', 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 416L + "'", long2 == 416L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-976792756), 4051.54190208279d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707921789939663d) + "'", double2 == (-1.5707921789939663d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        double[] doubleArray18 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 100.0d);
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray37 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 100.0d);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray47 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray57 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 100.0d);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray57);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray47);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray47);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray20);
        double[] doubleArray64 = null;
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray64);
        try {
            double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, 0.9470402840320061d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1417987263) + "'", int50 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 51.54639175257732d + "'", double63 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 733817339);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int int2 = org.apache.commons.math.util.FastMath.max(9409, 433);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9409 + "'", int2 == 9409);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1940631391, 99);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1758.1074345493353d + "'", double2 == 1758.1074345493353d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1078034560, (-1.90551168E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.90551168E9f) + "'", float2 == (-1.90551168E9f));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray31 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 100.0d);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray31);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (short) 100);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray31);
        double[] doubleArray44 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 100.0d);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 107L);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1417987263) + "'", int24 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1304428444L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0604815357003929E26d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1417987263L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str9 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1417987263) + "'", int7 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 100 + "'", number8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-1074790400L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1074790400L) + "'", long1 == (-1074790400L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 8625328720403893743L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.18866643501183092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0178503664321785d + "'", double1 == 1.0178503664321785d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.064377754059776E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0643777540597762E15d + "'", double1 == 2.0643777540597762E15d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 483811689960046592L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        long long2 = org.apache.commons.math.util.FastMath.max(3628800L, (long) (-1701847863));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-976792756), 97, 1100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 42);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 433, (-7.089936315E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415920428649846d + "'", double2 == 3.1415920428649846d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number3, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        boolean boolean12 = nonMonotonousSequenceException11.getStrict();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number18 = nonMonotonousSequenceException17.getArgument();
        int int19 = nonMonotonousSequenceException17.getIndex();
        int int20 = nonMonotonousSequenceException17.getIndex();
        int int21 = nonMonotonousSequenceException17.getIndex();
        java.lang.Number number22 = nonMonotonousSequenceException17.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException17.getArgument();
        java.lang.Number number24 = nonMonotonousSequenceException17.getArgument();
        int int25 = nonMonotonousSequenceException17.getIndex();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number28 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.76837158203125E-7d, (java.lang.Number) 703345450, 8148, orderDirection29, false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 100 + "'", number13.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 100 + "'", number18.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1417987263) + "'", int19 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1417987263) + "'", int20 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1417987263) + "'", int21 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 100 + "'", number22.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 100 + "'", number23.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) 100 + "'", number24.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1417987263) + "'", int25 == (-1417987263));
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(703345450, (-976792756));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1680138206 + "'", int2 == 1680138206);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 3492.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3492.0d + "'", double1 == 3492.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.2710663101885897d, (-0.9753901144082441d), 3.848501131276805d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.8332128969929774d), (java.lang.Number) 350.0d, 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double2 = org.apache.commons.math.util.MathUtils.round(5094.335727060004d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5094.335727060004d + "'", double2 == 5094.335727060004d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5295044036366281d), (java.lang.Number) 0.0d, (-1740689485), orderDirection3, true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        long long2 = org.apache.commons.math.util.MathUtils.pow(483811689960046592L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.0643777540597762E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.95675242672156d + "'", double1 == 35.95675242672156d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.59068859007500672E17d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray6 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray8 = new int[] {};
        int[] intArray13 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray8, intArray13);
        int[] intArray16 = new int[] { 0 };
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray16);
        int[] intArray21 = new int[] { ' ', (-1), (short) 0 };
        int int22 = org.apache.commons.math.util.MathUtils.distance1(intArray8, intArray21);
        int[] intArray23 = new int[] {};
        int[] intArray28 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray28);
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray21);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 47.43416490252569d + "'", double30 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.sinh(76683.40485184503d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        int int2 = org.apache.commons.math.util.FastMath.min(2147483647, (-11));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-11) + "'", int2 == (-11));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 8148, 1137241857L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1137250005L + "'", long2 == 1137250005L);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9117339147869651d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2909827789843418d) + "'", double1 == (-1.2909827789843418d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray41 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 100.0d);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) (byte) 100);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 117.6010204037363d + "'", double33 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 117.6010204037363d + "'", double34 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1417987263) + "'", int44 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 117.6010204037363d + "'", double45 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 117.6010204037363d + "'", double48 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray12 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray15 = new int[] { 0 };
        int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray15);
        int[] intArray20 = new int[] { ' ', (-1), (short) 0 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray27 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray27);
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray20);
        int[] intArray31 = null;
        try {
            int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray20, intArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 47.43416490252569d + "'", double29 == 47.43416490252569d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.5236984520405024d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-0.5545968900472659d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-601083104), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 10, 200L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1078034538L), (java.lang.Number) 6.283185307179586d, 84);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.6890099034821463E48d, (java.lang.Number) 8.660042967996203d, 84681, orderDirection7, true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.22084707418515226d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2208470741851523d + "'", double1 == 0.2208470741851523d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        java.lang.Class<?> wildcardClass20 = doubleArray6.getClass();
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray37 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 100.0d);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray47 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double52 = org.apache.commons.math.util.MathUtils.distance(doubleArray27, doubleArray47);
        java.lang.Class<?> wildcardClass53 = doubleArray47.getClass();
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray47);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1417987263) + "'", int50 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 117.6010204037363d + "'", double51 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        int int2 = org.apache.commons.math.util.FastMath.min(690655340, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.9392380839121388E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1907380.1681175595d + "'", double1 == 1907380.1681175595d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(159, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 81.22884179938251d + "'", double2 == 81.22884179938251d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.732511156817248d, 350.00000000000006d, 5.2930466684875075d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 15344331400L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 847295235L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.47295235E8d + "'", double1 == 8.47295235E8d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray16 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, 100.0d);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray16);
        double[] doubleArray26 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 100.0d);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray26);
        java.lang.Class<?> wildcardClass32 = doubleArray6.getClass();
        double[] doubleArray39 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.0d);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double[] doubleArray49 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 100.0d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray49);
        double[] doubleArray59 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 100.0d);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray59);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray39);
        java.lang.Class<?> wildcardClass66 = doubleArray6.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1417987263) + "'", int29 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 117.6010204037363d + "'", double30 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1417987263) + "'", int62 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 117.6010204037363d + "'", double63 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass66);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double1 = org.apache.commons.math.util.FastMath.log1p(115.32101539575581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.756353743077884d + "'", double1 == 4.756353743077884d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.2710663101885897d, 2.993222846126381d, (double) 572L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        double[] doubleArray18 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 100.0d);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray18);
        double[] doubleArray28 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 100.0d);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray28);
        double[] doubleArray38 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 100.0d);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double43 = org.apache.commons.math.util.MathUtils.distance(doubleArray18, doubleArray38);
        java.lang.Class<?> wildcardClass44 = doubleArray18.getClass();
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray18);
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1417987263) + "'", int21 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1417987263) + "'", int41 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 117.6010204037363d + "'", double42 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 117.6010204037363d + "'", double45 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 52.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 8625328720403893743L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (byte) 100);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (26.804 >= -0.515)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 117.6010204037363d + "'", double10 == 117.6010204037363d);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.785305188188436d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-72925529));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.2925528E7f + "'", float1 == 7.2925528E7f);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 351L, 1.5123436436581316E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5123436456787126E9d + "'", double2 == 1.5123436456787126E9d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(97.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.5545968900472659d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5878784501113676d + "'", double1 == 0.5878784501113676d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1304428543));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-351L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 351.0f + "'", float1 == 351.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.189484999845425E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.189485E8d + "'", double1 == 8.189485E8d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.28165299618869083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.27794389126080143d + "'", double1 == 0.27794389126080143d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3798147846415316520L, (float) 847295235L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.4729523E8f + "'", float2 == 8.4729523E8f);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-8934108775301215359L), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8934108775301215359L) + "'", long2 == (-8934108775301215359L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, bigInteger24);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 97);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 97);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger40);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger29);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) ' ');
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 3850L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double2 = org.apache.commons.math.util.MathUtils.log(35.420171747150924d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        double double2 = org.apache.commons.math.util.FastMath.min(21.04536101718726d, 6.668014432879854E240d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.04536101718726d + "'", double2 == 21.04536101718726d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-9), 84681);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.9512437185814275d, 0.947040284032006d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.6739307405472235d + "'", double2 == 3.6739307405472235d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 457133505L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9863503817641229d + "'", double1 == 0.9863503817641229d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 0L, 0.7185540823899328d, (-1.3075922879550428d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double2 = org.apache.commons.math.util.FastMath.atan2(4.247833728790283d, (double) 36.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.11745229794238002d + "'", double2 == 0.11745229794238002d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 351.0f, 4.7205075536646195d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5573483980559837d + "'", double2 == 1.5573483980559837d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.23879450315858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.23879450315858d + "'", double1 == 2.23879450315858d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1078034538L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-3));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.5510823758534835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1137241857L, 457133408);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.803576983176818E-194d + "'", double2 == 5.803576983176818E-194d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-3L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.0f) + "'", float2 == (-3.0f));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        int int13 = nonMonotonousSequenceException11.getIndex();
        int int14 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        boolean boolean17 = nonMonotonousSequenceException11.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int20 = nonMonotonousSequenceException11.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 100 + "'", number12.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1417987263) + "'", int13 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1417987263) + "'", int14 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 100 + "'", number18.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1417987263) + "'", int20 == (-1417987263));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double double1 = org.apache.commons.math.util.FastMath.log1p(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6407674052281456d + "'", double1 == 1.6407674052281456d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1078034560), 3798147846415316520L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1078034560L) + "'", long2 == (-1078034560L));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        double[] doubleArray30 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray40 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray40);
        double[] doubleArray50 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray60 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray50);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray50);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray23);
        double[] doubleArray79 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, 100.0d);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray79);
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray79, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection85 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray84, orderDirection85, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 9.619275968248924E151d, (java.lang.Number) 4521604579065856L, 84, orderDirection85, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException91 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6536664338884767d, (java.lang.Number) 10L, 9409, orderDirection85, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection85, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (0.515 < 26.804)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1417987263) + "'", int33 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1417987263) + "'", int53 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 51.54639175257732d + "'", double66 == 51.54639175257732d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1417987263) + "'", int82 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + orderDirection85 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection85.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-58132390), (double) (-1L), (int) '4');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0986122886681098d, (double) 847295235L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.47295235E8d + "'", double2 == 8.47295235E8d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-876364669));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.3866548812443612d, 32, (-106));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 690655340);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1078034560);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 9409);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9975511750072135d) + "'", double1 == (-0.9975511750072135d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-1740689485));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-58132355));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 1078034431);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 100);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 840L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 97);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (int) (short) 100);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger23);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger23);
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number41 = nonMonotonousSequenceException40.getArgument();
        int int42 = nonMonotonousSequenceException40.getIndex();
        int int43 = nonMonotonousSequenceException40.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection44 = nonMonotonousSequenceException40.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number34, (java.lang.Number) (-0.5063656411097588d), (int) (short) 10, orderDirection44, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.298292365610485d, (java.lang.Number) (-1304428544), (int) (short) -1, orderDirection44, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 457133415, (java.lang.Number) bigInteger29, (-471273129), orderDirection44, true);
        java.lang.Number number51 = nonMonotonousSequenceException50.getPrevious();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (short) 100 + "'", number41.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1417987263) + "'", int42 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1417987263) + "'", int43 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection44 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection44.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(number51);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1417987263), (-1740690059));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        float float1 = org.apache.commons.math.util.MathUtils.sign(572.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3850L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        long long1 = org.apache.commons.math.util.MathUtils.sign(34L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 100);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 840L);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (short) 100);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 100);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 468);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        double[] doubleArray15 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 100.0d);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray25 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray25);
        double[] doubleArray35 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 100.0d);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray15, doubleArray35);
        java.lang.Class<?> wildcardClass41 = doubleArray15.getClass();
        double[] doubleArray48 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 100.0d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray58 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 100.0d);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray58);
        double[] doubleArray68 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 100.0d);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray78 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, 100.0d);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray78);
        double double82 = org.apache.commons.math.util.MathUtils.distance(doubleArray58, doubleArray68);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray68);
        double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray8, doubleArray68);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1417987263) + "'", int18 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1417987263) + "'", int38 == (-1417987263));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 117.6010204037363d + "'", double39 == 117.6010204037363d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1417987263) + "'", int51 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1417987263) + "'", int71 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 56.98193772139799d + "'", double84 == 56.98193772139799d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 468);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(97.0d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2296210822213825E32d + "'", double2 == 1.2296210822213825E32d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        double double1 = org.apache.commons.math.util.FastMath.ceil(56.98193772139799d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.0d + "'", double1 == 57.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.3211147776427881d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.33288955682622284d + "'", double1 == 0.33288955682622284d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1417987263));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1417987263L + "'", long1 == 1417987263L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1078034560, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3383347192042695E42d + "'", double1 == 1.3383347192042695E42d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.7683715820308884E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.768371582030708E-7d + "'", double1 == 4.768371582030708E-7d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(Double.POSITIVE_INFINITY, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-9), 1680138206);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1360749647) + "'", int2 == (-1360749647));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.03013771392746352d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.6407674052281456d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-3L), (java.lang.Number) (-57.29577951308232d), 690655340);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray31 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 100.0d);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray31);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) (short) 100);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray31);
        try {
            double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 107L);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1417987263) + "'", int24 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        int int13 = nonMonotonousSequenceException11.getIndex();
        int int14 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        boolean boolean17 = nonMonotonousSequenceException11.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number21, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        java.lang.Number number26 = nonMonotonousSequenceException24.getPrevious();
        int int27 = nonMonotonousSequenceException24.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException24.getDirection();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number30 = nonMonotonousSequenceException11.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 100 + "'", number12.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1417987263) + "'", int13 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1417987263) + "'", int14 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 100 + "'", number18.equals((short) 100));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 97.00000000000001d + "'", number26.equals(97.00000000000001d));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 100L + "'", number30.equals(100L));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        double[] doubleArray30 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray40 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray40);
        double[] doubleArray50 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray60 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray50);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray50);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray23);
        double[] doubleArray67 = null;
        try {
            double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1417987263) + "'", int33 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1417987263) + "'", int53 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 51.54639175257732d + "'", double66 == 51.54639175257732d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection12, false);
        double[] doubleArray21 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 100.0d);
        double[] doubleArray30 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 100.0d);
        int int33 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double[] doubleArray40 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 100.0d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray40);
        double[] doubleArray50 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, 100.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray60 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray60, 100.0d);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray50);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray50);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray23);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray74 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 100.0d);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, 0.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection80 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray79, orderDirection80, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection80, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not decreasing (0.515 < 26.804)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1417987263) + "'", int33 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1417987263) + "'", int53 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 51.54639175257732d + "'", double66 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1740689953 + "'", int67 == 1740689953);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1417987263) + "'", int77 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + orderDirection80 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection80.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.expm1(3.9512437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.00000000000001d + "'", double1 == 51.00000000000001d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(107, (-613773255));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.5414832875078943d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-41616876) + "'", int1 == (-41616876));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1304428543, 5.365954178338396d, 4.768372718899808E-7d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.44802536211003324d), 4.247833728790283d, 5.365954178338396d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 613773256, (double) ' ');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (byte) 100, (-471273129));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int[] intArray0 = new int[] {};
        int[] intArray5 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int6 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
        int[] intArray8 = new int[] { 0 };
        int int9 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray8);
        int[] intArray13 = new int[] { ' ', (-1), (short) 0 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray20 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray20);
        int[] intArray23 = new int[] {};
        int[] intArray24 = null;
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = null;
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray27);
        int[] intArray30 = new int[] {};
        int[] intArray35 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray38 = new int[] { 0 };
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray38);
        int[] intArray43 = new int[] { ' ', (-1), (short) 0 };
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray43);
        int[] intArray46 = null;
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray53 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray53);
        int[] intArray56 = new int[] { 0 };
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray56);
        int[] intArray61 = new int[] { ' ', (-1), (short) 0 };
        int int62 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray61);
        int[] intArray63 = new int[] {};
        int[] intArray68 = new int[] { 0, (short) 0, '#', (byte) 1 };
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray63, intArray68);
        int[] intArray71 = new int[] { 0 };
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray63, intArray71);
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray71);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray48);
        try {
            int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray48);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 47.43416490252569d + "'", double22 == 47.43416490252569d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 6129261277899256865L, 34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.POSITIVE_INFINITY + "'", float2 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 690655340, (float) (-1740689485));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.74068954E9f) + "'", float2 == (-1.74068954E9f));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.7556040176252816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.786942101548964d + "'", double1 == 5.786942101548964d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 15344331400L, (float) 200L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 200.0f + "'", float2 == 200.0f);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 100);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 840L);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (short) 100);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (int) (short) 100);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger31);
        java.math.BigInteger bigInteger37 = null;
        try {
            java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 457133415);
        java.lang.Class<?> wildcardClass21 = bigInteger10.getClass();
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(bigInteger23);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger13);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 457133415);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 457133415, (java.lang.Number) 0.0d, (int) (short) 10, orderDirection23, true);
        java.lang.Number number26 = nonMonotonousSequenceException25.getPrevious();
        boolean boolean27 = nonMonotonousSequenceException25.getStrict();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.046844854187799066d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.523934322626308d + "'", double1 == 1.523934322626308d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.947040284032006d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(9.229031730666748d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16107699047116528d + "'", double1 == 0.16107699047116528d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1417987263L, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4253961789L + "'", long2 == 4253961789L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        double[] doubleArray6 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 100.0d);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        double[] doubleArray18 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 100.0d);
        double[] doubleArray27 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 100.0d);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray27);
        double[] doubleArray37 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 100.0d);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray37);
        double[] doubleArray47 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray57 = new double[] { 1.0d, '4', (-1.0f), ' ', 100.0d, 10L };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 100.0d);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray57);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray37, doubleArray47);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray47);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray20);
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, 5.0354544351403985E151d);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1417987263) + "'", int9 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1417987263) + "'", int30 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1417987263) + "'", int50 == (-1417987263));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 51.54639175257732d + "'", double63 == 51.54639175257732d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 60.619082682338295d + "'", double64 == 60.619082682338295d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 60.619082682338295d + "'", double65 == 60.619082682338295d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1078034538L), (java.lang.Number) 6.283185307179586d, 84);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 6.283185307179586d, (java.lang.Number) 3.4946286503353052d, (int) '#');
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        java.lang.Number number15 = nonMonotonousSequenceException7.getPrevious();
        boolean boolean16 = nonMonotonousSequenceException7.getStrict();
        java.lang.String str17 = nonMonotonousSequenceException7.toString();
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 6.283185307179586d + "'", number15.equals(6.283185307179586d));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 83 and 84 are not strictly increasing (6.283 >= -1,078,034,538)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 83 and 84 are not strictly increasing (6.283 >= -1,078,034,538)"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(6.691673596021443E41d, (-1078034560));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1966.506127417467d + "'", double2 == 1966.506127417467d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 'a', (double) 4521604579065856L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-613773204));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        int int13 = nonMonotonousSequenceException11.getIndex();
        int int14 = nonMonotonousSequenceException11.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException11.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException11.toString();
        boolean boolean17 = nonMonotonousSequenceException11.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException11.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number21, (java.lang.Number) 97.00000000000001d, (int) (short) 10);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        java.lang.Number number26 = nonMonotonousSequenceException24.getPrevious();
        int int27 = nonMonotonousSequenceException24.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException24.getDirection();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        boolean boolean30 = nonMonotonousSequenceException24.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 100 + "'", number12.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1417987263) + "'", int13 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1417987263) + "'", int14 == (-1417987263));
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,417,987,264 and -1,417,987,263 are not strictly increasing (100 >= 100)"));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 100 + "'", number18.equals((short) 100));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 97.00000000000001d + "'", number26.equals(97.00000000000001d));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 10 + "'", int27 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) 100L, (-1417987263));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        int int6 = nonMonotonousSequenceException3.getIndex();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number9 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number10 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number11 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number12 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1417987263) + "'", int5 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1417987263) + "'", int6 == (-1417987263));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1417987263) + "'", int7 == (-1417987263));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) 100 + "'", number8.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (short) 100 + "'", number9.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 100 + "'", number10.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 100 + "'", number11.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 100 + "'", number12.equals((short) 100));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }
}

