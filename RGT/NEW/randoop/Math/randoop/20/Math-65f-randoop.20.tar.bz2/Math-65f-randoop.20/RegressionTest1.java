import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException1 = new org.apache.commons.math.MaxEvaluationsExceededException(36);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException2 = new org.apache.commons.math.linear.InvalidMatrixException((java.lang.Throwable) maxEvaluationsExceededException1);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (short) 10);
        int int3 = blockRealMatrix2.getRowDimension();
        double double4 = blockRealMatrix2.getNorm();
        double double5 = blockRealMatrix2.getFrobeniusNorm();
        int int6 = blockRealMatrix2.getColumnDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double[] doubleArray3 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, objArray7);
        double[] doubleArray10 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray3, doubleArray10, false);
        double[] doubleArray16 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable17 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, localizable17, objArray20);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray3, doubleArray16, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException(throwable2, (double) (byte) 1);
        org.apache.commons.math.exception.Localizable localizable8 = null;
        double[] doubleArray11 = new double[] { 100, 'a' };
        double[] doubleArray14 = new double[] { 100, 'a' };
        double[] doubleArray17 = new double[] { 100, 'a' };
        double[][] doubleArray18 = new double[][] { doubleArray11, doubleArray14, doubleArray17 };
        double[][] doubleArray19 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException20 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable8, (java.lang.Object[]) doubleArray19);
        java.lang.IllegalArgumentException illegalArgumentException21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", (java.lang.Object[]) doubleArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException4, "", (java.lang.Object[]) doubleArray19);
        try {
            org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math.linear.BlockRealMatrix(52, 2147483647, doubleArray19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(illegalArgumentException21);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double[] doubleArray3 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, objArray7);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException8, "", objArray10);
        java.lang.Throwable[] throwableArray12 = mathRuntimeException11.getSuppressed();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException11);
        java.lang.Class<?> wildcardClass14 = mathException13.getClass();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        java.math.BigDecimal[][] bigDecimalArray0 = null;
        try {
            org.apache.commons.math.linear.BigMatrix bigMatrix2 = org.apache.commons.math.linear.MatrixUtils.createBigMatrix(bigDecimalArray0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray10);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] { 100, 'a' };
        double[] doubleArray21 = new double[] { 100, 'a' };
        double[] doubleArray24 = new double[] { 100, 'a' };
        double[][] doubleArray25 = new double[][] { doubleArray18, doubleArray21, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable15, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException27);
        org.apache.commons.math.exception.Localizable localizable29 = mathRuntimeException28.getLocalizablePattern();
        double[] doubleArray35 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable36, objArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray39);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException("maximal number of iterations ({0}) exceeded", objArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13, localizable29, objArray39);
        double[] doubleArray47 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, objArray51);
        double[] doubleArray54 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray54, false);
        double[] doubleArray57 = vectorialPointValuePair56.getPoint();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException43, doubleArray57);
        org.apache.commons.math.linear.BigMatrix bigMatrix59 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        double[][] doubleArray61 = array2DRowRealMatrix60.getDataRef();
        double[] doubleArray63 = array2DRowRealMatrix60.getRow(0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(bigMatrix59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test09");
        org.apache.commons.math.exception.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, localizable7, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable2, objArray10);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray10);
        org.apache.commons.math.exception.Localizable localizable15 = null;
        double[] doubleArray18 = new double[] { 100, 'a' };
        double[] doubleArray21 = new double[] { 100, 'a' };
        double[] doubleArray24 = new double[] { 100, 'a' };
        double[][] doubleArray25 = new double[][] { doubleArray18, doubleArray21, doubleArray24 };
        double[][] doubleArray26 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException27 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable15, (java.lang.Object[]) doubleArray26);
        org.apache.commons.math.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException27);
        org.apache.commons.math.exception.Localizable localizable29 = mathRuntimeException28.getLocalizablePattern();
        double[] doubleArray35 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable36 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray35, localizable36, objArray39);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException41 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray39);
        org.apache.commons.math.optimization.OptimizationException optimizationException42 = new org.apache.commons.math.optimization.OptimizationException("maximal number of iterations ({0}) exceeded", objArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException13, localizable29, objArray39);
        double[] doubleArray47 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable48 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, localizable48, objArray51);
        double[] doubleArray54 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray54, false);
        double[] doubleArray57 = vectorialPointValuePair56.getPoint();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException43, doubleArray57);
        org.apache.commons.math.linear.BigMatrix bigMatrix59 = org.apache.commons.math.linear.MatrixUtils.createRowBigMatrix(doubleArray57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57);
        double[][] doubleArray61 = array2DRowRealMatrix60.getDataRef();
        org.apache.commons.math.linear.RealMatrix realMatrix62 = array2DRowRealMatrix60.copy();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(bigMatrix59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realMatrix62);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.scalarAdd(100.0d);
        double double5 = array2DRowRealMatrix2.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.scalarAdd(100.0d);
        double double14 = array2DRowRealMatrix9.getEntry((int) (byte) 10, (int) (short) 0);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker15 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray20 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable21 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException(doubleArray20, localizable21, objArray24);
        double[] doubleArray27 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray27, false);
        double[] doubleArray33 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable34 = null;
        java.lang.Object[] objArray37 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray33, localizable34, objArray37);
        double[] doubleArray40 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray40, false);
        double[] doubleArray43 = vectorialPointValuePair42.getPoint();
        boolean boolean44 = simpleVectorialValueChecker15.converged((int) (byte) -1, vectorialPointValuePair29, vectorialPointValuePair42);
        double[] doubleArray45 = vectorialPointValuePair42.getPointRef();
        boolean boolean46 = array2DRowRealMatrix9.equals((java.lang.Object) doubleArray45);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix2.add(array2DRowRealMatrix9);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix52 = array2DRowRealMatrix50.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix55 = array2DRowRealMatrix50.createMatrix(36, (int) (byte) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix60 = array2DRowRealMatrix58.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealVector realVector62 = array2DRowRealMatrix58.getRowVector((int) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = array2DRowRealMatrix50.subtract(array2DRowRealMatrix58);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix63);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix67 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix69 = blockRealMatrix67.getRowMatrix(0);
        double double70 = blockRealMatrix67.getNorm();
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix72 = blockRealMatrix67.scalarAdd(100.0d);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix75 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (short) 10);
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix72.subtract(blockRealMatrix75);
        double double77 = blockRealMatrix76.getNorm();
        org.apache.commons.math.linear.RealVector realVector79 = blockRealMatrix76.getColumnVector(0);
        try {
            org.apache.commons.math.linear.RealVector realVector80 = array2DRowRealMatrix63.operate(realVector79);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(blockRealMatrix69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix72);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 3500.0d + "'", double77 == 3500.0d);
        org.junit.Assert.assertNotNull(realVector79);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (short) 10);
        int int3 = blockRealMatrix2.getRowDimension();
        try {
            boolean boolean4 = blockRealMatrix2.isSingular();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: a 35x10 matrix was provided instead of a square matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        double[] doubleArray3 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException8);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException9);
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable12, (double) (byte) 1);
        org.apache.commons.math.exception.Localizable localizable15 = functionEvaluationException14.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 100, 'a' };
        double[] doubleArray23 = new double[] { 100, 'a' };
        double[] doubleArray26 = new double[] { 100, 'a' };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray23, doubleArray26 };
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray27);
        java.util.ConcurrentModificationException concurrentModificationException30 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", (java.lang.Object[]) doubleArray27);
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, 10.0d, localizable15, (java.lang.Object[]) doubleArray27);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix37 = array2DRowRealMatrix35.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix38 = array2DRowRealMatrix35.copy();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix41.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix41.createMatrix(36, (int) (byte) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix51 = array2DRowRealMatrix49.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealVector realVector53 = array2DRowRealMatrix49.getRowVector((int) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix41.subtract(array2DRowRealMatrix49);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix59 = array2DRowRealMatrix57.scalarAdd(100.0d);
        double double60 = array2DRowRealMatrix57.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix61 = array2DRowRealMatrix57.copy();
        int int62 = array2DRowRealMatrix57.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix63 = array2DRowRealMatrix54.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = array2DRowRealMatrix35.subtract(array2DRowRealMatrix57);
        double[][] doubleArray65 = array2DRowRealMatrix57.getData();
        java.lang.ArithmeticException arithmeticException66 = org.apache.commons.math.MathRuntimeException.createArithmeticException(localizable15, (java.lang.Object[]) doubleArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) arithmeticException66);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(concurrentModificationException30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(realMatrix38);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(realMatrix51);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 32 + "'", int62 == 32);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(arithmeticException66);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        org.apache.commons.math.exception.Localizable localizable7 = null;
        double[] doubleArray11 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable12 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, localizable12, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable7, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(10, "hi!", objArray15);
        org.apache.commons.math.exception.Localizable localizable20 = null;
        double[] doubleArray23 = new double[] { 100, 'a' };
        double[] doubleArray26 = new double[] { 100, 'a' };
        double[] doubleArray29 = new double[] { 100, 'a' };
        double[][] doubleArray30 = new double[][] { doubleArray23, doubleArray26, doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException32 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable20, (java.lang.Object[]) doubleArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxEvaluationsExceededException32);
        org.apache.commons.math.exception.Localizable localizable34 = mathRuntimeException33.getLocalizablePattern();
        double[] doubleArray40 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable41 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray40, localizable41, objArray44);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException46 = new org.apache.commons.math.linear.InvalidMatrixException("hi!", objArray44);
        org.apache.commons.math.optimization.OptimizationException optimizationException47 = new org.apache.commons.math.optimization.OptimizationException("maximal number of iterations ({0}) exceeded", objArray44);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException18, localizable34, objArray44);
        org.apache.commons.math.exception.Localizable localizable50 = null;
        double[] doubleArray53 = new double[] { 100, 'a' };
        double[] doubleArray56 = new double[] { 100, 'a' };
        double[] doubleArray59 = new double[] { 100, 'a' };
        double[][] doubleArray60 = new double[][] { doubleArray53, doubleArray56, doubleArray59 };
        double[][] doubleArray61 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray60);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException62 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable50, (java.lang.Object[]) doubleArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable34, (java.lang.Object[]) doubleArray61);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException64 = new org.apache.commons.math.linear.InvalidMatrixException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray61);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", (java.lang.Object[]) doubleArray61);
        java.lang.NullPointerException nullPointerException66 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable34.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(nullPointerException66);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        double[] doubleArray3 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, objArray7);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray3);
        double[] doubleArray13 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable14 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray13, localizable14, objArray17);
        org.apache.commons.math.linear.RealMatrix realMatrix19 = org.apache.commons.math.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray13);
        org.apache.commons.math.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math.linear.AnyMatrix) realMatrix9, (org.apache.commons.math.linear.AnyMatrix) realMatrix19);
        org.apache.commons.math.linear.LUDecompositionImpl lUDecompositionImpl22 = new org.apache.commons.math.linear.LUDecompositionImpl(realMatrix9, (double) 100L);
        int[] intArray23 = lUDecompositionImpl22.getPivot();
        double double24 = lUDecompositionImpl22.getDeterminant();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        double[] doubleArray4 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable5 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(doubleArray4, localizable5, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException9);
        org.apache.commons.math.optimization.OptimizationException optimizationException11 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException10);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) (byte) 1);
        org.apache.commons.math.exception.Localizable localizable16 = functionEvaluationException15.getLocalizablePattern();
        double[] doubleArray21 = new double[] { 100, 'a' };
        double[] doubleArray24 = new double[] { 100, 'a' };
        double[] doubleArray27 = new double[] { 100, 'a' };
        double[][] doubleArray28 = new double[][] { doubleArray21, doubleArray24, doubleArray27 };
        double[][] doubleArray29 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException30 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray28);
        java.util.ConcurrentModificationException concurrentModificationException31 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", (java.lang.Object[]) doubleArray28);
        double[][] doubleArray32 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException10, 10.0d, localizable16, (java.lang.Object[]) doubleArray28);
        double[] doubleArray37 = new double[] { 100, 'a' };
        double[] doubleArray40 = new double[] { 100, 'a' };
        double[] doubleArray43 = new double[] { 100, 'a' };
        double[][] doubleArray44 = new double[][] { doubleArray37, doubleArray40, doubleArray43 };
        double[][] doubleArray45 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        java.lang.NullPointerException nullPointerException46 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray45);
        java.lang.IllegalStateException illegalStateException47 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable16, (java.lang.Object[]) doubleArray45);
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException49 = new org.apache.commons.math.MaxEvaluationsExceededException((int) '#', localizable16, objArray48);
        double[] doubleArray54 = new double[] { 100, 'a' };
        double[] doubleArray57 = new double[] { 100, 'a' };
        double[] doubleArray60 = new double[] { 100, 'a' };
        double[][] doubleArray61 = new double[][] { doubleArray54, doubleArray57, doubleArray60 };
        double[][] doubleArray62 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray61);
        java.lang.ArithmeticException arithmeticException63 = org.apache.commons.math.MathRuntimeException.createArithmeticException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        org.apache.commons.math.MathRuntimeException mathRuntimeException65 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.FunctionEvaluationException: ", (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable16, (java.lang.Object[]) doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable16.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(concurrentModificationException31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(nullPointerException46);
        org.junit.Assert.assertNotNull(illegalStateException47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(arithmeticException63);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix4 = array2DRowRealMatrix2.scalarAdd(100.0d);
        double double5 = array2DRowRealMatrix2.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        int int7 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix10.createMatrix(36, (int) (byte) 1);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) '4', (int) ' ');
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.scalarAdd(100.0d);
        org.apache.commons.math.linear.RealVector realVector22 = array2DRowRealMatrix18.getRowVector((int) '#');
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix18);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = array2DRowRealMatrix2.add(array2DRowRealMatrix18);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix24.createMatrix((int) '#', (int) (byte) 100);
        org.junit.Assert.assertNotNull(realMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 32 + "'", int7 == 32);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix23);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix24);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray5 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable6 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, localizable6, objArray9);
        double[] doubleArray12 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray12, false);
        double[] doubleArray18 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable19 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray18, localizable19, objArray22);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray5, doubleArray18, true);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker26 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
        double[] doubleArray31 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable32 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray31, localizable32, objArray35);
        double[] doubleArray38 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair40 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray38, false);
        double[] doubleArray44 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable45 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(doubleArray44, localizable45, objArray48);
        double[] doubleArray51 = new double[] { (-1L) };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair53 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray51, false);
        double[] doubleArray54 = vectorialPointValuePair53.getPoint();
        boolean boolean55 = simpleVectorialValueChecker26.converged((int) (byte) -1, vectorialPointValuePair40, vectorialPointValuePair53);
        double[] doubleArray56 = vectorialPointValuePair53.getPointRef();
        boolean boolean57 = simpleVectorialValueChecker0.converged((int) (short) 0, vectorialPointValuePair25, vectorialPointValuePair53);
        double[] doubleArray58 = vectorialPointValuePair53.getPointRef();
        double[] doubleArray59 = vectorialPointValuePair53.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double[] doubleArray3 = new double[] { 100, 'a' };
        double[] doubleArray6 = new double[] { 100, 'a' };
        double[] doubleArray9 = new double[] { 100, 'a' };
        double[][] doubleArray10 = new double[][] { doubleArray3, doubleArray6, doubleArray9 };
        double[][] doubleArray11 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        java.lang.ArithmeticException arithmeticException12 = org.apache.commons.math.MathRuntimeException.createArithmeticException("maximal number of iterations ({0}) exceeded", (java.lang.Object[]) doubleArray11);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix13.transpose();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        java.lang.String str18 = maxIterationsExceededException17.getPattern();
        java.lang.Throwable throwable19 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable19, (double) (byte) 1);
        org.apache.commons.math.exception.Localizable localizable22 = functionEvaluationException21.getLocalizablePattern();
        org.apache.commons.math.exception.Localizable localizable23 = null;
        org.apache.commons.math.exception.Localizable localizable24 = null;
        double[] doubleArray28 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable29 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(doubleArray28, localizable29, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable24, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable23, objArray32);
        org.apache.commons.math.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) maxIterationsExceededException17, localizable22, objArray32);
        double[] doubleArray40 = new double[] { 100, 'a' };
        double[] doubleArray43 = new double[] { 100, 'a' };
        double[] doubleArray46 = new double[] { 100, 'a' };
        double[][] doubleArray47 = new double[][] { doubleArray40, doubleArray43, doubleArray46 };
        double[][] doubleArray48 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math.optimization.OptimizationException optimizationException49 = new org.apache.commons.math.optimization.OptimizationException("", (java.lang.Object[]) doubleArray48);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48, false);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException52 = new org.apache.commons.math.MaxEvaluationsExceededException(36, localizable22, (java.lang.Object[]) doubleArray48);
        try {
            array2DRowRealMatrix13.setSubMatrix(doubleArray48, 2147483647, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixIndexException; message: row index 2,147,483,647 out of allowed range [0, 0]");
        } catch (org.apache.commons.math.linear.MatrixIndexException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(arithmeticException12);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str18.equals("maximal number of iterations ({0}) exceeded"));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable22.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math.linear.BlockRealMatrix((int) '#', (int) (short) 10);
        int int3 = blockRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply((double) '#');
        org.apache.commons.math.linear.RealVector realVector7 = blockRealMatrix2.getColumnVector(0);
        java.io.ObjectOutputStream objectOutputStream8 = null;
        try {
            org.apache.commons.math.linear.MatrixUtils.serializeRealVector(realVector7, objectOutputStream8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        double[] doubleArray3 = new double[] { 1.0f, 0L, 10.0d };
        org.apache.commons.math.exception.Localizable localizable4 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException(doubleArray3, localizable4, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException8);
        org.apache.commons.math.optimization.OptimizationException optimizationException10 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) convergenceException9);
        java.lang.Throwable throwable12 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable12, (double) (byte) 1);
        org.apache.commons.math.exception.Localizable localizable15 = functionEvaluationException14.getLocalizablePattern();
        double[] doubleArray20 = new double[] { 100, 'a' };
        double[] doubleArray23 = new double[] { 100, 'a' };
        double[] doubleArray26 = new double[] { 100, 'a' };
        double[][] doubleArray27 = new double[][] { doubleArray20, doubleArray23, doubleArray26 };
        double[][] doubleArray28 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math.linear.InvalidMatrixException invalidMatrixException29 = new org.apache.commons.math.linear.InvalidMatrixException("", (java.lang.Object[]) doubleArray27);
        java.util.ConcurrentModificationException concurrentModificationException30 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("", (java.lang.Object[]) doubleArray27);
        double[][] doubleArray31 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray27);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, 10.0d, localizable15, (java.lang.Object[]) doubleArray27);
        double[] doubleArray36 = new double[] { 100, 'a' };
        double[] doubleArray39 = new double[] { 100, 'a' };
        double[] doubleArray42 = new double[] { 100, 'a' };
        double[][] doubleArray43 = new double[][] { doubleArray36, doubleArray39, doubleArray42 };
        double[][] doubleArray44 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        java.lang.NullPointerException nullPointerException45 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", (java.lang.Object[]) doubleArray44);
        java.lang.IllegalStateException illegalStateException46 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable15, (java.lang.Object[]) doubleArray44);
        org.apache.commons.math.exception.Localizable localizable48 = null;
        double[] doubleArray51 = new double[] { 100, 'a' };
        double[] doubleArray54 = new double[] { 100, 'a' };
        double[] doubleArray57 = new double[] { 100, 'a' };
        double[][] doubleArray58 = new double[][] { doubleArray51, doubleArray54, doubleArray57 };
        double[][] doubleArray59 = org.apache.commons.math.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math.MaxEvaluationsExceededException maxEvaluationsExceededException60 = new org.apache.commons.math.MaxEvaluationsExceededException(1, localizable48, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.MathRuntimeException mathRuntimeException61 = new org.apache.commons.math.MathRuntimeException(localizable15, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(concurrentModificationException30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(nullPointerException45);
        org.junit.Assert.assertNotNull(illegalStateException46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
    }
}

