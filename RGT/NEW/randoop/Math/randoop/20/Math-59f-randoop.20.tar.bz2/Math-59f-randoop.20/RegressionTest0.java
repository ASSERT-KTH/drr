import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test005");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.1904592245245188d + "'", double0 == 0.1904592245245188d);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.1904592245245188d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4364163430997043d + "'", double1 == 0.4364163430997043d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        try {
            int int2 = mersenneTwister0.nextInt((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 2, 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0d + "'", double2 == 1024.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 8, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.695151321341658d + "'", double2 == 1.695151321341658d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.4364163430997043d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9062722711816759d + "'", double1 == 0.9062722711816759d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int2 = org.apache.commons.math.util.FastMath.max(32760, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32760 + "'", int2 == 32760);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 35, (double) (-972949811922108177L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-3480802555218261625L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.449445015198403d + "'", double1 == 4.449445015198403d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-919354121997984976L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.1935412199798502E17d + "'", double1 == 9.1935412199798502E17d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

//    @Test
//    public void test051() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test051");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
//        long long3 = mersenneTwister2.nextLong();
//        float float4 = mersenneTwister2.nextFloat();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        numberIsTooSmallException10.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
//        java.lang.Object[] objArray18 = new java.lang.Object[] { mersenneTwister2, 'a', ' ', numberIsTooSmallException14, (short) 100, (byte) -1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray18);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray18);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-6049992125526582820L) + "'", long3 == (-6049992125526582820L));
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.47270954f + "'", float4 == 0.47270954f);
//        org.junit.Assert.assertNotNull(objArray18);
//    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0.27374506f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-32767), (java.lang.Number) Double.NEGATIVE_INFINITY, false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6268604078470186d + "'", double1 == 3.6268604078470186d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-7202663140626610265L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963267948966d) + "'", double1 == (-1.5707963267948966d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.0f + "'", float1 == 8.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.000000000000002d + "'", double1 == 8.000000000000002d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        float float2 = org.apache.commons.math.util.FastMath.max(0.39877272f, (float) (-3421106811016285627L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.39877272f + "'", float2 == 0.39877272f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-5493406563038245403L), 0.5769788f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.5769788f + "'", float2 == 0.5769788f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-7063021267650039515L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9891756912986386d) + "'", double1 == (-0.9891756912986386d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double2 = org.apache.commons.math.util.FastMath.min((double) '4', 11013.232920103323d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.apache.commons.math.util.FastMath.round(32.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 5950004567201833768L, (double) (-28479206));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.8479206E7d) + "'", double2 == (-2.8479206E7d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 4.605170185988092d + "'", number5.equals(4.605170185988092d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1158608686));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.158608686E9d + "'", double1 == 1.158608686E9d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-356329160));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.9604644775390625E-8d + "'", double1 == 5.9604644775390625E-8d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1126640331));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5211141550652623d + "'", double1 == 1.5211141550652623d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.158608686E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08719003655753117d + "'", double1 == 0.08719003655753117d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        long long1 = org.apache.commons.math.util.FastMath.round(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        int int2 = org.apache.commons.math.util.FastMath.min((-2035370246), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2035370246) + "'", int2 == (-2035370246));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 691077309);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        long long4 = mersenneTwister3.nextLong();
//        float float5 = mersenneTwister3.nextFloat();
//        boolean boolean6 = mersenneTwister3.nextBoolean();
//        int int7 = mersenneTwister3.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        long long10 = mersenneTwister8.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister11.nextBytes(byteArray15);
//        mersenneTwister8.nextBytes(byteArray15);
//        mersenneTwister3.nextBytes(byteArray15);
//        mersenneTwister3.setSeed((-6049992125526582820L));
//        double double21 = mersenneTwister3.nextDouble();
//        java.lang.Object[] objArray27 = new java.lang.Object[] { double21, (short) -1, 9.1935412199798502E17d, (-2035370246), (-6049992125526582820L), 0.27374506f };
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray27);
//        java.lang.Object[] objArray29 = mathRuntimeException28.getArguments();
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5377943003167383641L + "'", long4 == 5377943003167383641L);
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.051930904f + "'", float5 == 0.051930904f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1166274520) + "'", int7 == (-1166274520));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5962689556159939772L + "'", long9 == 5962689556159939772L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3776972014042815764L + "'", long10 == 3776972014042815764L);
//        org.junit.Assert.assertNotNull(byteArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5734050033669145d + "'", double21 == 0.5734050033669145d);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertNotNull(objArray29);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.4364163430997043d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 691077309);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 691077309 + "'", int2 == 691077309);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test088");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        byte[] byteArray3 = null;
//        try {
//            mersenneTwister0.nextBytes(byteArray3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2458194797097641876L) + "'", long1 == (-2458194797097641876L));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.2730056f + "'", float2 == 0.2730056f);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 8.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9893582466233818d + "'", double1 == 0.9893582466233818d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-5440246529469988002L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int1 = org.apache.commons.math.util.FastMath.abs((-356329160));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 356329160 + "'", int1 == 356329160);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-4016513083209653692L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathRuntimeException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        java.lang.Object[] objArray6 = mathRuntimeException4.getArguments();
        java.lang.Object[] objArray7 = mathRuntimeException4.getArguments();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-2544114391450254357L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-3421106811016285627L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.4211068110162857E18d) + "'", double1 == (-3.4211068110162857E18d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-32767));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189894035458565E-12d + "'", double1 == 1.8189894035458565E-12d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-5493406563038245403L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11600.540643093926d + "'", double1 == 11600.540643093926d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 97);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 49.99500000000002d + "'", double1 == 49.99500000000002d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.298342365610589d, (double) (-5440246529469988002L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.298342365610588d + "'", double2 == 5.298342365610588d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 0.37085557f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.37085556983947754d + "'", double2 == 0.37085556983947754d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        long long2 = org.apache.commons.math.util.FastMath.max(2102934446297000809L, (-2544114391450254357L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2102934446297000809L + "'", long2 == 2102934446297000809L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.08719003655753117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08719003655753117d + "'", double1 == 0.08719003655753117d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-972949811922108177L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6981177674700366E16d) + "'", double1 == (-1.6981177674700366E16d));
    }

//    @Test
//    public void test114() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test114");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        long long4 = mersenneTwister3.nextLong();
//        float float5 = mersenneTwister3.nextFloat();
//        boolean boolean6 = mersenneTwister3.nextBoolean();
//        int int7 = mersenneTwister3.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        long long10 = mersenneTwister8.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister11.nextBytes(byteArray15);
//        mersenneTwister8.nextBytes(byteArray15);
//        mersenneTwister3.nextBytes(byteArray15);
//        mersenneTwister3.setSeed((-6049992125526582820L));
//        double double21 = mersenneTwister3.nextDouble();
//        java.lang.Object[] objArray27 = new java.lang.Object[] { double21, (short) -1, 9.1935412199798502E17d, (-2035370246), (-6049992125526582820L), 0.27374506f };
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray27);
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException29 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException28);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3371503387421592785L + "'", long4 == 3371503387421592785L);
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.54728854f + "'", float5 == 0.54728854f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 862952443 + "'", int7 == 862952443);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7940878414890026194L + "'", long9 == 7940878414890026194L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6279318891992503777L + "'", long10 == 6279318891992503777L);
//        org.junit.Assert.assertNotNull(byteArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5734050033669145d + "'", double21 == 0.5734050033669145d);
//        org.junit.Assert.assertNotNull(objArray27);
//    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.apache.commons.math.util.FastMath.round(0.9201069f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int2 = org.apache.commons.math.util.FastMath.min((-1979276953), 1599591723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1979276953) + "'", int2 == (-1979276953));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.15779906193855409d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1584547581788498d + "'", double1 == 0.1584547581788498d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        long long2 = org.apache.commons.math.util.FastMath.max((-735143788403443838L), (-3480802555218261625L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-735143788403443838L) + "'", long2 == (-735143788403443838L));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.String str8 = mathRuntimeException7.toString();
        java.lang.Throwable[] throwableArray9 = mathRuntimeException7.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.util.Localizable localizable11 = mathRuntimeException10.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str8.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 38062555481337953L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        int int5 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-7202663140626610265L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = org.apache.commons.math.dfp.DfpField.computeExp(dfp2, dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        int int2 = org.apache.commons.math.util.FastMath.max(1840572684, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1840572684 + "'", int2 == 1840572684);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        long long2 = org.apache.commons.math.util.FastMath.min((-6274053931908423703L), (-1001877702976037456L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6274053931908423703L) + "'", long2 == (-6274053931908423703L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.54728854f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5472885370254517d + "'", double1 == 0.5472885370254517d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 8700216650143127008L, (java.lang.Number) (-1L), false);
    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test136");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        double double2 = mersenneTwister0.nextDouble();
//        try {
//            int int4 = mersenneTwister0.nextInt((int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5565389466267249392L + "'", long1 == 5565389466267249392L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.33270834226114565d + "'", double2 == 0.33270834226114565d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-972949811922108177L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 128.0d + "'", double1 == 128.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 2233282500890457460L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.0d + "'", double1 == 256.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0.032155037f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.15779906193855409d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1577990619385541d + "'", double2 == 0.1577990619385541d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((-2028199038786459560L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 5950004567201833768L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-28479206));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-28479206) + "'", int2 == (-28479206));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        long long2 = org.apache.commons.math.util.FastMath.max(6279318891992503777L, (-9157910218227491957L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6279318891992503777L + "'", long2 == 6279318891992503777L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1126640331));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1126640384) + "'", int1 == (-1126640384));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2035370246));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2035370246 + "'", int1 == 2035370246);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-3335828026518722798L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.33582812E18f + "'", float1 == 3.33582812E18f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.exp(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 3371503387421592785L, (-0.30685281944d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0638830775714374E-6d + "'", double2 == 2.0638830775714374E-6d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7764722807237177d + "'", double1 == 2.7764722807237177d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        boolean boolean17 = dfp13.unequal(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp4.newInstance(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getZero();
        int int22 = dfp21.log10K();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.negate();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getLn2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.subtract(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn2();
        boolean boolean36 = dfp32.unequal(dfp35);
        double double37 = dfp32.toDouble();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp23, dfp32);
        org.apache.commons.math.dfp.Dfp dfp39 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp40 = dfp4.nextAfter(dfp39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + (-0.30685281944d) + "'", double37 == (-0.30685281944d));
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-28479206));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-28479206L) + "'", long1 == (-28479206L));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 3776972014042815764L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0.059582233f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8203978461801373d) + "'", double1 == (-2.8203978461801373d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        boolean boolean17 = dfp13.unequal(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp4.newInstance(dfp16);
        int int19 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 7051874667675530367L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1917644.923099989d + "'", double1 == 1917644.923099989d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-390747649201991964L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        java.lang.Number number10 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException7.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 4.605170185988092d + "'", number10.equals(4.605170185988092d));
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        boolean boolean12 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-7085894727024589701L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.0858947270245898E18d) + "'", double1 == (-7.0858947270245898E18d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        long long2 = org.apache.commons.math.util.FastMath.max((-6697407083237886024L), 1724693326383689720L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1724693326383689720L + "'", long2 == 1724693326383689720L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-798010429));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-28479206));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-8905087586450486507L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.9050875864504863E18d) + "'", double1 == (-8.9050875864504863E18d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-8.9050875864504863E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 5.551115123125783E-17d);
        java.lang.Number number7 = notStrictlyPositiveException6.getArgument();
        java.lang.Object[] objArray8 = notStrictlyPositiveException6.getArguments();
        mathIllegalArgumentException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        boolean boolean10 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 5.551115123125783E-17d + "'", number7.equals(5.551115123125783E-17d));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.getTwo();
        double double16 = dfp4.toDouble();
        boolean boolean17 = dfp4.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.69314718056d + "'", double16 == 0.69314718056d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-3421106811016285627L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-321798667), 0.54728854f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.54728854f + "'", float2 == 0.54728854f);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        long long2 = org.apache.commons.math.util.FastMath.min((-2544114391450254357L), (-5493406563038245403L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5493406563038245403L) + "'", long2 == (-5493406563038245403L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1209585570, (double) 307753049);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.321654020981052d + "'", double2 == 1.321654020981052d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.57812226f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5464523106791267d + "'", double1 == 0.5464523106791267d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1873816088));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-2035370246), 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0353702459999998E9d) + "'", double2 == (-2.0353702459999998E9d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 356329160, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.56329152E8f + "'", float2 == 3.56329152E8f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int1 = org.apache.commons.math.util.FastMath.round(0.54728854f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.1830461f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2008697699318138d + "'", double1 == 1.2008697699318138d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-4653545980580729856L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.6662854445734396E20d) + "'", double1 == (-2.6662854445734396E20d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.log1p(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1309831832));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9098793529329888d + "'", double1 == 0.9098793529329888d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.subtract(dfp10);
        boolean boolean12 = dfp11.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister8.setSeed(32);
        org.junit.Assert.assertNotNull(intArray6);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        float float16 = mersenneTwister0.nextFloat();
//        boolean boolean17 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(0L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2105748279754649252L + "'", long1 == 2105748279754649252L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.3598838f + "'", float2 == 0.3598838f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-493018183) + "'", int4 == (-493018183));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4022127595976768309L) + "'", long6 == (-4022127595976768309L));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3305612614089886808L + "'", long7 == 3305612614089886808L);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.10626459f + "'", float16 == 0.10626459f);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        java.lang.String str13 = dfp11.toString();
        int int14 = dfp11.getRadixDigits();
        int int15 = dfp11.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.6931471805599453" + "'", str13.equals("0.6931471805599453"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.158608686E9d, (double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5552862773777275E27d + "'", double2 == 1.5552862773777275E27d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1724693326383689720L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1724693326383689728L + "'", long1 == 1724693326383689728L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int2 = org.apache.commons.math.util.FastMath.max(1890270366, (-32767));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1890270366 + "'", int2 == 1890270366);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 8288323919154863780L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.91846671556146d + "'", double1 == 18.91846671556146d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-8905087586450486507L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 253.1682802423552d + "'", double1 == 253.1682802423552d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.8189894035458565E-12d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.8189894035458565E-12d + "'", number4.equals(1.8189894035458565E-12d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.5472885370254517d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-3421106811016285627L), Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3776972014042815764L, (float) (-3335828026518722798L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.77697197E18f + "'", float2 == 3.77697197E18f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-2390231283762284050L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 5950004567201833768L, (java.lang.Number) 4674391295565184309L, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.atan(8.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4464413322481353d + "'", double1 == 1.4464413322481353d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 4, (-2334012524150612377L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6086280993848117d + "'", double1 == 1.6086280993848117d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '4');
        int int10 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 23 + "'", int10 == 23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 5193330595655160931L, (double) (-28479206));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.1933305956551608E18d + "'", double2 == 5.1933305956551608E18d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-257383192460495582L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.4921841477298935E15d) + "'", double1 == (-4.4921841477298935E15d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        int int5 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1209585570);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9340424858798563d) + "'", double1 == (-0.9340424858798563d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.050000000000001d + "'", double1 == 5.050000000000001d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3765110317740726359L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.76511044E18f + "'", float1 == 3.76511044E18f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.power10K((-1158608686));
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn2();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.subtract(dfp26);
        java.lang.String str28 = dfp27.toString();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp18.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp13.newInstance(dfp18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "-0.3068528194400547" + "'", str28.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.321654020981052d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.382454517517492d + "'", double2 == 4.382454517517492d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.624619224577892d + "'", double1 == 7.624619224577892d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        int int2 = org.apache.commons.math.util.FastMath.max((-1279918493), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.8813735870195429d, (double) (-2023300344));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195428d + "'", double2 == 0.8813735870195428d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int1 = org.apache.commons.math.util.FastMath.abs(1599591723);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1599591723 + "'", int1 == 1599591723);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3371503387421592785L, (java.lang.Number) (-7202663140626610265L), true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 4674391295565184309L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        java.lang.String str9 = dfp8.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0.3068528194400547" + "'", str9.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0.1830461f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.181028762004227d + "'", double1 == 0.181028762004227d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-28479206));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-627795142));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1579276996);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.579276996E9d + "'", double1 == 1.579276996E9d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        boolean boolean5 = dfp2.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test245");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((int) (byte) 2);
//        double double5 = mersenneTwister0.nextGaussian();
//        double double6 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-6617460709915868453L) + "'", long1 == (-6617460709915868453L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5710982096930849361L + "'", long2 == 5710982096930849361L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.4871469606651075d) + "'", double5 == (-2.4871469606651075d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5496624849398524d + "'", double6 == 0.5496624849398524d);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        double double9 = mersenneTwister8.nextGaussian();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.2641277886148765d + "'", double9 == 0.2641277886148765d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.2999725393337596d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 567075184614940841L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6707518461494086E17d + "'", double1 == 5.6707518461494086E17d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int1 = org.apache.commons.math.util.FastMath.abs(1142922799);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1142922799 + "'", int1 == 1142922799);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        int int5 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.1904592245245188d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.19045922452451883d + "'", double2 == 0.19045922452451883d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        int int2 = org.apache.commons.math.util.FastMath.max(10000, (-1166274520));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10000 + "'", int2 == 10000);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1890270366);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.1904592245245188d, (java.lang.Number) 10, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

//    @Test
//    public void test256() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test256");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        long long3 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3462641030462656495L) + "'", long1 == (-3462641030462656495L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1853740354352149377L + "'", long2 == 1853740354352149377L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 8320216286286413930L + "'", long3 == 8320216286286413930L);
//    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.8189894035458565E-12d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 5193330595655160931L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        boolean boolean11 = dfp8.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((double) (-798010429));
        int int16 = dfp15.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.7716423f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5719069849177855d + "'", double1 == 0.5719069849177855d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-5440246529469988002L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 5.4402466E18f + "'", float1 == 5.4402466E18f);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double2 = org.apache.commons.math.util.FastMath.max(0.37085556983947754d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.37085556983947754d + "'", double2 == 0.37085556983947754d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.5063656411097588d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1599591723, (-3.4211068110162857E18d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        int int2 = org.apache.commons.math.util.FastMath.min(307753049, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3.33582812E18f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        java.lang.Number number21 = numberIsTooSmallException20.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 49.99500000000002d + "'", number21.equals(49.99500000000002d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        boolean boolean9 = dfp8.isNaN();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.power10K((int) ' ');
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.ceil(18.91846671556146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.0d + "'", double1 == 19.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((double) 1.0f);
        int int6 = dfp2.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-4) + "'", int6 == (-4));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.sin(5.1933305956551608E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9815025944569622d) + "'", double1 == (-0.9815025944569622d));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (-1590619262214363973L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.4464413322481353d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        int int8 = dfp7.log10K();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.negate();
        boolean boolean10 = dfp4.lessThan(dfp9);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0.100408316f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0050451514874326d + "'", double1 == 1.0050451514874326d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits(1840572684);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2093271168964412317L));
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: -2,093,271,168,964,412,317 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: -2,093,271,168,964,412,317 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.subtract(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.ceil();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp34.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance((double) 0.86033094f);
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeExp(dfp25, dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = new org.apache.commons.math.dfp.Dfp(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        double double6 = mersenneTwister0.nextDouble();
//        int int7 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8372167407663449d + "'", double6 == 0.8372167407663449d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1971268331 + "'", int7 == 1971268331);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 787369448);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.37549102187068223d) + "'", double1 == (-0.37549102187068223d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 5193330595655160931L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        float float2 = org.apache.commons.math.util.FastMath.max(0.30810094f, 0.8748847f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8748847f + "'", float2 == 0.8748847f);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-493018183), 4674391295565184309L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4674391295565184309L + "'", long2 == 4674391295565184309L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3839296689174442270L, (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.83929669E18f + "'", float2 == 3.83929669E18f);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister();
//        long long2 = mersenneTwister1.nextLong();
//        long long3 = mersenneTwister1.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister4.nextBytes(byteArray8);
//        mersenneTwister1.nextBytes(byteArray8);
//        java.lang.Object[] objArray11 = new java.lang.Object[] { mersenneTwister1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException16);
//        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) mathRuntimeException17);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8676598251368639082L + "'", long2 == 8676598251368639082L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5417275700760945706L + "'", long3 == 5417275700760945706L);
//        org.junit.Assert.assertNotNull(byteArray8);
//        org.junit.Assert.assertNotNull(objArray11);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.2270567152701908d), 1.695151321341658d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.13315227625029352d) + "'", double2 == (-0.13315227625029352d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-2.8479206E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-497055.9130537242d) + "'", double1 == (-497055.9130537242d));
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        double double5 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed(10L);
//        float float8 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2099567481933244851L + "'", long1 == 2099567481933244851L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.83084273f + "'", float2 == 0.83084273f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1066394775 + "'", int4 == 1066394775);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.3719691646482689d) + "'", double5 == (-0.3719691646482689d));
//        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5711645f + "'", float8 == 0.5711645f);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-3335828026518722798L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.21565585836876824d) + "'", double1 == (-0.21565585836876824d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.794759035160894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01387116192353098d + "'", double1 == 0.01387116192353098d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.298342365610588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 2059804394);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        java.lang.Number number12 = numberIsTooSmallException9.getArgument();
        java.lang.Number number13 = numberIsTooSmallException9.getMin();
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray14);
        java.lang.Throwable[] throwableArray16 = mathIllegalArgumentException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 4.605170185988092d + "'", number12.equals(4.605170185988092d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1853740354352149377L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8537403543521495E18d + "'", double1 == 1.8537403543521495E18d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10491011863382856d) + "'", double1 == (-0.10491011863382856d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.apache.commons.math.util.FastMath.max(5477467001140908072L, (-4202901040889903664L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5477467001140908072L + "'", long2 == 5477467001140908072L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        java.lang.Throwable[] throwableArray6 = mathRuntimeException4.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4);
        java.lang.Throwable[] throwableArray8 = mathRuntimeException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1890270366);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9834153981676406d) + "'", double1 == (-0.9834153981676406d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getZero();
        int int24 = dfpField22.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField22.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, (java.lang.Object[]) dfpArray25);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dfpArray25);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 4.605 is smaller than, or equal to, the minimum (0)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 4.605 is smaller than, or equal to, the minimum (0)"));
    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test310");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1209585570);
//        int[] intArray2 = null;
//        mersenneTwister1.setSeed(intArray2);
//        float float4 = mersenneTwister1.nextFloat();
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.14439452f + "'", float4 == 0.14439452f);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        java.lang.Throwable throwable10 = null;
        try {
            numberIsTooSmallException7.addSuppressed(throwable10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3.56329152E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1209585570);
        try {
            int int3 = mersenneTwister1.nextInt((-1166274520));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1,166,274,520 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 8315623740657388300L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.223156202527103d + "'", double1 == 1.223156202527103d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.String str9 = mathRuntimeException8.toString();
        java.lang.Throwable[] throwableArray10 = mathRuntimeException8.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable1, localizable2, localizable3, (java.lang.Object[]) throwableArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.4364163430997043d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6606181522632453d + "'", double1 == 0.6606181522632453d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (-5108934833899263838L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9188797929052988d), 19.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 19.0d + "'", double2 == 19.0d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long long1 = org.apache.commons.math.util.FastMath.abs(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 3);
        int int4 = dfp3.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1166274520));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1807347122), 0.8372167407663449d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8073471219999998E9d) + "'", double2 == (-1.8073471219999998E9d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        boolean boolean7 = dfp6.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        boolean boolean9 = dfp8.isNaN();
        int int10 = dfp8.getRadixDigits();
        boolean boolean11 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(5.551115123125783E-17d);
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp4.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpField5);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1279918493));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9340424858798563d));
        int int8 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-6697407083237886024L));
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.56900036f + "'", float2 == 0.56900036f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((double) 0.100408316f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        int int14 = dfp11.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.3598838f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43316285021641454d + "'", double1 == 0.43316285021641454d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        java.lang.String str5 = dfp2.toString();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            boolean boolean7 = dfp2.unequal(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0." + "'", str5.equals("0."));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9340424858798563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3522461778175519d) + "'", double1 == (-1.3522461778175519d));
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister();
//        long long2 = mersenneTwister1.nextLong();
//        float float3 = mersenneTwister1.nextFloat();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { mersenneTwister1, 'a', ' ', numberIsTooSmallException13, (short) 100, (byte) -1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
//        java.lang.String str20 = mathIllegalArgumentException18.toString();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4805324952470941280L + "'", long2 == 4805324952470941280L);
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.35889983f + "'", float3 == 0.35889983f);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNull(localizable19);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str20.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5193330595655160931L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2.0d);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.subtract(dfp19);
        java.lang.String str21 = dfp20.toString();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp11.nextAfter(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp("-0.3068528194400547");
        boolean boolean27 = dfp11.unequal(dfp26);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp6.subtract(dfp11);
        int int29 = dfp6.classify();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-0.3068528194400547" + "'", str21.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 787369448);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 923.4063420514391d + "'", double1 == 923.4063420514391d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.subtract(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((double) (-798010429));
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp8.dotrap((-798010429), "0.6931471805599453", dfp25, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp25.newInstance("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1872492081878224521L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.87249208187822464E18d + "'", double1 == 1.87249208187822464E18d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        double double13 = dfp8.toDouble();
        int int14 = dfp8.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.30685281944d) + "'", double13 == (-0.30685281944d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfpField1.getRadixDigits();
        java.lang.Class<?> wildcardClass8 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getPiSplit();
        dfpField13.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getPi();
        boolean boolean18 = dfp11.unequal(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp11.power10K((-483117249));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dfp20);
    }

//    @Test
//    public void test346() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test346");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed(2780242596957121269L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1256098311067136322L + "'", long1 == 1256098311067136322L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.37672758f + "'", float2 == 0.37672758f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 595445506 + "'", int4 == 595445506);
//    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = null;
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp17.unequal(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.rint();
        try {
            org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.DfpField.computeLn(dfp7, dfp8, dfp20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 3.83929669E18f, (double) (-3480802555218261625L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister();
//        long long2 = mersenneTwister1.nextLong();
//        float float3 = mersenneTwister1.nextFloat();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException13);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { mersenneTwister1, 'a', ' ', numberIsTooSmallException13, (short) 100, (byte) -1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray17);
//        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable20 = mathIllegalArgumentException18.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 377087298069241222L + "'", long2 == 377087298069241222L);
//        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.7598312f + "'", float3 == 0.7598312f);
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNull(localizable19);
//        org.junit.Assert.assertNull(localizable20);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        double double5 = mersenneTwister0.nextGaussian();
//        int int7 = mersenneTwister0.nextInt(356329160);
//        java.lang.Class<?> wildcardClass8 = mersenneTwister0.getClass();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6297565019306407176L + "'", long1 == 6297565019306407176L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.49845362f + "'", float2 == 0.49845362f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1611539525) + "'", int4 == (-1611539525));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.08696887948932319d) + "'", double5 == (-0.08696887948932319d));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 154794522 + "'", int7 == 154794522);
//        org.junit.Assert.assertNotNull(wildcardClass8);
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9893582466233818d, (double) (-2225318385036581271L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9893582466233818d + "'", double2 == 0.9893582466233818d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        long long2 = org.apache.commons.math.util.FastMath.min((-4310219521635352857L), (-3180649955282255128L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4310219521635352857L) + "'", long2 == (-4310219521635352857L));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray7);
        mathRuntimeException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException8);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067811865475d + "'", double1 == 0.7071067811865475d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-3180649955282255128L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp2.newInstance((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister7.setSeed((-1629873166195752489L));
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0.39877272f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38889557469347424d + "'", double1 == 0.38889557469347424d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        long long2 = org.apache.commons.math.util.FastMath.min((-5139101697689628891L), (long) (-1873816088));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5139101697689628891L) + "'", long2 == (-5139101697689628891L));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-28479206));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.19045922452451883d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1142922799, (double) (-1158608686));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1429227989999998E9d + "'", double2 == 1.1429227989999998E9d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        java.lang.String str13 = dfp11.toString();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.6931471805599453" + "'", str13.equals("0.6931471805599453"));
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1026999590, (double) 0.01806581f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.018065810203552246d + "'", double2 == 0.018065810203552246d);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test368");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray6);
//        long long8 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1241236742866107100L) + "'", long1 == (-1241236742866107100L));
//        org.junit.Assert.assertNotNull(byteArray6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2315732674968627721L) + "'", long8 == (-2315732674968627721L));
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("0.6931471805599453");
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Throwable[] throwableArray3 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.String str16 = mathRuntimeException15.toString();
        java.lang.Object[] objArray17 = mathRuntimeException15.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number25 = numberIsTooSmallException24.getArgument();
        java.lang.Number number26 = numberIsTooSmallException24.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31);
        java.lang.String str33 = mathRuntimeException32.toString();
        java.lang.Object[] objArray34 = mathRuntimeException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        java.lang.Throwable[] throwableArray46 = mathIllegalArgumentException45.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable27, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number52 = numberIsTooSmallException51.getArgument();
        java.lang.Number number53 = numberIsTooSmallException51.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException51.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException59 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException58);
        java.lang.String str60 = mathRuntimeException59.toString();
        java.lang.Object[] objArray61 = mathRuntimeException59.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable54, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField66.getZero();
        int int68 = dfpField66.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField66.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable54, (java.lang.Object[]) dfpArray69);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 2662705844154317738L + "'", number8.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 2662705844154317738L + "'", number9.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2662705844154317738L + "'", number25.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 2662705844154317738L + "'", number26.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str33.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 2662705844154317738L + "'", number52.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 2662705844154317738L + "'", number53.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str60.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 4 + "'", int68 == 4);
        org.junit.Assert.assertNotNull(dfpArray69);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number10 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 4.605170185988092d + "'", number10.equals(4.605170185988092d));
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        mersenneTwister0.setSeed((-6049992125526582820L));
//        double double18 = mersenneTwister0.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister();
//        long long20 = mersenneTwister19.nextLong();
//        byte[] byteArray25 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 100 };
//        mersenneTwister19.nextBytes(byteArray25);
//        mersenneTwister0.nextBytes(byteArray25);
//        int int28 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed((long) (-1611539525));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7663144315323579569L + "'", long1 == 7663144315323579569L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.9596857f + "'", float2 == 0.9596857f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1240426438 + "'", int4 == 1240426438);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 8363141116348244588L + "'", long6 == 8363141116348244588L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 7477930465695145157L + "'", long7 == 7477930465695145157L);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5734050033669145d + "'", double18 == 0.5734050033669145d);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 8604973897169534704L + "'", long20 == 8604973897169534704L);
//        org.junit.Assert.assertNotNull(byteArray25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1308428405 + "'", int28 == 1308428405);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1L), (float) (-2028199038786459560L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-346.8269597771289d) + "'", double1 == (-346.8269597771289d));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 2,662,705,844,154,317,738 is smaller than, or equal to, the minimum (1.563)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 2,662,705,844,154,317,738 is smaller than, or equal to, the minimum (1.563)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2662705844154317738L + "'", number6.equals(2662705844154317738L));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.10491011863382856d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10471778205546493d) + "'", double1 == (-0.10471778205546493d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int1 = org.apache.commons.math.util.FastMath.round(0.08757305f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        boolean boolean9 = dfp8.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.subtract(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((double) (-798010429));
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp8.dotrap((-798010429), "0.6931471805599453", dfp25, dfp33);
        int int35 = dfp33.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 8.0f);
        java.lang.String str19 = notStrictlyPositiveException18.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 8 is smaller than, or equal to, the minimum (0): 8 is smaller than, or equal to, the minimum (0)" + "'", str19.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 8 is smaller than, or equal to, the minimum (0): 8 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1240426438);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int2 = org.apache.commons.math.util.FastMath.min(32760, 2114456903);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32760 + "'", int2 == 32760);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9340424858798563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 8288323919154863780L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.2883239191548641E18d + "'", double1 == 8.2883239191548641E18d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((long) (byte) 2);
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-4016513083209653692L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-356329160));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.881373587019543d + "'", double1 == 0.881373587019543d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2114456903);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.472063833491536d + "'", double1 == 21.472063833491536d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.subtract(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((double) (-798010429));
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp8.dotrap((-798010429), "0.6931471805599453", dfp25, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.newInstance(10);
        boolean boolean37 = dfp33.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1429227989999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2075512827288153d + "'", double1 == 0.2075512827288153d);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        double double16 = mersenneTwister0.nextGaussian();
//        long long17 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-6582382041595213764L) + "'", long1 == (-6582382041595213764L));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.59621847f + "'", float2 == 0.59621847f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2067035082) + "'", int4 == (-2067035082));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-4639711752862856129L) + "'", long6 == (-4639711752862856129L));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3558690542494639229L + "'", long7 == 3558690542494639229L);
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.29445034032018347d + "'", double16 == 0.29445034032018347d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-3145292860822071060L) + "'", long17 == (-3145292860822071060L));
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        long long2 = org.apache.commons.math.util.FastMath.min((-9157910218227491957L), (-5438854013234158598L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9157910218227491957L) + "'", long2 == (-9157910218227491957L));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1890270366, (java.lang.Number) 0.23687017f, true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 7963711078987545635L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1996971.339170858d + "'", double1 == 1996971.339170858d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-3335828026518722798L), 10.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.335828026518722E18d) + "'", double2 == (-3.335828026518722E18d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-2014857210165424996L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0148572101654249E18d) + "'", double1 == (-2.0148572101654249E18d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.38676608f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39648104811528284d + "'", double1 == 0.39648104811528284d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 675614889, (java.lang.Number) 1.1429227989999998E9d, false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-28479206L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5345935162830573d) + "'", double1 == (-0.5345935162830573d));
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test403");
//        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
//        long long8 = mersenneTwister7.nextLong();
//        long long9 = mersenneTwister7.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray14 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister10.nextBytes(byteArray14);
//        java.lang.Class<?> wildcardClass16 = mersenneTwister10.getClass();
//        int int17 = mersenneTwister10.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister();
//        long long19 = mersenneTwister18.nextLong();
//        float float20 = mersenneTwister18.nextFloat();
//        boolean boolean21 = mersenneTwister18.nextBoolean();
//        int int22 = mersenneTwister18.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister();
//        long long24 = mersenneTwister23.nextLong();
//        long long25 = mersenneTwister23.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister26 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray30 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister26.nextBytes(byteArray30);
//        mersenneTwister23.nextBytes(byteArray30);
//        mersenneTwister18.nextBytes(byteArray30);
//        mersenneTwister10.nextBytes(byteArray30);
//        mersenneTwister7.nextBytes(byteArray30);
//        mersenneTwister7.setSeed(0L);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4202901040889903664L) + "'", long8 == (-4202901040889903664L));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3016148340477316550L + "'", long9 == 3016148340477316550L);
//        org.junit.Assert.assertNotNull(byteArray14);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1738639778) + "'", int17 == (-1738639778));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 7348760020049218068L + "'", long19 == 7348760020049218068L);
//        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.48714733f + "'", float20 == 0.48714733f);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-435974713) + "'", int22 == (-435974713));
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 3645447953643564127L + "'", long24 == 3645447953643564127L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 8660989344074991798L + "'", long25 == 8660989344074991798L);
//        org.junit.Assert.assertNotNull(byteArray30);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5552862773777275E27d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        double double5 = mersenneTwister0.nextGaussian();
//        double double6 = mersenneTwister0.nextGaussian();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister7.nextBytes(byteArray11);
//        java.lang.Class<?> wildcardClass13 = mersenneTwister7.getClass();
//        int int14 = mersenneTwister7.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister();
//        long long16 = mersenneTwister15.nextLong();
//        float float17 = mersenneTwister15.nextFloat();
//        boolean boolean18 = mersenneTwister15.nextBoolean();
//        int int19 = mersenneTwister15.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister();
//        long long21 = mersenneTwister20.nextLong();
//        long long22 = mersenneTwister20.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray27 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister23.nextBytes(byteArray27);
//        mersenneTwister20.nextBytes(byteArray27);
//        mersenneTwister15.nextBytes(byteArray27);
//        mersenneTwister7.nextBytes(byteArray27);
//        int[] intArray33 = new int[] { 8 };
//        mersenneTwister7.setSeed(intArray33);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math.random.MersenneTwister(intArray33);
//        mersenneTwister0.setSeed(intArray33);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 78319978379718557L + "'", long1 == 78319978379718557L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.87750924f + "'", float2 == 0.87750924f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1263985607 + "'", int4 == 1263985607);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.36547519442269466d + "'", double5 == 0.36547519442269466d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.072763416717771d + "'", double6 == 1.072763416717771d);
//        org.junit.Assert.assertNotNull(byteArray11);
//        org.junit.Assert.assertNotNull(wildcardClass13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1536375455 + "'", int14 == 1536375455);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + (-6605076130036793320L) + "'", long16 == (-6605076130036793320L));
//        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.13131857f + "'", float17 == 0.13131857f);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1011709885) + "'", int19 == (-1011709885));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 732677041123915846L + "'", long21 == 732677041123915846L);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1592948537342222583L + "'", long22 == 1592948537342222583L);
//        org.junit.Assert.assertNotNull(byteArray27);
//        org.junit.Assert.assertNotNull(intArray33);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4364163430997043d, (double) (-28479206));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.43641634309970423d + "'", double2 == 0.43641634309970423d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        java.lang.String str13 = dfp11.toString();
        int int14 = dfp11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.getZero();
        int int16 = dfp15.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.6931471805599453" + "'", str13.equals("0.6931471805599453"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.059582233f, (java.lang.Number) (-1651126836), true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1629873166195752489L), 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4, localizable6, localizable7, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathRuntimeException4.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.321654020981052d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = org.apache.commons.math.dfp.DfpField.computeExp(dfp4, dfp5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.subtract(dfp10);
        boolean boolean12 = dfp11.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getOne();
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        mersenneTwister0.setSeed((-6049992125526582820L));
//        double double18 = mersenneTwister0.nextDouble();
//        double double19 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1468630187447899059L + "'", long1 == 1468630187447899059L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.29133427f + "'", float2 == 0.29133427f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1397189196 + "'", int4 == 1397189196);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 4672451722473715821L + "'", long6 == 4672451722473715821L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-127443198497536972L) + "'", long7 == (-127443198497536972L));
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5734050033669145d + "'", double18 == 0.5734050033669145d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3690380939809956d + "'", double19 == 1.3690380939809956d);
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long8 = mersenneTwister7.nextLong();
        mersenneTwister7.setSeed(0);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4202901040889903664L) + "'", long8 == (-4202901040889903664L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.8537403543521495E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3615213381920056E9d + "'", double1 == 1.3615213381920056E9d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1490462459981488708L, (java.lang.Number) 0.47270954f, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.String str9 = mathRuntimeException8.toString();
        java.lang.Throwable[] throwableArray10 = mathRuntimeException8.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException8);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) mathRuntimeException11);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-3145292860822071060L), (double) 0.66136897f);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        java.lang.Throwable[] throwableArray6 = mathRuntimeException4.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathRuntimeException7.getSpecificPattern();
        java.lang.String str9 = mathRuntimeException7.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str9.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfpField1.getRadixDigits();
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        long long1 = org.apache.commons.math.util.FastMath.round(5.298342365610588d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.9815025944569622d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3781582506918066d) + "'", double1 == (-1.3781582506918066d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1001877702976037456L), (float) 4L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.00187768E18f) + "'", float2 == (-1.00187768E18f));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        int int2 = org.apache.commons.math.util.FastMath.max(35, (-1158608686));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 675614889);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.subtract(dfp25);
        boolean boolean27 = dfp26.isNaN();
        boolean boolean28 = dfp11.greaterThan(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp11.remainder(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getLn2();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp31.add(dfp41);
        boolean boolean43 = dfp7.unequal(dfp31);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField13.getPiSplit();
        dfpField13.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.getPi();
        boolean boolean18 = dfp11.unequal(dfp17);
        int int19 = dfp17.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.8188580248934337d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.014291768640768109d) + "'", double1 == (-0.014291768640768109d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.subtract(dfp24);
        int int26 = dfp11.log10K();
        int int27 = dfp11.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (-3145292860822071060L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32760);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5552862773777275E27d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-4));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01831563888873418d + "'", double1 == 0.01831563888873418d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-2014857210165424996L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0148572101654249E18d) + "'", double1 == (-2.0148572101654249E18d));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-3.4211068110162857E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.97095779146376E16d) + "'", double1 == (-5.97095779146376E16d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1166274520), (float) 2102934446297000809L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.16627456E9f) + "'", float2 == (-1.16627456E9f));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        java.lang.String str14 = dfp13.toString();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp("-0.3068528194400547");
        boolean boolean20 = dfp4.unequal(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp23.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getPi();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp28.dotrap((int) (byte) 3, "hi!", dfp36, dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.getTwo();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp19.newInstance(dfp41);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-0.3068528194400547" + "'", str14.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfp6.intValue();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 9223372036854775807L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        java.lang.Number number12 = numberIsTooSmallException9.getArgument();
        java.lang.Number number13 = numberIsTooSmallException9.getMin();
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathIllegalArgumentException15.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 4.605170185988092d + "'", number12.equals(4.605170185988092d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNull(localizable16);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((int) (byte) 2);
//        double double5 = mersenneTwister0.nextGaussian();
//        int int6 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed(1142922799);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-8362349223201464979L) + "'", long1 == (-8362349223201464979L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1009788293753960737L) + "'", long2 == (-1009788293753960737L));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.4871469606651075d) + "'", double5 == (-2.4871469606651075d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1934184938) + "'", int6 == (-1934184938));
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((-0.2270567152701908d));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField12.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray14 = dfpField12.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField12.getRoundingMode();
        dfpField12.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp10.add(dfp18);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfpArray14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.86033094f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 8, (double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 512.0d + "'", double2 == 512.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0.051930904f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9986518935921188d + "'", double1 == 0.9986518935921188d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 6328612794128143597L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6260280327603795E20d + "'", double1 == 3.6260280327603795E20d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.27374506f, (java.lang.Number) 32.0f, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 32.0f + "'", number4.equals(32.0f));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        java.lang.String str4 = mathIllegalArgumentException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str4.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long8 = mersenneTwister7.nextLong();
        long long9 = mersenneTwister7.nextLong();
        double double10 = mersenneTwister7.nextGaussian();
        mersenneTwister7.setSeed((-2315732674968627721L));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4202901040889903664L) + "'", long8 == (-4202901040889903664L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3016148340477316550L + "'", long9 == 3016148340477316550L);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.21816162099303413d + "'", double10 == 0.21816162099303413d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        java.lang.Class<?> wildcardClass6 = mersenneTwister0.getClass();
//        int int7 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        float float10 = mersenneTwister8.nextFloat();
//        boolean boolean11 = mersenneTwister8.nextBoolean();
//        int int12 = mersenneTwister8.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        long long14 = mersenneTwister13.nextLong();
//        long long15 = mersenneTwister13.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister16.nextBytes(byteArray20);
//        mersenneTwister13.nextBytes(byteArray20);
//        mersenneTwister8.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        int[] intArray26 = new int[] { 8 };
//        mersenneTwister0.setSeed(intArray26);
//        double double28 = mersenneTwister0.nextDouble();
//        long long29 = mersenneTwister0.nextLong();
//        double double30 = mersenneTwister0.nextDouble();
//        mersenneTwister0.setSeed((long) 862952443);
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-977133878) + "'", int7 == (-977133878));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-3646061510984148298L) + "'", long9 == (-3646061510984148298L));
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.12921166f + "'", float10 == 0.12921166f);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1252664110 + "'", int12 == 1252664110);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5151322010331405173L + "'", long14 == 5151322010331405173L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-8793035573911753160L) + "'", long15 == (-8793035573911753160L));
//        org.junit.Assert.assertNotNull(byteArray20);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.22670585469025162d + "'", double28 == 0.22670585469025162d);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-695533844184942996L) + "'", long29 == (-695533844184942996L));
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.1263309000896906d + "'", double30 == 0.1263309000896906d);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test465");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        double double5 = mersenneTwister0.nextGaussian();
//        double double6 = mersenneTwister0.nextGaussian();
//        double double7 = mersenneTwister0.nextDouble();
//        mersenneTwister0.setSeed((long) (byte) 1);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2564688882439977360L + "'", long1 == 2564688882439977360L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.14522278f + "'", float2 == 0.14522278f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-2010432284) + "'", int4 == (-2010432284));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.618121759347547d + "'", double5 == 1.618121759347547d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.118329883854619d) + "'", double6 == (-1.118329883854619d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.6425133095429472d + "'", double7 == 0.6425133095429472d);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        java.lang.Throwable[] throwableArray10 = numberIsTooSmallException7.getSuppressed();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        int[] intArray3 = new int[] { '4', (-435974713), 1391990588 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        java.lang.Number number12 = numberIsTooSmallException9.getArgument();
        java.lang.Number number13 = numberIsTooSmallException9.getMin();
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray14);
        java.lang.Class<?> wildcardClass16 = mathIllegalArgumentException15.getClass();
        java.lang.Throwable[] throwableArray17 = mathIllegalArgumentException15.getSuppressed();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 4.605170185988092d + "'", number12.equals(4.605170185988092d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.newDfp((double) 0.30810094f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.negate();
        org.apache.commons.math.dfp.DfpField dfpField13 = dfp12.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpField13);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long8 = mersenneTwister7.nextLong();
        long long9 = mersenneTwister7.nextLong();
        int int10 = mersenneTwister7.nextInt();
        double double11 = mersenneTwister7.nextDouble();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4202901040889903664L) + "'", long8 == (-4202901040889903664L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3016148340477316550L + "'", long9 == 3016148340477316550L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-759168209) + "'", int10 == (-759168209));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.6415419412604866d + "'", double11 == 0.6415419412604866d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        java.lang.String str13 = dfp11.toString();
        int int14 = dfp11.getRadixDigits();
        int int15 = dfp11.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.6931471805599453" + "'", str13.equals("0.6931471805599453"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3690380939809956d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9315670779835608d + "'", double1 == 3.9315670779835608d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1279918493));
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(5.551115123125783E-17d);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.subtract(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp20.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp20.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((double) (-798010429));
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.getLn5();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp8.dotrap((-798010429), "0.6931471805599453", dfp25, dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.newInstance(10);
        int int37 = dfp33.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp39 = dfp33.newInstance(dfp38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance("-0.3068528194400547");
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp5.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double2 = org.apache.commons.math.util.FastMath.max((-2.6662854445734396E20d), (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.power10K((-1158608686));
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0.6744807f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.594700892207039d + "'", double1 == 4.594700892207039d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-627795142));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 23);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        double double6 = mersenneTwister0.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray11 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister7.nextBytes(byteArray11);
//        float float13 = mersenneTwister7.nextFloat();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister();
//        long long15 = mersenneTwister14.nextLong();
//        byte[] byteArray20 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 100 };
//        mersenneTwister14.nextBytes(byteArray20);
//        mersenneTwister7.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5528221248423568d + "'", double6 == 0.5528221248423568d);
//        org.junit.Assert.assertNotNull(byteArray11);
//        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5528221f + "'", float13 == 0.5528221f);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8783263278571641584L + "'", long15 == 8783263278571641584L);
//        org.junit.Assert.assertNotNull(byteArray20);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags(2114456903);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        double[] doubleArray8 = dfp7.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.subtract(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getLn2();
        boolean boolean22 = dfp18.unequal(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.subtract(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.ceil();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp21.subtract(dfp34);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp34.newInstance((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField1.newDfp(dfp34);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 5262056089720230926L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        double double5 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed(8315623740657388300L);
//        mersenneTwister0.setSeed(0L);
//        long long10 = mersenneTwister0.nextLong();
//        boolean boolean11 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2874235194293067408L + "'", long1 == 2874235194293067408L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.9980687f + "'", float2 == 0.9980687f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1241873047) + "'", int4 == (-1241873047));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.07487947464424609d + "'", double5 == 0.07487947464424609d);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 2780242596957121269L + "'", long10 == 2780242596957121269L);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField3.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField3.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray7);
    }
}

