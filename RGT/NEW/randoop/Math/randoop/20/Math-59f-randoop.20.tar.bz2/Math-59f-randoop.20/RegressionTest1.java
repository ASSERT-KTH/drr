import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-3145292860822071060L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((byte) -1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        boolean boolean17 = dfp13.unequal(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp4.newInstance(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp20 = dfp4.newInstance(dfp19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1324063135);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        java.lang.Class<?> wildcardClass6 = mersenneTwister0.getClass();
//        int int7 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed(0);
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1035772328) + "'", int7 == (-1035772328));
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.3522461778175519d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        boolean boolean15 = dfp14.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 6279318891992503777L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 5710982096930849361L, (double) 5L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.7109820969308488E18d + "'", double2 == 5.7109820969308488E18d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.008837747656337245d) + "'", double1 == (-0.008837747656337245d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        java.lang.Class<?> wildcardClass7 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        mersenneTwister9.setSeed(1263985607);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long2 = org.apache.commons.math.util.FastMath.max((-28479206L), 8657169977664086989L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8657169977664086989L + "'", long2 == 8657169977664086989L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6900760708753189d + "'", double1 == 0.6900760708753189d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1279918493));
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.060727477f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06065299102014886d + "'", double1 == 0.06065299102014886d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3258176636680326d + "'", double1 == 1.3258176636680326d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long8 = mersenneTwister7.nextLong();
        long long9 = mersenneTwister7.nextLong();
        boolean boolean10 = mersenneTwister7.nextBoolean();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4202901040889903664L) + "'", long8 == (-4202901040889903664L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3016148340477316550L + "'", long9 == 3016148340477316550L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-3086986065405221662L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        float float2 = org.apache.commons.math.util.FastMath.max(0.29133427f, 3.83929669E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.83929669E18f + "'", float2 == 3.83929669E18f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlags(10863993);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 0.27374506f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3148795440708736d + "'", double1 == 0.3148795440708736d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.2008697699318138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6236721793459901d + "'", double1 == 0.6236721793459901d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(1971268331);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        java.lang.Class<?> wildcardClass6 = mersenneTwister0.getClass();
//        int int7 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        float float10 = mersenneTwister8.nextFloat();
//        boolean boolean11 = mersenneTwister8.nextBoolean();
//        int int12 = mersenneTwister8.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        long long14 = mersenneTwister13.nextLong();
//        long long15 = mersenneTwister13.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister16.nextBytes(byteArray20);
//        mersenneTwister13.nextBytes(byteArray20);
//        mersenneTwister8.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        double double25 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-2088356514) + "'", int7 == (-2088356514));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5934193063806897197L + "'", long9 == 5934193063806897197L);
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.6585586f + "'", float10 == 0.6585586f);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 71221372 + "'", int12 == 71221372);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 5934193063806897197L + "'", long14 == 5934193063806897197L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-6298481322752721650L) + "'", long15 == (-6298481322752721650L));
//        org.junit.Assert.assertNotNull(byteArray20);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.8611639681535683d + "'", double25 == 0.8611639681535683d);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField3.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 6328612794128143597L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        java.lang.Class<?> wildcardClass6 = mersenneTwister0.getClass();
//        int int7 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        float float10 = mersenneTwister8.nextFloat();
//        boolean boolean11 = mersenneTwister8.nextBoolean();
//        int int12 = mersenneTwister8.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        long long14 = mersenneTwister13.nextLong();
//        long long15 = mersenneTwister13.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister16.nextBytes(byteArray20);
//        mersenneTwister13.nextBytes(byteArray20);
//        mersenneTwister8.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        int[] intArray26 = new int[] { 8 };
//        mersenneTwister0.setSeed(intArray26);
//        double double28 = mersenneTwister0.nextDouble();
//        long long29 = mersenneTwister0.nextLong();
//        double double30 = mersenneTwister0.nextDouble();
//        int int31 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2075596693 + "'", int7 == 2075596693);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-8387616844026538091L) + "'", long9 == (-8387616844026538091L));
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.44936085f + "'", float10 == 0.44936085f);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1351125343) + "'", int12 == (-1351125343));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2569162496513017153L) + "'", long14 == (-2569162496513017153L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 6831141753458935384L + "'", long15 == 6831141753458935384L);
//        org.junit.Assert.assertNotNull(byteArray20);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.22670585469025162d + "'", double28 == 0.22670585469025162d);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-695533844184942996L) + "'", long29 == (-695533844184942996L));
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.1263309000896906d + "'", double30 == 0.1263309000896906d);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1267801638) + "'", int31 == (-1267801638));
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-6697407083237886024L), (double) (-3145292860822071060L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.6974070832378849E18d) + "'", double2 == (-6.6974070832378849E18d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        double double6 = mersenneTwister0.nextDouble();
//        float float7 = mersenneTwister0.nextFloat();
//        mersenneTwister0.setSeed((long) 536467855);
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9092943027811466d + "'", double6 == 0.9092943027811466d);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.63688934f + "'", float7 == 0.63688934f);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) (-1873816088));
        int int8 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1009788293753960737L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 5.551115123125783E-17d);
        java.lang.Number number7 = notStrictlyPositiveException6.getArgument();
        java.lang.Object[] objArray8 = notStrictlyPositiveException6.getArguments();
        mathIllegalArgumentException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        java.lang.Number number10 = notStrictlyPositiveException6.getMin();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 5.551115123125783E-17d + "'", number7.equals(5.551115123125783E-17d));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.0f));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-6.6974070832378849E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((-837412152));
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode8);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField8.setRoundingMode(roundingMode9);
        dfpField1.setRoundingMode(roundingMode9);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.695151321341658d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField11.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField11.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.newDfp(11013.232920103323d);
        boolean boolean17 = dfp9.equals((java.lang.Object) dfpField11);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        mersenneTwister0.setSeed((-6049992125526582820L));
//        double double18 = mersenneTwister0.nextDouble();
//        double double19 = mersenneTwister0.nextGaussian();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister();
//        long long21 = mersenneTwister20.nextLong();
//        long long22 = mersenneTwister20.nextLong();
//        mersenneTwister20.setSeed((int) (byte) 2);
//        int[] intArray26 = new int[] { (-1279918493) };
//        mersenneTwister20.setSeed(intArray26);
//        mersenneTwister0.setSeed(intArray26);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2241884805980510668L + "'", long1 == 2241884805980510668L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.64026713f + "'", float2 == 0.64026713f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1923729756 + "'", int4 == 1923729756);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-2646912173498487664L) + "'", long6 == (-2646912173498487664L));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-1394556286692433155L) + "'", long7 == (-1394556286692433155L));
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5734050033669145d + "'", double18 == 0.5734050033669145d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.3690380939809956d + "'", double19 == 1.3690380939809956d);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + (-3640189784518587754L) + "'", long21 == (-3640189784518587754L));
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + (-6962348008906314576L) + "'", long22 == (-6962348008906314576L));
//        org.junit.Assert.assertNotNull(intArray26);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        java.lang.Number number10 = numberIsTooSmallException7.getArgument();
        java.lang.Number number11 = numberIsTooSmallException7.getMin();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException7.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 4.605170185988092d + "'", number10.equals(4.605170185988092d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2035370246);
        double double2 = mersenneTwister1.nextDouble();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6432980984102405d + "'", double2 == 0.6432980984102405d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.92000186f + "'", float3 == 0.92000186f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4364163430997043d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 2964848217754529147L);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2780242596957121269L, (float) 1324063135);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.78024269E18f + "'", float2 == 2.78024269E18f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        long long8 = mersenneTwister7.nextLong();
        long long9 = mersenneTwister7.nextLong();
        int int10 = mersenneTwister7.nextInt();
        mersenneTwister7.setSeed((-8387616844026538091L));
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-4202901040889903664L) + "'", long8 == (-4202901040889903664L));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 3016148340477316550L + "'", long9 == 3016148340477316550L);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-759168209) + "'", int10 == (-759168209));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 5377943003167383641L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5377943003167383552L + "'", long1 == 5377943003167383552L);
    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        long long4 = mersenneTwister3.nextLong();
//        float float5 = mersenneTwister3.nextFloat();
//        boolean boolean6 = mersenneTwister3.nextBoolean();
//        int int7 = mersenneTwister3.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        long long10 = mersenneTwister8.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister11.nextBytes(byteArray15);
//        mersenneTwister8.nextBytes(byteArray15);
//        mersenneTwister3.nextBytes(byteArray15);
//        mersenneTwister3.setSeed((-6049992125526582820L));
//        double double21 = mersenneTwister3.nextDouble();
//        java.lang.Object[] objArray27 = new java.lang.Object[] { double21, (short) -1, 9.1935412199798502E17d, (-2035370246), (-6049992125526582820L), 0.27374506f };
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray27);
//        java.lang.String str29 = mathRuntimeException28.toString();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException33);
//        java.lang.String str35 = mathRuntimeException34.toString();
//        org.apache.commons.math.exception.util.Localizable localizable36 = null;
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        java.lang.Object[] objArray40 = new java.lang.Object[] { (-1629873166195752489L), 100 };
//        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException34, localizable36, localizable37, objArray40);
//        mathRuntimeException28.addSuppressed((java.lang.Throwable) mathRuntimeException34);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5676777770325730557L + "'", long4 == 5676777770325730557L);
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.6887845f + "'", float5 == 0.6887845f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 704294645 + "'", int7 == 704294645);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 5676777770325730557L + "'", long9 == 5676777770325730557L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-5740912516853166146L) + "'", long10 == (-5740912516853166146L));
//        org.junit.Assert.assertNotNull(byteArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.5734050033669145d + "'", double21 == 0.5734050033669145d);
//        org.junit.Assert.assertNotNull(objArray27);
//        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str29.equals("org.apache.commons.math.exception.MathRuntimeException: "));
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str35.equals("org.apache.commons.math.exception.MathRuntimeException: "));
//        org.junit.Assert.assertNotNull(objArray40);
//    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test060");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister();
//        long long2 = mersenneTwister1.nextLong();
//        long long3 = mersenneTwister1.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray8 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister4.nextBytes(byteArray8);
//        mersenneTwister1.nextBytes(byteArray8);
//        java.lang.Object[] objArray11 = new java.lang.Object[] { mersenneTwister1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray11);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
//        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) numberIsTooSmallException16);
//        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooSmallException16.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-37690374182988541L) + "'", long2 == (-37690374182988541L));
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-2188433434216731685L) + "'", long3 == (-2188433434216731685L));
//        org.junit.Assert.assertNotNull(byteArray8);
//        org.junit.Assert.assertNotNull(objArray11);
//        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 4018924884232996376L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        boolean boolean17 = dfp13.unequal(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getLn2();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.power10(0);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.subtract(dfp25);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.ceil();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp16.subtract(dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.subtract(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.ceil();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp39.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance((double) 0.86033094f);
        org.apache.commons.math.dfp.Dfp dfp47 = org.apache.commons.math.dfp.DfpField.computeExp(dfp30, dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp4.add(dfp30);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        java.lang.String str13 = dfp11.toString();
        double[] doubleArray14 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.ceil();
        double double16 = dfp15.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.6931471805599453" + "'", str13.equals("0.6931471805599453"));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(10L);
        boolean boolean8 = dfp7.isInfinite();
        int int9 = dfp7.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.newInstance((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(2035370246);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.getZero();
        org.apache.commons.math.dfp.Dfp dfp32 = new org.apache.commons.math.dfp.Dfp(dfp31);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3839296689174442270L, 0.2075512827288153d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0.17415476f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.978332641498348d + "'", double1 == 9.978332641498348d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getLn5();
        boolean boolean10 = dfp4.greaterThan(dfp9);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = org.apache.commons.math.dfp.DfpField.computeExp(dfp2, dfp7);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1126640384));
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.2883239191548641E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-8.9050875864504863E18d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.16627456E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getPi();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp20.dotrap((int) (byte) 3, "hi!", dfp28, dfp31);
        boolean boolean33 = dfp10.greaterThan(dfp28);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(8676598251368639082L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.String str8 = mathRuntimeException7.toString();
        java.lang.Throwable[] throwableArray9 = mathRuntimeException7.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str8.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-1934184938));
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp7);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int2 = org.apache.commons.math.util.FastMath.min((-529182127), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-529182127) + "'", int2 == (-529182127));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32760);
        int int7 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1166274520));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getZero();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.newDfp(5.551115123125783E-17d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.sqrt();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.ceil();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.ceil();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.power10K((-1158608686));
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.newInstance((double) (-798010429));
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.getLn5();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp13.dotrap((-798010429), "0.6931471805599453", dfp30, dfp38);
        boolean boolean40 = dfp4.unequal(dfp30);
        java.lang.String str41 = dfp4.toString();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "2." + "'", str41.equals("2."));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-977133878));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-992.3191143765591d) + "'", double1 == (-992.3191143765591d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2035370246, (float) 7492662034980647367L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.03537024E9f + "'", float2 == 2.03537024E9f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.9579870417283d + "'", double1 == 2979.9579870417283d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-3335828026518722798L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1071487177940904d + "'", double1 == 1.1071487177940904d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlagsBits((-627795142));
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(1853740354352149377L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15071724896777527d + "'", double2 == 0.15071724896777527d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1873816088));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        int int4 = dfp2.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField5 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField5.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfpField5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5.551115123125783E-17d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.String str10 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 5.551115123125783E-17d + "'", number3.equals(5.551115123125783E-17d));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str10.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.8189894035458565E-12d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 100, (java.lang.Number) (-5108934833899263838L), false);
        boolean boolean9 = numberIsTooSmallException8.getBoundIsAllowed();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.37085556983947754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3708555698394776d + "'", double1 == 0.3708555698394776d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.6425133095429472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.19211787157458274d) + "'", double1 == (-0.19211787157458274d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 4672451722473715821L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9650764465259036d + "'", double1 == 0.9650764465259036d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-5493406563038245403L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.String str8 = mathRuntimeException7.toString();
        java.lang.Throwable[] throwableArray9 = mathRuntimeException7.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, (java.lang.Object[]) throwableArray9);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.String str16 = mathRuntimeException15.toString();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1629873166195752489L), 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException15, localizable17, localizable18, objArray21);
        mathRuntimeException10.addSuppressed((java.lang.Throwable) mathRuntimeException22);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException24 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException22);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str8.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp4.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException16);
        java.lang.String str18 = mathIllegalArgumentException16.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: {0} is smaller than, or equal to, the minimum ({1})" + "'", str18.equals("org.apache.commons.math.exception.MathIllegalArgumentException: {0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        boolean boolean18 = dfp17.isNaN();
        boolean boolean19 = dfp2.greaterThan(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp2.remainder(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp22.add(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.sqrt();
        boolean boolean35 = dfp34.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test115");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister();
//        long long3 = mersenneTwister2.nextLong();
//        float float4 = mersenneTwister2.nextFloat();
//        boolean boolean5 = mersenneTwister2.nextBoolean();
//        int int6 = mersenneTwister2.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister();
//        long long8 = mersenneTwister7.nextLong();
//        float float9 = mersenneTwister7.nextFloat();
//        boolean boolean10 = mersenneTwister7.nextBoolean();
//        int int11 = mersenneTwister7.nextInt();
//        double double12 = mersenneTwister7.nextGaussian();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        long long14 = mersenneTwister13.nextLong();
//        float float15 = mersenneTwister13.nextFloat();
//        boolean boolean16 = mersenneTwister13.nextBoolean();
//        int int17 = mersenneTwister13.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister();
//        long long19 = mersenneTwister18.nextLong();
//        long long20 = mersenneTwister18.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray25 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister21.nextBytes(byteArray25);
//        mersenneTwister18.nextBytes(byteArray25);
//        mersenneTwister13.nextBytes(byteArray25);
//        mersenneTwister7.nextBytes(byteArray25);
//        mersenneTwister2.nextBytes(byteArray25);
//        mersenneTwister1.nextBytes(byteArray25);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3191223455618187489L + "'", long3 == 3191223455618187489L);
//        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.2699244f + "'", float4 == 0.2699244f);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1157169221) + "'", int6 == (-1157169221));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2247640055251279554L + "'", long8 == 2247640055251279554L);
//        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.88827336f + "'", float9 == 0.88827336f);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1906980426) + "'", int11 == (-1906980426));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6649230650330993d + "'", double12 == 0.6649230650330993d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 784580897736319797L + "'", long14 == 784580897736319797L);
//        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.30700302f + "'", float15 == 0.30700302f);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 510880674 + "'", int17 == 510880674);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-7543858675950694592L) + "'", long19 == (-7543858675950694592L));
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + (-6831748299344510284L) + "'", long20 == (-6831748299344510284L));
//        org.junit.Assert.assertNotNull(byteArray25);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K(1240426438);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1279918493));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9340424858798563d));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits((-1126640331));
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getLn2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.ceil();
        boolean boolean17 = dfp2.unequal(dfp13);
        int int18 = dfp2.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-4) + "'", int18 == (-4));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 704294645);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 704294656 + "'", int1 == 704294656);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 5.551115123125783E-17d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException13.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        java.lang.Number number19 = numberIsTooSmallException17.getMin();
        java.lang.Number number20 = numberIsTooSmallException17.getArgument();
        notStrictlyPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException17);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 5.551115123125783E-17d + "'", number3.equals(5.551115123125783E-17d));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 4.605170185988092d + "'", number20.equals(4.605170185988092d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 5.551115123125783E-17d);
        java.lang.Number number7 = notStrictlyPositiveException6.getArgument();
        java.lang.Object[] objArray8 = notStrictlyPositiveException6.getArguments();
        mathIllegalArgumentException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.1904592245245188d, (java.lang.Number) 10, false);
        mathIllegalArgumentException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException14.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 5.551115123125783E-17d + "'", number7.equals(5.551115123125783E-17d));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-759168209), 4042757885623281268L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-759168209L) + "'", long2 == (-759168209L));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(0.0d);
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

//    @Test
//    public void test125() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test125");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        double double3 = mersenneTwister0.nextGaussian();
//        byte[] byteArray4 = null;
//        try {
//            mersenneTwister0.nextBytes(byteArray4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3566501493280767227L) + "'", long1 == (-3566501493280767227L));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.99755204f + "'", float2 == 0.99755204f);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1668754752951458d + "'", double3 == 1.1668754752951458d);
//    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 8.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 787369448);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 787369448L + "'", long1 == 787369448L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp16.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = org.apache.commons.math.dfp.DfpField.computeExp(dfp12, dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((byte) 3);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-977133878));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        mersenneTwister0.setSeed((-6049992125526582820L));
//        double double18 = mersenneTwister0.nextDouble();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister();
//        long long20 = mersenneTwister19.nextLong();
//        byte[] byteArray25 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 100 };
//        mersenneTwister19.nextBytes(byteArray25);
//        mersenneTwister0.nextBytes(byteArray25);
//        mersenneTwister0.setSeed((-3180649955282255128L));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6266073843442835506L + "'", long1 == 6266073843442835506L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.6634178f + "'", float2 == 0.6634178f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1783233776) + "'", int4 == (-1783233776));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7410554363559879278L + "'", long6 == 7410554363559879278L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-928405147962258605L) + "'", long7 == (-928405147962258605L));
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5734050033669145d + "'", double18 == 0.5734050033669145d);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 6065080993093839244L + "'", long20 == 6065080993093839244L);
//        org.junit.Assert.assertNotNull(byteArray25);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        int int6 = dfpField1.getRadixDigits();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 691077309);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 2075596693);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.44023645f + "'", float2 == 0.44023645f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        boolean boolean18 = dfp17.isNaN();
        boolean boolean19 = dfp2.greaterThan(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray22 = dfpField21.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((double) 4184190201324072520L);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getLn2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp28.subtract(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getLn2();
        boolean boolean38 = dfp34.unequal(dfp37);
        java.lang.String str39 = dfp37.toString();
        int int40 = dfp37.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp37.getZero();
        org.apache.commons.math.dfp.Dfp dfp42 = org.apache.commons.math.dfp.DfpField.computeLn(dfp17, dfp25, dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.newInstance((-483117249));
        int int45 = dfp41.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfpArray22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "0.6931471805599453" + "'", str39.equals("0.6931471805599453"));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Throwable[] throwableArray3 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.String str16 = mathRuntimeException15.toString();
        java.lang.Object[] objArray17 = mathRuntimeException15.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number25 = numberIsTooSmallException24.getArgument();
        java.lang.Number number26 = numberIsTooSmallException24.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31);
        java.lang.String str33 = mathRuntimeException32.toString();
        java.lang.Object[] objArray34 = mathRuntimeException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        java.lang.Throwable[] throwableArray46 = mathIllegalArgumentException45.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable27, (java.lang.Object[]) throwableArray46);
        java.lang.Number number49 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 1.0d, number49, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) (-1.3522461778175519d), (java.lang.Number) (-0.9188797929052988d), false);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 2662705844154317738L + "'", number8.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 2662705844154317738L + "'", number9.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2662705844154317738L + "'", number25.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 2662705844154317738L + "'", number26.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str33.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray46);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5444437451708134E-14d + "'", double1 == 2.5444437451708134E-14d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.ceil();
        double double14 = dfp12.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 5417275700760945706L, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-5440246529469988002L), (java.lang.Number) 0.6425133095429472d, true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.subtract(dfp10);
        boolean boolean12 = dfp11.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getLn2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp25.subtract(dfp30);
        boolean boolean32 = dfp31.isNaN();
        boolean boolean33 = dfp16.greaterThan(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp16.remainder(dfp36);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp16.floor();
        boolean boolean41 = dfp11.unequal(dfp40);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(2345417298469447538L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.newInstance((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.power10K(2035370246);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getPi();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance((int) 'a');
        double double36 = dfp35.toDouble();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.floor();
        boolean boolean38 = dfp28.greaterThan(dfp37);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 97.0d + "'", double36 == 97.0d);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1934184938));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp8.power10K((-1158608686));
        int int14 = dfp13.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-339467448) + "'", int14 == (-339467448));
    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((int) (byte) 2);
//        mersenneTwister0.setSeed((-4));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-750629598534898297L) + "'", long1 == (-750629598534898297L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8905159172365499345L) + "'", long2 == (-8905159172365499345L));
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        int int5 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1209585570);
        int[] intArray2 = null;
        mersenneTwister1.setSeed(intArray2);
        int[] intArray10 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        mersenneTwister1.setSeed(intArray10);
        try {
            int int16 = mersenneTwister1.nextInt((-1158608686));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1,158,608,686 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 5377943003167383641L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.3779430031673836E18d + "'", double1 == 5.3779430031673836E18d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8886110.520507872d + "'", double1 == 8886110.520507872d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(5377943003167383552L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp10.newInstance((byte) 10, (byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 395437101657814910L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(675614889);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int int2 = org.apache.commons.math.util.FastMath.max(32768, (-1906980426));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32768 + "'", int2 == 32768);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-759168209L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        int int14 = dfp13.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1209585570);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1111250781112347E7d + "'", double1 == 2.1111250781112347E7d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.remainder(dfp9);
        boolean boolean11 = dfp10.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(dfp13);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        java.lang.Class<?> wildcardClass6 = mersenneTwister0.getClass();
//        int int7 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        float float10 = mersenneTwister8.nextFloat();
//        boolean boolean11 = mersenneTwister8.nextBoolean();
//        int int12 = mersenneTwister8.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        long long14 = mersenneTwister13.nextLong();
//        long long15 = mersenneTwister13.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister16.nextBytes(byteArray20);
//        mersenneTwister13.nextBytes(byteArray20);
//        mersenneTwister8.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        int[] intArray26 = new int[] { 8 };
//        mersenneTwister0.setSeed(intArray26);
//        double double28 = mersenneTwister0.nextDouble();
//        long long29 = mersenneTwister0.nextLong();
//        boolean boolean30 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(5445645231746192477L);
//        int int33 = mersenneTwister0.nextInt();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1740589117 + "'", int7 == 1740589117);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2355936615629505129L) + "'", long9 == (-2355936615629505129L));
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.14163148f + "'", float10 == 0.14163148f);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-2063708553) + "'", int12 == (-2063708553));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + (-2355936615629505129L) + "'", long14 == (-2355936615629505129L));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2612641644025118463L + "'", long15 == 2612641644025118463L);
//        org.junit.Assert.assertNotNull(byteArray20);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.22670585469025162d + "'", double28 == 0.22670585469025162d);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-695533844184942996L) + "'", long29 == (-695533844184942996L));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 762399420 + "'", int33 == 762399420);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-5108934833899263838L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.String str8 = numberIsTooSmallException3.toString();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number13 = numberIsTooSmallException12.getArgument();
        java.lang.Number number14 = numberIsTooSmallException12.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooSmallException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.String str21 = mathRuntimeException20.toString();
        java.lang.Object[] objArray22 = mathRuntimeException20.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray22);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 8.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 0.2399081f);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getLn2();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray37 = dfpField32.getLn5Split();
        java.lang.Class<?> wildcardClass38 = dfpArray37.getClass();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable15, localizable30, (java.lang.Object[]) dfpArray37);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 2,662,705,844,154,317,738 is smaller than, or equal to, the minimum (1.563)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 2,662,705,844,154,317,738 is smaller than, or equal to, the minimum (1.563)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 2662705844154317738L + "'", number13.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 2662705844154317738L + "'", number14.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str21.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfpArray37);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.9340424858798563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1142922799);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 377087298069241222L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((int) (byte) 2);
//        int[] intArray6 = new int[] { (-1279918493) };
//        mersenneTwister0.setSeed(intArray6);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        long long10 = mersenneTwister8.nextLong();
//        mersenneTwister8.setSeed((int) (byte) 2);
//        int[] intArray14 = new int[] { (-1279918493) };
//        mersenneTwister8.setSeed(intArray14);
//        mersenneTwister0.setSeed(intArray14);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1361730973752638394L) + "'", long1 == (-1361730973752638394L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2975184571501263852L + "'", long2 == 2975184571501263852L);
//        org.junit.Assert.assertNotNull(intArray6);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4953558520595083711L + "'", long9 == 4953558520595083711L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1690413709989292703L + "'", long10 == 1690413709989292703L);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 4805324952470941280L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.8053249524709427E18d + "'", double1 == 4.8053249524709427E18d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.8611639681535683d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp14.getField();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((-1309831832));
        dfpField15.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 8.0f);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 0.2399081f);
        java.lang.Number number21 = notStrictlyPositiveException20.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 0.2399081f + "'", number21.equals(0.2399081f));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (-5108934833899263838L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1L, (java.lang.Number) 0.5734050033669145d, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10K((-798010429));
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField28 = dfp25.getField();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp25.getTwo();
        boolean boolean30 = dfp16.greaterThan(dfp25);
        org.apache.commons.math.dfp.Dfp dfp31 = null;
        try {
            boolean boolean32 = dfp25.lessThan(dfp31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfpField28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.rint();
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance((-6605076130036793320L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 3765110317740726359L, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7651103177407258E18d + "'", double2 == 3.7651103177407258E18d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        int int7 = dfp6.log10();
        boolean boolean8 = dfp6.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-4) + "'", int7 == (-4));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp("0.6931471805599453");
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getZero();
        int int7 = dfp6.log10K();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0.59621847f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6387825241068495d + "'", double1 == 0.6387825241068495d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        java.lang.Object[] objArray8 = new java.lang.Object[] { roundingMode6, 97 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable4, localizable5, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathRuntimeException9.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.9891756912986386d), (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9891756912986385d) + "'", double2 == (-0.9891756912986385d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0.56900036f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009930929785500081d + "'", double1 == 0.009930929785500081d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-4016513083209653692L), 18.91846671556146d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-2014857210165424996L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        int int9 = dfp7.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-2010432284));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8372167407663449d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.309928890591918d + "'", double1 == 1.309928890591918d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getPiSplit();
        dfpField11.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(10L);
        boolean boolean18 = dfp17.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp17);
        java.lang.String str20 = dfp17.toString();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "10." + "'", str20.equals("10."));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 8.0f);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 1, number20, true);
        java.lang.Number number23 = numberIsTooSmallException22.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 1 + "'", number23.equals((short) 1));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-7066019921865745681L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.ceil();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getPi();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp12.dotrap((int) (byte) 3, "hi!", dfp20, dfp23);
        boolean boolean25 = dfp4.unequal(dfp12);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.subtract(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp19 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp20 = org.apache.commons.math.dfp.DfpField.computeLn(dfp4, dfp18, dfp19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getPi();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp(5.551115123125783E-17d);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.dotrap((int) (byte) 0, "hi!", dfp13, dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K(32760);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((-627795142));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10K(23);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.floor();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.subtract(dfp10);
        boolean boolean12 = dfp11.isNaN();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp11);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        int int2 = org.apache.commons.math.util.FastMath.min(97, 1599591723);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (-5108934833899263838L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-5,108,934,833,899,263,838)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-5,108,934,833,899,263,838)"));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        int int8 = dfp7.log10K();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.rint();
        boolean boolean12 = dfp4.lessThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp7.newInstance((double) 0.64026713f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4337364037399572181L, (java.lang.Number) 5.3779430031673836E18d, false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-6298481322752721650L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1241873047), (double) (-2364509551357261017L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.3645095513572608E18d) + "'", double2 == (-2.3645095513572608E18d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.remainder(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp5.getOne();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.String str5 = mathRuntimeException4.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1629873166195752489L), 100 };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException4, localizable6, localizable7, objArray10);
        java.lang.String str12 = mathRuntimeException4.toString();
        java.lang.String str13 = mathRuntimeException4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str5.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.sqrt();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp4);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getSqr3();
        boolean boolean13 = dfp4.unequal(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getLn2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.subtract(dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.subtract(dfp27);
        boolean boolean29 = dfp28.isNaN();
        boolean boolean30 = dfp13.greaterThan(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn2();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp13.remainder(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode39 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField38.setRoundingMode(roundingMode39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getE();
        boolean boolean42 = dfp33.unequal(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeExp(dfp10, dfp33);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getLn2();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10(0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp46.subtract(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField54.getLn2();
        boolean boolean56 = dfp52.unequal(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getLn2();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp62.power10(0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.subtract(dfp64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp65.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp65.ceil();
        org.apache.commons.math.dfp.Dfp dfp69 = dfp55.subtract(dfp68);
        org.apache.commons.math.dfp.DfpField dfpField71 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField71.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getLn2();
        org.apache.commons.math.dfp.Dfp dfp77 = dfp75.power10(0);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp72.subtract(dfp77);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp72.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp81 = org.apache.commons.math.dfp.Dfp.copysign(dfp55, dfp80);
        try {
            org.apache.commons.math.dfp.Dfp dfp82 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp10, dfp80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + roundingMode39 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode39.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        int int2 = org.apache.commons.math.util.FastMath.max((int) ' ', (-1807347122));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        java.lang.String str9 = dfp8.toString();
        java.lang.String str10 = dfp8.toString();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0.3068528194400547" + "'", str9.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "-0.3068528194400547" + "'", str10.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-2225318385036581271L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-1934184938));
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-3480802555218261625L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.dotrap((int) (byte) 3, "hi!", dfp15, dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp19.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((-627795142));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10K(23);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (short) -1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.FastMath.log1p(253.1682802423552d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.537996568287817d + "'", double1 == 5.537996568287817d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 510880674, (long) (-627795142));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-627795142L) + "'", long2 == (-627795142L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp17.unequal(dfp20);
        java.lang.String str22 = dfp20.toString();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.remainder(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getLn2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.subtract(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn2();
        boolean boolean36 = dfp32.unequal(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp2.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance(1324063135);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0.6931471805599453" + "'", str22.equals("0.6931471805599453"));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 377087298069241222L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7708729806924122E17d + "'", double2 == 3.7708729806924122E17d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((-1934184938));
        dfpField1.setIEEEFlags(97);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 6065080993093839244L, (double) 0.5711645f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.346742482120122E10d + "'", double2 == 5.346742482120122E10d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        long long2 = org.apache.commons.math.util.FastMath.min(8288323919154863780L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 7348760020049218068L, (double) 0.034397364f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.3487600200492175E18d + "'", double2 == 7.3487600200492175E18d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0.44936085f, (double) (-1158608686));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4493608474731445d + "'", double2 == 0.4493608474731445d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0.6585586f, (double) (-8827692080485524242L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((-6962348008906314576L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double2 = org.apache.commons.math.util.FastMath.max((-3.335828026518722E18d), (double) (-1979276953));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.979276953E9d) + "'", double2 == (-1.979276953E9d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 7180357068650626439L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.25320872316801936E17d + "'", double1 == 1.25320872316801936E17d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (-5108934833899263838L), false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.String str7 = numberIsTooSmallException4.toString();
        java.lang.Object[] objArray8 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 100 + "'", number5.equals((short) 100));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-5,108,934,833,899,263,838)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-5,108,934,833,899,263,838)"));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-4202901040889903664L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.57545386532345d) + "'", double1 == (-43.57545386532345d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        boolean boolean18 = dfp17.isNaN();
        boolean boolean19 = dfp2.greaterThan(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.power10(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp2.remainder(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.getLn2();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getZero();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp22.add(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.sqrt();
        boolean boolean35 = dfp33.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
        java.lang.Throwable[] throwableArray4 = mathIllegalArgumentException3.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException3);
        java.lang.Throwable[] throwableArray6 = mathIllegalArgumentException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 377087298069241222L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 40.47125311541821d + "'", double1 == 40.47125311541821d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 536467855, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.181028762004227d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1984496486113532d + "'", double1 == 1.1984496486113532d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        java.lang.String str9 = dfp8.toString();
        boolean boolean10 = dfp8.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0.3068528194400547" + "'", str9.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

//    @Test
//    public void test245() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test245");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        double double5 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed(10L);
//        double double8 = mersenneTwister0.nextGaussian();
//        double double9 = mersenneTwister0.nextDouble();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2793407059384899110L) + "'", long1 == (-2793407059384899110L));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.83137345f + "'", float2 == 0.83137345f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 269041736 + "'", int4 == 269041736);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.7496121781651819d) + "'", double5 == (-1.7496121781651819d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0845474930192402d + "'", double8 == 1.0845474930192402d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5711645232847797d + "'", double9 == 0.5711645232847797d);
//    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((-1590619262214363973L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 7348760020049218068L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6436290138242364d) + "'", double1 == (-0.6436290138242364d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.072763416717771d, (-2.6662854445734396E20d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        java.lang.String str13 = dfp11.toString();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp11.newInstance((long) 35);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField17.getPiSplit();
        dfpField17.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.getZero();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField17.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField17.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp15.divide(dfp26);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0.6931471805599453" + "'", str13.equals("0.6931471805599453"));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        int int6 = dfp5.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.6260280327603795E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.55943115729564d + "'", double1 == 20.55943115729564d);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test252");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((int) (byte) 2);
//        int[] intArray6 = new int[] { (-1279918493) };
//        mersenneTwister0.setSeed(intArray6);
//        try {
//            int int9 = mersenneTwister0.nextInt((-1309831832));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1,309,831,832 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-3726689152828877509L) + "'", long1 == (-3726689152828877509L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-632938320733442577L) + "'", long2 == (-632938320733442577L));
//        org.junit.Assert.assertNotNull(intArray6);
//    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(8320216286286413930L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int[] intArray6 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray6);
        int int8 = mersenneTwister7.nextInt();
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-978564155) + "'", int8 == (-978564155));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getLn2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10(0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.subtract(dfp18);
        boolean boolean20 = dfp19.isNaN();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField9.newDfp(dfp19);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField9.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode22);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.dotrap((int) (byte) 3, "hi!", dfp15, dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.getTwo();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp18.divide((int) ' ');
        int int23 = dfp18.getRadixDigits();
        int int24 = dfp18.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-28479206));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5151322010331405173L, (float) 2102934446297000809L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.1513219E18f + "'", float2 == 5.1513219E18f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1279918493));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9340424858798563d));
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6425133095429472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011213972739409932d + "'", double1 == 0.011213972739409932d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.getZero();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField16.getPiSplit();
        dfpField16.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.getPi();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.getZero();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField16.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField16.newDfp((byte) -1);
        boolean boolean26 = dfp12.unequal(dfp25);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp12.getZero();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 9070021916704890773L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.08719003655753117d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.995621110337893d + "'", double1 == 4.995621110337893d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getE();
        int int11 = dfp10.intValue();
        boolean boolean12 = dfp5.greaterThan(dfp10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField11.getPiSplit();
        dfpField11.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.getOne();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance(10L);
        boolean boolean18 = dfp17.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray21);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        java.lang.Number number6 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException11);
        java.lang.String str13 = mathRuntimeException12.toString();
        java.lang.Object[] objArray14 = mathRuntimeException12.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 1996971.339170858d, (java.lang.Number) (-5228266772725723885L), true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number30 = numberIsTooSmallException29.getArgument();
        java.lang.Number number31 = numberIsTooSmallException29.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException36);
        java.lang.String str38 = mathRuntimeException37.toString();
        java.lang.Object[] objArray39 = mathRuntimeException37.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray39);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray45 = dfpField44.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField44.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray47 = dfpField44.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException48 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable7, localizable32, (java.lang.Object[]) dfpArray47);
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray50 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray50);
        java.lang.Throwable[] throwableArray52 = mathIllegalArgumentException51.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number57 = numberIsTooSmallException56.getArgument();
        java.lang.Number number58 = numberIsTooSmallException56.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable59 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException64 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException63);
        java.lang.String str65 = mathRuntimeException64.toString();
        java.lang.Object[] objArray66 = mathRuntimeException64.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, objArray66);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException69 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable59, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number74 = numberIsTooSmallException73.getArgument();
        java.lang.Number number75 = numberIsTooSmallException73.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable76 = numberIsTooSmallException73.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException80 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException81 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException80);
        java.lang.String str82 = mathRuntimeException81.toString();
        java.lang.Object[] objArray83 = mathRuntimeException81.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException84 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, objArray83);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException86 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable76, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException90 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable76, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable91 = null;
        org.apache.commons.math.exception.util.Localizable localizable92 = null;
        java.lang.Object[] objArray93 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException94 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable91, localizable92, objArray93);
        java.lang.Throwable[] throwableArray95 = mathIllegalArgumentException94.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException96 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException51, localizable59, localizable76, (java.lang.Object[]) throwableArray95);
        java.lang.Object[] objArray97 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable76, objArray97);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2662705844154317738L + "'", number6.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 2662705844154317738L + "'", number30.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 2662705844154317738L + "'", number31.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str38.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(dfpArray45);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertNotNull(dfpArray47);
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 2662705844154317738L + "'", number57.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number58 + "' != '" + 2662705844154317738L + "'", number58.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str65.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + number74 + "' != '" + 2662705844154317738L + "'", number74.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 2662705844154317738L + "'", number75.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str82 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str82.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(throwableArray95);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.695151321341658d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22920847250391416d + "'", double1 == 0.22920847250391416d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField15 = dfp13.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpField15);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.881373587019543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.881373587019543d + "'", double1 == 0.881373587019543d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        java.lang.String str9 = dfp8.toString();
        int int10 = dfp8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0.3068528194400547" + "'", str9.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-1267801638));
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 5151322010331405173L, 0.5734050033669145d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5734050033669145d + "'", double2 == 0.5734050033669145d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) 3.77697197E18f);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.51009417f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(1066394775);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getLn2();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp15.subtract(dfp20);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.ceil();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.subtract(dfp24);
        int int26 = dfp11.log10K();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp11.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 1996971.339170858d, (java.lang.Number) (-5228266772725723885L), true);
        java.lang.Throwable[] throwableArray25 = numberIsTooSmallException24.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1738639778));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1738639778 + "'", int1 == 1738639778);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.subtract(dfp27);
        java.lang.String str29 = dfp28.toString();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp19.nextAfter(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp("-0.3068528194400547");
        boolean boolean35 = dfp19.unequal(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp13.subtract(dfp34);
        double[] doubleArray37 = dfp36.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "-0.3068528194400547" + "'", str29.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) 4184190201324072520L);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode11 = dfpField7.getRoundingMode();
        dfpField7.setIEEEFlagsBits(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField7.newDfp("10.");
        boolean boolean16 = dfp5.equals((java.lang.Object) dfpField7);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode11 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode11.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp17.unequal(dfp20);
        java.lang.String str22 = dfp20.toString();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.remainder(dfp20);
        java.lang.String str24 = dfp2.toString();
        int int25 = dfp2.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0.6931471805599453" + "'", str22.equals("0.6931471805599453"));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "0.6931471805599453" + "'", str24.equals("0.6931471805599453"));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getOne();
        boolean boolean9 = dfp7.isInfinite();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode2);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.subtract(dfp16);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp8);
        java.lang.Class<?> wildcardClass20 = dfp8.getClass();
        java.lang.Class<?> wildcardClass21 = dfp8.getClass();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(wildcardClass21);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (-5,108,934,833,899,263,838)");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-8.9050875864504863E18d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("0.6931471805599453");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        numberIsTooSmallException5.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number11 = numberIsTooSmallException9.getMin();
        java.lang.Number number12 = numberIsTooSmallException9.getArgument();
        java.lang.Number number13 = numberIsTooSmallException9.getMin();
        java.lang.Throwable[] throwableArray14 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException19);
        java.lang.String str21 = mathRuntimeException20.toString();
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        org.apache.commons.math.exception.util.Localizable localizable23 = mathRuntimeException20.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 4.605170185988092d + "'", number12.equals(4.605170185988092d));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str21.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNull(localizable23);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1490462459981488708L, (java.lang.Number) 0.47270954f, true);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        long long2 = org.apache.commons.math.util.FastMath.min((-369223069614690192L), (-8905087586450486507L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8905087586450486507L) + "'", long2 == (-8905087586450486507L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 16, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.Object[] objArray13 = mathRuntimeException11.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray13);
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 8.0f);
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (short) 1, number20, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Throwable[] throwableArray26 = mathIllegalArgumentException25.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number31 = numberIsTooSmallException30.getArgument();
        java.lang.Number number32 = numberIsTooSmallException30.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException30.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException38 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException37);
        java.lang.String str39 = mathRuntimeException38.toString();
        java.lang.Object[] objArray40 = mathRuntimeException38.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException47 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number48 = numberIsTooSmallException47.getArgument();
        java.lang.Number number49 = numberIsTooSmallException47.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooSmallException47.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException54);
        java.lang.String str56 = mathRuntimeException55.toString();
        java.lang.Object[] objArray57 = mathRuntimeException55.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, objArray57);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException60 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable50, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray67 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray67);
        java.lang.Throwable[] throwableArray69 = mathIllegalArgumentException68.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException70 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException25, localizable33, localizable50, (java.lang.Object[]) throwableArray69);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray73 = dfpField72.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray74 = dfpField72.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable50, (java.lang.Object[]) dfpArray74);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2662705844154317738L + "'", number4.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2662705844154317738L + "'", number5.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 2662705844154317738L + "'", number31.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 2662705844154317738L + "'", number32.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str39.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 2662705844154317738L + "'", number48.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 2662705844154317738L + "'", number49.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str56.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(dfpArray73);
        org.junit.Assert.assertNotNull(dfpArray74);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((-627795142));
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.power10K(23);
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp4.multiply(dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        int int1 = mersenneTwister0.nextInt();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed((-7066019921865745681L));
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1071582242) + "'", int1 == (-1071582242));
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField9.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField9.getSqr2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField9.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode18);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField6.getPiSplit();
        dfpField6.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField6.newDfp((-1934184938));
        org.apache.commons.math.dfp.Dfp dfp13 = dfp3.subtract(dfp12);
        java.lang.String str14 = dfp3.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "-0.3068528194400547" + "'", str14.equals("-0.3068528194400547"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2059804394);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.dotrap((int) (byte) 3, "hi!", dfp15, dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp18.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 4.605 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10(787369448);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        byte[] byteArray6 = new byte[] { (byte) 10, (byte) 10, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray6);
//        mersenneTwister0.setSeed(2345417298469447538L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-6924012615781291498L) + "'", long1 == (-6924012615781291498L));
//        org.junit.Assert.assertNotNull(byteArray6);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance(7180357068650626439L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2114456903, (java.lang.Number) 0.13131857f, false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((double) 'a');
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        double[] doubleArray3 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((long) 16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        int int8 = dfp7.log10K();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp7.rint();
        boolean boolean12 = dfp4.lessThan(dfp7);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.ceil();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn5();
        boolean boolean5 = dfp4.isNaN();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(11013.232920103323d);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        boolean boolean10 = dfp8.equals((java.lang.Object) 9070021916704890773L);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 100, (-321798667));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-321798667) + "'", int2 == (-321798667));
    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        double double6 = mersenneTwister0.nextDouble();
//        float float7 = mersenneTwister0.nextFloat();
//        long long8 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.04413046370976259d + "'", double6 == 0.04413046370976259d);
//        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.9674183f + "'", float7 == 0.9674183f);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-2469982280624799714L) + "'", long8 == (-2469982280624799714L));
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        int int5 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 6328612794128143597L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 2102934446297000809L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.10293446E18f + "'", float2 == 2.10293446E18f);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        int int4 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister();
//        long long6 = mersenneTwister5.nextLong();
//        long long7 = mersenneTwister5.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister8.nextBytes(byteArray12);
//        mersenneTwister5.nextBytes(byteArray12);
//        mersenneTwister0.nextBytes(byteArray12);
//        mersenneTwister0.setSeed((-6049992125526582820L));
//        boolean boolean18 = mersenneTwister0.nextBoolean();
//        byte[] byteArray20 = new byte[] { (byte) 3 };
//        mersenneTwister0.nextBytes(byteArray20);
//        mersenneTwister0.setSeed((-627795142));
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-488784732077258853L) + "'", long1 == (-488784732077258853L));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.1314311f + "'", float2 == 0.1314311f);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2041007209 + "'", int4 == 2041007209);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-54016075154516871L) + "'", long6 == (-54016075154516871L));
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2434630124113679437L) + "'", long7 == (-2434630124113679437L));
//        org.junit.Assert.assertNotNull(byteArray12);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(byteArray20);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 4953558520595083711L, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9535585205950822E18d + "'", double2 == 4.9535585205950822E18d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0.68108356f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getPi();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getZero();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp(5.551115123125783E-17d);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.dotrap((int) (byte) 0, "hi!", dfp13, dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getLn2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.subtract(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp24.subtract(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp24.getTwo();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp24.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp18.add(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.signum((-992.3191143765591d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getLn2();
        boolean boolean21 = dfp17.unequal(dfp20);
        java.lang.String str22 = dfp20.toString();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp2.remainder(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getLn2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp29.power10(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.subtract(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getLn2();
        boolean boolean36 = dfp32.unequal(dfp35);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp2.subtract(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "0.6931471805599453" + "'", str22.equals("0.6931471805599453"));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) -1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3305612614089886808L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (short) 100, (java.lang.Number) (-5108934833899263838L), false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-5108934833899263838L) + "'", number6.equals((-5108934833899263838L)));
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        int[] intArray5 = new int[] { 4, 58249551, (-493018183), 1142922799, 1890270366 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
//        int[] intArray13 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
//        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray13);
//        long long15 = mersenneTwister14.nextLong();
//        long long16 = mersenneTwister14.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray21 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister17.nextBytes(byteArray21);
//        java.lang.Class<?> wildcardClass23 = mersenneTwister17.getClass();
//        int int24 = mersenneTwister17.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math.random.MersenneTwister();
//        long long26 = mersenneTwister25.nextLong();
//        float float27 = mersenneTwister25.nextFloat();
//        boolean boolean28 = mersenneTwister25.nextBoolean();
//        int int29 = mersenneTwister25.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister30 = new org.apache.commons.math.random.MersenneTwister();
//        long long31 = mersenneTwister30.nextLong();
//        long long32 = mersenneTwister30.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister33 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray37 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister33.nextBytes(byteArray37);
//        mersenneTwister30.nextBytes(byteArray37);
//        mersenneTwister25.nextBytes(byteArray37);
//        mersenneTwister17.nextBytes(byteArray37);
//        mersenneTwister14.nextBytes(byteArray37);
//        mersenneTwister6.nextBytes(byteArray37);
//        org.junit.Assert.assertNotNull(intArray5);
//        org.junit.Assert.assertNotNull(intArray13);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-4202901040889903664L) + "'", long15 == (-4202901040889903664L));
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 3016148340477316550L + "'", long16 == 3016148340477316550L);
//        org.junit.Assert.assertNotNull(byteArray21);
//        org.junit.Assert.assertNotNull(wildcardClass23);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1632181809 + "'", int24 == 1632181809);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 4554251643272973458L + "'", long26 == 4554251643272973458L);
//        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.95329463f + "'", float27 == 0.95329463f);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-980308064) + "'", int29 == (-980308064));
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + (-2575513999290128878L) + "'", long31 == (-2575513999290128878L));
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + (-8370967431035224148L) + "'", long32 == (-8370967431035224148L));
//        org.junit.Assert.assertNotNull(byteArray37);
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        java.lang.String str9 = dfp8.toString();
        int int10 = dfp8.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getLn2();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getPi();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp18.dotrap((int) (byte) 3, "hi!", dfp26, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getLn2();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.subtract(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp33.newInstance((long) (byte) 3);
        boolean boolean42 = dfp30.equals((java.lang.Object) dfp41);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getLn2();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10(0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp45.subtract(dfp50);
        java.lang.String str52 = dfp51.toString();
        java.lang.String str53 = dfp51.toString();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp30.multiply(dfp51);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp8.divide(dfp30);
        try {
            org.apache.commons.math.dfp.Dfp dfp57 = dfp55.newInstance(9223372036854775807L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-0.3068528194400547" + "'", str9.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "-0.3068528194400547" + "'", str52.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "-0.3068528194400547" + "'", str53.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(5.551115123125783E-17d);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-6.053272382792838d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 1, (byte) 10);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags((-837412152));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getLn2();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10(0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp24.subtract(dfp29);
        java.lang.String str31 = dfp30.toString();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp21.nextAfter(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp("-0.3068528194400547");
        boolean boolean37 = dfp21.unequal(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp10.dotrap(35, "org.apache.commons.math.exception.NotStrictlyPositiveException: 8 is smaller than, or equal to, the minimum (0): 8 is smaller than, or equal to, the minimum (0)", dfp16, dfp21);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "-0.3068528194400547" + "'", str31.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(dfp38);
    }

//    @Test
//    public void test336() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test336");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister();
//        long long4 = mersenneTwister3.nextLong();
//        float float5 = mersenneTwister3.nextFloat();
//        boolean boolean6 = mersenneTwister3.nextBoolean();
//        int int7 = mersenneTwister3.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        long long10 = mersenneTwister8.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray15 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister11.nextBytes(byteArray15);
//        mersenneTwister8.nextBytes(byteArray15);
//        mersenneTwister3.nextBytes(byteArray15);
//        mersenneTwister3.setSeed((-6049992125526582820L));
//        boolean boolean21 = mersenneTwister3.nextBoolean();
//        byte[] byteArray23 = new byte[] { (byte) 3 };
//        mersenneTwister3.nextBytes(byteArray23);
//        mersenneTwister0.nextBytes(byteArray23);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-8007703528903205970L) + "'", long1 == (-8007703528903205970L));
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8853854f + "'", float2 == 0.8853854f);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 4337672576680472026L + "'", long4 == 4337672576680472026L);
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.71135044f + "'", float5 == 0.71135044f);
//        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 114315862 + "'", int7 == 114315862);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-2369192567451237115L) + "'", long9 == (-2369192567451237115L));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6072171215999824792L + "'", long10 == 6072171215999824792L);
//        org.junit.Assert.assertNotNull(byteArray15);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
//        org.junit.Assert.assertNotNull(byteArray23);
//    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-2575513999290128878L));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) (-1873816088));
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(2564688882439977360L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getPi();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp7.dotrap((int) (byte) 3, "hi!", dfp15, dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getLn2();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.power10(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.subtract(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp22.newInstance((long) (byte) 3);
        boolean boolean31 = dfp19.equals((java.lang.Object) dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getZero();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.getLn5();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.divide(dfp35);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((-627795142));
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Throwable[] throwableArray3 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number8 = numberIsTooSmallException7.getArgument();
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException14);
        java.lang.String str16 = mathRuntimeException15.toString();
        java.lang.Object[] objArray17 = mathRuntimeException15.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray17);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2662705844154317738L, (java.lang.Number) 1.5632289605524932d, false);
        java.lang.Number number25 = numberIsTooSmallException24.getArgument();
        java.lang.Number number26 = numberIsTooSmallException24.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 0, false);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException32 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException31);
        java.lang.String str33 = mathRuntimeException32.toString();
        java.lang.Object[] objArray34 = mathRuntimeException32.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 1872492081878224521L);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable27, (java.lang.Number) 0.062765f, (java.lang.Number) 49.99500000000002d, true);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray44);
        java.lang.Throwable[] throwableArray46 = mathIllegalArgumentException45.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable27, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField49.getLn5Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, (java.lang.Object[]) dfpArray51);
        java.lang.Object[] objArray53 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray53);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 2662705844154317738L + "'", number8.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 2662705844154317738L + "'", number9.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str16.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 2662705844154317738L + "'", number25.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 2662705844154317738L + "'", number26.equals(2662705844154317738L));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str33.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits(4);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1209585570);
        long long2 = mersenneTwister1.nextLong();
        try {
            int int4 = mersenneTwister1.nextInt((-1117159045));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1,117,159,045 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7955327270422267651L) + "'", long2 == (-7955327270422267651L));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.subtract(dfp7);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        boolean boolean12 = dfp8.unequal(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(dfp14);
    }

//    @Test
//    public void test345() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test345");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray4 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister0.nextBytes(byteArray4);
//        java.lang.Class<?> wildcardClass6 = mersenneTwister0.getClass();
//        int int7 = mersenneTwister0.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister();
//        long long9 = mersenneTwister8.nextLong();
//        float float10 = mersenneTwister8.nextFloat();
//        boolean boolean11 = mersenneTwister8.nextBoolean();
//        int int12 = mersenneTwister8.nextInt();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister();
//        long long14 = mersenneTwister13.nextLong();
//        long long15 = mersenneTwister13.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister();
//        byte[] byteArray20 = new byte[] { (byte) -1, (byte) 100, (byte) 100 };
//        mersenneTwister16.nextBytes(byteArray20);
//        mersenneTwister13.nextBytes(byteArray20);
//        mersenneTwister8.nextBytes(byteArray20);
//        mersenneTwister0.nextBytes(byteArray20);
//        int[] intArray26 = new int[] { 8 };
//        mersenneTwister0.setSeed(intArray26);
//        double double28 = mersenneTwister0.nextDouble();
//        long long29 = mersenneTwister0.nextLong();
//        boolean boolean30 = mersenneTwister0.nextBoolean();
//        mersenneTwister0.setSeed(5445645231746192477L);
//        long long33 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertNotNull(byteArray4);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1278695402) + "'", int7 == (-1278695402));
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4060562475220248598L + "'", long9 == 4060562475220248598L);
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5381963f + "'", float10 == 0.5381963f);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-919902096) + "'", int12 == (-919902096));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 7835011304219233125L + "'", long14 == 7835011304219233125L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + (-7691270636881230007L) + "'", long15 == (-7691270636881230007L));
//        org.junit.Assert.assertNotNull(byteArray20);
//        org.junit.Assert.assertNotNull(intArray26);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.22670585469025162d + "'", double28 == 0.22670585469025162d);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + (-695533844184942996L) + "'", long29 == (-695533844184942996L));
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 3274480579657007153L + "'", long33 == 3274480579657007153L);
//    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2564688882439977360L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((-1279918493));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9340424858798563d));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("0.");
        org.apache.commons.math.dfp.DfpField dfpField10 = dfp9.getField();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpField10);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getZero();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 567075184614940841L, (double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.setIEEEFlagsBits((int) (byte) -1);
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.sqrt();
        int int9 = dfp7.intValue();
        boolean boolean10 = dfp7.isNaN();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((double) (-1873816088));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) 32760);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp("-0.3068528194400547");
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((-1279918493));
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.newDfp((-0.9340424858798563d));
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.newInstance(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance("10.");
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        int int5 = dfp4.intValue();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getZero();
        int int9 = dfp8.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.newInstance((double) 1.0f);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.rint();
        int int13 = dfp12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.add(dfp12);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        int int3 = dfp2.log10K();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.negate();
        java.lang.String str5 = dfp2.toString();
        double double6 = dfp2.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "0." + "'", str5.equals("0."));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (-2093271168964412317L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-2093271168964412416L) + "'", long1 == (-2093271168964412416L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlagsBits((-1979276953));
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) '4');
        java.lang.Class<?> wildcardClass10 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.rint();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1507172489677753d + "'", double1 == 0.1507172489677753d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField3 = dfp2.getField();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.getZero();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getZero();
        int int8 = dfp7.log10K();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance((double) 1.0f);
        boolean boolean11 = dfp2.equals((java.lang.Object) dfp10);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpField3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((byte) 3);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double2 = org.apache.commons.math.util.FastMath.max(3.831008000716577E22d, (double) 0.27374506f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.831008000716577E22d + "'", double2 == 3.831008000716577E22d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        int[] intArray7 = new int[] { 691077309, 'a', 100, ' ', (short) 100, 1209585570 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister0.setSeed(intArray7);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(5.551115123125783E-17d);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.power10(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.subtract(dfp13);
        java.lang.String str15 = dfp14.toString();
        java.lang.String str16 = dfp14.toString();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp19.subtract(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp14.remainder(dfp19);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp5.floor();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode31 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField30.setRoundingMode(roundingMode31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getE();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getLn2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp40.power10(0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp37.subtract(dfp42);
        java.lang.String str44 = dfp43.toString();
        int int45 = dfp43.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getLn2();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp48.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp48.subtract(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField(16);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField58.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getPi();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp53.dotrap((int) (byte) 3, "hi!", dfp61, dfp64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField70 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField70.getLn2();
        org.apache.commons.math.dfp.Dfp dfp73 = dfp71.power10(0);
        org.apache.commons.math.dfp.Dfp dfp74 = dfp68.subtract(dfp73);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp68.newInstance((long) (byte) 3);
        boolean boolean77 = dfp65.equals((java.lang.Object) dfp76);
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField79.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField82.getLn2();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp83.power10(0);
        org.apache.commons.math.dfp.Dfp dfp86 = dfp80.subtract(dfp85);
        java.lang.String str87 = dfp86.toString();
        java.lang.String str88 = dfp86.toString();
        org.apache.commons.math.dfp.Dfp dfp89 = dfp65.multiply(dfp86);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp43.divide(dfp65);
        org.apache.commons.math.dfp.Dfp dfp91 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp34, dfp65);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "-0.3068528194400547" + "'", str15.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-0.3068528194400547" + "'", str16.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + roundingMode31 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode31.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "-0.3068528194400547" + "'", str44.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertTrue("'" + str87 + "' != '" + "-0.3068528194400547" + "'", str87.equals("-0.3068528194400547"));
        org.junit.Assert.assertTrue("'" + str88 + "' != '" + "-0.3068528194400547" + "'", str88.equals("-0.3068528194400547"));
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
    }
}

