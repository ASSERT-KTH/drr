import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_NUMBER_OF_POINTS));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 0, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_ROWS_AND_COLUMNS));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Object obj0 = new java.lang.Object();
        java.lang.Class<?> wildcardClass1 = obj0.getClass();
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.4210854715202004E-14d, (java.lang.Number) 10L, false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(throwable2, (double) ' ', "", objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        java.lang.Object[] objArray15 = new java.lang.Object[] { localizedFormats1, ' ', 10L, localizedFormats13, localizedFormats14 };
        java.lang.ArithmeticException arithmeticException16 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_LARGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arithmeticException16);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_BANDWIDTH));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_BIN_SELECTED));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.lang.Throwable throwable2 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(throwable2, (double) ' ', "", objArray10);
        java.text.ParseException parseException12 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) parseException12, (double) 0);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(parseException12);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10, number1, false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        java.lang.Object[] objArray1 = null;
        java.lang.IllegalStateException illegalStateException2 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertNotNull(illegalStateException2);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.605170185988092d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.21714724095162588d + "'", double2 == 0.21714724095162588d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) (-1), false);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1920928955078125E-7d + "'", double1 == 1.1920928955078125E-7d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test087() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test087");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        try {
//            double double6 = randomDataImpl1.nextChiSquare((double) (-1));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 59 + "'", int4 == 59);
//    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.32673690788361603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32673690788361603d + "'", double1 == 0.32673690788361603d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248699261236361d + "'", double1 == 4.248699261236361d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POSITION_SIZE_MISMATCH_INPUT_ARRAY));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPANSION_FACTOR_SMALLER_THAN_ONE));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 116.3165626204744d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        try {
//            double double7 = randomDataImpl1.nextChiSquare((double) (short) -1);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 34 + "'", int5 == 34);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution2 = null;
        try {
            int int3 = randomDataImpl1.nextInversionDeviate(integerDistribution2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_MATRIX));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        try {
            org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 1, (double) (-1L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test109");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        randomDataImpl1.reSeed((long) ' ');
//        try {
//            int int10 = randomDataImpl1.nextBinomial(52, (double) (short) 100);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 91L + "'", long3 == 91L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.7836102254995015d + "'", double5 == 0.7836102254995015d);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, number1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = functionEvaluationException1.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable5, (double) ' ', "", objArray13);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray13);
        double[] doubleArray16 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        java.lang.ArithmeticException arithmeticException24 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray22);
        try {
            org.apache.commons.math.FunctionEvaluationException functionEvaluationException25 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray16, (org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(arithmeticException24);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        convergenceException0.addSuppressed((java.lang.Throwable) functionEvaluationException2);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray45 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException("", objArray45);
        double[] doubleArray48 = new double[] { (short) 1 };
        java.lang.Throwable throwable50 = null;
        java.lang.Object[] objArray58 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(throwable50, (double) ' ', "", objArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(doubleArray48, "", objArray58);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable64 = null;
        java.lang.Object[] objArray72 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException(throwable64, (double) ' ', "", objArray72);
        java.text.ParseException parseException74 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray72);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException46, doubleArray48, (org.apache.commons.math.exception.util.Localizable) localizedFormats61, objArray72);
        java.lang.IllegalArgumentException illegalArgumentException76 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, "hi!", objArray72);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats61.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray72);
        org.junit.Assert.assertNotNull(parseException74);
        org.junit.Assert.assertNotNull(illegalArgumentException76);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("", objArray4);
        double[] doubleArray7 = new double[] { (short) 1 };
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(throwable23, (double) ' ', "", objArray31);
        java.text.ParseException parseException33 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException5, doubleArray7, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray31);
        java.lang.IllegalArgumentException illegalArgumentException35 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray31);
        java.lang.IllegalArgumentException illegalArgumentException36 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) illegalArgumentException35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(parseException33);
        org.junit.Assert.assertNotNull(illegalArgumentException35);
        org.junit.Assert.assertNotNull(illegalArgumentException36);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure();
        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
        try {
            double double8 = randomDataImpl1.nextBeta((double) (byte) 0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: Cumulative probability function returned NaN for argument 0.468 p = 0.468");
        } catch (org.apache.commons.math.FunctionEvaluationException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        try {
//            double double8 = randomDataImpl1.nextBeta((double) (-1L), 4.4626898195446465d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: Cumulative probability function returned NaN for argument 0.465 p = 0.465");
//        } catch (org.apache.commons.math.FunctionEvaluationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.32673690788361603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005702634830354518d + "'", double1 == 0.005702634830354518d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
//        org.apache.commons.math.exception.util.Localizable localizable3 = functionEvaluationException2.getLocalizablePattern();
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
//        java.lang.Throwable throwable6 = null;
//        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(throwable6, (double) ' ', "", objArray14);
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
//        try {
//            java.util.NoSuchElementException noSuchElementException17 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException(localizable0, objArray14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
//        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
//        org.junit.Assert.assertNotNull(objArray14);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.4210854715202004E-14d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, Double.NaN);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 63);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.836218912841156d + "'", double1 == 4.836218912841156d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.836218912841156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 125.99206299209445d + "'", double1 == 125.99206299209445d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_BETA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_BETA));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 52L, (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2005.3522829578812d + "'", double1 == 2005.3522829578812d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException("", objArray1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        double[] doubleArray11 = new double[] { (short) 1 };
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) ' ', "", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) ' ', "", objArray35);
        java.text.ParseException parseException37 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, doubleArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray35);
        java.lang.IllegalArgumentException illegalArgumentException39 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray35);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray35);
        java.lang.String str41 = mathException40.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(parseException37);
        org.junit.Assert.assertNotNull(illegalArgumentException39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)" + "'", str41.equals("org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.4626898195446465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07788863084628568d + "'", double1 == 0.07788863084628568d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        convergenceException0.addSuppressed((java.lang.Throwable) functionEvaluationException2);
        java.lang.RuntimeException runtimeException40 = org.apache.commons.math.MathRuntimeException.createInternalError((java.lang.Throwable) convergenceException0);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertNotNull(runtimeException40);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double[] doubleArray1 = new double[] { (short) 1 };
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) ' ', "", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1, "", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double0 = org.apache.commons.math.distribution.PoissonDistributionImpl.DEFAULT_EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-12d + "'", double0 == 1.0E-12d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISTRIBUTION_NOT_LOADED));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) ' ', "", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable10 = functionEvaluationException9.getLocalizablePattern();
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable10);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        try {
//            double double7 = randomDataImpl1.nextF((double) 87, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 88 + "'", int4 == 88);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) 10.0f);
        int[] intArray4 = poissonDistributionImpl2.sample((int) 'a');
        double double6 = poissonDistributionImpl2.normalApproximateProbability((int) (short) 100);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ALPHA));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        int int1 = org.apache.commons.math.util.FastMath.abs(92);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 92 + "'", int1 == 92);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException(2005.3522829578812d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.lang.Object[] objArray1 = null;
        java.lang.NullPointerException nullPointerException2 = org.apache.commons.math.MathRuntimeException.createNullPointerException("", objArray1);
        org.junit.Assert.assertNotNull(nullPointerException2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

//    @Test
//    public void test181() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test181");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        try {
//            int int6 = randomDataImpl1.nextSecureInt((int) (short) 100, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 110L + "'", long3 == 110L);
//    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
    }

//    @Test
//    public void test183() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test183");
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
//        double double5 = poissonDistributionImpl3.probability(80);
//        int int6 = poissonDistributionImpl3.sample();
//        try {
//            double double8 = poissonDistributionImpl3.cumulativeProbability(87);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
//        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.1401737047361744E-120d + "'", double5 == 5.1401737047361744E-120d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
//    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        try {
//            double double7 = randomDataImpl1.nextUniform((double) 35, 4.605170185988092d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (4.605): lower bound (35) must be strictly less than upper bound (4.605)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 41 + "'", int4 == 41);
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(4.248699261236361d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248699261236362d + "'", double1 == 4.248699261236362d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density((double) 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.746366256758777E-223d + "'", double2 == 1.746366256758777E-223d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextUniform(1.0E-9d, (double) 48);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl14 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
//        double double16 = poissonDistributionImpl14.probability(80);
//        try {
//            int int17 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl14);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: maximal number of iterations (-1) exceeded");
//        } catch (org.apache.commons.math.FunctionEvaluationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.366141128733193d + "'", double7 == 0.366141128733193d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 37.39430394894423d + "'", double10 == 37.39430394894423d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.1401737047361744E-120d + "'", double16 == 5.1401737047361744E-120d);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N;
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) ' ', "", objArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable0, 0.0d, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_NTH_ROOT_FOR_NEGATIVE_N));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.5601874895062087E-41d, (java.lang.Number) 100.0d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_PERMUTATION));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure((long) 92);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 87);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray3);
        java.util.ConcurrentModificationException concurrentModificationException5 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException7 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) concurrentModificationException5, (double) 32);
        java.lang.Throwable[] throwableArray8 = concurrentModificationException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(concurrentModificationException5);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_WEIGHT));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.IllegalArgumentException illegalArgumentException3 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) mathException2);
        org.junit.Assert.assertNotNull(illegalArgumentException3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test213");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        try {
//            int int8 = randomDataImpl1.nextBinomial((int) (short) -1, 1.0E-9d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 100L + "'", long3 == 100L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8825487860534429d + "'", double5 == 0.8825487860534429d);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (byte) -1, 1);
        try {
            int int5 = poissonDistributionImpl3.inverseCumulativeProbability((double) 32);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("", objArray4);
        double[] doubleArray7 = new double[] { (short) 1 };
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(throwable23, (double) ' ', "", objArray31);
        java.text.ParseException parseException33 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException5, doubleArray7, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        double[] doubleArray45 = new double[] { (short) 1 };
        java.lang.Throwable throwable47 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException56 = new org.apache.commons.math.FunctionEvaluationException(throwable47, (double) ' ', "", objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(doubleArray45, "", objArray55);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable61 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException(throwable61, (double) ' ', "", objArray69);
        java.text.ParseException parseException71 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray69);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException43, doubleArray45, (org.apache.commons.math.exception.util.Localizable) localizedFormats58, objArray69);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats76 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray77 = new java.lang.Object[] { localizedFormats37, localizedFormats38, functionEvaluationException72, 100, 0L, localizedFormats76 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "", objArray77);
        java.lang.NullPointerException nullPointerException79 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray77);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(parseException33);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(parseException71);
        org.junit.Assert.assertTrue("'" + localizedFormats76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats76.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(nullPointerException79);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.21714724095162588d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ROBUSTNESS_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 80);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 80L + "'", long1 == 80L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test227");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        randomDataImpl1.reSeed((long) ' ');
//        try {
//            java.lang.String str9 = randomDataImpl1.nextHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 92L + "'", long3 == 92L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.6321579503217268d + "'", double5 == 0.6321579503217268d);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 80);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        double[] doubleArray8 = new double[] { (short) 1 };
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) ' ', "", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable24, (double) ' ', "", objArray32);
        java.text.ParseException parseException34 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray42);
        java.text.ParseException parseException46 = org.apache.commons.math.MathRuntimeException.createParseException((-1), (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray42);
        java.lang.String str47 = parseException46.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(parseException34);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(parseException46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}" + "'", str47.equals("org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("", objArray4);
        double[] doubleArray7 = new double[] { (short) 1 };
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(throwable23, (double) ' ', "", objArray31);
        java.text.ParseException parseException33 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException5, doubleArray7, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray31);
        org.apache.commons.math.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.MathRuntimeException(localizable0, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable36 = mathRuntimeException35.getLocalizablePattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(parseException33);
        org.junit.Assert.assertNull(localizable36);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POPULATION_LIMIT_NOT_POSITIVE));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.00000000000001d + "'", double1 == 98.00000000000001d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        normalDistributionImpl0.setStandardDeviation((double) 100);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.4530981184745694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1005587164121773d + "'", double1 == 1.1005587164121773d);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        randomDataImpl1.reSeed((long) (short) -1);
//        try {
//            double double11 = randomDataImpl1.nextT((double) (-1.0f));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 47 + "'", int4 == 47);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3759925000357864d + "'", double7 == 0.3759925000357864d);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray43 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray43);
        org.apache.commons.math.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.MathRuntimeException("", objArray43);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray43);
        java.text.ParseException parseException47 = org.apache.commons.math.MathRuntimeException.createParseException((-1), (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray43);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(parseException47);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027181892591221314d + "'", double1 == 0.027181892591221314d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4530981184745694d, (double) 96);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.45309811847456943d + "'", double2 == 0.45309811847456943d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability(57.29577951308232d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 38);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2963685787093853d + "'", double1 == 0.2963685787093853d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        double[] doubleArray8 = new double[] { (short) 1 };
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) ' ', "", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable24, (double) ' ', "", objArray32);
        java.text.ParseException parseException34 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray48 = new java.lang.Object[] { localizedFormats42, 'a', true, (short) 1, localizedFormats46, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray48);
        java.lang.IllegalArgumentException illegalArgumentException50 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray48);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray48);
        double[] doubleArray52 = functionEvaluationException51.getArgument();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(parseException34);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(illegalArgumentException50);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.4530981184745694d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.885883777914569d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable5, (double) ' ', "", objArray13);
        java.text.ParseException parseException15 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray21 = new java.lang.Object[] { ' ', localizedFormats16, localizedFormats17, localizedFormats18, 0.32673690788361603d, localizedFormats20 };
        java.lang.IllegalStateException illegalStateException22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray21);
        java.lang.IllegalStateException illegalStateException23 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray21);
        java.lang.ArithmeticException arithmeticException24 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(parseException15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(illegalStateException22);
        org.junit.Assert.assertNotNull(illegalStateException23);
        org.junit.Assert.assertNotNull(arithmeticException24);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double2 = org.apache.commons.math.util.FastMath.pow(10.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1d + "'", double2 == 0.1d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) 10.0f);
        int[] intArray4 = poissonDistributionImpl2.sample((int) 'a');
        double double7 = poissonDistributionImpl2.cumulativeProbability((-1.8720243875170033d), (double) 1);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.8160602794142788d + "'", double7 == 0.8160602794142788d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.32673690788361603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.31580206989499693d + "'", double1 == 0.31580206989499693d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 116.3165626204744d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray10 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray10);
        java.util.ConcurrentModificationException concurrentModificationException12 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray10);
        java.lang.Object[] objArray13 = new java.lang.Object[] { notStrictlyPositiveException4, 92, localizedFormats6, concurrentModificationException12 };
        java.util.ConcurrentModificationException concurrentModificationException14 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("hi!", objArray13);
        java.lang.ArithmeticException arithmeticException15 = org.apache.commons.math.MathRuntimeException.createArithmeticException("", objArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(concurrentModificationException12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(concurrentModificationException14);
        org.junit.Assert.assertNotNull(arithmeticException15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_COLUMN));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.1920928955078125E-7d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.292486337515024E-9d + "'", double2 == 2.292486337515024E-9d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.STANDARD_DEVIATION));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray2 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray2);
        java.lang.String str4 = mathRuntimeException3.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "no optimum computed yet" + "'", str4.equals("no optimum computed yet"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.4626898195446465d);
//        try {
//            int int7 = randomDataImpl1.nextHypergeometric(47, 96, 80);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.7614252740310148d) + "'", double3 == (-0.7614252740310148d));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.IllegalArgumentException illegalArgumentException6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) illegalArgumentException6, (double) 98L);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(illegalArgumentException6);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(116.3165626204744d, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 116.31656262047439d + "'", double2 == 116.31656262047439d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1005587164121773d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52.0f, (java.lang.Number) 52, false);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.10294463232638718d + "'", double0 == 0.10294463232638718d);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) 100, 4.248699261236362d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1433918474859405E8d + "'", double2 == 3.1433918474859405E8d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.885883777914569d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6774505542241952d) + "'", double1 == (-0.6774505542241952d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(4.248699261236361d, (double) (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextSecureInt((int) 'a', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (10): lower bound (97) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.Localizable localizable6 = functionEvaluationException5.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException5, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable3, objArray17);
        java.text.ParseException parseException21 = org.apache.commons.math.MathRuntimeException.createParseException(0, "org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray26);
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException21, "", objArray26);
        java.util.NoSuchElementException noSuchElementException30 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(parseException21);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertNotNull(noSuchElementException30);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.MathRuntimeException(localizable2, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException38 = new org.apache.commons.math.MaxIterationsExceededException(10, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray33);
        int int39 = maxIterationsExceededException38.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) ' ', "", objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray9);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException4.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable7, (double) ' ', "", objArray15);
        java.lang.UnsupportedOperationException unsupportedOperationException17 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray15);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException(48, localizable5, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(unsupportedOperationException17);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double2 = org.apache.commons.math.util.FastMath.min(0.3666502051862685d, 0.32673690788361603d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.32673690788361603d + "'", double2 == 0.32673690788361603d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_NAN));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        double double4 = normalDistributionImpl0.inverseCumulativeProbability(1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.POSITIVE_INFINITY + "'", double4 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator((long) (short) -1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 38, (long) 25);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.0d), (double) 92, (double) (short) 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        try {
//            long long8 = randomDataImpl1.nextLong(80L, 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 80 is larger than, or equal to, the maximum (1): lower bound (80) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 114L + "'", long3 == 114L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0011714547303645823d + "'", double5 == 0.0011714547303645823d);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.IllegalArgumentException illegalArgumentException8 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException((double) 52L, "hi!", objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(illegalArgumentException8);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 25L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.258096538021482d + "'", double1 == 3.258096538021482d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_ENDPOINT_ABOVE_UPPER_ENDPOINT));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        try {
            double double5 = poissonDistributionImpl3.cumulativeProbability((double) 25L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray9);
        java.lang.ArithmeticException arithmeticException11 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray9);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException12 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray9);
        java.text.ParseException parseException13 = org.apache.commons.math.MathRuntimeException.createParseException(100, "hi!", objArray9);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "no optimum computed yet", objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(arithmeticException11);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException12);
        org.junit.Assert.assertNotNull(parseException13);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double[] doubleArray5 = new double[] { 2.292486337515024E-9d, 1.8267797762229168d, (byte) 1, 47, 10.584300860350366d };
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable7, (double) ' ', "", objArray15);
        java.lang.Object[] objArray17 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray15);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9312248195170991d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int0 = org.apache.commons.math.distribution.PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000000 + "'", int0 == 10000000);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DATA));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_POLYNOMIAL_DEGREE));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.Localizable localizable6 = functionEvaluationException5.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException5, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray17);
        java.text.ParseException parseException21 = org.apache.commons.math.MathRuntimeException.createParseException((int) (byte) 100, "no optimum computed yet", objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(parseException21);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double[] doubleArray2 = new double[] { (short) 1 };
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable4, (double) ' ', "", objArray12);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(doubleArray2, "", objArray12);
        java.lang.IllegalArgumentException illegalArgumentException15 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("", objArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(illegalArgumentException15);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10000000, (long) 92);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000000L + "'", long2 == 10000000L);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5585053606381855d + "'", double1 == 0.5585053606381855d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        double[] doubleArray6 = new double[] { (short) 1 };
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(throwable8, (double) ' ', "", objArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable22 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(throwable22, (double) ' ', "", objArray30);
        java.text.ParseException parseException32 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException4, doubleArray6, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        java.lang.Throwable throwable37 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException46 = new org.apache.commons.math.FunctionEvaluationException(throwable37, (double) ' ', "", objArray45);
        java.lang.Object[] objArray47 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray45);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray54 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray54);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException("", objArray54);
        org.apache.commons.math.MathRuntimeException mathRuntimeException57 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException34, (org.apache.commons.math.exception.util.Localizable) localizedFormats50, objArray54);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(parseException32);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats50.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 32 + "'", number2.equals(32));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        double double7 = randomDataImpl1.nextBeta((double) 101L, (double) (short) 100);
//        int[] intArray10 = randomDataImpl1.nextPermutation(1, 1);
//        try {
//            double double13 = randomDataImpl1.nextUniform((double) 34, 3.885883777914569d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 34 is larger than, or equal to, the maximum (3.886): lower bound (34) must be strictly less than upper bound (3.886)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 96.81999287065965d + "'", double4 == 96.81999287065965d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.511013276324823d + "'", double7 == 0.511013276324823d);
//        org.junit.Assert.assertNotNull(intArray10);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        double[] doubleArray39 = functionEvaluationException2.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray49 = new java.lang.Object[] { localizedFormats43, 'a', true, (short) 1, localizedFormats47, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray49);
        java.lang.IllegalArgumentException illegalArgumentException51 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(illegalArgumentException51);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl(1.1920928955078125E-7d, 1.0E-12d, 52);
        poissonDistributionImpl3.reseedRandomGenerator((long) 80);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 92);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 92.0d + "'", double1 == 92.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        double double5 = poissonDistributionImpl3.probability(80);
        double double7 = poissonDistributionImpl3.probability((int) '#');
        double double8 = poissonDistributionImpl3.getMean();
        int[] intArray10 = poissonDistributionImpl3.sample(0);
        try {
            double double13 = poissonDistributionImpl3.cumulativeProbability(10000000, 80);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.1401737047361744E-120d + "'", double5 == 5.1401737047361744E-120d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.5601874895062087E-41d + "'", double7 == 3.5601874895062087E-41d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        java.lang.Object[] objArray7 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        java.lang.ArithmeticException arithmeticException9 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray7);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException10 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        java.text.ParseException parseException11 = org.apache.commons.math.MathRuntimeException.createParseException(100, "hi!", objArray7);
        org.apache.commons.math.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathRuntimeException12.getLocalizablePattern();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(arithmeticException9);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException10);
        org.junit.Assert.assertNotNull(parseException11);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double2 = normalDistributionImpl0.density(5.551115123125783E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3989422804014327d + "'", double2 == 0.3989422804014327d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 92);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.214906219438257d + "'", double1 == 5.214906219438257d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable5, (double) ' ', "", objArray13);
        java.text.ParseException parseException15 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray13);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray21 = new java.lang.Object[] { ' ', localizedFormats16, localizedFormats17, localizedFormats18, 0.32673690788361603d, localizedFormats20 };
        java.lang.IllegalStateException illegalStateException22 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray21);
        java.lang.IllegalStateException illegalStateException23 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray21);
        java.lang.NullPointerException nullPointerException24 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(parseException15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(illegalStateException22);
        org.junit.Assert.assertNotNull(illegalStateException23);
        org.junit.Assert.assertNotNull(nullPointerException24);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.8267797762229168d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.026456734019081d + "'", double1 == 3.026456734019081d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.IllegalArgumentException illegalArgumentException8 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        java.lang.Object[] objArray9 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray6);
        java.text.ParseException parseException10 = org.apache.commons.math.MathRuntimeException.createParseException(25, "be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(illegalArgumentException8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(parseException10);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test351");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform(0.0d, (double) 10.0f);
//        try {
//            int int7 = randomDataImpl1.nextSecureInt(32, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (1): lower bound (32) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.5780687845010117d + "'", double4 == 3.5780687845010117d);
//    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long1 = org.apache.commons.math.util.FastMath.round(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test354");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        try {
//            int int6 = randomDataImpl1.nextZipf((int) (short) -1, (-0.6774505542241952d));
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 87L + "'", long3 == 87L);
//    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 80);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 80.00000000000001d + "'", double1 == 80.00000000000001d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator((long) 35);
        normalDistributionImpl0.setStandardDeviation((double) 5L);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10000000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '#');
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        java.lang.String str9 = randomDataImpl1.nextHexString(34);
//        try {
//            randomDataImpl1.setSecureAlgorithm("hi!", "org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 80 + "'", int4 == 80);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.396226148105636d + "'", double7 == 0.396226148105636d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "c6571ec0e41ec142f50143b5332ea8827d" + "'", str9.equals("c6571ec0e41ec142f50143b5332ea8827d"));
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(throwable6, (double) ' ', "", objArray14);
        java.text.ParseException parseException16 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray22 = new java.lang.Object[] { ' ', localizedFormats17, localizedFormats18, localizedFormats19, 0.32673690788361603d, localizedFormats21 };
        java.lang.IllegalStateException illegalStateException23 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray22);
        java.lang.IllegalStateException illegalStateException24 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray22);
        java.io.EOFException eOFException25 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("no optimum computed yet", objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(parseException16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(illegalStateException23);
        org.junit.Assert.assertNotNull(illegalStateException24);
        org.junit.Assert.assertNotNull(eOFException25);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, 'a', true, (short) 1, localizedFormats6, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        java.lang.IllegalArgumentException illegalArgumentException10 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) illegalArgumentException10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(illegalArgumentException10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.5601874895062087E-41d, (double) '4');
        double double4 = normalDistributionImpl2.cumulativeProbability((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5076714940793816d + "'", double4 == 0.5076714940793816d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double3 = normalDistributionImpl0.cumulativeProbability(1.3830047278040059d);
        double double5 = normalDistributionImpl0.density(100.0d);
        normalDistributionImpl0.setStandardDeviation(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9166682918784135d + "'", double3 == 0.9166682918784135d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) ' ', "", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 91L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.51085950651685d + "'", double1 == 4.51085950651685d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray6);
        java.text.ParseException parseException9 = org.apache.commons.math.MathRuntimeException.createParseException((int) '4', "64081c3d512d1d30db234ec5122f9be561", objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats13, 'a', true, (short) 1, localizedFormats17, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray19);
        java.lang.IllegalArgumentException illegalArgumentException21 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray19);
        java.lang.Object[] objArray22 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) parseException9, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray22);
        java.lang.Object[] objArray24 = mathRuntimeException23.getArguments();
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(arithmeticException8);
        org.junit.Assert.assertNotNull(parseException9);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(illegalArgumentException21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(47);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        double double8 = randomDataImpl1.nextCauchy((double) 80, (double) 98L);
//        try {
//            int int11 = randomDataImpl1.nextInt(10000000, 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10,000,000 is larger than, or equal to, the maximum (35): lower bound (10,000,000) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 35 + "'", int5 == 35);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.019473317099724d + "'", double8 == 2.019473317099724d);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.ArithmeticException arithmeticException7 = org.apache.commons.math.MathRuntimeException.createArithmeticException("hi!", objArray5);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException8 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray5);
        java.lang.Throwable throwable9 = null;
        try {
            arrayIndexOutOfBoundsException8.addSuppressed(throwable9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(arithmeticException7);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.885883777914569d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATIONS));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable43 = null;
        java.lang.Object[] objArray51 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException(throwable43, (double) ' ', "", objArray51);
        java.text.ParseException parseException53 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray51);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray59 = new java.lang.Object[] { ' ', localizedFormats54, localizedFormats55, localizedFormats56, 0.32673690788361603d, localizedFormats58 };
        java.lang.IllegalStateException illegalStateException60 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException0, doubleArray9);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(parseException53);
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(illegalStateException60);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextUniform(0.0d, (double) 10.0f);
//        try {
//            long long6 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 6.429478231261438d + "'", double4 == 6.429478231261438d);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.IllegalArgumentException illegalArgumentException7 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("no optimum computed yet", objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(illegalArgumentException7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray9 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException("", objArray9);
        double[] doubleArray12 = new double[] { (short) 1 };
        java.lang.Throwable throwable14 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(throwable14, (double) ' ', "", objArray22);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException24 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, "", objArray22);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable28 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(throwable28, (double) ' ', "", objArray36);
        java.text.ParseException parseException38 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException10, doubleArray12, (org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray36);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray47 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException("", objArray47);
        double[] doubleArray50 = new double[] { (short) 1 };
        java.lang.Throwable throwable52 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(throwable52, (double) ' ', "", objArray60);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException62 = new org.apache.commons.math.FunctionEvaluationException(doubleArray50, "", objArray60);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats63 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable66 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException(throwable66, (double) ' ', "", objArray74);
        java.text.ParseException parseException76 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException77 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException48, doubleArray50, (org.apache.commons.math.exception.util.Localizable) localizedFormats63, objArray74);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException79 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats81 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray82 = new java.lang.Object[] { localizedFormats42, localizedFormats43, functionEvaluationException77, 100, 0L, localizedFormats81 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException(doubleArray12, "", objArray82);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException84 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException3, (double) (byte) 100, "", objArray82);
        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray82);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException86 = new org.apache.commons.math.MaxIterationsExceededException(38, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray82);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(parseException38);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertTrue("'" + localizedFormats63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats63.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(parseException76);
        org.junit.Assert.assertTrue("'" + localizedFormats81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats81.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f));
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (-1.0f) + "'", number3.equals((-1.0f)));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f));
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray8 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        double[] doubleArray11 = new double[] { (short) 1 };
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) ' ', "", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) ' ', "", objArray35);
        java.text.ParseException parseException37 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, doubleArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException4, doubleArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable45 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(throwable45, (double) ' ', "", objArray53);
        java.text.ParseException parseException55 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray53);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats58 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray61 = new java.lang.Object[] { ' ', localizedFormats56, localizedFormats57, localizedFormats58, 0.32673690788361603d, localizedFormats60 };
        java.lang.IllegalStateException illegalStateException62 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException63 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray61);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) notStrictlyPositiveException2, doubleArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(parseException37);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(parseException55);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats58.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(illegalStateException62);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.3830047278040059d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.3830047278040059d + "'", number2.equals(1.3830047278040059d));
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextUniform(1.0E-9d, (double) 48);
//        try {
//            int int13 = randomDataImpl1.nextPascal(0, 0.308537538725987d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.FunctionEvaluationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.36524797691112804d + "'", double7 == 0.36524797691112804d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.213242420588339d + "'", double10 == 4.213242420588339d);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(1.0070796772362076d, 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        java.lang.Object[] objArray1 = null;
        java.util.NoSuchElementException noSuchElementException2 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(noSuchElementException2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(80);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10000000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8115262724608532d + "'", double1 == 1.8115262724608532d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 103L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.14889156509222d + "'", double1 == 10.14889156509222d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.292486337515024E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2924863375150246E-9d + "'", double1 == 2.2924863375150246E-9d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException("", objArray1);
        java.io.IOException iOException3 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) mathRuntimeException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathRuntimeException2.getLocalizablePattern();
        java.lang.Object[] objArray5 = mathRuntimeException2.getArguments();
        org.junit.Assert.assertNotNull(iOException3);
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.lang.Throwable throwable4 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException13 = new org.apache.commons.math.FunctionEvaluationException(throwable4, (double) ' ', "", objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        java.lang.IllegalArgumentException illegalArgumentException16 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray14);
        java.lang.NullPointerException nullPointerException17 = org.apache.commons.math.MathRuntimeException.createNullPointerException("64081c3d512d1d30db234ec5122f9be561", objArray14);
        java.io.EOFException eOFException18 = org.apache.commons.math.MathRuntimeException.createEOFException("org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray14);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(illegalArgumentException16);
        org.junit.Assert.assertNotNull(nullPointerException17);
        org.junit.Assert.assertNotNull(eOFException18);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math.util.FastMath.signum(82.93985818391583d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0.0f, 92.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double1 = org.apache.commons.math.util.FastMath.atanh(8.561941414461641E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.561941414461641E-10d + "'", double1 == 8.561941414461641E-10d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray3);
        java.util.ConcurrentModificationException concurrentModificationException5 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        java.lang.Object[] objArray6 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(concurrentModificationException5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.IllegalArgumentException illegalArgumentException7 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        org.apache.commons.math.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.MathRuntimeException("", objArray12);
        java.text.ParseException parseException15 = org.apache.commons.math.MathRuntimeException.createParseException((int) (short) 1, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(illegalArgumentException7);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(parseException15);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        double double7 = randomDataImpl1.nextCauchy(0.47948615734257893d, 22026.465794806718d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 103.9401145057132d + "'", double4 == 103.9401145057132d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12022.029173652518d + "'", double7 == 12022.029173652518d);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        try {
            double double6 = normalDistributionImpl0.inverseCumulativeProbability((double) 47);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator(0L);
        double double7 = poissonDistributionImpl3.normalApproximateProbability((int) (short) 0);
        try {
            double double10 = poissonDistributionImpl3.cumulativeProbability(0.27487025211907634d, 0.9866275920404853d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.308537538725987d + "'", double7 == 0.308537538725987d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25 + "'", int1 == 25);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        double double8 = randomDataImpl1.nextUniform(4.9E-324d, (double) 52L);
//        try {
//            int int11 = randomDataImpl1.nextBinomial(1, 22026.465794806718d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 34 + "'", int5 == 34);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 33.68035951850837d + "'", double8 == 33.68035951850837d);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97, 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        try {
            double double6 = poissonDistributionImpl3.cumulativeProbability((int) '4', 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test422() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test422");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextBeta(1.0E-9d, 2.718281828459045d);
//        try {
//            int int13 = randomDataImpl1.nextPascal(0, (double) 0.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.FunctionEvaluationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 75 + "'", int4 == 75);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.408266879341327d + "'", double7 == 0.408266879341327d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 87);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 87 + "'", int1 == 87);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(110.29757148748227d, 0.3373155475049838d, (double) 89L);
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, 'a', true, (short) 1, localizedFormats6, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        java.lang.Object[] objArray10 = null;
        java.lang.IllegalStateException illegalStateException11 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        double[] doubleArray16 = new double[] { (short) 1 };
        java.lang.Throwable throwable18 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(throwable18, (double) ' ', "", objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException28 = new org.apache.commons.math.FunctionEvaluationException(doubleArray16, "", objArray26);
        java.lang.ArithmeticException arithmeticException29 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray26);
        java.text.ParseException parseException30 = org.apache.commons.math.MathRuntimeException.createParseException(35, "", objArray26);
        java.text.ParseException parseException31 = org.apache.commons.math.MathRuntimeException.createParseException((int) '#', (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray26);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(illegalStateException11);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(arithmeticException29);
        org.junit.Assert.assertNotNull(parseException30);
        org.junit.Assert.assertNotNull(parseException31);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.005702634830354518d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.005702665739129447d + "'", double1 == 0.005702665739129447d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 96, (java.lang.Number) 5L, true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16372121576841134d + "'", double1 == 0.16372121576841134d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.43031226025118197d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.Localizable localizable5 = functionEvaluationException4.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(throwable8, (double) ' ', "", objArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException4, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable2, objArray16);
        java.text.ParseException parseException20 = org.apache.commons.math.MathRuntimeException.createParseException(0, "org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)", objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray25 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException26 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray25);
        java.util.ConcurrentModificationException concurrentModificationException27 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException20, "", objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray36);
        double[] doubleArray39 = new double[] { (short) 1 };
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException(throwable41, (double) ' ', "", objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, "", objArray49);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable55 = null;
        java.lang.Object[] objArray63 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException64 = new org.apache.commons.math.FunctionEvaluationException(throwable55, (double) ' ', "", objArray63);
        java.text.ParseException parseException65 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray63);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException66 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException37, doubleArray39, (org.apache.commons.math.exception.util.Localizable) localizedFormats52, objArray63);
        org.apache.commons.math.MathRuntimeException mathRuntimeException67 = new org.apache.commons.math.MathRuntimeException(localizable32, objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException(10, (org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray63);
        java.lang.Object[] objArray69 = maxIterationsExceededException68.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException20, "org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray69);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(parseException20);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(concurrentModificationException27);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats52.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(parseException65);
        org.junit.Assert.assertNotNull(objArray69);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT(4.4626898195446465d);
//        try {
//            int int6 = randomDataImpl1.nextZipf((int) (short) 10, 0.0d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1871303566073577d + "'", double3 == 1.1871303566073577d);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.lang.Object[] objArray1 = null;
        java.util.ConcurrentModificationException concurrentModificationException2 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("hi!", objArray1);
        org.junit.Assert.assertNotNull(concurrentModificationException2);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        long long8 = randomDataImpl1.nextSecureLong(0L, (long) 100);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 98L + "'", long3 == 98L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.8696595500205586d + "'", double5 == 0.8696595500205586d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        randomDataImpl1.reSeedSecure((long) 'a');
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 90 + "'", int4 == 90);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.43443402669501685d + "'", double7 == 0.43443402669501685d);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(2.302585092994046d, (double) 0);
        double double3 = poissonDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.302585092994046d + "'", double3 == 2.302585092994046d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.026456734019081d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8267797762229165d + "'", double1 == 1.8267797762229165d);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        randomDataImpl1.reSeed((long) 32);
//        double double9 = randomDataImpl1.nextBeta(3.5601874895062087E-41d, (double) 100L);
//        double double12 = randomDataImpl1.nextGamma((double) 1, 1.8115262724608532d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 114.33935795337915d + "'", double4 == 114.33935795337915d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.561941414461641E-10d + "'", double9 == 8.561941414461641E-10d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.9863129095127194d + "'", double12 == 1.9863129095127194d);
//    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 98L, 4.9417037382460585d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.919095770830797E9d + "'", double2 == 6.919095770830797E9d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) -1, 4.641588833612779d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextBeta(1.0E-9d, 2.718281828459045d);
//        long long12 = randomDataImpl1.nextPoisson((double) 100L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 82 + "'", int4 == 82);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.35006978688184565d + "'", double7 == 0.35006978688184565d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 83L + "'", long12 == 83L);
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double1 = org.apache.commons.math.util.FastMath.atan((-8.390631979415364d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4521753121103431d) + "'", double1 == (-1.4521753121103431d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator((long) 100);
        int[] intArray7 = poissonDistributionImpl3.sample(10);
        double double8 = poissonDistributionImpl3.getMean();
        double double10 = poissonDistributionImpl3.normalApproximateProbability(34);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.IllegalArgumentException illegalArgumentException7 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
        org.apache.commons.math.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(illegalArgumentException7);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) 10.0f);
        try {
            double double5 = poissonDistributionImpl2.cumulativeProbability((double) 97, (double) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        java.lang.Object[] objArray3 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException("", objArray3);
        double[] doubleArray6 = new double[] { (short) 1 };
        java.lang.Throwable throwable8 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(throwable8, (double) ' ', "", objArray16);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, "", objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable22 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException31 = new org.apache.commons.math.FunctionEvaluationException(throwable22, (double) ' ', "", objArray30);
        java.text.ParseException parseException32 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException4, doubleArray6, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray30);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.MathRuntimeException("", objArray40);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray6, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, objArray40);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException43);
        java.io.IOException iOException45 = org.apache.commons.math.MathRuntimeException.createIOException((java.lang.Throwable) functionEvaluationException43);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(parseException32);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(iOException45);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double3 = normalDistributionImpl0.cumulativeProbability(1.3830047278040059d);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability(Double.POSITIVE_INFINITY);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.ConvergenceException; message: Continued fraction diverged to NaN for value ∞");
        } catch (org.apache.commons.math.ConvergenceException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9166682918784135d + "'", double3 == 0.9166682918784135d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, 'a', true, (short) 1, localizedFormats6, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray8);
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException11 = new org.apache.commons.math.FunctionEvaluationException(0.9880780077038624d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double5 = randomDataImpl1.nextUniform(1.8267797762229165d, 125.99206299209445d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 87.02025688510561d + "'", double5 == 87.02025688510561d);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "bandwidth must be in the interval [0,1], but got {0}" + "'", str1.equals("bandwidth must be in the interval [0,1], but got {0}"));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator((long) 100);
        try {
            double double7 = poissonDistributionImpl3.cumulativeProbability(110.29757148748227d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (-1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test452");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "bandwidth must be in the interval [0,1], but got {0}");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: bandwidth must be in the interval [0,1], but got {0}");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 111L + "'", long3 == 111L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08647916849314084d + "'", double5 == 0.08647916849314084d);
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator((long) 100);
        int[] intArray7 = poissonDistributionImpl3.sample(10);
        double double8 = poissonDistributionImpl3.getMean();
        double double9 = poissonDistributionImpl3.getMean();
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "invalid iteration limits: min={0}, max={1}" + "'", str1.equals("invalid iteration limits: min={0}, max={1}"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.cos((-8.390631979415364d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5112600848828895d) + "'", double1 == (-0.5112600848828895d));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        double double6 = normalDistributionImpl0.density((java.lang.Double) 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.3989422804014327d + "'", double6 == 0.3989422804014327d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure();
        try {
            double double5 = randomDataImpl1.nextCauchy(0.9880780077038624d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(2.302585092994046d, (double) 0);
//        int int3 = poissonDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
//    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException5 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.Localizable localizable6 = functionEvaluationException5.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException5, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats8, objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable3, objArray17);
        java.text.ParseException parseException21 = org.apache.commons.math.MathRuntimeException.createParseException(0, "org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray26 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException27 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray26);
        java.util.ConcurrentModificationException concurrentModificationException28 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray26);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) parseException21, "", objArray26);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException30 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException("", objArray26);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) arrayIndexOutOfBoundsException30, (double) (-1));
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) arrayIndexOutOfBoundsException30, localizable33, objArray34);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(parseException21);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(concurrentModificationException28);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException30);
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        randomDataImpl1.reSeed((long) ' ');
//        int int10 = randomDataImpl1.nextInt(0, 34);
//        double double13 = randomDataImpl1.nextBeta((double) 87, 1.8267797762229168d);
//        double double16 = randomDataImpl1.nextBeta(4.836218912841156d, 0.5489699635783718d);
//        double double18 = randomDataImpl1.nextT(0.5489699635783718d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 116L + "'", long3 == 116L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.785496437113239E-4d + "'", double5 == 5.785496437113239E-4d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9880780077038624d + "'", double13 == 0.9880780077038624d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.9966772353889407d + "'", double16 == 0.9966772353889407d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.3146833758098274d + "'", double18 == 0.3146833758098274d);
//    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        double[] doubleArray39 = functionEvaluationException2.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        java.lang.Object[] objArray44 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        double[] doubleArray47 = new double[] { (short) 1 };
        java.lang.Throwable throwable49 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(throwable49, (double) ' ', "", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, "", objArray57);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable63 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException(throwable63, (double) ' ', "", objArray71);
        java.text.ParseException parseException73 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException45, doubleArray47, (org.apache.commons.math.exception.util.Localizable) localizedFormats60, objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats76 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        java.lang.Throwable throwable78 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException87 = new org.apache.commons.math.FunctionEvaluationException(throwable78, (double) ' ', "", objArray86);
        java.lang.Object[] objArray88 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray86);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException("", objArray88);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException((java.lang.Throwable) functionEvaluationException75, (org.apache.commons.math.exception.util.Localizable) localizedFormats76, objArray88);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException91 = new org.apache.commons.math.FunctionEvaluationException(doubleArray39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray88);
        java.lang.NullPointerException nullPointerException92 = org.apache.commons.math.MathRuntimeException.createNullPointerException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray88);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH_OUT_OF_INTERVAL));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(parseException73);
        org.junit.Assert.assertTrue("'" + localizedFormats76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats76.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(objArray88);
        org.junit.Assert.assertNotNull(nullPointerException92);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl1 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 100);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        double double5 = poissonDistributionImpl3.probability(80);
        double double7 = poissonDistributionImpl3.probability((int) '#');
        double double8 = poissonDistributionImpl3.getMean();
        int[] intArray10 = poissonDistributionImpl3.sample(0);
        double double12 = poissonDistributionImpl3.normalApproximateProbability(0);
        double double14 = poissonDistributionImpl3.probability(80);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.1401737047361744E-120d + "'", double5 == 5.1401737047361744E-120d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.5601874895062087E-41d + "'", double7 == 3.5601874895062087E-41d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.308537538725987d + "'", double12 == 0.308537538725987d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 5.1401737047361744E-120d + "'", double14 == 5.1401737047361744E-120d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(2.302585092994046d, (double) 0);
        double double5 = poissonDistributionImpl2.cumulativeProbability(0.308537538725987d, 1.1005587164121773d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.23025850929940445d + "'", double5 == 0.23025850929940445d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(4.605170185988092d, 10);
        double double4 = poissonDistributionImpl2.probability((int) (byte) 0);
        double double6 = poissonDistributionImpl2.probability(2.302585092994046d);
        poissonDistributionImpl2.reseedRandomGenerator(103L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.009999999999999995d + "'", double4 == 0.009999999999999995d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7182818284590455d + "'", double1 == 2.7182818284590455d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) 101L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 101.0f + "'", float2 == 101.0f);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.43031226025118197d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9088355331805057d + "'", double1 == 0.9088355331805057d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.Localizable localizable3 = functionEvaluationException2.getLocalizablePattern();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Throwable throwable6 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException15 = new org.apache.commons.math.FunctionEvaluationException(throwable6, (double) ' ', "", objArray14);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, 4.605170185988092d, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable0, objArray14);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException("", objArray22);
        double[] doubleArray25 = new double[] { (short) 1 };
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) ' ', "", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray25, "", objArray35);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable41 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException50 = new org.apache.commons.math.FunctionEvaluationException(throwable41, (double) ' ', "", objArray49);
        java.text.ParseException parseException51 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray49);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException52 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException23, doubleArray25, (org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray49);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException17, "bandwidth must be in the interval [0,1], but got {0}", objArray49);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(parseException51);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double6 = randomDataImpl1.nextT(0.32673690788361603d);
//        double double9 = randomDataImpl1.nextBeta(0.21714724095162588d, 4.9E-324d);
//        double double11 = randomDataImpl1.nextExponential(3.885883777914569d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 43 + "'", int4 == 43);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.29866560743336373d + "'", double6 == 0.29866560743336373d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.5489699634323477d + "'", double9 == 0.5489699634323477d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 5.087266790017875d + "'", double11 == 5.087266790017875d);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(38);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        java.lang.Throwable throwable0 = null;
        try {
            java.io.IOException iOException1 = org.apache.commons.math.MathRuntimeException.createIOException(throwable0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray3 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable5 = mathRuntimeException4.getLocalizablePattern();
        org.apache.commons.math.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) mathRuntimeException4);
        java.lang.Object[] objArray7 = mathRuntimeException6.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test480() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test480");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(110.29757148748227d, 0.3373155475049838d, (double) 89L);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 110.04754437272602d + "'", double4 == 110.04754437272602d);
//    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test482");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 83.69268663091121d + "'", double4 == 83.69268663091121d);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("", objArray4);
        java.lang.IllegalArgumentException illegalArgumentException6 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        java.lang.String str7 = illegalArgumentException6.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(illegalArgumentException6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MathRuntimeException$4: a ax10 matrix cannot be a rotation matrix" + "'", str7.equals("org.apache.commons.math.MathRuntimeException$4: a ax10 matrix cannot be a rotation matrix"));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.4521753121103431d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 92, (long) 96);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.5489699641878028d, (java.lang.Number) 0.3373155475049838d, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.3373155475049838d + "'", number6.equals(0.3373155475049838d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int2 = org.apache.commons.math.util.FastMath.min(52, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray7 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        double[] doubleArray10 = new double[] { (short) 1 };
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable12, (double) ' ', "", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, "", objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable26 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(throwable26, (double) ' ', "", objArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException8, doubleArray10, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException3, doubleArray10);
        double[] doubleArray40 = functionEvaluationException3.getArgument();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray50 = new java.lang.Object[] { localizedFormats44, 'a', true, (short) 1, localizedFormats48, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray50);
        java.lang.IllegalArgumentException illegalArgumentException52 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(throwable1, doubleArray40, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray50);
        java.util.ConcurrentModificationException concurrentModificationException54 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray50);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(illegalArgumentException52);
        org.junit.Assert.assertNotNull(concurrentModificationException54);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IDENTICAL_ABSCISSAS_DIVISION_BY_ZERO));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SAMPLES));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 101L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 34, (float) 10000000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 34.0f + "'", float2 == 34.0f);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.605170185988092d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000004d + "'", double1 == 100.00000000000004d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.292486337515024E-9d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_BOTTH_ZERO_FOR_ENTRY));
    }
}

