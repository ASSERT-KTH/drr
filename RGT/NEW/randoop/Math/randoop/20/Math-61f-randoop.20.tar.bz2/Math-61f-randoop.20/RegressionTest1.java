import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(91.48470308883076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.505913264717999d + "'", double1 == 4.505913264717999d);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test02");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long3 = randomDataImpl1.nextPoisson((double) 100.0f);
//        double double5 = randomDataImpl1.nextChiSquare((double) 1L);
//        randomDataImpl1.reSeed((long) ' ');
//        int int10 = randomDataImpl1.nextInt(0, 34);
//        double double13 = randomDataImpl1.nextBeta((double) 87, 1.8267797762229168d);
//        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl16 = new org.apache.commons.math.distribution.PoissonDistributionImpl(4.605170185988092d, 10);
//        double double18 = poissonDistributionImpl16.probability((int) (byte) 0);
//        try {
//            int int19 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.IntegerDistribution) poissonDistributionImpl16);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.FunctionEvaluationException; message: maximal number of iterations (10) exceeded");
//        } catch (org.apache.commons.math.FunctionEvaluationException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 95L + "'", long3 == 95L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.5976623028941181d + "'", double5 == 1.5976623028941181d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 25 + "'", int10 == 25);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.9880780077038624d + "'", double13 == 0.9880780077038624d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.009999999999999995d + "'", double18 == 0.009999999999999995d);
//    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        double double1 = org.apache.commons.math.util.FastMath.exp(125.99206299209445d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.2198463699426665E54d + "'", double1 == 5.2198463699426665E54d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.4145261442845148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1433742847738315d + "'", double1 == 1.1433742847738315d);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test06");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextBeta(1.0E-9d, 2.718281828459045d);
//        double double13 = randomDataImpl1.nextGamma(0.39683395630511054d, (double) 2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 96 + "'", int4 == 96);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.34564640171826505d + "'", double7 == 0.34564640171826505d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 5.01663604451618E-10d + "'", double10 == 5.01663604451618E-10d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 3.3608794521526724d + "'", double13 == 3.3608794521526724d);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        float float1 = org.apache.commons.math.util.FastMath.abs(101.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 101.0f + "'", float1 == 101.0f);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        double[] doubleArray8 = new double[] { (short) 1 };
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) ' ', "", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable24, (double) ' ', "", objArray32);
        java.text.ParseException parseException34 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray8);
        java.lang.Throwable throwable39 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException48 = new org.apache.commons.math.FunctionEvaluationException(throwable39, (double) ' ', "", objArray47);
        java.lang.Object[] objArray49 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray47);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException1, "no optimum computed yet", objArray49);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(parseException34);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(objArray49);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        double double8 = randomDataImpl1.nextUniform(4.9E-324d, (double) 52L);
//        try {
//            long long11 = randomDataImpl1.nextLong(10000000L, (long) 47);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10,000,000 is larger than, or equal to, the maximum (47): lower bound (10,000,000) must be strictly less than upper bound (47)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 34 + "'", int5 == 34);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 45.30282743132553d + "'", double8 == 45.30282743132553d);
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_LENGTH));
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.99627207622075d + "'", double1 == 0.99627207622075d);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl3 = new org.apache.commons.math.distribution.PoissonDistributionImpl((double) (short) 1, (double) (short) 1, (int) (short) -1);
        poissonDistributionImpl3.reseedRandomGenerator(0L);
        double double7 = poissonDistributionImpl3.normalApproximateProbability((int) (short) 0);
        double double9 = poissonDistributionImpl3.probability(10.0d);
        try {
            double double12 = poissonDistributionImpl3.cumulativeProbability((double) 100L, 1.0070796772362076d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.308537538725987d + "'", double7 == 0.308537538725987d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0137771196302933E-7d + "'", double9 == 1.0137771196302933E-7d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 83L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        double[] doubleArray11 = new double[] { (short) 1 };
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) ' ', "", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) ' ', "", objArray35);
        java.text.ParseException parseException37 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, doubleArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray35);
        org.apache.commons.math.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.MathRuntimeException(localizable4, objArray35);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(10, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray35);
        java.io.EOFException eOFException41 = org.apache.commons.math.MathRuntimeException.createEOFException("64081c3d512d1d30db234ec5122f9be561", objArray35);
        java.util.NoSuchElementException noSuchElementException42 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathRuntimeException$4: a ax10 matrix cannot be a rotation matrix", objArray35);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.AT_LEAST_ONE_ROW));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(parseException37);
        org.junit.Assert.assertNotNull(eOFException41);
        org.junit.Assert.assertNotNull(noSuchElementException42);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.1315354668067224d, 0.0d);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.7182818284590455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6487212707001282d + "'", double1 == 1.6487212707001282d);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 34.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.35006978688184565d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        double[] doubleArray8 = new double[] { (short) 1 };
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) ' ', "", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable24, (double) ' ', "", objArray32);
        java.text.ParseException parseException34 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray8);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray44 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("", objArray44);
        double[] doubleArray47 = new double[] { (short) 1 };
        java.lang.Throwable throwable49 = null;
        java.lang.Object[] objArray57 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(throwable49, (double) ' ', "", objArray57);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47, "", objArray57);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable63 = null;
        java.lang.Object[] objArray71 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException(throwable63, (double) ' ', "", objArray71);
        java.text.ParseException parseException73 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException45, doubleArray47, (org.apache.commons.math.exception.util.Localizable) localizedFormats60, objArray71);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException75 = new org.apache.commons.math.FunctionEvaluationException(doubleArray47);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException40, doubleArray47);
        convergenceException38.addSuppressed((java.lang.Throwable) functionEvaluationException40);
        functionEvaluationException37.addSuppressed((java.lang.Throwable) convergenceException38);
        java.lang.String str79 = functionEvaluationException37.getPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(parseException34);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertNotNull(parseException73);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{0}" + "'", str79.equals("{0}"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator((long) 35);
        double double4 = normalDistributionImpl0.density((java.lang.Double) 0.10294463232638718d);
        double double6 = normalDistributionImpl0.cumulativeProbability(0.43031226025118197d);
        double double7 = normalDistributionImpl0.getStandardDeviation();
        double double9 = normalDistributionImpl0.inverseCumulativeProbability(0.4145261442845148d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.39683395630511054d + "'", double4 == 0.39683395630511054d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6665157450783973d + "'", double6 == 0.6665157450783973d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.21591720139972495d) + "'", double9 == (-0.21591720139972495d));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
    }

//    @Test
//    public void test24() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test24");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextBeta(1.0E-9d, 2.718281828459045d);
//        double double13 = randomDataImpl1.nextF(0.5585053606381855d, 9.719261706085652d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 86 + "'", int4 == 86);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.4300521121849293d + "'", double7 == 0.4300521121849293d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.09517383631521263d + "'", double13 == 0.09517383631521263d);
//    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 101L, (java.lang.Number) 43, false);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.6774505542241952d), number6, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.34564640171826505d, (double) '#');
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.34564640171826505d + "'", double3 == 0.34564640171826505d);
    }

//    @Test
//    public void test27() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test27");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        java.lang.String str9 = randomDataImpl1.nextHexString(34);
//        try {
//            long long12 = randomDataImpl1.nextLong((long) (short) 1, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 85 + "'", int4 == 85);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.36924985020674234d + "'", double7 == 0.36924985020674234d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8175494ed10107070d1b06799e0e4f144b" + "'", str9.equals("8175494ed10107070d1b06799e0e4f144b"));
//    }

//    @Test
//    public void test28() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test28");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        int int7 = randomDataImpl1.nextInt((int) (short) -1, (int) '4');
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 110.00178407039651d + "'", double4 == 110.00178407039651d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 20 + "'", int7 == 20);
//    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.3146833758098274d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3199027713623606d + "'", double1 == 0.3199027713623606d);
    }

//    @Test
//    public void test31() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test31");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextUniform(1.0E-9d, (double) 48);
//        double double12 = randomDataImpl1.nextT((double) '#');
//        java.lang.String str14 = randomDataImpl1.nextHexString(80);
//        try {
//            long long16 = randomDataImpl1.nextPoisson((double) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3672731794243224d + "'", double7 == 0.3672731794243224d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.4437271939914d + "'", double10 == 10.4437271939914d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.370500895888279d) + "'", double12 == (-0.370500895888279d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "8a2a2d2cfe993b03b4786e76e1199f54c7b46935e69308a7c8fea290be2b1e4e803619b1eb581a41" + "'", str14.equals("8a2a2d2cfe993b03b4786e76e1199f54c7b46935e69308a7c8fea290be2b1e4e803619b1eb581a41"));
//    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(throwable0, doubleArray9, "{0}", objArray40);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test33");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double6 = randomDataImpl1.nextT(0.32673690788361603d);
//        double double9 = randomDataImpl1.nextBeta(0.21714724095162588d, 4.9E-324d);
//        randomDataImpl1.reSeed(52L);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 87 + "'", int4 == 87);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 38.95481863798524d + "'", double6 == 38.95481863798524d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.548969963869607d + "'", double9 == 0.548969963869607d);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        double double1 = org.apache.commons.math.util.FastMath.asin(2005.3522829578812d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test35");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats3, 'a', true, (short) 1, localizedFormats7, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        java.lang.IllegalArgumentException illegalArgumentException11 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 116.3165626204744d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray22 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray22);
        java.util.ConcurrentModificationException concurrentModificationException24 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException((org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { notStrictlyPositiveException16, 92, localizedFormats18, concurrentModificationException24 };
        java.util.ConcurrentModificationException concurrentModificationException26 = org.apache.commons.math.MathRuntimeException.createConcurrentModificationException("hi!", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) illegalArgumentException11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray25);
        java.lang.NullPointerException nullPointerException28 = org.apache.commons.math.MathRuntimeException.createNullPointerException("org.apache.commons.math.MathRuntimeException$4: a ax10 matrix cannot be a rotation matrix", objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(illegalArgumentException11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(concurrentModificationException24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(concurrentModificationException26);
        org.junit.Assert.assertNotNull(nullPointerException28);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5489699641878028d, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0d);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException8 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray12 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException("", objArray12);
        double[] doubleArray15 = new double[] { (short) 1 };
        java.lang.Throwable throwable17 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException26 = new org.apache.commons.math.FunctionEvaluationException(throwable17, (double) ' ', "", objArray25);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException27 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, "", objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable31 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(throwable31, (double) ' ', "", objArray39);
        java.text.ParseException parseException41 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException42 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException13, doubleArray15, (org.apache.commons.math.exception.util.Localizable) localizedFormats28, objArray39);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException43 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException44 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException8, doubleArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray55 = new java.lang.Object[] { localizedFormats49, 'a', true, (short) 1, localizedFormats53, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats48, objArray55);
        java.lang.IllegalArgumentException illegalArgumentException57 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats47, objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray15, (org.apache.commons.math.exception.util.Localizable) localizedFormats46, objArray55);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException59 = new org.apache.commons.math.FunctionEvaluationException((double) 92, "org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray55);
        java.lang.IllegalArgumentException illegalArgumentException60 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("hi!", objArray55);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray55);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(parseException41);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(illegalArgumentException57);
        org.junit.Assert.assertNotNull(illegalArgumentException60);
    }

//    @Test
//    public void test38() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test38");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        randomDataImpl1.reSeed((long) 32);
//        double double8 = randomDataImpl1.nextExponential(0.4145261442845148d);
//        randomDataImpl1.reSeedSecure(98L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 91.07278587848073d + "'", double4 == 91.07278587848073d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1315354668067224d + "'", double8 == 0.1315354668067224d);
//    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException3 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray7 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("", objArray7);
        double[] doubleArray10 = new double[] { (short) 1 };
        java.lang.Throwable throwable12 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(throwable12, (double) ' ', "", objArray20);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, "", objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable26 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(throwable26, (double) ' ', "", objArray34);
        java.text.ParseException parseException36 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException8, doubleArray10, (org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException3, doubleArray10);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray50 = new java.lang.Object[] { localizedFormats44, 'a', true, (short) 1, localizedFormats48, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray50);
        java.lang.IllegalArgumentException illegalArgumentException52 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException53 = new org.apache.commons.math.FunctionEvaluationException(doubleArray10, (org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray50);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException((double) 92, "org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray50);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray62 = new java.lang.Object[] { localizedFormats56, 'a', true, (short) 1, localizedFormats60, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray62);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        java.lang.Object[] objArray70 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException("", objArray70);
        org.apache.commons.math.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.MathRuntimeException("", objArray70);
        java.io.EOFException eOFException73 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats65, objArray70);
        java.lang.IllegalArgumentException illegalArgumentException74 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats64, objArray70);
        org.apache.commons.math.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException54, (org.apache.commons.math.exception.util.Localizable) localizedFormats55, objArray70);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(parseException36);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats48.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(illegalArgumentException52);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats60.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(eOFException73);
        org.junit.Assert.assertNotNull(illegalArgumentException74);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test41");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        double double4 = randomDataImpl1.nextChiSquare((double) 100L);
//        randomDataImpl1.reSeed((long) 32);
//        double double8 = randomDataImpl1.nextExponential(0.4145261442845148d);
//        double double10 = randomDataImpl1.nextT(116.3165626204744d);
//        double double13 = randomDataImpl1.nextGamma(7.105427357601002E-15d, (double) 83L);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 85.22779314211448d + "'", double4 == 85.22779314211448d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1315354668067224d + "'", double8 == 0.1315354668067224d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.42986961674693636d + "'", double10 == 0.42986961674693636d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.520450168700376E-10d + "'", double13 == 6.520450168700376E-10d);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        java.lang.Throwable throwable3 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException12 = new org.apache.commons.math.FunctionEvaluationException(throwable3, (double) ' ', "", objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray13);
        java.lang.IllegalArgumentException illegalArgumentException15 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray13);
        java.lang.IllegalStateException illegalStateException16 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("hi!", objArray13);
        java.lang.IllegalArgumentException illegalArgumentException17 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((java.lang.Throwable) illegalStateException16);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(illegalArgumentException15);
        org.junit.Assert.assertNotNull(illegalStateException16);
        org.junit.Assert.assertNotNull(illegalArgumentException17);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException1 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        double[] doubleArray8 = new double[] { (short) 1 };
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) ' ', "", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable24, (double) ' ', "", objArray32);
        java.text.ParseException parseException34 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException1, doubleArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable42 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException(throwable42, (double) ' ', "", objArray50);
        java.text.ParseException parseException52 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray50);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats57 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray58 = new java.lang.Object[] { ' ', localizedFormats53, localizedFormats54, localizedFormats55, 0.32673690788361603d, localizedFormats57 };
        java.lang.IllegalStateException illegalStateException59 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, objArray58);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray58);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) functionEvaluationException60);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(parseException34);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(parseException52);
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats53.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats54.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats55.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats57.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(illegalStateException59);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 63);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 63L + "'", long1 == 63L);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        double[] doubleArray5 = new double[] { (short) 1 };
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable7, (double) ' ', "", objArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException17 = new org.apache.commons.math.FunctionEvaluationException(doubleArray5, "", objArray15);
        java.lang.ArithmeticException arithmeticException18 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray15);
        java.text.ParseException parseException19 = org.apache.commons.math.MathRuntimeException.createParseException(35, "", objArray15);
        java.lang.ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException20 = org.apache.commons.math.MathRuntimeException.createArrayIndexOutOfBoundsException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(arithmeticException18);
        org.junit.Assert.assertNotNull(parseException19);
        org.junit.Assert.assertNotNull(arrayIndexOutOfBoundsException20);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        double[] doubleArray8 = new double[] { (short) 1 };
        java.lang.Throwable throwable10 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(throwable10, (double) ' ', "", objArray18);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, "", objArray18);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable24 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException33 = new org.apache.commons.math.FunctionEvaluationException(throwable24, (double) ' ', "", objArray32);
        java.text.ParseException parseException34 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException6, doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        java.lang.Object[] objArray42 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray42);
        org.apache.commons.math.MathRuntimeException mathRuntimeException44 = new org.apache.commons.math.MathRuntimeException("", objArray42);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException45 = new org.apache.commons.math.FunctionEvaluationException(doubleArray8, (org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray42);
        java.util.NoSuchElementException noSuchElementException46 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)", objArray42);
        java.util.NoSuchElementException noSuchElementException47 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("hi!", objArray42);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(parseException34);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(noSuchElementException46);
        org.junit.Assert.assertNotNull(noSuchElementException47);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10000000L, number1, false);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(0.1315354668067224d, 4.9417037382460585d);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test52");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextInt((int) '#', (int) (byte) 100);
//        double double7 = randomDataImpl1.nextBeta((double) '#', (double) '4');
//        double double10 = randomDataImpl1.nextUniform(1.0E-9d, (double) 48);
//        double double12 = randomDataImpl1.nextT((double) '#');
//        java.lang.String str14 = randomDataImpl1.nextHexString(80);
//        int[] intArray17 = randomDataImpl1.nextPermutation(100, 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 63 + "'", int4 == 63);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5069819409656626d + "'", double7 == 0.5069819409656626d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.795062956932616d + "'", double10 == 4.795062956932616d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.031469217044112215d + "'", double12 == 0.031469217044112215d);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "6d0ab4e2bb212b39a6a7e3766af31db7235a4fbf5cdb0e1229e9745501d3e94a9df70493458f72f4" + "'", str14.equals("6d0ab4e2bb212b39a6a7e3766af31db7235a4fbf5cdb0e1229e9745501d3e94a9df70493458f72f4"));
//        org.junit.Assert.assertNotNull(intArray17);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Throwable throwable5 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException14 = new org.apache.commons.math.FunctionEvaluationException(throwable5, (double) ' ', "", objArray13);
        java.lang.Object[] objArray15 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray13);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        java.lang.IllegalArgumentException illegalArgumentException17 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray15);
        java.lang.NullPointerException nullPointerException18 = org.apache.commons.math.MathRuntimeException.createNullPointerException("64081c3d512d1d30db234ec5122f9be561", objArray15);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(0.47948615734257893d, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(illegalArgumentException17);
        org.junit.Assert.assertNotNull(nullPointerException18);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.5601874895062087E-41d, (double) '4');
        double double4 = normalDistributionImpl2.density((double) 10);
        normalDistributionImpl2.setMean(0.1315354668067224d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.007531407195733809d + "'", double4 == 0.007531407195733809d);
    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test55");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        double double8 = randomDataImpl1.nextUniform(4.9E-324d, (double) 52L);
//        double double11 = randomDataImpl1.nextUniform(0.6665157450783973d, 1.8115262724608532d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 34 + "'", int5 == 34);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 18.64825265230116d + "'", double8 == 18.64825265230116d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9615646755386573d + "'", double11 == 0.9615646755386573d);
//    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException2 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
        double[] doubleArray9 = new double[] { (short) 1 };
        java.lang.Throwable throwable11 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException20 = new org.apache.commons.math.FunctionEvaluationException(throwable11, (double) ' ', "", objArray19);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException21 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9, "", objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable25 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException(throwable25, (double) ' ', "", objArray33);
        java.text.ParseException parseException35 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException7, doubleArray9, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray33);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException37 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException2, doubleArray9);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray9);
        java.lang.Object[] objArray43 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException("", objArray43);
        double[] doubleArray46 = new double[] { (short) 1 };
        java.lang.Throwable throwable48 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException57 = new org.apache.commons.math.FunctionEvaluationException(throwable48, (double) ' ', "", objArray56);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException58 = new org.apache.commons.math.FunctionEvaluationException(doubleArray46, "", objArray56);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable62 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException71 = new org.apache.commons.math.FunctionEvaluationException(throwable62, (double) ' ', "", objArray70);
        java.text.ParseException parseException72 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException73 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException44, doubleArray46, (org.apache.commons.math.exception.util.Localizable) localizedFormats59, objArray70);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException(doubleArray46);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        java.lang.Number number76 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats75, number76, (java.lang.Number) 110.29757148748227d, true);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats80 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats81 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray83 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException84 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats81, objArray83);
        java.lang.IllegalStateException illegalStateException85 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats80, objArray83);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException86 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException39, doubleArray46, (org.apache.commons.math.exception.util.Localizable) localizedFormats75, objArray83);
        java.lang.IllegalStateException illegalStateException87 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray83);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(parseException35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(parseException72);
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats75.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats80.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray83);
        org.junit.Assert.assertNotNull(illegalStateException85);
        org.junit.Assert.assertNotNull(illegalStateException87);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.258096538021482d);
    }

//    @Test
//    public void test58() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test58");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
//        java.lang.Throwable throwable9 = null;
//        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
//        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
//        java.text.ParseException parseException19 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray17);
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
//        java.lang.Object[] objArray25 = new java.lang.Object[] { ' ', localizedFormats20, localizedFormats21, localizedFormats22, 0.32673690788361603d, localizedFormats24 };
//        java.lang.IllegalStateException illegalStateException26 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray25);
//        java.lang.IllegalStateException illegalStateException27 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray25);
//        java.io.EOFException eOFException28 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray25);
//        java.lang.IllegalArgumentException illegalArgumentException29 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)", objArray25);
//        java.lang.NullPointerException nullPointerException30 = org.apache.commons.math.MathRuntimeException.createNullPointerException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray25);
//        java.lang.IllegalStateException illegalStateException31 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray25);
//        try {
//            java.lang.IllegalStateException illegalStateException32 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable0, objArray25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
//        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(parseException19);
//        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
//        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
//        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
//        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(illegalStateException26);
//        org.junit.Assert.assertNotNull(illegalStateException27);
//        org.junit.Assert.assertNotNull(eOFException28);
//        org.junit.Assert.assertNotNull(illegalArgumentException29);
//        org.junit.Assert.assertNotNull(nullPointerException30);
//        org.junit.Assert.assertNotNull(illegalStateException31);
//    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException9 = new org.apache.commons.math.FunctionEvaluationException(throwable0, (double) ' ', "", objArray8);
        java.lang.String str10 = functionEvaluationException9.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Object[] objArray15 = new java.lang.Object[] { 52 };
        org.apache.commons.math.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.MathRuntimeException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray15);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray15);
        org.apache.commons.math.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.MathRuntimeException((java.lang.Throwable) functionEvaluationException9, localizable11, objArray15);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.32673690788361603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException4 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        java.lang.Object[] objArray8 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        double[] doubleArray11 = new double[] { (short) 1 };
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) ' ', "", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) ' ', "", objArray35);
        java.text.ParseException parseException37 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, doubleArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException40 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) functionEvaluationException4, doubleArray11);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException41 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray51 = new java.lang.Object[] { localizedFormats45, 'a', true, (short) 1, localizedFormats49, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats44, objArray51);
        java.lang.IllegalArgumentException illegalArgumentException53 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats43, objArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats42, objArray51);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((double) 92, "org.apache.commons.math.MathRuntimeException$10: input data array length = a does not match the number of observations = 10 and the number of regressors = {2}", objArray51);
        java.lang.ArithmeticException arithmeticException56 = org.apache.commons.math.MathRuntimeException.createArithmeticException("org.apache.commons.math.MathRuntimeException$4: a ax10 matrix cannot be a rotation matrix", objArray51);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(parseException37);
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats44.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats45.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats49.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(illegalArgumentException53);
        org.junit.Assert.assertNotNull(arithmeticException56);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats3, 'a', true, (short) 1, localizedFormats7, 0.0f };
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray9);
        java.lang.UnsupportedOperationException unsupportedOperationException12 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(unsupportedOperationException12);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        java.lang.Object[] objArray4 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException("", objArray4);
        double[] doubleArray7 = new double[] { (short) 1 };
        java.lang.Throwable throwable9 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException18 = new org.apache.commons.math.FunctionEvaluationException(throwable9, (double) ' ', "", objArray17);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException19 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "", objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable23 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException32 = new org.apache.commons.math.FunctionEvaluationException(throwable23, (double) ' ', "", objArray31);
        java.text.ParseException parseException33 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray31);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException34 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException5, doubleArray7, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray40);
        double[] doubleArray43 = new double[] { (short) 1 };
        java.lang.Throwable throwable45 = null;
        java.lang.Object[] objArray53 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException54 = new org.apache.commons.math.FunctionEvaluationException(throwable45, (double) ' ', "", objArray53);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException(doubleArray43, "", objArray53);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable59 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException68 = new org.apache.commons.math.FunctionEvaluationException(throwable59, (double) ' ', "", objArray67);
        java.text.ParseException parseException69 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException70 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException41, doubleArray43, (org.apache.commons.math.exception.util.Localizable) localizedFormats56, objArray67);
        org.apache.commons.math.MathRuntimeException mathRuntimeException71 = new org.apache.commons.math.MathRuntimeException(localizable36, objArray67);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException72 = new org.apache.commons.math.FunctionEvaluationException(doubleArray7, "", objArray67);
        java.lang.ArithmeticException arithmeticException73 = org.apache.commons.math.MathRuntimeException.createArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray67);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(parseException33);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(parseException69);
        org.junit.Assert.assertNotNull(arithmeticException73);
    }

//    @Test
//    public void test65() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test65");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
//        java.lang.Object[] objArray6 = new java.lang.Object[] { 'a', (short) 10 };
//        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException("", objArray6);
//        java.lang.IllegalArgumentException illegalArgumentException8 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
//        org.apache.commons.math.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.MathRuntimeException("hi!", objArray6);
//        try {
//            java.lang.IllegalStateException illegalStateException10 = org.apache.commons.math.MathRuntimeException.createIllegalStateException(localizable0, objArray6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertNotNull(illegalArgumentException8);
//    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.007531407195733809d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43151784611000593d + "'", double1 == 0.43151784611000593d);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test67");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        java.lang.Object[] objArray8 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("", objArray8);
        double[] doubleArray11 = new double[] { (short) 1 };
        java.lang.Throwable throwable13 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException22 = new org.apache.commons.math.FunctionEvaluationException(throwable13, (double) ' ', "", objArray21);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException23 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable27 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(throwable27, (double) ' ', "", objArray35);
        java.text.ParseException parseException37 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException38 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException9, doubleArray11, (org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray35);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException39 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        java.lang.Object[] objArray46 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException("", objArray46);
        double[] doubleArray49 = new double[] { (short) 1 };
        java.lang.Throwable throwable51 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException60 = new org.apache.commons.math.FunctionEvaluationException(throwable51, (double) ' ', "", objArray59);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException61 = new org.apache.commons.math.FunctionEvaluationException(doubleArray49, "", objArray59);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats62 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable65 = null;
        java.lang.Object[] objArray73 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException74 = new org.apache.commons.math.FunctionEvaluationException(throwable65, (double) ' ', "", objArray73);
        java.text.ParseException parseException75 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray73);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException76 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException47, doubleArray49, (org.apache.commons.math.exception.util.Localizable) localizedFormats62, objArray73);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException78 = new org.apache.commons.math.FunctionEvaluationException((double) 100);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats80 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray81 = new java.lang.Object[] { localizedFormats41, localizedFormats42, functionEvaluationException76, 100, 0L, localizedFormats80 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException82 = new org.apache.commons.math.FunctionEvaluationException(doubleArray11, "", objArray81);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException83 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException2, (double) (byte) 100, "", objArray81);
        java.util.NoSuchElementException noSuchElementException84 = org.apache.commons.math.MathRuntimeException.createNoSuchElementException("org.apache.commons.math.MathException: lower bound (0) must be strictly less than upper bound (false)", objArray81);
        java.io.EOFException eOFException85 = org.apache.commons.math.MathRuntimeException.createEOFException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray81);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(parseException37);
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + localizedFormats62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats62.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(parseException75);
        org.junit.Assert.assertTrue("'" + localizedFormats80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats80.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(noSuchElementException84);
        org.junit.Assert.assertNotNull(eOFException85);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test68");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.3989422804014327d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49024759963171943d + "'", double1 == 0.49024759963171943d);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test69");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 87.02025688510561d);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test70");
        org.apache.commons.math.distribution.PoissonDistributionImpl poissonDistributionImpl2 = new org.apache.commons.math.distribution.PoissonDistributionImpl(2.302585092994046d, (double) 0);
        double double5 = poissonDistributionImpl2.cumulativeProbability((int) '4', 90);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test71");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str4 = randomDataImpl1.nextSecureHexString(97);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "637e3ea1638ae49f6df4c71b4304e20345d6c73b8fa1c83ac7a0c293dcacfef611c23f6c095a80a85a093aceb7c10c740" + "'", str4.equals("637e3ea1638ae49f6df4c71b4304e20345d6c73b8fa1c83ac7a0c293dcacfef611c23f6c095a80a85a093aceb7c10c740"));
//    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test72");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double2 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test73");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        java.lang.Throwable throwable7 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException16 = new org.apache.commons.math.FunctionEvaluationException(throwable7, (double) ' ', "", objArray15);
        java.text.ParseException parseException17 = org.apache.commons.math.MathRuntimeException.createParseException((int) ' ', "", objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        java.lang.Object[] objArray23 = new java.lang.Object[] { ' ', localizedFormats18, localizedFormats19, localizedFormats20, 0.32673690788361603d, localizedFormats22 };
        java.lang.IllegalStateException illegalStateException24 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray23);
        java.lang.IllegalStateException illegalStateException25 = org.apache.commons.math.MathRuntimeException.createIllegalStateException("", objArray23);
        java.io.EOFException eOFException26 = org.apache.commons.math.MathRuntimeException.createEOFException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray23);
        java.lang.Object[] objArray27 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(20, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(parseException17);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(illegalStateException24);
        org.junit.Assert.assertNotNull(illegalStateException25);
        org.junit.Assert.assertNotNull(eOFException26);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test74");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        normalDistributionImpl0.setMean(1.8267797762229168d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test75");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(101L);
        double double4 = normalDistributionImpl0.cumulativeProbability(0.0d);
        normalDistributionImpl0.setStandardDeviation(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5d + "'", double4 == 0.5d);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test76");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.16372121576841134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16372121576841137d + "'", double1 == 0.16372121576841137d);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test77");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5434354838975394d + "'", double1 == 0.5434354838975394d);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test78");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getStandardDeviation();
        double double3 = normalDistributionImpl0.cumulativeProbability(1.3830047278040059d);
        double double4 = normalDistributionImpl0.getMean();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.9166682918784135d + "'", double3 == 0.9166682918784135d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test79");
        double double2 = org.apache.commons.math.util.FastMath.pow(83.69268663091121d, 0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 78.88175195574571d + "'", double2 == 78.88175195574571d);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test80");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        java.lang.Object[] objArray5 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        java.lang.IllegalStateException illegalStateException7 = org.apache.commons.math.MathRuntimeException.createIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray5);
        java.lang.ArithmeticException arithmeticException8 = org.apache.commons.math.MathRuntimeException.createArithmeticException("64081c3d512d1d30db234ec5122f9be561", objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(illegalStateException7);
        org.junit.Assert.assertNotNull(arithmeticException8);
    }

//    @Test
//    public void test81() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test81");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeedSecure();
//        int int5 = randomDataImpl1.nextSecureInt((int) ' ', (int) '#');
//        double double8 = randomDataImpl1.nextCauchy((double) 80, (double) 98L);
//        double double10 = randomDataImpl1.nextT(0.5489699634323477d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 12.214920945604874d + "'", double8 == 12.214920945604874d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.459873605851924d + "'", double10 == 4.459873605851924d);
//    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test82");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException2 = new org.apache.commons.math.MathRuntimeException("org.apache.commons.math.MathRuntimeException$4: a ax10 matrix cannot be a rotation matrix", objArray1);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test83");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Throwable throwable1 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException10 = new org.apache.commons.math.FunctionEvaluationException(throwable1, (double) ' ', "", objArray9);
        java.lang.UnsupportedOperationException unsupportedOperationException11 = org.apache.commons.math.MathRuntimeException.createUnsupportedOperationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray9);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.MathRuntimeException("", objArray14);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        java.lang.Object[] objArray21 = new java.lang.Object[] { 'a', (short) 10 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException("", objArray21);
        double[] doubleArray24 = new double[] { (short) 1 };
        java.lang.Throwable throwable26 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException35 = new org.apache.commons.math.FunctionEvaluationException(throwable26, (double) ' ', "", objArray34);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException36 = new org.apache.commons.math.FunctionEvaluationException(doubleArray24, "", objArray34);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE;
        java.lang.Throwable throwable40 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException49 = new org.apache.commons.math.FunctionEvaluationException(throwable40, (double) ' ', "", objArray48);
        java.text.ParseException parseException50 = org.apache.commons.math.MathRuntimeException.createParseException((int) 'a', "", objArray48);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException51 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) convergenceException22, doubleArray24, (org.apache.commons.math.exception.util.Localizable) localizedFormats37, objArray48);
        java.lang.IllegalArgumentException illegalArgumentException52 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray48);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathRuntimeException15, (org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray48);
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException55 = new org.apache.commons.math.FunctionEvaluationException((java.lang.Throwable) mathException53, 141.41030934205642d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        java.lang.Throwable throwable58 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] { (short) 0, false, 1, (short) 10, (short) 10 };
        org.apache.commons.math.FunctionEvaluationException functionEvaluationException67 = new org.apache.commons.math.FunctionEvaluationException(throwable58, (double) ' ', "", objArray66);
        java.lang.Object[] objArray68 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("", objArray68);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53, (org.apache.commons.math.exception.util.Localizable) localizedFormats56, objArray68);
        java.lang.IllegalArgumentException illegalArgumentException71 = org.apache.commons.math.MathRuntimeException.createIllegalArgumentException("be3357ad8f76985218d3dc999e121a2e323f1d5b97450e61bd950d78e0962fb536d6ab872ec0ee04", objArray68);
        unsupportedOperationException11.addSuppressed((java.lang.Throwable) illegalArgumentException71);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(unsupportedOperationException11);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAMPLE_SIZE_EXCEEDS_COLLECTION_SIZE));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(parseException50);
        org.junit.Assert.assertNotNull(illegalArgumentException52);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats56.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(illegalArgumentException71);
    }
}

