import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double1 = org.apache.commons.math.util.FastMath.log1p(981.5727003086395d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.890174336230983d + "'", double1 == 6.890174336230983d);
    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        long long10 = randomDataImpl0.nextSecureLong((long) 3, 11L);
//        int int13 = randomDataImpl0.nextInt(0, 52);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4L + "'", long10 == 4L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 28 + "'", int13 == 28);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.7353096508879174E-81d, (double) 10L, (double) (-1));
        normalDistributionImpl3.reseedRandomGenerator((long) 91);
        normalDistributionImpl3.reseedRandomGenerator((long) 35);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(5.566640214978967d, 0.10516633568161556d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999898796765d + "'", double2 == 0.9999999898796765d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1114875376100244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        long long2 = org.apache.commons.math.util.FastMath.min(52L, (long) 28);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 9.0d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray17);
        java.lang.Object[] objArray19 = mathIllegalArgumentException18.getArguments();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable15, objArray19);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable15, objArray26);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable33, (java.lang.Number) 5);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray40);
        java.lang.Object[] objArray42 = mathIllegalArgumentException41.getArguments();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable38, objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable15, objArray42);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, (java.lang.Number) 211.718280929568d, (java.lang.Number) 2.649558242894909d, (java.lang.Number) 77);
        java.lang.Number number51 = outOfRangeException50.getHi();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 77 + "'", number51.equals(77));
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test010");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = normalDistributionImpl7.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7994617241372165d + "'", double4 == 0.7994617241372165d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.211542432219526d + "'", double11 == 10.211542432219526d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-18.951180091987943d) + "'", double12 == (-18.951180091987943d));
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.5995081831701013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5424087716241401d) + "'", double1 == (-1.5424087716241401d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(6.890174336230983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.624914157878498d + "'", double1 == 2.624914157878498d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 91);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10598751175115685d + "'", double1 == 0.10598751175115685d);
    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test014");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double17 = normalDistributionImpl8.cumulativeProbability((-1.3170218223604584d), 2.140641475065075d);
//        double[] doubleArray19 = normalDistributionImpl8.sample(4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-29.725107973897302d) + "'", double12 == (-29.725107973897302d));
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.03794591252408147d + "'", double17 == 0.03794591252408147d);
//        org.junit.Assert.assertNotNull(doubleArray19);
//    }

//    @Test
//    public void test015() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test015");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare(5.298342365610589d);
//        java.lang.Class<?> wildcardClass14 = randomDataImpl0.getClass();
//        double double17 = randomDataImpl0.nextCauchy(22025.465794806718d, 35.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.08975154096881159d + "'", double11 == 0.08975154096881159d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 8.106684489637818d + "'", double13 == 8.106684489637818d);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 22019.308492636723d + "'", double17 == 22019.308492636723d);
//    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9981159886028054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.649474997576156d + "'", double1 == 1.649474997576156d);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        double double11 = randomDataImpl0.nextExponential(20.138852114085488d);
//        try {
//            double double14 = randomDataImpl0.nextGamma(0.0d, 9.331123969810432E-48d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.326629620632489E-16d + "'", double9 == 2.326629620632489E-16d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 23.94197375126742d + "'", double11 == 23.94197375126742d);
//    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        long long10 = randomDataImpl0.nextSecureLong((long) 3, 11L);
//        long long13 = randomDataImpl0.nextLong(4L, (long) ' ');
//        int int16 = randomDataImpl0.nextZipf(9, (double) 3);
//        double double19 = randomDataImpl0.nextBeta(0.9999999898796765d, 9.999999999999998d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 3L + "'", long10 == 3L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 30L + "'", long13 == 30L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.08162760144578235d + "'", double19 == 0.08162760144578235d);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.log(67.37427577395592d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.210263279990771d + "'", double1 == 4.210263279990771d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6173982341988522d + "'", double1 == 1.6173982341988522d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.asin(10.354879102416552d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        java.lang.Number number21 = outOfRangeException19.getLo();
        java.lang.String str22 = outOfRangeException19.toString();
        java.lang.Throwable[] throwableArray23 = outOfRangeException19.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) -1 + "'", number21.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed" + "'", str22.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed"));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable5);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        try {
//            double double7 = randomDataImpl1.nextCauchy(0.6252948841919719d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8112386621980094d + "'", double4 == 0.8112386621980094d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.5553480614894135d, 62.052186898622494d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.555348061489414d + "'", double2 == 3.555348061489414d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test026");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        try {
//            int int10 = randomDataImpl0.nextBinomial(0, 1.4653112823676238d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.465 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        double double4 = randomDataImpl0.nextChiSquare(5.0d);
//        double double7 = randomDataImpl0.nextWeibull(58.77259166757209d, 0.14739687503825846d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.003240757521403d + "'", double2 == 3.003240757521403d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.786154752642094d + "'", double4 == 9.786154752642094d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.14559973882750185d + "'", double7 == 0.14559973882750185d);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator((long) 1);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double17 = normalDistributionImpl8.cumulativeProbability((-1.3170218223604584d), 2.140641475065075d);
//        double double19 = normalDistributionImpl8.cumulativeProbability(0.0d);
//        try {
//            double[] doubleArray21 = normalDistributionImpl8.sample((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-23.891766272835984d) + "'", double12 == (-23.891766272835984d));
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.03794591252408147d + "'", double17 == 0.03794591252408147d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.38754848109799234d + "'", double19 == 0.38754848109799234d);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.41032129904824216d), 2.7353096508879174E-81d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.log(10.21763731027119d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3241153751006367d + "'", double1 == 2.3241153751006367d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.140641475065075d, 9.786154752642094d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1406414750650753d + "'", double2 == 2.1406414750650753d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7165313105737893d + "'", double1 == 0.7165313105737893d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.8414709848078965d, (-0.9999999999999999d), 22.396067961896854d, 4);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare(5.298342365610589d);
//        java.lang.Class<?> wildcardClass14 = randomDataImpl0.getClass();
//        double double17 = randomDataImpl0.nextBeta((double) 97, (double) 97L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.1220513355946986d + "'", double11 == 0.1220513355946986d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.302600404579019d + "'", double13 == 7.302600404579019d);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5204850725651131d + "'", double17 == 0.5204850725651131d);
//    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString(59);
//        double double6 = randomDataImpl0.nextExponential(0.9723704937007157d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.873493405344944d + "'", double2 == 2.873493405344944d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "cb30ce2cc5a53f914449df2d1a2bb988dd079f56beff4104e5ec2022c04" + "'", str4.equals("cb30ce2cc5a53f914449df2d1a2bb988dd079f56beff4104e5ec2022c04"));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.2444563861200875d + "'", double6 == 4.2444563861200875d);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.0358611199105672d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5197241010377943d) + "'", double1 == (-0.5197241010377943d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 28);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        long long14 = randomDataImpl1.nextSecureLong(3L, (long) 97);
//        try {
//            int[] intArray17 = randomDataImpl1.nextPermutation(5, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.5630731831180844d + "'", double4 == 1.5630731831180844d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 40.174957713920875d + "'", double11 == 40.174957713920875d);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 43L + "'", long14 == 43L);
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable2, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable0, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable9, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable6, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable25, objArray26);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable23, objArray26);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException21, "hi!", objArray26);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray26);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException13, "7bd99ca9566238edf415e66bcf285b66dd207b5bc5c7ab5276e287391f4389988f913f3cb1f1c196b583296726b64497eaf3", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable33 = convergenceException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray35);
        java.lang.Object[] objArray37 = mathIllegalArgumentException36.getArguments();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable33, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        java.lang.Object[] objArray50 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable49, objArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable47, objArray50);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException45, "hi!", objArray50);
        java.lang.Object[] objArray54 = mathException53.getArguments();
        java.lang.Object[] objArray55 = mathException53.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable40, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable59, objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable57, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable66, objArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable64, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException62, localizable63, objArray67);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException78 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable74, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable80 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        java.lang.Object[] objArray83 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable82, objArray83);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException(localizable80, objArray83);
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException78, "hi!", objArray83);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable73, objArray83);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException70, "7bd99ca9566238edf415e66bcf285b66dd207b5bc5c7ab5276e287391f4389988f913f3cb1f1c196b583296726b64497eaf3", objArray83);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31, localizable40, objArray83);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray83);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.269105190070966d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(22019.308492636723d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 198162.53939935166d + "'", double1 == 198162.53939935166d);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeedSecure(0L);
//        long long11 = randomDataImpl0.nextPoisson(1.062082127705336d);
//        try {
//            int int14 = randomDataImpl0.nextZipf((int) (short) -1, 1.0E-9d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 81 + "'", int5 == 81);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.0617805573411296d) + "'", double7 == (-1.0617805573411296d));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test045");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        double double12 = randomDataImpl0.nextUniform(1.5466015894759282E-16d, 0.3643932802642205d);
//        try {
//            double double15 = randomDataImpl0.nextF(20.138852114085488d, (-4.440892098500626E-16d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0 is smaller than, or equal to, the minimum (0): degrees of freedom (-0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.81710259554422d + "'", double2 == 2.81710259554422d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.170326864286127d + "'", double6 == 2.170326864286127d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2566164852388466d + "'", double12 == 0.2566164852388466d);
//    }

//    @Test
//    public void test046() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test046");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double10 = randomDataImpl0.nextF(1.370200520658798d, 0.3643932802642205d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.12381582826601184d + "'", double10 == 0.12381582826601184d);
//    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test048() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test048");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double19 = normalDistributionImpl9.density(457.80894445968283d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2490467924755557d + "'", double2 == 3.2490467924755557d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4731882506573599d + "'", double6 == 0.4731882506573599d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-17.507085610289575d) + "'", double17 == (-17.507085610289575d));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.23427173053794E-38d + "'", double19 == 3.23427173053794E-38d);
//    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.7353096508879174E-81d, number1, (java.lang.Number) 10.0d);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(3994.2244190822403d, 3.1604453667426053d, 1.0E-323d, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (3) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3010299956639812d + "'", double1 == 0.3010299956639812d);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure((long) 4);
//        double double14 = randomDataImpl0.nextBeta(0.08975154096881159d, 2.1006052018952572E25d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "c967e9dd7ca960b02ad6e05846fb28e1471ff70a8ca82b55322f4260d210eb08fa2727ff80cc30faf0cf2875c4f119baeabb" + "'", str9.equals("c967e9dd7ca960b02ad6e05846fb28e1471ff70a8ca82b55322f4260d210eb08fa2727ff80cc30faf0cf2875c4f119baeabb"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextCauchy(1.2335150624571722d, 3.2300693823966125d);
//        try {
//            int int14 = randomDataImpl0.nextPascal(2, 67.37427577395592d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 67.374 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-13.517307254324127d) + "'", double11 == (-13.517307254324127d));
//    }

//    @Test
//    public void test055() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test055");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        int int12 = randomDataImpl0.nextZipf(97, (double) 4);
//        double double15 = randomDataImpl0.nextUniform(0.0d, (double) 79);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 41.481592977995554d + "'", double15 == 41.481592977995554d);
//    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed((long) 6);
//        try {
//            java.lang.String str6 = randomDataImpl0.nextHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.792065655851452d + "'", double2 == 3.792065655851452d);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double2 = org.apache.commons.math.util.FastMath.min(0.01094247885554892d, 3.2300693823966125d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01094247885554892d + "'", double2 == 0.01094247885554892d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(62.052186898622494d, 5.68362480479509E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 62.05218689862249d + "'", double2 == 62.05218689862249d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 38);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 38.0f + "'", float1 == 38.0f);
    }

//    @Test
//    public void test061() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test061");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextCauchy(1.2335150624571722d, 3.2300693823966125d);
//        int int14 = randomDataImpl0.nextBinomial(59, 0.32450856213773277d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-2.05290015479987d) + "'", double11 == (-2.05290015479987d));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 18 + "'", int14 == 18);
//    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int5 = randomDataImpl1.nextHypergeometric((int) (byte) 10, (int) (byte) -1, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(91);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1);
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 91 + "'", int3 == 91);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.4433586747974933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5579310247365137d + "'", double1 == 0.5579310247365137d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double2 = org.apache.commons.math.util.FastMath.min(3.23427173053794E-38d, 0.2654476119283987d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.23427173053794E-38d + "'", double2 == 3.23427173053794E-38d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8357835894321308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable3, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable12, objArray13);
        int int15 = maxIterationsExceededException14.getMaxIterations();
        java.lang.Throwable[] throwableArray16 = maxIterationsExceededException14.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable3, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable19, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable3, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 59, (java.lang.Number) 8.447150561318425d, true);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable28, objArray29);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(59, localizable3, objArray29);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.1406414750650753d, (double) 96, 0.7546229182176941d, 17);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.786154752642094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8892.891857520402d + "'", double1 == 8892.891857520402d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.6199568117265704d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6813756275810965d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6813756275810964d + "'", double2 == 0.6813756275810964d);
    }

//    @Test
//    public void test072() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test072");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        try {
//            long long9 = randomDataImpl0.nextLong((long) 6, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than, or equal to, the maximum (0): lower bound (6) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.970423371567589d + "'", double2 == 1.970423371567589d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.753744245128226d + "'", double6 == 3.753744245128226d);
//    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.35769113710681816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.ceil(7.051545121200191E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.051545122E9d + "'", double1 == 7.051545122E9d);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeedSecure(0L);
//        java.lang.String str11 = randomDataImpl0.nextHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 33 + "'", int5 == 33);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.6155834591786209d) + "'", double7 == (-0.6155834591786209d));
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "3cb6d77380" + "'", str11.equals("3cb6d77380"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 35.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.7353096508879174E-81d, number1, (java.lang.Number) 10.0d);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.special.Erf.erf((-20.32515112776791d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9999092042625951d, 0.0d, (double) 49L, 6);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0E-323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-323d + "'", double1 == 1.0E-323d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.873493405344944d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.873493405344944d + "'", double1 == 2.873493405344944d);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        long long10 = randomDataImpl0.nextSecureLong((long) 3, 11L);
//        long long13 = randomDataImpl0.nextLong(4L, (long) ' ');
//        int int16 = randomDataImpl0.nextZipf(9, (double) 3);
//        try {
//            int int19 = randomDataImpl0.nextZipf(47, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 6L + "'", long10 == 6L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 27L + "'", long13 == 27L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.exp(55.0022873474593d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.712406057422732E23d + "'", double1 == 7.712406057422732E23d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double21 = randomDataImpl0.nextExponential(0.6932886241683209d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.8885045809884895d + "'", double2 == 2.8885045809884895d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5247322684662222d + "'", double6 == 0.5247322684662222d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.5292559883696909d) + "'", double17 == (-0.5292559883696909d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.6601835659372152d + "'", double21 == 0.6601835659372152d);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException8.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray18 = numberIsTooSmallException17.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable13, (java.lang.Object[]) throwableArray18);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray23);
        java.lang.Object[] objArray25 = mathIllegalArgumentException24.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable21, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, objArray30);
        java.lang.Object[] objArray32 = mathIllegalArgumentException31.getArguments();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable28, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable28, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable28, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray47 = numberIsTooSmallException46.getSuppressed();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException19, localizable21, (java.lang.Object[]) throwableArray47);
        notStrictlyPositiveException8.addSuppressed((java.lang.Throwable) mathException48);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwableArray47);
    }

//    @Test
//    public void test088() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test088");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.9389941379013969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03836943389087866d + "'", double1 == 0.03836943389087866d);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        try {
//            int int10 = randomDataImpl0.nextInt(47, 7);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 47 is larger than, or equal to, the maximum (7): lower bound (47) must be strictly less than upper bound (7)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.3607517723734253d) + "'", double7 == (-1.3607517723734253d));
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.03268169191673955d, (java.lang.Number) 51.07285574583457d, true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.cosh(130.57717034608623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5580825088611197E56d + "'", double1 == 2.5580825088611197E56d);
    }

//    @Test
//    public void test095() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test095");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        long long10 = randomDataImpl0.nextSecureLong((long) 3, 11L);
//        long long13 = randomDataImpl0.nextLong(4L, (long) ' ');
//        double double16 = randomDataImpl0.nextCauchy((-105.77959572529313d), 0.6483608274590866d);
//        try {
//            double double19 = randomDataImpl0.nextCauchy((-18.951180091987943d), (-0.6321205588285577d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.632 is smaller than, or equal to, the minimum (0): scale (-0.632)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 11L + "'", long10 == 11L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 10L + "'", long13 == 10L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-105.62571831131342d) + "'", double16 == (-105.62571831131342d));
//    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8687969548680085d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8687969548680085d + "'", double1 == 0.8687969548680085d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.cosh(62.052186898622494d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4452108369129785E26d + "'", double1 == 4.4452108369129785E26d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.20394536991302709d), 0.27744497381094396d, 0.8085268581205644d, 22);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(60.16716521718691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 60.16716521718692d + "'", double1 == 60.16716521718692d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.2300693823966125d, 8.447150561318425d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.013047206887944206d + "'", double2 == 0.013047206887944206d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(97);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException6, "hi!", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("0", objArray11);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException("560cd8f23f6e59cba3fc7ed7a97ce57932db02ee41b58ef479d8759377961f16d1104970165702ace31e61d0206ecc6269cf", objArray11);
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long1 = org.apache.commons.math.util.FastMath.round(0.03268169191673955d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.1204773664933685E-9d, (java.lang.Number) 59L, true);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeedSecure(0L);
//        double double11 = randomDataImpl0.nextT(0.6252948841919719d);
//        double double14 = randomDataImpl0.nextGaussian(11.575061052263854d, 0.9999999958776927d);
//        int int17 = randomDataImpl0.nextPascal(49, 0.001001501918542427d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 13 + "'", int5 == 13);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-1.1735708591312843d) + "'", double7 == (-1.1735708591312843d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.6656844087028861d) + "'", double11 == (-0.6656844087028861d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 10.252512306139309d + "'", double14 == 10.252512306139309d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 41670 + "'", int17 == 41670);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure(0L);
        randomDataImpl0.reSeed();
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 3.0167501573306144d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.6173982341988522d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable7, objArray11);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable0, objArray11);
        java.lang.String str16 = mathException15.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.MathException: " + "'", str16.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString(59);
//        int[] intArray7 = randomDataImpl0.nextPermutation(9, 2);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.253034309429778d + "'", double2 == 1.253034309429778d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4d657f87511bbe53ccf2afe46f3a76e27e6c4aff7fc881e5290120335cf" + "'", str4.equals("4d657f87511bbe53ccf2afe46f3a76e27e6c4aff7fc881e5290120335cf"));
//        org.junit.Assert.assertNotNull(intArray7);
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double[] doubleArray5 = normalDistributionImpl2.sample(2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0001294476790334d, 0.21406959939352824d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0001294476790332d + "'", double2 == 1.0001294476790332d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(5.68362480479509E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0956310783665996E32d + "'", double1 == 3.0956310783665996E32d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.6813756275810964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2739505966505669d) + "'", double1 == (-1.2739505966505669d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        double double7 = normalDistributionImpl2.inverseCumulativeProbability((double) (short) 0);
        double double8 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) (short) 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        long long1 = org.apache.commons.math.util.FastMath.round(1.1727661719426563d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable2, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray3);
        java.lang.String str6 = mathException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException5.getGeneralPattern();
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable7, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 52L);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 5L, (java.lang.Number) 130.5771703460862d, (java.lang.Number) 0.9999989861899106d);
        java.lang.Number number16 = outOfRangeException15.getHi();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: " + "'", str6.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.9999989861899106d + "'", number16.equals(0.9999989861899106d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 36.07140440247247d + "'", double1 == 36.07140440247247d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable14, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable33, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable31, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray34);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable43, objArray44);
        int int46 = maxIterationsExceededException45.getMaxIterations();
        int int47 = maxIterationsExceededException45.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable50 = convergenceException49.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray52);
        java.lang.Object[] objArray54 = mathIllegalArgumentException53.getArguments();
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException(localizable50, objArray54);
        java.lang.Class<?> wildcardClass56 = objArray54.getClass();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException45, "{0}", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException40, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable14, objArray54);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (-0.9999999999999999d), (java.lang.Number) 5L, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 9.70732464415742d, (java.lang.Number) 41.481592977995554d, (java.lang.Number) 0.3230978683634768d);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.03844259002118798d, Double.NEGATIVE_INFINITY, 0.5530611949430921d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): standard deviation (-∞)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.785022317073703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7449022902956208d + "'", double1 == 0.7449022902956208d);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        randomDataImpl0.reSeed((long) 22);
//        try {
//            randomDataImpl0.setSecureAlgorithm("convergence failed", "c5e812786c90d63df97f8e7b1c5f56a4b3bd6c8bed1f3fa1ef2d8b0673f");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: c5e812786c90d63df97f8e7b1c5f56a4b3bd6c8bed1f3fa1ef2d8b0673f");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3675622790222834d + "'", double2 == 1.3675622790222834d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.760105737113283d + "'", double6 == 5.760105737113283d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test127");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed((long) 6);
//        double double7 = randomDataImpl0.nextGaussian(76.48788695911851d, 0.3230978683634768d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6587097628512972d + "'", double2 == 1.6587097628512972d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 77.00509280338461d + "'", double7 == 77.00509280338461d);
//    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        long long10 = randomDataImpl0.nextSecureLong((long) 3, 11L);
//        long long13 = randomDataImpl0.nextLong(4L, (long) ' ');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl17 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.7353096508879174E-81d, (double) 10L, (double) (-1));
//        double double18 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl17);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 4L + "'", long10 == 4L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 30L + "'", long13 == 30L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 6.357578668376476d + "'", double18 == 6.357578668376476d);
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        java.lang.Class<?> wildcardClass8 = objArray6.getClass();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable0, objArray6);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable11 = convergenceException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        java.lang.Object[] objArray15 = mathIllegalArgumentException14.getArguments();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable11, objArray15);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray26);
        java.lang.Object[] objArray28 = mathIllegalArgumentException27.getArguments();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable24, objArray28);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable24, objArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable24, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, localizable24, objArray41);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(41.481592977995554d, 0.032675876863609975d, 5.657992163650382E-18d, 41670);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.119539299153502E-112d + "'", double4 == 1.119539299153502E-112d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        int int1 = org.apache.commons.math.util.FastMath.abs(40);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 40 + "'", int1 == 40);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.7174095342479367d, 7.712406057422732E23d, (double) 59, (int) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.370200520658798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9799480354874641d + "'", double1 == 0.9799480354874641d);
    }

//    @Test
//    public void test134() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test134");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) 'a', (int) ' ');
//        double double18 = randomDataImpl0.nextGaussian(0.9434837013395192d, 4.071380944090519E157d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-9.023585134363584d) + "'", double12 == (-9.023585134363584d));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-4.3190334838657587E157d) + "'", double18 == (-4.3190334838657587E157d));
//    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeedSecure(0L);
//        long long12 = randomDataImpl0.nextLong((long) 28, 49L);
//        int int15 = randomDataImpl0.nextZipf(4, 0.3796077390275217d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("c967e9dd7ca960b02ad6e05846fb28e1471ff70a8ca82b55322f4260d210eb08fa2727ff80cc30faf0cf2875c4f119baeabb", "org.apache.commons.math.MathException: ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MathException: ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 36 + "'", int5 == 36);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-0.4575703144297792d) + "'", double7 == (-0.4575703144297792d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 42L + "'", long12 == 42L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.47712125471966244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.45922383319968013d + "'", double1 == 0.45922383319968013d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.4731882506573599d, (java.lang.Number) 41.481592977995554d, (java.lang.Number) 22.396067961896854d);
    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        double double12 = randomDataImpl0.nextUniform(1.5466015894759282E-16d, 0.3643932802642205d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            java.lang.String str15 = randomDataImpl0.nextSecureHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7461097919792115d + "'", double2 == 1.7461097919792115d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.378846617286709d + "'", double6 == 4.378846617286709d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.25362230852417955d + "'", double12 == 0.25362230852417955d);
//    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, (float) 37L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 37.0f + "'", float2 == 37.0f);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(10.20756028082422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.169238570007596d + "'", double1 == 2.169238570007596d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        float float2 = org.apache.commons.math.util.FastMath.min(97.0f, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 40);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 40L + "'", long1 == 40L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 96, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 96L + "'", long2 == 96L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 47);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 132.95257503561632d + "'", double1 == 132.95257503561632d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.011026339477238639d, (-4.3190334838657587E157d), 0.7963446374991774d, 5);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.4772803120976288d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49560828776125515d + "'", double1 == 0.49560828776125515d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double1 = org.apache.commons.math.util.FastMath.log(5.68362480479509E-17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-37.406357381851215d) + "'", double1 == (-37.406357381851215d));
    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double12 = randomDataImpl0.nextGamma(0.984807753012208d, 0.28366218546322625d);
//        randomDataImpl0.reSeedSecure();
//        int int16 = randomDataImpl0.nextZipf((int) ' ', 2.7353096508879174E-81d);
//        int[] intArray19 = randomDataImpl0.nextPermutation(78, 3);
//        long long21 = randomDataImpl0.nextPoisson((double) 2);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ea9581bcb3ec4e774bb615e94ea9da69d36e0e0d2271fce3190b0e66e6eeea30e67fc48ca803920f9a5dae87857e2abede46" + "'", str9.equals("ea9581bcb3ec4e774bb615e94ea9da69d36e0e0d2271fce3190b0e66e6eeea30e67fc48ca803920f9a5dae87857e2abede46"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.1048547808195645d + "'", double12 == 0.1048547808195645d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertNotNull(intArray19);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 3L + "'", long21 == 3L);
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        java.lang.Number number14 = numberIsTooLargeException12.getArgument();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException12);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.417595318551267d + "'", number14.equals(0.417595318551267d));
    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test153");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed((long) 6);
//        java.lang.String str6 = randomDataImpl0.nextSecureHexString((int) 'a');
//        java.lang.String str8 = randomDataImpl0.nextHexString(1);
//        try {
//            int int11 = randomDataImpl0.nextSecureInt(49, (int) '#');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 49 is larger than, or equal to, the maximum (35): lower bound (49) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.800638167869659d + "'", double2 == 0.800638167869659d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "20bc586d40709546bee43dd40df9c761ff4ec579db0f7f2bfefa1b5d33ab11b0ce90f0ebec6536c6b50b595ba1c0cb326" + "'", str6.equals("20bc586d40709546bee43dd40df9c761ff4ec579db0f7f2bfefa1b5d33ab11b0ce90f0ebec6536c6b50b595ba1c0cb326"));
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "0" + "'", str8.equals("0"));
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException12);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = normalDistributionImpl7.inverseCumulativeProbability(0.9999999958776927d);
//        double double16 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) 8);
//        double double17 = normalDistributionImpl7.sample();
//        try {
//            double[] doubleArray19 = normalDistributionImpl7.sample(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0139067098350252d + "'", double4 == 1.0139067098350252d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-44.471514899981344d) + "'", double11 == (-44.471514899981344d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 211.718280929568d + "'", double13 == 211.718280929568d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08966721745884815d + "'", double16 == 0.08966721745884815d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 15.494898642491348d + "'", double17 == 15.494898642491348d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.27744497381094396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.896426046484745d + "'", double1 == 15.896426046484745d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0934846107779827E-16d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Object[] objArray26 = mathIllegalArgumentException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable22, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray37);
        java.lang.Object[] objArray39 = mathIllegalArgumentException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable35, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray55);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable64, objArray65);
        int int67 = maxIterationsExceededException66.getMaxIterations();
        int int68 = maxIterationsExceededException66.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable71 = convergenceException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray73);
        java.lang.Object[] objArray75 = mathIllegalArgumentException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable71, objArray75);
        java.lang.Class<?> wildcardClass77 = objArray75.getClass();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException66, "{0}", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable35, objArray75);
        outOfRangeException19.addSuppressed((java.lang.Throwable) convergenceException80);
        java.lang.Object[] objArray82 = outOfRangeException19.getArguments();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(objArray82);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.sin(22.16932672019457d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17723685681799714d) + "'", double1 == (-0.17723685681799714d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.051545121200191E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0402377449083746E11d + "'", double1 == 4.0402377449083746E11d);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        java.lang.String str4 = randomDataImpl0.nextHexString(59);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.31565990958148843d + "'", double2 == 0.31565990958148843d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "517e267014691a0613acd2ad3f736d89534f2c7da833b639329fc4a9a80" + "'", str4.equals("517e267014691a0613acd2ad3f736d89534f2c7da833b639329fc4a9a80"));
//    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test162");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        double double11 = randomDataImpl0.nextExponential(20.138852114085488d);
//        double double13 = randomDataImpl0.nextT(33.63261756898911d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.2404923147350416E-17d + "'", double9 == 2.2404923147350416E-17d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.842358651511157d + "'", double11 == 10.842358651511157d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.293836631774737d + "'", double13 == 0.293836631774737d);
//    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test163");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        randomDataImpl1.reSeed();
//        double double7 = randomDataImpl1.nextChiSquare(0.010942894613315412d);
//        double double10 = randomDataImpl1.nextCauchy((-7.170036909513635d), 67.37427577395592d);
//        double double13 = randomDataImpl1.nextGaussian((-4.323674867630536d), 0.4433586747974933d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.2163089849960882d + "'", double4 == 1.2163089849960882d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.576866094423735E-9d + "'", double7 == 1.576866094423735E-9d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-124.27838647862293d) + "'", double10 == (-124.27838647862293d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-4.4045644774029915d) + "'", double13 == (-4.4045644774029915d));
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7963446374991774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(60.16716521718692d, 2.0794415416798357d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 60.16716521718691d + "'", double2 == 60.16716521718691d);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        long long10 = randomDataImpl0.nextSecureLong(10L, (long) 13);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 10L + "'", long10 == 10L);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.6155834591786209d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.7353096508879174E-81d, (double) 10L, (double) (-1));
        normalDistributionImpl3.reseedRandomGenerator((long) 91);
        double double7 = normalDistributionImpl3.density(35.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.726826950457602E-5d + "'", double7 == 8.726826950457602E-5d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5707963267948966d, number1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(number4);
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double16 = normalDistributionImpl8.cumulativeProbability((-0.6155834591786209d));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 37.70817463479268d + "'", double12 == 37.70817463479268d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.38082971456174475d + "'", double16 == 0.38082971456174475d);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double8 = normalDistributionImpl2.cumulativeProbability((double) 33, 10.20756028082422d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 0);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 0 + "'", number5.equals((short) 0));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.7546229182176941d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.646453217127139d + "'", double1 == 0.646453217127139d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.17723685681799714d), (java.lang.Number) 32.0d, true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.15460457598974447d, 0.6252948841919719d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.31118946036584083d + "'", double2 == 0.31118946036584083d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double double1 = org.apache.commons.math.special.Gamma.digamma(3.2300693823966125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0097943322771317d + "'", double1 == 1.0097943322771317d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        double double7 = normalDistributionImpl2.inverseCumulativeProbability((double) (short) 0);
        normalDistributionImpl2.reseedRandomGenerator(0L);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test179() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test179");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double3 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.cumulativeProbability(2.0d, 20.30766683149986d);
//        double double8 = normalDistributionImpl2.density(0.0d);
//        normalDistributionImpl2.reseedRandomGenerator(97L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.92428691076829d + "'", double3 == 35.92428691076829d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.20621287249438264d + "'", double6 == 0.20621287249438264d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.01094247885554892d + "'", double8 == 0.01094247885554892d);
//    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.4653112823676238d, 0.7669549644331817d, (-0.12130284660365231d), 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (2) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 0.7712985484622012d, true);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(48.80259668333492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020702081394849754d + "'", double1 == 0.020702081394849754d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.003240757521403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7638922592190975d + "'", double1 == 1.7638922592190975d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray19);
        java.lang.Object[] objArray21 = mathIllegalArgumentException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable17, objArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable27, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, objArray28);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        convergenceException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException35);
        java.lang.Number number37 = numberIsTooSmallException35.getMin();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException35);
        java.lang.String str39 = mathException38.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10.0f + "'", number37.equals(10.0f));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.MathException: -20.325 is smaller than, or equal to, the minimum (10): convergence failed" + "'", str39.equals("org.apache.commons.math.MathException: -20.325 is smaller than, or equal to, the minimum (10): convergence failed"));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.04923284879062803d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.20756028082422d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double17 = normalDistributionImpl8.cumulativeProbability((-1.3170218223604584d), 2.140641475065075d);
//        normalDistributionImpl8.reseedRandomGenerator((long) 28);
//        double double21 = normalDistributionImpl8.cumulativeProbability((-1.6199568117265704d));
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 11.183469542488302d + "'", double12 == 11.183469542488302d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.03794591252408147d + "'", double17 == 0.03794591252408147d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.3699450953823475d + "'", double21 == 0.3699450953823475d);
//    }

//    @Test
//    public void test188() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test188");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeedSecure(0L);
//        long long12 = randomDataImpl0.nextLong((long) 28, 49L);
//        int int15 = randomDataImpl0.nextZipf(4, 0.3796077390275217d);
//        try {
//            long long17 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.026491862797005338d + "'", double7 == 0.026491862797005338d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 40L + "'", long12 == 40L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        float float2 = org.apache.commons.math.util.FastMath.max(32.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double15 = normalDistributionImpl8.getMean();
//        double double17 = normalDistributionImpl8.density(0.004655363473036653d);
//        normalDistributionImpl8.reseedRandomGenerator((long) 3);
//        try {
//            double double22 = normalDistributionImpl8.cumulativeProbability(7.888609052210118E69d, (double) 11L);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 12.70274305837531d + "'", double12 == 12.70274305837531d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.010942894613315412d + "'", double17 == 0.010942894613315412d);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double12 = normalDistributionImpl7.getMean();
//        double double13 = normalDistributionImpl7.getMean();
//        double double14 = normalDistributionImpl7.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.015099165163087d + "'", double4 == 1.015099165163087d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-10.842329587419833d) + "'", double11 == (-10.842329587419833d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 10.0d + "'", double12 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 10.0d + "'", double13 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable14, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray38 = numberIsTooSmallException37.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable33, (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException30, "org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)", (java.lang.Object[]) throwableArray38);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException30.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.1735708591312843d), 5.657992163650382E-18d, 10.20756028082422d, (int) '4');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.7353096508879174E-81d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7353096508879174E-81d + "'", double1 == 2.7353096508879174E-81d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 19.0d, (java.lang.Number) 7.302600404579019d, false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.649558242894909d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4231734706666733d + "'", double1 == 0.4231734706666733d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable12, objArray13);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable2, objArray13);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Object[] objArray26 = mathIllegalArgumentException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable22, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray37);
        java.lang.Object[] objArray39 = mathIllegalArgumentException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable35, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray55);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable64, objArray65);
        int int67 = maxIterationsExceededException66.getMaxIterations();
        int int68 = maxIterationsExceededException66.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable71 = convergenceException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray73);
        java.lang.Object[] objArray75 = mathIllegalArgumentException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable71, objArray75);
        java.lang.Class<?> wildcardClass77 = objArray75.getClass();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException66, "{0}", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable35, objArray75);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException(localizable2, objArray75);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException("c967e9dd7ca960b02ad6e05846fb28e1471ff70a8ca82b55322f4260d210eb08fa2727ff80cc30faf0cf2875c4f119baeabb", objArray75);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(wildcardClass77);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextZipf(3, 0.417595318551267d);
//        randomDataImpl0.reSeed(8L);
//        double double14 = randomDataImpl0.nextUniform(1.649474997576156d, 100.00000000000001d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.043061054761816d + "'", double6 == 12.043061054761816d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 73.47005733131445d + "'", double14 == 73.47005733131445d);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        double double12 = randomDataImpl0.nextF((double) 6, (double) 5L);
//        randomDataImpl0.reSeedSecure((long) 35);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.7716297994643084d + "'", double12 == 0.7716297994643084d);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray7);
        java.lang.Object[] objArray9 = mathIllegalArgumentException8.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable5, objArray9);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 32.0f);
        java.lang.Number number13 = notStrictlyPositiveException12.getMin();
        boolean boolean14 = notStrictlyPositiveException12.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException12.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable17, objArray18);
        int int20 = maxIterationsExceededException19.getMaxIterations();
        int int21 = maxIterationsExceededException19.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray26);
        java.lang.Object[] objArray28 = mathIllegalArgumentException27.getArguments();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable24, objArray28);
        java.lang.Class<?> wildcardClass30 = objArray28.getClass();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException19, "{0}", objArray28);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable15, objArray28);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable43, objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable41, objArray44);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException39, "hi!", objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable34, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray44);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertNotNull(objArray44);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        double double9 = randomDataImpl0.nextChiSquare((double) 97.0f);
//        double double11 = randomDataImpl0.nextT(0.4433586747974933d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.09079298437813d + "'", double9 == 100.09079298437813d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0568296365613066d) + "'", double11 == (-1.0568296365613066d));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 18);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100, (float) 30L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare(5.298342365610589d);
//        double double16 = randomDataImpl0.nextF(1.5707963267948966d, 3.564674068467739d);
//        int int19 = randomDataImpl0.nextZipf(32, 2.0794415416798357d);
//        try {
//            long long22 = randomDataImpl0.nextLong((long) 'a', (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (0): lower bound (97) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.381652038973522d + "'", double11 == 1.381652038973522d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.4629915299853753d + "'", double13 == 1.4629915299853753d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.46907358922737247d + "'", double16 == 0.46907358922737247d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test205");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeed();
//        try {
//            randomDataImpl0.setSecureAlgorithm("convergence failed", "89392b942a270257063a49d0cc96aeb08980f817d020df6c61c438f6ec4");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 89392b942a270257063a49d0cc96aeb08980f817d020df6c61c438f6ec4");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.49970718021368654d + "'", double2 == 0.49970718021368654d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.560786565883738d + "'", double6 == 12.560786565883738d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 132.95257503561632d, (java.lang.Number) (-53.40321167064011d), true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1870539200198031d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.927270000289983d + "'", double1 == 0.927270000289983d);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        randomDataImpl1.reSeed();
//        long long7 = randomDataImpl1.nextPoisson(48.80259668333492d);
//        int int10 = randomDataImpl1.nextInt(0, 2);
//        double double13 = randomDataImpl1.nextGaussian(0.08966721745884815d, 0.9459647154445872d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.125364473480065d + "'", double4 == 1.125364473480065d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 46L + "'", long7 == 46L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.5864774157928854d) + "'", double13 == (-0.5864774157928854d));
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.68362480479509E-17d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.683624804795088E-17d + "'", double2 == 5.683624804795088E-17d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = maxIterationsExceededException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable2, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray3);
        java.lang.String str6 = mathException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException5.getGeneralPattern();
        java.lang.Class<?> wildcardClass8 = mathException5.getClass();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: " + "'", str6.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(localizable7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5574077246549023d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.5574077246549023d + "'", number2.equals(1.5574077246549023d));
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        int int10 = randomDataImpl0.nextZipf(13, (double) 49L);
//        try {
//            int int14 = randomDataImpl0.nextHypergeometric(1, 52, 91);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (1): number of successes (52) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4231734706666733d, 0.11672719383326711d, 3.4211442918333637d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        java.lang.Number number20 = outOfRangeException19.getLo();
        java.lang.Number number21 = outOfRangeException19.getLo();
        java.lang.Number number22 = outOfRangeException19.getLo();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) -1 + "'", number20.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) -1 + "'", number21.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (byte) -1 + "'", number22.equals((byte) -1));
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test217");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextBeta(2.2291105668993048d, 0.7712985484622012d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.9719665427479347d + "'", double6 == 0.9719665427479347d);
//    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int2 = org.apache.commons.math.util.FastMath.max(59, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 59 + "'", int2 == 59);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        long long5 = randomDataImpl0.nextLong((long) 13, (long) 59);
//        try {
//            int int8 = randomDataImpl0.nextBinomial((int) (byte) 10, 5.566640214978967d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 5.567 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 43L + "'", long5 == 43L);
//    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        java.lang.String str7 = numberIsTooLargeException6.toString();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException6, "56bbe72af64574b2a6667713a220cf01b5d46d788a99788713f9bc7a4e1", objArray11);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(throwable0, localizable1, objArray11);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 49, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray17);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable23, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable21, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException19, localizable20, objArray24);
        java.lang.Object[] objArray28 = mathException19.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException(localizable13, objArray28);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException29);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.10598751175115685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.6849166814234299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8163069850811673d + "'", double1 == 0.8163069850811673d);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl1.nextGaussian(0.6932886241683209d, (-0.17723685681799714d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.177 is smaller than, or equal to, the minimum (0): standard deviation (-0.177)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1053157649775356d + "'", double4 == 1.1053157649775356d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 34.35649067230317d + "'", double11 == 34.35649067230317d);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray7);
        java.lang.Object[] objArray9 = mathIllegalArgumentException8.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable5, objArray9);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-18.951180091987943d), (java.lang.Number) 8.112963841460668E31d, false);
        java.lang.Number number24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NEGATIVE_INFINITY, number24, false);
        java.lang.Object[] objArray27 = numberIsTooLargeException26.getArguments();
        java.lang.Number number28 = numberIsTooLargeException26.getMax();
        java.lang.Object[] objArray29 = numberIsTooLargeException26.getArguments();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable5, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray34);
        java.lang.Object[] objArray36 = mathIllegalArgumentException35.getArguments();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable32, objArray36);
        java.lang.Class<?> wildcardClass38 = objArray36.getClass();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable5, objArray36);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNull(number28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(wildcardClass38);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        java.lang.String str6 = numberIsTooLargeException5.toString();
        boolean boolean7 = numberIsTooLargeException5.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray12);
        java.lang.Object[] objArray14 = mathIllegalArgumentException13.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable10, objArray14);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray22);
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable29, objArray30);
        int int32 = maxIterationsExceededException31.getMaxIterations();
        int int33 = maxIterationsExceededException31.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable36 = convergenceException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, objArray38);
        java.lang.Object[] objArray40 = mathIllegalArgumentException39.getArguments();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable36, objArray40);
        java.lang.Class<?> wildcardClass42 = objArray40.getClass();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException31, "{0}", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException26, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "a96ffb6c81a563cbdc1668901786fdbfef4c242b7b95e26e01780bdb4a7614ca9f4b3520894defb9abc72303382821f8b", objArray40);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("dfcd9353f6fd68866b38e7bc02efc68cf8c855918588b5f14e14c92b57c61b93da9760a6b43d3ffa73c7a5650195e53d7a1f", objArray40);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NEGATIVE_INFINITY, number1, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Object[] objArray6 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) (-18.951180091987943d), (java.lang.Number) 8.112963841460668E31d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 0.880878861002552d);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0E-9d, 1.5550942069020652d, 0.0d, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 1.555 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.47712125471966244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1159980517894756d + "'", double1 == 1.1159980517894756d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.2258332313601624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22583323136016242d + "'", double1 == 0.22583323136016242d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 6, 97.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.6461019110467638d), 1.941393916153892E-4d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Object[] objArray26 = mathIllegalArgumentException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable22, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray37);
        java.lang.Object[] objArray39 = mathIllegalArgumentException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable35, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray55);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable64, objArray65);
        int int67 = maxIterationsExceededException66.getMaxIterations();
        int int68 = maxIterationsExceededException66.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable71 = convergenceException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray73);
        java.lang.Object[] objArray75 = mathIllegalArgumentException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable71, objArray75);
        java.lang.Class<?> wildcardClass77 = objArray75.getClass();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException66, "{0}", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable35, objArray75);
        outOfRangeException19.addSuppressed((java.lang.Throwable) convergenceException80);
        java.lang.Number number82 = outOfRangeException19.getHi();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertTrue("'" + number82 + "' != '" + 0.9999999958776927d + "'", number82.equals(0.9999999958776927d));
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double15 = normalDistributionImpl8.getMean();
//        double double16 = normalDistributionImpl8.sample();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 49.53105525271461d + "'", double12 == 49.53105525271461d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-22.20906688552266d) + "'", double16 == (-22.20906688552266d));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) 100L, (java.lang.Number) (short) -1, (java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) (-1));
        outOfRangeException18.addSuppressed((java.lang.Throwable) notStrictlyPositiveException21);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test240() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test240");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        int int10 = randomDataImpl0.nextZipf(13, (double) 49L);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test242");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.35896499244058394d + "'", double2 == 0.35896499244058394d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.2305517408388402d + "'", double6 == 3.2305517408388402d);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6849166814234299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 4, (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 39.106169829075185d);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException8.getSpecificPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, number12, (java.lang.Number) (-0.41032129904824216d), (java.lang.Number) 1.1712659507785417d);
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable19 = convergenceException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, objArray21);
        java.lang.Object[] objArray23 = mathIllegalArgumentException22.getArguments();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable19, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException37 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable35, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable33, objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException31, "hi!", objArray36);
        java.lang.Object[] objArray40 = mathException39.getArguments();
        java.lang.Object[] objArray41 = mathException39.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable26, objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException(4, "c967e9dd7ca960b02ad6e05846fb28e1471ff70a8ca82b55322f4260d210eb08fa2727ff80cc30faf0cf2875c4f119baeabb", objArray41);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable11, objArray41);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable4, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray8);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed", objArray8);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.08975154096881159d, (java.lang.Number) 1.1727661719426563d, false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.abs(60.16716521718691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 60.16716521718691d + "'", double1 == 60.16716521718691d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
        randomDataImpl0.reSeedSecure(48L);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.269105190070966d, (java.lang.Number) 7.960870902199058d, (java.lang.Number) 0.37665202364295614d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7.960870902199058d + "'", number4.equals(7.960870902199058d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 7.960870902199058d + "'", number5.equals(7.960870902199058d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.38082971456174475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.939723417654897d + "'", double1 == 7.939723417654897d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Object[] objArray26 = mathIllegalArgumentException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable22, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable35 = convergenceException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray37 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray37);
        java.lang.Object[] objArray39 = mathIllegalArgumentException38.getArguments();
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable35, objArray39);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray46 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, localizable35, objArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable35, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException56 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable54, objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable52, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray55);
        java.lang.Object[] objArray60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray65 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable64, objArray65);
        int int67 = maxIterationsExceededException66.getMaxIterations();
        int int68 = maxIterationsExceededException66.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable71 = convergenceException70.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray73 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException74 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray73);
        java.lang.Object[] objArray75 = mathIllegalArgumentException74.getArguments();
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable71, objArray75);
        java.lang.Class<?> wildcardClass77 = objArray75.getClass();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException66, "{0}", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray75);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException(localizable35, objArray75);
        outOfRangeException19.addSuppressed((java.lang.Throwable) convergenceException80);
        java.lang.Class<?> wildcardClass82 = outOfRangeException19.getClass();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1) + "'", int68 == (-1));
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(wildcardClass82);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-1.1735708591312843d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02048267549729947d) + "'", double1 == (-0.02048267549729947d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.26708481774098d, 0.9999092042625951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.273793348760653d + "'", double2 == 1.273793348760653d);
    }

//    @Test
//    public void test258() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test258");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeed();
//        int int14 = randomDataImpl0.nextSecureInt((int) (byte) 0, 49);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.16496662947522d + "'", double2 == 5.16496662947522d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5391385500093169d + "'", double6 == 0.5391385500093169d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 49 + "'", int14 == 49);
//    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0001294476790332d, (double) 3);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0001294476790332d + "'", double2 == 1.0001294476790332d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3994.2244190822403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        java.lang.Class<?> wildcardClass10 = randomDataImpl0.getClass();
//        randomDataImpl0.reSeed();
//        double double14 = randomDataImpl0.nextCauchy(0.27744497381094396d, 76.48788695911851d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.542536405015017d + "'", double2 == 4.542536405015017d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7687129202811087d + "'", double6 == 0.7687129202811087d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-450.653846000755d) + "'", double14 == (-450.653846000755d));
//    }

//    @Test
//    public void test262() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test262");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextWeibull(1.126723365149817d, (double) (short) 10);
//        int int9 = randomDataImpl0.nextZipf(97, (double) 2.0f);
//        try {
//            double double12 = randomDataImpl0.nextUniform(91.13649087589248d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 91.136 is larger than, or equal to, the maximum (0): lower bound (91.136) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.509373916671324d + "'", double2 == 4.509373916671324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.7884741225001545d + "'", double6 == 0.7884741225001545d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.signum((-7.4121522588382405d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599457d + "'", double1 == 0.6931471805599457d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.695071770287532d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.atanh(35.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.062082127705336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.032756869138569567d) + "'", double1 == (-0.032756869138569567d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 52L, 1.2163089849960882d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.4653112823676238d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16592989353261933d + "'", double1 == 0.16592989353261933d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray8);
        java.lang.Object[] objArray10 = mathIllegalArgumentException9.getArguments();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable6, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable17, objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable14, objArray18);
        java.lang.Object[] objArray22 = convergenceException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable24, (java.lang.Number) 0.874591382923689d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray34);
        java.lang.Object[] objArray36 = mathIllegalArgumentException35.getArguments();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable32, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray44 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, objArray44);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) (-18.951180091987943d), (java.lang.Number) 8.112963841460668E31d, false);
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NEGATIVE_INFINITY, number51, false);
        java.lang.Object[] objArray54 = numberIsTooLargeException53.getArguments();
        java.lang.Number number55 = numberIsTooLargeException53.getMax();
        java.lang.Object[] objArray56 = numberIsTooLargeException53.getArguments();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException30, localizable32, objArray56);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray56);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNull(number55);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(26.111155375796386d, 0.21406959939352824d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability(60.16716521718691d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 60.167 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test274() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test274");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString(59);
//        int int8 = randomDataImpl0.nextHypergeometric((int) '#', 1, 2);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1029364590444358d + "'", double2 == 0.1029364590444358d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "26e04558bc5e744f336dea595b10f938000dc0967ee36484fb32c14cbd9" + "'", str4.equals("26e04558bc5e744f336dea595b10f938000dc0967ee36484fb32c14cbd9"));
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
//    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6932886241683209d, 5.0d, 0.0d, 2147483647);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.997014536446109d + "'", double4 == 0.997014536446109d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.785022317073703d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.special.Erf.erf((-1.6199568117265704d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9780345558188829d) + "'", double1 == (-0.9780345558188829d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.signum(60.16716521718691d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 49L, 1.8402864822065015d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray7);
        java.lang.Object[] objArray9 = mathIllegalArgumentException8.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable5, objArray9);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 32.0f);
        java.lang.Number number13 = notStrictlyPositiveException12.getMin();
        boolean boolean14 = notStrictlyPositiveException12.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException12.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable17, objArray18);
        int int20 = maxIterationsExceededException19.getMaxIterations();
        int int21 = maxIterationsExceededException19.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable24 = convergenceException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, objArray26);
        java.lang.Object[] objArray28 = mathIllegalArgumentException27.getArguments();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable24, objArray28);
        java.lang.Class<?> wildcardClass30 = objArray28.getClass();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException19, "{0}", objArray28);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable15, objArray28);
        java.lang.Number number33 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException(localizable15, number33, (java.lang.Number) 10.0f, (java.lang.Number) 0.4433586747974933d);
        java.lang.Number number37 = outOfRangeException36.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 10.0f + "'", number37.equals(10.0f));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(26.111155375796386d, 0.21406959939352824d);
        double double3 = normalDistributionImpl2.getMean();
        normalDistributionImpl2.reseedRandomGenerator((long) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 26.111155375796386d + "'", double3 == 26.111155375796386d);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test284");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        int int12 = randomDataImpl0.nextZipf(97, (double) 4);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) (short) 100, 77);
//        try {
//            double double18 = randomDataImpl0.nextWeibull(0.8163069850811673d, (-0.41032129904824216d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.41 is smaller than, or equal to, the minimum (0): scale (-0.41)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-114.24942688691974d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0742717944444664E49d + "'", double1 == 2.0742717944444664E49d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        java.lang.Number number21 = outOfRangeException19.getLo();
        java.lang.String str22 = outOfRangeException19.toString();
        java.lang.String str23 = outOfRangeException19.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) -1 + "'", number21.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed" + "'", str22.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed" + "'", str23.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6153681842182257d, 0.5579310247365137d, 0.9389941379013969d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray17);
        java.lang.Object[] objArray19 = mathIllegalArgumentException18.getArguments();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable15, objArray19);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable15, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray26 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable15, objArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable38, objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable36, objArray39);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException34, "hi!", objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray39);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable2, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable46 = convergenceException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray48 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, objArray48);
        java.lang.Object[] objArray50 = mathIllegalArgumentException49.getArguments();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable46, objArray50);
        java.lang.Class<?> wildcardClass52 = objArray50.getClass();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException(2, localizable2, objArray50);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 33);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33.00000000000001d + "'", double1 == 33.00000000000001d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 32, 0.6848195916477331d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0714062094034648E-41d + "'", double2 == 1.0714062094034648E-41d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(3.9316011043147263d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7065106379312245d + "'", double1 == 1.7065106379312245d);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double17 = normalDistributionImpl8.cumulativeProbability((-1.3170218223604584d), 2.140641475065075d);
//        double double18 = normalDistributionImpl8.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 34.31084298699474d + "'", double12 == 34.31084298699474d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.03794591252408147d + "'", double17 == 0.03794591252408147d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        long long12 = randomDataImpl0.nextLong((-1L), (long) 35);
//        randomDataImpl0.reSeedSecure();
//        int int16 = randomDataImpl0.nextPascal((int) (byte) 10, 1.1102230246251565E-16d);
//        try {
//            double double19 = randomDataImpl0.nextCauchy(20.138852114085488d, (-6.587365386954465d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -6.587 is smaller than, or equal to, the minimum (0): scale (-6.587)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.1742562972484646E-17d + "'", double9 == 3.1742562972484646E-17d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 21L + "'", long12 == 21L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2147483647 + "'", int16 == 2147483647);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 59);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 59 + "'", int1 == 59);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1017612416682803d + "'", double1 == 2.1017612416682803d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(20.30766683149986d, 1.4422183953814958d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.963368833937733E-17d + "'", double2 == 6.963368833937733E-17d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextGamma((-0.016529301951210582d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.017 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("3cb6d77380", objArray1);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0485188062602397E-16d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        org.junit.Assert.assertNotNull(objArray1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.567216986572803E-79d, 1.339598465938762d, 5.566640214978967d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NEGATIVE_INFINITY, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable4, objArray5);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1L);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextSecureInt(0, 49);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 68.60545717301939d + "'", double6 == 68.60545717301939d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 30 + "'", int9 == 30);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray22);
        java.lang.Object[] objArray24 = mathIllegalArgumentException23.getArguments();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable20, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 32.0f);
        java.lang.Number number28 = notStrictlyPositiveException27.getMin();
        boolean boolean29 = notStrictlyPositiveException27.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException27.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable32, objArray33);
        int int35 = maxIterationsExceededException34.getMaxIterations();
        int int36 = maxIterationsExceededException34.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray41);
        java.lang.Object[] objArray43 = mathIllegalArgumentException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, objArray43);
        java.lang.Class<?> wildcardClass45 = objArray43.getClass();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException34, "{0}", objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException18, localizable30, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable51, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable49, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable58, objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(localizable56, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54, localizable55, objArray59);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable48, objArray59);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException14, localizable30, objArray59);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 2.0d, (java.lang.Number) (-4.3190334838657587E157d), true);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray59);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        int int5 = maxIterationsExceededException3.getMaxIterations();
        java.lang.Object[] objArray6 = maxIterationsExceededException3.getArguments();
        int int7 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray19);
        java.lang.Object[] objArray21 = mathIllegalArgumentException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable17, objArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable27, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable17, objArray36);
        java.lang.Number number39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(number39, (java.lang.Number) 1.5574077246549023d, false);
        java.lang.Object[] objArray43 = numberIsTooLargeException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, "{0}", objArray43);
        java.lang.String str45 = mathException37.toString();
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable47 = convergenceException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        java.lang.Object[] objArray49 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray49);
        java.lang.Object[] objArray51 = mathIllegalArgumentException50.getArguments();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable47, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable47, (java.lang.Number) 32.0f);
        java.lang.Number number55 = notStrictlyPositiveException54.getMin();
        boolean boolean56 = notStrictlyPositiveException54.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException54.getSpecificPattern();
        java.lang.Number number58 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable57, number58, (java.lang.Number) (-0.41032129904824216d), (java.lang.Number) 1.1712659507785417d);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable62, (java.lang.Number) 100.0f);
        java.lang.Number number65 = notStrictlyPositiveException64.getMin();
        boolean boolean66 = notStrictlyPositiveException64.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable68, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException78 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable76, objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable74, objArray77);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException72, "hi!", objArray77);
        java.lang.Object[] objArray81 = mathException80.getArguments();
        java.lang.Object[] objArray82 = mathException80.getArguments();
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException64, "0", objArray82);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, localizable57, objArray82);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math.MathException: convergence failed" + "'", str45.equals("org.apache.commons.math.MathException: convergence failed"));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 0 + "'", number55.equals(0));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 0 + "'", number65.equals(0));
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(objArray82);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        java.lang.String str14 = randomDataImpl0.nextHexString(9);
//        int[] intArray17 = randomDataImpl0.nextPermutation(41670, 40);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-61.00673703611574d) + "'", double12 == (-61.00673703611574d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "c00ac4e7a" + "'", str14.equals("c00ac4e7a"));
//        org.junit.Assert.assertNotNull(intArray17);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable3, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 32.0f);
        java.lang.Number number11 = notStrictlyPositiveException10.getMin();
        boolean boolean12 = notStrictlyPositiveException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable13 = notStrictlyPositiveException10.getSpecificPattern();
        java.lang.Number number14 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, number14, (java.lang.Number) (-0.41032129904824216d), (java.lang.Number) 1.1712659507785417d);
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable19, objArray20);
        int int22 = maxIterationsExceededException21.getMaxIterations();
        java.lang.Object[] objArray23 = maxIterationsExceededException21.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(throwable0, "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray23);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(objArray23);
    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextBeta(6.890174336230983d, 0.6601835659372152d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.322305945891773d + "'", double2 == 5.322305945891773d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6718398470219528d + "'", double6 == 0.6718398470219528d);
//    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test315");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double18 = normalDistributionImpl9.sample();
//        double double20 = normalDistributionImpl9.cumulativeProbability(0.0732195152644789d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.35671433996022d + "'", double2 == 5.35671433996022d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.28835455373380897d + "'", double6 == 0.28835455373380897d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-44.9938259916666d) + "'", double17 == (-44.9938259916666d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 39.58221229967447d + "'", double18 == 39.58221229967447d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.38834992300229415d + "'", double20 == 0.38834992300229415d);
//    }

//    @Test
//    public void test316() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test316");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double20 = randomDataImpl0.nextGaussian((double) 77, 0.011026339477238639d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.288641346076946d + "'", double2 == 5.288641346076946d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2923867554399245d + "'", double6 == 0.2923867554399245d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-22.6011723050848d) + "'", double17 == (-22.6011723050848d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 77.0021595097338d + "'", double20 == 77.0021595097338d);
//    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable22 = convergenceException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray24);
        java.lang.Object[] objArray26 = mathIllegalArgumentException25.getArguments();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable22, objArray26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable22, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable32, objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable22, objArray33);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException(localizable22, (java.lang.Number) 1.0703681598182642d, (java.lang.Number) (-11.735926445149872d), (java.lang.Number) 52L);
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException55 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable53, objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable51, objArray54);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException49, "hi!", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable22, objArray54);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-105.77959572529313d), (double) 32.0f, 0.37665202364295614d);
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test319");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextWeibull(1.119539299153502E-112d, 0.28366218546322625d);
//        double double11 = randomDataImpl1.nextBeta(4.547473508864641E-13d, 1.1114875376100244d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3373770092092436d + "'", double4 == 1.3373770092092436d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable6, objArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray9);
        boolean boolean13 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean14 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4);
        java.lang.Object[] objArray16 = mathException15.getArguments();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-105.77959572529313d), (double) 32.0f, 0.37665202364295614d);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.inverseCumulativeProbability(0.5995081831701013d);
        normalDistributionImpl3.reseedRandomGenerator((long) 2147483647);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-105.77959572529313d) + "'", double4 == (-105.77959572529313d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-97.77959572529313d) + "'", double6 == (-97.77959572529313d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.2128932128133587d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08899592599034412d) + "'", double1 == (-0.08899592599034412d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.46792183978854374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6840481268072764d + "'", double1 == 0.6840481268072764d);
    }

//    @Test
//    public void test324() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test324");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeedSecure(0L);
//        randomDataImpl0.reSeed(46L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 71 + "'", int5 == 71);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.9153597418509827d + "'", double7 == 1.9153597418509827d);
//    }

//    @Test
//    public void test325() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test325");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) 'a', (int) ' ');
//        double double18 = randomDataImpl0.nextGaussian(8.106684489637818d, 0.45922383319968013d);
//        randomDataImpl0.reSeed((long) (byte) 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 64.65251160049506d + "'", double12 == 64.65251160049506d);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 7.8420435035862415d + "'", double18 == 7.8420435035862415d);
//    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray14);
        java.lang.Throwable[] throwableArray16 = mathIllegalArgumentException15.getSuppressed();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5", (java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-9.023585134363584d), 2.2404923147350416E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.023585134363582d) + "'", double2 == (-9.023585134363582d));
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test328");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        try {
//            long long5 = randomDataImpl0.nextLong(9L, (long) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 9 is larger than, or equal to, the maximum (0): lower bound (9) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.258479974783693d + "'", double2 == 2.258479974783693d);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6252948841919719d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.48568926651358063d + "'", double1 == 0.48568926651358063d);
    }

//    @Test
//    public void test330() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test330");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl10 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl10.reseedRandomGenerator((long) (byte) 0);
//        double double16 = normalDistributionImpl10.cumulativeProbability((-1.0d));
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl10);
//        java.lang.String str19 = randomDataImpl0.nextSecureHexString((int) (short) 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.37665202364295614d + "'", double16 == 0.37665202364295614d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-27.249522896351838d) + "'", double17 == (-27.249522896351838d));
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "0" + "'", str19.equals("0"));
//    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray9);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException(localizable5, objArray9);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "org.apache.commons.math.MathException: convergence failed", objArray9);
        java.lang.String str14 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 8.447 is larger than, or equal to, the maximum (100)" + "'", str14.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 8.447 is larger than, or equal to, the maximum (100)"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6252948841919719d, 5.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7994617241372165d, 1.2128932128133587d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) 1.0f, (java.lang.Number) 1.4810085152958163d, (java.lang.Number) 2.269105190070966d);
        java.lang.Number number24 = outOfRangeException23.getLo();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.4810085152958163d + "'", number24.equals(1.4810085152958163d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.927270000289983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6385529113687611d + "'", double1 == 1.6385529113687611d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable4, objArray8);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, objArray17);
        java.lang.Object[] objArray19 = mathIllegalArgumentException18.getArguments();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable15, objArray19);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) 32.0f);
        java.lang.Number number23 = notStrictlyPositiveException22.getMin();
        boolean boolean24 = notStrictlyPositiveException22.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable27, objArray28);
        int int30 = maxIterationsExceededException29.getMaxIterations();
        int int31 = maxIterationsExceededException29.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray36);
        java.lang.Object[] objArray38 = mathIllegalArgumentException37.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, objArray38);
        java.lang.Class<?> wildcardClass40 = objArray38.getClass();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException29, "{0}", objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException13, localizable25, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(throwable2, localizable4, objArray38);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0, "89392b942a270257063a49d0cc96aeb08980f817d020df6c61c438f6ec4", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable45 = maxIterationsExceededException44.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0 + "'", number23.equals(0));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNull(localizable45);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test338");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        try {
//            int[] intArray10 = randomDataImpl0.nextPermutation(18, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        java.lang.String str8 = numberIsTooLargeException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException7, "56bbe72af64574b2a6667713a220cf01b5d46d788a99788713f9bc7a4e1", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException("dfcd9353f6fd68866b38e7bc02efc68cf8c855918588b5f14e14c92b57c61b93da9760a6b43d3ffa73c7a5650195e53d7a1f", objArray12);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray12);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertNotNull(objArray12);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        long long14 = randomDataImpl0.nextPoisson(0.5530611949430921d);
//        double double16 = randomDataImpl0.nextChiSquare((double) 52);
//        int int19 = randomDataImpl0.nextSecureInt(35, 52);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-20.968137748696204d) + "'", double12 == (-20.968137748696204d));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 0L + "'", long14 == 0L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 45.48315888275097d + "'", double16 == 45.48315888275097d);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 42 + "'", int19 == 42);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 3.141592653589793d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.141592653589793d + "'", number4.equals(3.141592653589793d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double2 = org.apache.commons.math.util.FastMath.min(Double.NaN, (double) 9L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 48.80259668333492d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray8);
        java.lang.Object[] objArray10 = mathException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable6, objArray10);
        java.lang.Object[] objArray12 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.718281828459045d + "'", number4.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (2.718)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (2.718)"));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.076442011154464d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-17.507085610289575d), (-0.5197241010377943d), 0.5294253307266855d, 2147483647);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.FastMath.asinh(11.183469542488302d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1095768488586333d + "'", double1 == 3.1095768488586333d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-4.3190334838657587E157d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.319033483865758E157d) + "'", double1 == (-4.319033483865758E157d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.273793348760653d, 4.071380944090519E157d, 0.7963446374991774d, 2147483647);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        int int12 = randomDataImpl0.nextZipf(97, (double) 4);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) (short) 100, 77);
//        double double18 = randomDataImpl0.nextBeta(1.5707963267948966d, 0.2654476119283987d);
//        try {
//            int int22 = randomDataImpl0.nextHypergeometric(79, 49, 96);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 96 is larger than the maximum (79): sample size (96) must be less than or equal to population size (79)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.999232923694112d + "'", double18 == 0.999232923694112d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable2, objArray3);
        int int5 = maxIterationsExceededException4.getMaxIterations();
        int int6 = maxIterationsExceededException4.getMaxIterations();
        java.lang.Object[] objArray7 = maxIterationsExceededException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("e", objArray7);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.2227587494850775E-162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2227587494850775E-162d + "'", double1 == 2.2227587494850775E-162d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable5 = convergenceException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray7);
        java.lang.Object[] objArray9 = mathIllegalArgumentException8.getArguments();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable5, objArray9);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable13, objArray17);
        java.lang.Object[] objArray21 = convergenceException20.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable5, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 0.874591382923689d);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable28, objArray29);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray29);
        java.lang.String str32 = mathException31.toString();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException31.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable33, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray39);
        java.lang.Object[] objArray41 = mathIllegalArgumentException40.getArguments();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable37, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable47, objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray48);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException(localizable37, objArray48);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException(localizable37, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable57 = convergenceException56.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray59);
        java.lang.Object[] objArray61 = mathIllegalArgumentException60.getArguments();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable57, objArray61);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException64 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable57, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable57, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable70 = convergenceException69.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable71, objArray72);
        java.lang.Object[] objArray74 = mathIllegalArgumentException73.getArguments();
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(localizable70, objArray74);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable70, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray81 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable70, objArray81);
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException88 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray89 = numberIsTooSmallException88.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable84, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable37, localizable70, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException25, localizable33, (java.lang.Object[]) throwableArray89);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.MathException: " + "'", str32.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(localizable33);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + localizable70 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable70.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(throwableArray89);
    }

//    @Test
//    public void test354() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test354");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure(11L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("39eccbd7470df7a9c394a535528467a07cf282b73bce2977a0108f230f087974e6fceb98536fdee270d8c27e98fa28b6044f", "convergence failed");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: convergence failed");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0b7adc67d4fca181c9a3569bb3d57dffa5079e1492dcb05561e38e2d3f4abcfdf37fa60c5a948cda58250d18119c907f9355" + "'", str9.equals("0b7adc67d4fca181c9a3569bb3d57dffa5079e1492dcb05561e38e2d3f4abcfdf37fa60c5a948cda58250d18119c907f9355"));
//    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test355");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        long long11 = randomDataImpl0.nextSecureLong((long) 2, 10L);
//        int[] intArray14 = randomDataImpl0.nextPermutation(97, (int) (byte) 1);
//        int int17 = randomDataImpl0.nextZipf(78, 0.9434837013395192d);
//        long long20 = randomDataImpl0.nextLong((long) (byte) 0, (long) (short) 100);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertNotNull(intArray14);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 19L + "'", long20 == 19L);
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0523779637351338d + "'", double1 == 1.0523779637351338d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double17 = normalDistributionImpl8.cumulativeProbability((-1.3170218223604584d), 2.140641475065075d);
//        double double19 = normalDistributionImpl8.cumulativeProbability(0.0d);
//        try {
//            double double21 = normalDistributionImpl8.inverseCumulativeProbability((double) 96L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 96 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-9.342507445368732d) + "'", double12 == (-9.342507445368732d));
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.03794591252408147d + "'", double17 == 0.03794591252408147d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.38754848109799234d + "'", double19 == 0.38754848109799234d);
//    }

//    @Test
//    public void test358() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test358");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextZipf(3, 0.417595318551267d);
//        try {
//            double double12 = randomDataImpl0.nextGamma((-0.032756869138569567d), 77.00509280338461d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.033 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 79.59713990693653d + "'", double6 == 79.59713990693653d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3);
        int int7 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 38.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5444866095419745d + "'", double1 == 1.5444866095419745d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5707963267948966d, (java.lang.Number) 2.0d, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(35);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.071380944090519E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1169897120066503d + "'", double1 == 2.1169897120066503d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.169238570007596d, (double) 40);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        double double11 = randomDataImpl0.nextExponential(20.138852114085488d);
//        int int14 = randomDataImpl0.nextPascal(33, 0.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.40638333556074E-16d + "'", double9 == 1.40638333556074E-16d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 20.116651136843824d + "'", double11 == 20.116651136843824d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.27744497381094396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28101811919568764d + "'", double1 == 0.28101811919568764d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable4, objArray8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable16, objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(throwable0, "56bbe72af64574b2a6667713a220cf01b5d46d788a99788713f9bc7a4e1", objArray17);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray11);
        java.lang.Object[] objArray13 = mathIllegalArgumentException12.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable9, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray18);
        java.lang.Object[] objArray20 = mathIllegalArgumentException19.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable16, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException34.getSuppressed();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException7, localizable9, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 4.071380944090519E157d, (java.lang.Number) 0L, true);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException40);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        long long2 = org.apache.commons.math.util.FastMath.min(28L, (long) 40);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 28L + "'", long2 == 28L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0986122886681098d + "'", double1 == 1.0986122886681098d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.28366218546322625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.27629111752846225d + "'", double1 == 0.27629111752846225d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        double double1 = org.apache.commons.math.util.FastMath.abs(130.57717034608623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 130.57717034608623d + "'", double1 == 130.57717034608623d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double1 = org.apache.commons.math.special.Gamma.digamma(3.26708481774098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0231193673522567d + "'", double1 == 1.0231193673522567d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.0485188062602397E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.715474581211435E-6d + "'", double1 == 4.715474581211435E-6d);
    }

//    @Test
//    public void test375() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test375");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double15 = normalDistributionImpl8.getMean();
//        double double16 = normalDistributionImpl8.getStandardDeviation();
//        double double17 = normalDistributionImpl8.getStandardDeviation();
//        double double18 = normalDistributionImpl8.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 19.67538083282162d + "'", double12 == 19.67538083282162d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 35.0d + "'", double16 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 35.0d + "'", double17 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
//    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        java.lang.Number number21 = outOfRangeException19.getLo();
        java.lang.String str22 = outOfRangeException19.toString();
        java.lang.Number number23 = outOfRangeException19.getLo();
        java.lang.Number number24 = outOfRangeException19.getLo();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) -1 + "'", number21.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed" + "'", str22.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) -1 + "'", number23.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (byte) -1 + "'", number24.equals((byte) -1));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable14, objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable12, objArray15);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException10, "hi!", objArray15);
        java.lang.Object[] objArray19 = mathException18.getArguments();
        java.lang.Object[] objArray20 = mathException18.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2, "0", objArray20);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.17453292519943295d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare(5.298342365610589d);
//        double double16 = randomDataImpl0.nextF(1.5707963267948966d, 3.564674068467739d);
//        long long19 = randomDataImpl0.nextSecureLong((long) (byte) 0, (long) 41670);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0549155775750718d + "'", double11 == 1.0549155775750718d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6.631596349889896d + "'", double13 == 6.631596349889896d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.907765581414011d + "'", double16 == 4.907765581414011d);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 41326L + "'", long19 == 41326L);
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 59L, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, 0.6896086545712306d, 2.2291105668993048d);
        normalDistributionImpl3.reseedRandomGenerator((long) 2147483647);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.FastMath.max(45.48315888275097d, (-1.6461019110467638d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 45.48315888275097d + "'", double2 == 45.48315888275097d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.880878861002552d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, Double.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 13);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 47);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 47L + "'", long1 == 47L);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray11);
        java.lang.Object[] objArray13 = mathIllegalArgumentException12.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable9, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray18);
        java.lang.Object[] objArray20 = mathIllegalArgumentException19.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable16, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException34.getSuppressed();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException7, localizable9, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException36.getGeneralPattern();
        java.lang.Class<?> wildcardClass39 = localizable38.getClass();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 0);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) 7);
        double double11 = normalDistributionImpl2.density((double) 35.0f);
        double double12 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.008831868880544757d + "'", double11 == 0.008831868880544757d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 35.0d + "'", double12 == 35.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.269105190070966d, (java.lang.Number) 7.960870902199058d, (java.lang.Number) 0.37665202364295614d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7.960870902199058d + "'", number4.equals(7.960870902199058d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.37665202364295614d + "'", number5.equals(0.37665202364295614d));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.03385530500536467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.9088654161053E-4d + "'", double1 == 5.9088654161053E-4d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.1604453667426053d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare(5.298342365610589d);
//        double double16 = randomDataImpl0.nextGaussian(0.6079460389352821d, 2.873493405344944d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.8605650626253211d + "'", double11 == 0.8605650626253211d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 5.943011184591827d + "'", double13 == 5.943011184591827d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.28700296674051295d + "'", double16 == 0.28700296674051295d);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.2490467924755557d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2490467924755553d + "'", double2 == 3.2490467924755553d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 51.38619813786682d, (java.lang.Number) 0.0d, (java.lang.Number) 5.298342365610589d);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.4433586747974933d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4289758235173803d + "'", double1 == 0.4289758235173803d);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray5);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5", objArray5);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable0, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.5579310247365137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test398");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 10);
//        randomDataImpl0.reSeed();
//        try {
//            int int13 = randomDataImpl0.nextBinomial(35, 7.888609052210118E69d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 7,888,609,052,210,118,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 88.5779025437899d + "'", double6 == 88.5779025437899d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 1.1870539200198031d, number9, true);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray24 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException25 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable23, objArray24);
        int int26 = maxIterationsExceededException25.getMaxIterations();
        java.lang.Throwable[] throwableArray27 = maxIterationsExceededException25.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable14, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable30, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable14, objArray31);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable2, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, objArray39);
        java.lang.Object[] objArray41 = mathIllegalArgumentException40.getArguments();
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable37, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable46, objArray47);
        int int49 = maxIterationsExceededException48.getMaxIterations();
        java.lang.Throwable[] throwableArray50 = maxIterationsExceededException48.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException51 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable37, (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException52 = new org.apache.commons.math.MaxIterationsExceededException(9, localizable2, (java.lang.Object[]) throwableArray50);
        java.lang.Throwable[] throwableArray53 = maxIterationsExceededException52.getSuppressed();
        java.lang.Throwable[] throwableArray54 = maxIterationsExceededException52.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7669549644331817d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.153199691507864d + "'", double1 == 1.153199691507864d);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test401");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) 'a', (int) ' ');
//        randomDataImpl0.reSeed((long) 'a');
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 13.460481098312574d + "'", double12 == 13.460481098312574d);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.abs((-3.300300617072217d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.300300617072217d + "'", double1 == 3.300300617072217d);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        double double12 = randomDataImpl0.nextF((double) 6, (double) 5L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("261573cf1", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.113685824297978d + "'", double12 == 1.113685824297978d);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable9, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, "hi!", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException("0", objArray10);
        org.apache.commons.math.exception.util.Localizable localizable15 = convergenceException14.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(localizable15);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable5 = maxIterationsExceededException3.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3);
        java.lang.Throwable[] throwableArray7 = maxIterationsExceededException3.getSuppressed();
        int int8 = maxIterationsExceededException3.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray23);
        java.lang.Object[] objArray25 = mathIllegalArgumentException24.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable21, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable28 = convergenceException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable37, objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable35, objArray38);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException33, "hi!", objArray38);
        java.lang.Object[] objArray42 = mathException41.getArguments();
        java.lang.Object[] objArray43 = mathException41.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable28, objArray43);
        java.lang.Object[] objArray45 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable21, objArray45);
        java.lang.Throwable[] throwableArray47 = mathIllegalArgumentException46.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(throwableArray47);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray9);
        java.lang.Object[] objArray11 = mathIllegalArgumentException10.getArguments();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable7, objArray11);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 32.0f);
        java.lang.Number number15 = notStrictlyPositiveException14.getMin();
        boolean boolean16 = notStrictlyPositiveException14.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable19, objArray20);
        int int22 = maxIterationsExceededException21.getMaxIterations();
        int int23 = maxIterationsExceededException21.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable26 = convergenceException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, objArray28);
        java.lang.Object[] objArray30 = mathIllegalArgumentException29.getArguments();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable26, objArray30);
        java.lang.Class<?> wildcardClass32 = objArray30.getClass();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException21, "{0}", objArray30);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException5, localizable17, objArray30);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "4d657f87511bbe53ccf2afe46f3a76e27e6c4aff7fc881e5290120335cf", objArray30);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0 + "'", number15.equals(0));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(20.30766683149986d, (-10.842329587419833d), 4.9E-324d, 47);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.649474997576156d, (java.lang.Number) 1.9153597418509827d, (java.lang.Number) 7.990273425901318d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable4, objArray5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("", objArray5);
        java.lang.String str8 = mathException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException7.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable9, objArray10);
        java.lang.Object[] objArray12 = mathException11.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(throwable0, "7bd99ca9566238edf415e66bcf285b66dd207b5bc5c7ab5276e287391f4389988f913f3cb1f1c196b583296726b64497eaf3", objArray12);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.MathException: " + "'", str8.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable5, objArray6);
        int int8 = maxIterationsExceededException7.getMaxIterations();
        int int9 = maxIterationsExceededException7.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable12 = convergenceException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray14);
        java.lang.Object[] objArray16 = mathIllegalArgumentException15.getArguments();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable12, objArray16);
        java.lang.Class<?> wildcardClass18 = objArray16.getClass();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException7, "{0}", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray16);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number22);
        java.lang.Object[] objArray24 = notStrictlyPositiveException23.getArguments();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, "org.apache.commons.math.MathException: convergence failed", objArray24);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        int int9 = maxIterationsExceededException8.getMaxIterations();
        int int10 = maxIterationsExceededException8.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray15);
        java.lang.Object[] objArray17 = mathIllegalArgumentException16.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable13, objArray17);
        java.lang.Class<?> wildcardClass19 = objArray17.getClass();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException8, "{0}", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray17);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException("hi!", objArray17);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test416");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        java.lang.String str14 = randomDataImpl0.nextSecureHexString(78);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-3.7736974634864056d) + "'", double12 == (-3.7736974634864056d));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "496ce94899fb743b09977bfd1cbfc14512576bb52fa6a5f3081092aaa3f8ecf5412a8429e69672" + "'", str14.equals("496ce94899fb743b09977bfd1cbfc14512576bb52fa6a5f3081092aaa3f8ecf5412a8429e69672"));
//    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double1 = org.apache.commons.math.util.FastMath.tan(20.138852114085488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.458063320409825d + "'", double1 == 3.458063320409825d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.0742717944444664E49d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable21 = convergenceException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, objArray23);
        java.lang.Object[] objArray25 = mathIllegalArgumentException24.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable21, objArray25);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException28 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable34 = convergenceException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, objArray36);
        java.lang.Object[] objArray38 = mathIllegalArgumentException37.getArguments();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable34, objArray38);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable34, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable34, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray53 = numberIsTooSmallException52.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable48, (java.lang.Object[]) throwableArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable34, (java.lang.Object[]) throwableArray53);
        java.lang.Throwable[] throwableArray56 = mathIllegalArgumentException55.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(throwableArray56);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        int int2 = org.apache.commons.math.util.FastMath.min(100, 33);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33 + "'", int2 == 33);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Number number21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (-1.0f), number21, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        java.lang.String str29 = numberIsTooLargeException28.toString();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray34);
        java.lang.Object[] objArray36 = mathIllegalArgumentException35.getArguments();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable32, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable42, objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable32, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException28, "org.apache.commons.math.MathException: convergence failed", objArray43);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable1, objArray43);
        java.lang.Throwable[] throwableArray49 = mathException48.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)" + "'", str29.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.0d + "'", double1 == 20.0d);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test423");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        randomDataImpl0.reSeedSecure();
//        double double5 = randomDataImpl0.nextExponential(70.41488413089515d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 94.76274198748554d + "'", double5 == 94.76274198748554d);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.5574077246549023d, 35.82675781532156d);
        double[] doubleArray4 = normalDistributionImpl2.sample(47);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.03268169191673955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5381088142324228d + "'", double1 == 1.5381088142324228d);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test426");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        double double8 = randomDataImpl0.nextChiSquare(1.5061176655412654d);
//        try {
//            double double10 = randomDataImpl0.nextChiSquare((-1.3170218223604584d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.659 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 92.19032820739554d + "'", double6 == 92.19032820739554d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.3685635247944408d + "'", double8 == 3.3685635247944408d);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.015099165163087d);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.FastMath.atan(130.57717034608623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5631381699505487d + "'", double1 == 1.5631381699505487d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.01094247885554892d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable2, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable10 = convergenceException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray12);
        java.lang.Object[] objArray14 = mathIllegalArgumentException13.getArguments();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable10, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray19);
        java.lang.Object[] objArray21 = mathIllegalArgumentException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable17, objArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable27, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, objArray28);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray36 = numberIsTooSmallException35.getSuppressed();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException8, localizable10, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable40 = convergenceException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray42);
        java.lang.Object[] objArray44 = mathIllegalArgumentException43.getArguments();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable40, objArray44);
        java.lang.Class<?> wildcardClass46 = objArray44.getClass();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable38, objArray44);
        java.lang.Object[] objArray48 = mathException47.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(32, localizable10, objArray48);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray8);
        java.lang.Object[] objArray10 = mathIllegalArgumentException9.getArguments();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable6, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable17, objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable14, objArray18);
        java.lang.Object[] objArray22 = convergenceException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException("7bd99ca9566238edf415e66bcf285b66dd207b5bc5c7ab5276e287391f4389988f913f3cb1f1c196b583296726b64497eaf3", objArray22);
        java.lang.Throwable[] throwableArray25 = convergenceException24.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-1.0f), (java.lang.Number) 0.0d, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable6, objArray7);
        int int9 = maxIterationsExceededException8.getMaxIterations();
        int int10 = maxIterationsExceededException8.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable13 = convergenceException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray15);
        java.lang.Object[] objArray17 = mathIllegalArgumentException16.getArguments();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable13, objArray17);
        java.lang.Class<?> wildcardClass19 = objArray17.getClass();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException8, "{0}", objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable23 = convergenceException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray25 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, objArray25);
        java.lang.Object[] objArray27 = mathIllegalArgumentException26.getArguments();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable23, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException30 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable33, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray34);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable23, objArray34);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable44 = convergenceException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray46);
        java.lang.Object[] objArray48 = mathIllegalArgumentException47.getArguments();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable44, objArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 32.0f);
        java.lang.Number number52 = notStrictlyPositiveException51.getMin();
        boolean boolean53 = notStrictlyPositiveException51.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable54 = notStrictlyPositiveException51.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable56 = convergenceException55.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray58 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, objArray58);
        java.lang.Object[] objArray60 = mathIllegalArgumentException59.getArguments();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(localizable56, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable54, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable66, objArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable64, objArray67);
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable73, objArray74);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable71, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException69, localizable70, objArray74);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5", objArray74);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable54, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable23, objArray74);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 0 + "'", number52.equals(0));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 548.3161232732465d + "'", double1 == 548.3161232732465d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double2 = org.apache.commons.math.util.FastMath.atan2(8.726826950457602E-5d, 5.683624804795088E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267942453d + "'", double2 == 1.5707963267942453d);
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test435");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        randomDataImpl0.reSeedSecure((long) '4');
//        int[] intArray22 = randomDataImpl0.nextPermutation((int) '4', 1);
//        try {
//            double double25 = randomDataImpl0.nextUniform(1.153199691507864d, (-9.023585134363582d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1.153 is larger than, or equal to, the maximum (-9.024): lower bound (1.153) must be strictly less than upper bound (-9.024)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1054893763011588d + "'", double2 == 1.1054893763011588d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.2571421351811887d + "'", double6 == 1.2571421351811887d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-18.908816441509625d) + "'", double17 == (-18.908816441509625d));
//        org.junit.Assert.assertNotNull(intArray22);
//    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException5.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, localizable1, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable9 = convergenceException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray11);
        java.lang.Object[] objArray13 = mathIllegalArgumentException12.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(localizable9, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable16 = convergenceException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, objArray18);
        java.lang.Object[] objArray20 = mathIllegalArgumentException19.getArguments();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable16, objArray20);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable26, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException34.getSuppressed();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException7, localizable9, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 4.071380944090519E157d, (java.lang.Number) 0L, true);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) (-1L), (java.lang.Number) 1.4653112823676238d, false);
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, number45, (java.lang.Number) 64.65251160049506d, false);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(throwableArray35);
    }
}

