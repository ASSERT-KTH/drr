import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextZipf((int) (byte) 0, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.special.Erf.erf(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10.0f, 32.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextLong((long) (short) 10, 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.floor(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        float float2 = org.apache.commons.math.util.FastMath.max(10.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextInt((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (0): lower bound (97) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(Double.NaN, (double) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test020");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 115.38511591030161d + "'", double6 == 115.38511591030161d);
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.649558242894909d + "'", double1 == 2.649558242894909d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

//    @Test
//    public void test026() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test026");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextGaussian(32.0d, (double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 22.21848783030661d + "'", double6 == 22.21848783030661d);
//    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double3 = randomDataImpl1.nextChiSquare((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        long long1 = org.apache.commons.math.util.FastMath.round(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

//    @Test
//    public void test043() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test043");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        try {
//            long long8 = randomDataImpl0.nextPoisson((-0.8813735870195429d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.881 is smaller than, or equal to, the minimum (0): mean (-0.881)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 54.26160623230651d + "'", double6 == 54.26160623230651d);
//    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.acosh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure(0L);
        try {
            double double5 = randomDataImpl0.nextGamma((double) '4', (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): beta");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5772156649015329d, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9434837013395192d + "'", double2 == 0.9434837013395192d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08883204370725284d + "'", double1 == 0.08883204370725284d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0, 0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int2 = org.apache.commons.math.util.FastMath.max(7, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 0, (-0.5063656411097588d), (double) 0, (int) (byte) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(10.076442011154464d, (double) (short) 0, 0.0d, 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.447150561318425d + "'", double1 == 8.447150561318425d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double1 = org.apache.commons.math.util.FastMath.log10(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        try {
//            int int8 = randomDataImpl0.nextSecureInt(1, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double2 = randomDataImpl0.nextChiSquare(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        try {
//            double double11 = randomDataImpl0.nextT((double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "8518d173e9eb18fab07311f4dfc09f752389cd99301752d051a39d5310e297d16d620b53e4cc79f6e5dd1b215b3993d61b02" + "'", str9.equals("8518d173e9eb18fab07311f4dfc09f752389cd99301752d051a39d5310e297d16d620b53e4cc79f6e5dd1b215b3993d61b02"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3796077390275217d + "'", double1 == 0.3796077390275217d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 10, (-0.5063656411097588d), (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.506 is smaller than, or equal to, the minimum (0): standard deviation (-0.506)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.8813735870195429d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) '4', 0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7353096508879174E-81d + "'", double2 == 2.7353096508879174E-81d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertNull(localizable1);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        try {
//            randomDataImpl0.setSecureAlgorithm("7bd99ca9566238edf415e66bcf285b66dd207b5bc5c7ab5276e287391f4389988f913f3cb1f1c196b583296726b64497eaf3", "convergence failed");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: convergence failed");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ad3b56731b4347bdd0133f3413e6b70e5debeac1053c02647ac372bfc83707135eb3b7f7a6a8f8dfff48b45c2ef972b8b2d1" + "'", str9.equals("ad3b56731b4347bdd0133f3413e6b70e5debeac1053c02647ac372bfc83707135eb3b7f7a6a8f8dfff48b45c2ef972b8b2d1"));
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2227587494850775E-162d + "'", double1 == 2.2227587494850775E-162d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5553480614894135d + "'", double1 == 3.5553480614894135d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextF((double) 10, 35.0d);
//        try {
//            double double11 = randomDataImpl0.nextUniform((double) 1.0f, (double) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.7561009253020676d + "'", double8 == 1.7561009253020676d);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int2 = org.apache.commons.math.util.FastMath.min(10, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta(1.5574077246549023d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.857");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test086");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        try {
//            double double9 = randomDataImpl0.nextF(0.0d, (double) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 149.59574312241196d + "'", double6 == 149.59574312241196d);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9836065573770492d + "'", double1 == 0.9836065573770492d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.04323229440977d) + "'", double1 == (-1.04323229440977d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double2 = org.apache.commons.math.util.FastMath.min(0.08883204370725284d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test093");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        try {
//            java.lang.String str4 = randomDataImpl0.nextHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.403827102906973d + "'", double2 == 0.403827102906973d);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            long long4 = randomDataImpl1.nextSecureLong((long) 10, (long) 7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (7): lower bound (10) must be strictly less than upper bound (7)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 3.5553480614894135d, (double) 10.0f, (int) ' ');
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        double double5 = normalDistributionImpl2.cumulativeProbability(2.718281828459045d);
        try {
            double double8 = normalDistributionImpl2.cumulativeProbability(0.9999999958776927d, (double) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.417595318551267d + "'", double5 == 0.417595318551267d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.112963841460668E31d + "'", double1 == 8.112963841460668E31d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        try {
//            int int6 = randomDataImpl0.nextHypergeometric((int) (byte) 1, (int) 'a', 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (1): number of successes (97) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1902576054103355d + "'", double2 == 3.1902576054103355d);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9999999958776927d, (double) 32.0f, 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 0.417595318551267d, true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 100.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1L, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            java.lang.String str3 = randomDataImpl1.nextSecureHexString((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.649558242894909d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.9836065573770492d, 0.9999999999999999d, (double) 10, 52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6295941819582136d + "'", double4 == 0.6295941819582136d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        double double1 = org.apache.commons.math.special.Gamma.digamma(35.82675781532156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.564674068467739d + "'", double1 == 3.564674068467739d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.apache.commons.math.util.FastMath.max(5, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextWeibull(0.0d, 0.9999999999999999d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure(0L);
        try {
            double double5 = randomDataImpl0.nextUniform(0.9999999999999999d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("", "hi!");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: hi!");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 10, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.special.Gamma.digamma(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) 1);
        try {
            int int5 = randomDataImpl0.nextBinomial((int) (byte) 1, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 52 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.47712125471966244d + "'", double1 == 0.47712125471966244d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0392740995950414d + "'", double1 == 2.0392740995950414d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double1 = org.apache.commons.math.util.FastMath.tanh(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.0d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.984807753012208d + "'", double1 == 0.984807753012208d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.String str4 = mathException3.getPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        try {
//            double double10 = randomDataImpl0.nextUniform((double) 32.0f, (double) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (10): lower bound (32) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextZipf(1, (-0.9999999999999999d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): exponent (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4422183953814958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2300693823966125d + "'", double1 == 3.2300693823966125d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.211102550927978d + "'", double1 == 7.211102550927978d);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            randomDataImpl1.setSecureAlgorithm("hi!", "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.8654957446839106d + "'", double4 == 0.8654957446839106d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 22.040582766214527d + "'", double11 == 22.040582766214527d);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28366218546322625d + "'", double1 == 0.28366218546322625d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 10.0f, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999939016400656d + "'", double2 == 0.9999939016400656d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable14, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        boolean boolean31 = numberIsTooSmallException30.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double2 = org.apache.commons.math.util.FastMath.atan2(8.0d, 3.2300693823966125d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1870539200198031d + "'", double2 == 1.1870539200198031d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(211.718280929568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.695181088883283d + "'", double1 == 3.695181088883283d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 100, 0.0d, 0.8344894259657916d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9389941379013969d + "'", double1 == 0.9389941379013969d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.112963841460668E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.04323229440977d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double12 = randomDataImpl0.nextUniform(0.0d, 0.5772156649015329d);
//        try {
//            int int16 = randomDataImpl0.nextHypergeometric(5, (int) (short) 0, 97);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (5): sample size (97) must be less than or equal to population size (5)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "3659a0bf3b0556314f6d8c9e8032f42107972fc2e050a97a885ce0ff19dbc26491713f1e544501f40cc2a54a092df0a1139f" + "'", str9.equals("3659a0bf3b0556314f6d8c9e8032f42107972fc2e050a97a885ce0ff19dbc26491713f1e544501f40cc2a54a092df0a1139f"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4369754810260937d + "'", double12 == 0.4369754810260937d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(35.82675781532156d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6252948841919718d + "'", double1 == 0.6252948841919718d);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        try {
//            long long9 = randomDataImpl0.nextSecureLong(0L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 173.89414715234523d + "'", double6 == 173.89414715234523d);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        int int2 = org.apache.commons.math.util.FastMath.min(5, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable14, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException35 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable33, objArray34);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException(localizable31, objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray34);
        java.lang.String str38 = mathIllegalArgumentException37.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed" + "'", str38.equals("org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.8462022268348846d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-105.77959572529313d) + "'", double1 == (-105.77959572529313d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 1L, (-0.8813735870195429d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.881 is smaller than, or equal to, the minimum (0): standard deviation (-0.881)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        double double4 = normalDistributionImpl2.density(0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.011026339477238639d + "'", double4 == 0.011026339477238639d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException4 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable2, objArray3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(localizable0, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException11 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable9, objArray10);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable7, objArray10);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable6, objArray10);
        java.lang.Object[] objArray14 = mathException5.getArguments();
        try {
            java.lang.String str15 = mathException5.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(211.718280929568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 211.71828092956804d + "'", double1 == 211.71828092956804d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 2.7353096508879174E-81d, number1, (java.lang.Number) 10.0d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) -1, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable6, objArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray9);
        java.lang.Object[] objArray13 = mathException12.getArguments();
        java.lang.Object[] objArray14 = mathException12.getArguments();
        java.lang.Throwable throwable15 = null;
        try {
            mathException12.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 10.0f, (-105.77959572529313d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.7353096508879174E-81d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.567216986572803E-79d + "'", double1 == 1.567216986572803E-79d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextF(4.158638853279167d, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8402864822065015d + "'", double1 == 1.8402864822065015d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException14);
        java.lang.Object[] objArray16 = mathIllegalArgumentException14.getArguments();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0794415416798357d + "'", double1 == 2.0794415416798357d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 74.20994852478785d + "'", double1 == 74.20994852478785d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray24 = numberIsTooSmallException23.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) throwableArray24);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray24);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 0, (java.lang.Number) 0L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-20.32515112776791d), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6199568117265704d) + "'", double2 == (-1.6199568117265704d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.984807753012208d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9848077530122081d + "'", double1 == 0.9848077530122081d);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl1.nextCauchy((double) 4L, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.929510498066484d + "'", double4 == 0.929510498066484d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-4.511605389812224d) + "'", double11 == (-4.511605389812224d));
//    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test192");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextSecureInt((int) ' ', 100);
//        try {
//            int int12 = randomDataImpl0.nextPascal((int) (byte) -1, 10.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 363.0524728113744d + "'", double6 == 363.0524728113744d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 68 + "'", int9 == 68);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.46792183978854374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1114875376100244d + "'", double1 == 1.1114875376100244d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 1, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9434837013395192d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (-1.0f), 35.82675781532156d, 2.0392740995950414d, 2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 52, 2.649558242894909d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.331123969810432E-48d + "'", double2 == 9.331123969810432E-48d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5061176655412654d + "'", double1 == 1.5061176655412654d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        double double5 = normalDistributionImpl2.getStandardDeviation();
        try {
            double double7 = normalDistributionImpl2.inverseCumulativeProbability((double) 32.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 32 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.ceil(102.21046194254437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 103.0d + "'", double1 == 103.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NEGATIVE_INFINITY, number1, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Number number5 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + Double.NEGATIVE_INFINITY + "'", number5.equals(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        java.lang.String str5 = numberIsTooLargeException4.toString();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: -0.881 is larger than, or equal to, the maximum (100)"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

//    @Test
//    public void test205() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test205");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6079460389352821d + "'", double0 == 0.6079460389352821d);
//    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) 10, 3.2300693823966125d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9981159886028054d + "'", double2 == 0.9981159886028054d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 11L, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.0794415416798357d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test209() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test209");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double double15 = randomDataImpl0.nextGamma(10.076442011154464d, 19.13879622348371d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-7.170036909513635d) + "'", double12 == (-7.170036909513635d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 130.5771703460862d + "'", double15 == 130.5771703460862d);
//    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test210");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) 'a', (int) ' ');
//        try {
//            double double18 = randomDataImpl0.nextF(1.567216986572803E-79d, Double.NEGATIVE_INFINITY);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -∞ is smaller than, or equal to, the minimum (0): degrees of freedom (-∞)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-7.46315676599472d) + "'", double12 == (-7.46315676599472d));
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextUniform((double) 97L, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (10): lower bound (97) must be strictly less than upper bound (10)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.log(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.874591382923689d + "'", double1 == 0.874591382923689d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7546229182176941d + "'", double1 == 0.7546229182176941d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 100, (double) (byte) -1, (double) 0.0f, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
        try {
            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4505495340698077d) + "'", double1 == (-0.4505495340698077d));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.5707963267948966d, (-105.77959572529313d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -105.78 is smaller than, or equal to, the minimum (0): standard deviation (-105.78)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 3L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) 1);
        try {
            randomDataImpl0.setSecureAlgorithm("hi!", "1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.expm1(22.6765125960267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.051545121200191E9d + "'", double1 == 7.051545121200191E9d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 103.0d, (java.lang.Number) 0.8128310357656914d, true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test226");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        long long11 = randomDataImpl0.nextSecureLong((long) 2, 10L);
//        int[] intArray14 = randomDataImpl0.nextPermutation(97, (int) (byte) 1);
//        try {
//            int[] intArray17 = randomDataImpl0.nextPermutation(6, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 2L + "'", long11 == 2L);
//        org.junit.Assert.assertNotNull(intArray14);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0L, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.special.Erf.erf(8.112963841460668E31d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextF((double) 10, 35.0d);
//        try {
//            double double10 = randomDataImpl0.nextExponential((-0.4505495340698077d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.451 is smaller than, or equal to, the minimum (0): mean (-0.451)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3148600980499343d + "'", double8 == 1.3148600980499343d);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6252948841919718d, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6252948841919719d + "'", double2 == 0.6252948841919719d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        boolean boolean11 = notStrictlyPositiveException8.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(1.567216986572803E-79d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.071380944090519E157d + "'", double1 == 4.071380944090519E157d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable3, objArray7);
        java.lang.Class<?> wildcardClass9 = objArray7.getClass();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(localizable1, objArray7);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable0, objArray7);
        try {
            java.lang.String str12 = mathException11.getPattern();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10L, (float) 97);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0575056994167058E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0575056994167058E-16d + "'", double1 == 1.0575056994167058E-16d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 10, 9L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextF((double) 10, 35.0d);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2290050093398686d + "'", double8 == 1.2290050093398686d);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure((long) (byte) 1);
        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
        randomDataImpl0.reSeedSecure((long) (short) 100);
        randomDataImpl0.reSeedSecure((long) (short) -1);
        try {
            int int12 = randomDataImpl0.nextInt(6, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 6 is larger than, or equal to, the maximum (1): lower bound (6) must be strictly less than upper bound (1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.874591382923689d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5491895702039902d + "'", double1 == 0.5491895702039902d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '4', 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            double double14 = randomDataImpl1.nextWeibull(0.0d, 10.076442011154464d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1034194088040175d + "'", double4 == 1.1034194088040175d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 52.916048535548434d + "'", double11 == 52.916048535548434d);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.3230978683634768d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test250");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        try {
//            java.lang.String str14 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 21.761451804892648d + "'", double12 == 21.761451804892648d);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.3978952727983707d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 5, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.888609052210118E69d + "'", double2 == 7.888609052210118E69d);
    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        int int15 = randomDataImpl1.nextHypergeometric((int) (byte) 100, (int) '#', 52);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0773225613564128d + "'", double4 == 1.0773225613564128d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 67.37427577395592d + "'", double11 == 67.37427577395592d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 17 + "'", int15 == 17);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.211102550927978d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6639263015294263d + "'", double1 == 2.6639263015294263d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.ceil(8.447150561318425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test257() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test257");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        int[] intArray15 = randomDataImpl0.nextPermutation((int) 'a', (int) ' ');
//        randomDataImpl0.reSeed((long) 'a');
//        try {
//            int[] intArray20 = randomDataImpl0.nextPermutation((int) ' ', 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (32): permutation size (35) exceeds permuation domain (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 23.871163416207043d + "'", double12 == 23.871163416207043d);
//        org.junit.Assert.assertNotNull(intArray15);
//    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 0);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) 7);
        double double10 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 35.0d + "'", double10 == 35.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.special.Erf.erf(211.718280929568d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test260");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare(5.298342365610589d);
//        try {
//            double double16 = randomDataImpl0.nextWeibull((double) 0L, 0.46792183978854374d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9293691674070165d + "'", double11 == 0.9293691674070165d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.674337205151919d + "'", double13 == 4.674337205151919d);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 10);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) (byte) 1);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 22.16932672019457d + "'", double6 == 22.16932672019457d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "e" + "'", str11.equals("e"));
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 9L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.140641475065075d + "'", double1 == 2.140641475065075d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double2 = org.apache.commons.math.util.FastMath.max(2.718281828459045d, 33.63261756898911d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.63261756898911d + "'", double2 == 33.63261756898911d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        java.lang.Throwable[] throwableArray15 = maxIterationsExceededException13.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable2, (java.lang.Object[]) throwableArray15);
        int int17 = maxIterationsExceededException16.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.special.Erf.erf(0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8357835894321308d + "'", double1 == 0.8357835894321308d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable14, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable32 = convergenceException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, objArray34);
        java.lang.Object[] objArray36 = mathIllegalArgumentException35.getArguments();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable32, objArray36);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable32, (java.lang.Number) 32.0f);
        java.lang.Number number40 = notStrictlyPositiveException39.getMin();
        boolean boolean41 = notStrictlyPositiveException39.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException39.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable46, objArray47);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable44, objArray47);
        java.lang.Throwable[] throwableArray50 = mathException49.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException39, "{0}", (java.lang.Object[]) throwableArray50);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable14, (java.lang.Object[]) throwableArray50);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0 + "'", number40.equals(0));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(throwableArray50);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        try {
//            double double16 = normalDistributionImpl8.inverseCumulativeProbability((-1.6199568117265704d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1.62 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-7.3649608403233575d) + "'", double12 == (-7.3649608403233575d));
//        org.junit.Assert.assertNotNull(doubleArray14);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            double double20 = randomDataImpl0.nextGamma((double) (short) 0, 0.9848077530122081d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.72385544918475d + "'", double2 == 1.72385544918475d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8486588344834177d + "'", double6 == 0.8486588344834177d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-21.64224017890133d) + "'", double17 == (-21.64224017890133d));
//    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test271");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution8 = null;
//        try {
//            double double9 = randomDataImpl0.nextInversionDeviate(continuousDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 0);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) 7);
        double double11 = normalDistributionImpl2.density(2.0392740995950414d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.011107294888830867d + "'", double11 == 0.011107294888830867d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.0d, 2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException("0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray6);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(localizable9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 2L, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable4 = convergenceException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray6);
        java.lang.Object[] objArray8 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable4, objArray8);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException("0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException("convergence failed", objArray8);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416906d + "'", double1 == 0.5514266812416906d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution18 = null;
//        try {
//            int int19 = randomDataImpl0.nextInversionDeviate(integerDistribution18);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.833797981379118d + "'", double2 == 0.833797981379118d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6015582526107854d + "'", double6 == 1.6015582526107854d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-26.12602487702836d) + "'", double17 == (-26.12602487702836d));
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double2 = org.apache.commons.math.util.FastMath.max(0.37665202364295614d, 0.08966721745884815d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.37665202364295614d + "'", double2 == 0.37665202364295614d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test283");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        double double8 = randomDataImpl0.nextF((double) 10, 35.0d);
//        try {
//            double double11 = randomDataImpl0.nextF((double) (short) -1, 0.9459647154445872d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): degrees of freedom (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0859200672766416d + "'", double8 == 1.0859200672766416d);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException(localizable0, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable8 = convergenceException7.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable8);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = normalDistributionImpl7.inverseCumulativeProbability((double) (byte) 1);
//        double double14 = normalDistributionImpl7.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.062082127705336d + "'", double4 == 1.062082127705336d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-11.735926445149872d) + "'", double11 == (-11.735926445149872d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + Double.POSITIVE_INFINITY + "'", double13 == Double.POSITIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 80.85070966037884d + "'", double14 == 80.85070966037884d);
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.695181088883283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.138852114085488d + "'", double1 == 20.138852114085488d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.016529301951210582d) + "'", double1 == (-0.016529301951210582d));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
        try {
            double double6 = randomDataImpl0.nextWeibull(0.0d, (double) 32.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6457010490141613d, 74.20994852478785d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6457010490141613d + "'", double2 == 0.6457010490141613d);
    }

//    @Test
//    public void test290() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test290");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        try {
//            double double8 = normalDistributionImpl2.cumulativeProbability(0.6483608274590866d, 0.3796077390275217d);
//            org.junit.Assert.fail("Expected anonymous exception");
//        } catch (java.lang.IllegalArgumentException e) {
//            if (!e.getClass().isAnonymousClass()) {
//                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
//            }
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 38.01297053755719d + "'", double4 == 38.01297053755719d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
//    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        float float2 = org.apache.commons.math.util.FastMath.min(2.0f, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(130.5771703460862d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 130.57717034608623d + "'", double1 == 130.57717034608623d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.46792183978854374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4376573717755923d + "'", double1 == 0.4376573717755923d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-105.77959572529313d), (double) 32.0f, 0.37665202364295614d);
        double double4 = normalDistributionImpl3.getMean();
        normalDistributionImpl3.reseedRandomGenerator((long) 5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-105.77959572529313d) + "'", double4 == (-105.77959572529313d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.128136236237445d + "'", double1 == 2.128136236237445d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
        int int6 = randomDataImpl0.nextPascal((int) '#', (double) 1.0f);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 2, (double) 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03844259002118798d + "'", double2 == 0.03844259002118798d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5772156649015329d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1712659507785417d + "'", double1 == 1.1712659507785417d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray20 = numberIsTooSmallException19.getSuppressed();
        java.lang.Number number21 = numberIsTooSmallException19.getMin();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        int int14 = maxIterationsExceededException13.getMaxIterations();
        java.lang.Throwable[] throwableArray15 = maxIterationsExceededException13.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException16 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable2, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable18, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable2, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException21);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray19);
        java.lang.Object[] objArray21 = mathIllegalArgumentException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable17, objArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable27, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable17, objArray36);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 2.128136236237445d, (java.lang.Number) 10.331729836362769d, false);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.2535588913246345d, 0.0d, 0.17453292519943295d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) '#', "7bd99ca9566238edf415e66bcf285b66dd207b5bc5c7ab5276e287391f4389988f913f3cb1f1c196b583296726b64497eaf3", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 10, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        try {
//            int int9 = randomDataImpl0.nextSecureInt(52, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3794215498493797d + "'", double2 == 0.3794215498493797d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.08762116706463d + "'", double6 == 3.08762116706463d);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.expm1(8.292855031611916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3994.2244190822403d + "'", double1 == 3994.2244190822403d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10516633568161556d + "'", double1 == 0.10516633568161556d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.011107294888830867d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9385886680003617E-4d + "'", double1 == 1.9385886680003617E-4d);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test313");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextT((double) '#');
//        try {
//            int int6 = randomDataImpl1.nextZipf(0, 0.9999999958776927d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.457278301361457d + "'", double3 == 0.457278301361457d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 0, 0.20621287249438264d, 0.28366218546322625d, 1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test318");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        try {
//            double double6 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1050518235546933d + "'", double4 == 1.1050518235546933d);
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.special.Gamma.digamma(103.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.629866764257651d + "'", double1 == 4.629866764257651d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 91);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.tan(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.asin((-7.4121522588382405d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double2 = org.apache.commons.math.util.FastMath.min(3.2300693823966125d, 0.6813756275810965d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6813756275810965d + "'", double2 == 0.6813756275810965d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-7.4121522588382405d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double12 = randomDataImpl0.nextUniform(0.0d, 0.5772156649015329d);
//        try {
//            int int15 = randomDataImpl0.nextInt((int) 'a', 97);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (97): lower bound (97) must be strictly less than upper bound (97)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "216a2ae62601de81b633f8cccd87aad417b3a3dbaf1b8ef000a9c11e4b29fb4c9c31a4845c686bda28e80b351952da3a2107" + "'", str9.equals("216a2ae62601de81b633f8cccd87aad417b3a3dbaf1b8ef000a9c11e4b29fb4c9c31a4845c686bda28e80b351952da3a2107"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4277056352450599d + "'", double12 == 0.4277056352450599d);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4772803120976288d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4772803120976288d + "'", double2 == 0.4772803120976288d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(20.807541096843487d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04923284879062803d + "'", double1 == 0.04923284879062803d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double3 = normalDistributionImpl2.sample();
//        double double6 = normalDistributionImpl2.cumulativeProbability(2.0d, 20.30766683149986d);
//        try {
//            double double8 = normalDistributionImpl2.inverseCumulativeProbability((double) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.934124936505501d + "'", double3 == 14.934124936505501d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.20621287249438264d + "'", double6 == 0.20621287249438264d);
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-1.8462022268348846d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = normalDistributionImpl7.inverseCumulativeProbability(0.9999999958776927d);
//        double double16 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) 8);
//        try {
//            double double18 = normalDistributionImpl7.inverseCumulativeProbability(1.3440585709080678E43d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.6844350521331375d + "'", double4 == 0.6844350521331375d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-18.128884510034258d) + "'", double11 == (-18.128884510034258d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 211.718280929568d + "'", double13 == 211.718280929568d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.08966721745884815d + "'", double16 == 0.08966721745884815d);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.asinh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        java.lang.Number number11 = notStrictlyPositiveException8.getMin();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0 + "'", number11.equals(0));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.004655363473036653d, (java.lang.Number) 5, (java.lang.Number) 2.695071770287532d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9459647154445872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.785022317073703d + "'", double1 == 1.785022317073703d);
    }

//    @Test
//    public void test338() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test338");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        try {
//            double double10 = randomDataImpl0.nextChiSquare((-105.77959572529313d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -52.89 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
//    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        int int1 = org.apache.commons.math.util.FastMath.abs(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 7 + "'", int1 == 7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1, (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, (double) 5L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test342() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test342");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 1, (int) (short) 10);
//        randomDataImpl0.reSeed();
//        try {
//            int int13 = randomDataImpl0.nextBinomial(59, 62.052186898622494d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 62.052 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 146.6782315552325d + "'", double6 == 146.6782315552325d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
//    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double double2 = org.apache.commons.math.util.FastMath.min(1.9385886680003617E-4d, 0.08966721745884815d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9385886680003617E-4d + "'", double2 == 1.9385886680003617E-4d);
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test344");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        try {
//            double double10 = randomDataImpl0.nextGaussian(0.6252948841919718d, (double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double double1 = org.apache.commons.math.util.FastMath.floor(3994.2244190822403d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3994.0d + "'", double1 == 3994.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException14);
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable17 = convergenceException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray19 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, objArray19);
        java.lang.Object[] objArray21 = mathIllegalArgumentException20.getArguments();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable17, objArray21);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException29 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable27, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException(localizable17, objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException(localizable17, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException15, localizable17, objArray36);
        java.lang.Object[] objArray39 = null;
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37, "dfcd9353f6fd68866b38e7bc02efc68cf8c855918588b5f14e14c92b57c61b93da9760a6b43d3ffa73c7a5650195e53d7a1f", objArray39);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.4376573717755923d, (double) (short) 1, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test348");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        try {
//            double double12 = randomDataImpl0.nextWeibull(1.785022317073703d, (-0.8813735870195429d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.881 is smaller than, or equal to, the minimum (0): scale (-0.881)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (-1.0f), (double) 10L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.4422183953814958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12130284660365231d) + "'", double1 == (-0.12130284660365231d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) 100, 0.32450856213773277d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.32450856213773277d + "'", double2 == 0.32450856213773277d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 2, 0.8344894259657916d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7963446374991774d + "'", double2 == 0.7963446374991774d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.35769113710681816d, 0.0d, 0.8128310357656914d, 91);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(17.13167546807732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 981.5727003086395d + "'", double1 == 981.5727003086395d);
    }

//    @Test
//    public void test355() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test355");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(59);
//        try {
//            int[] intArray14 = randomDataImpl0.nextPermutation(0, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (0): permutation size (100) exceeds permuation domain (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.338066758813489E-17d + "'", double9 == 4.338066758813489E-17d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ae322e3500f2b3803a60ab4de18ebb6bc66a6d6db281d1204a82790c469" + "'", str11.equals("ae322e3500f2b3803a60ab4de18ebb6bc66a6d6db281d1204a82790c469"));
//    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2);
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, (float) 4);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.447150561318425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        boolean boolean10 = notStrictlyPositiveException8.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException8.getSpecificPattern();
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException(localizable11, number12, (java.lang.Number) (-0.41032129904824216d), (java.lang.Number) 1.1712659507785417d);
        java.lang.Number number16 = outOfRangeException15.getLo();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (-0.41032129904824216d) + "'", number16.equals((-0.41032129904824216d)));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        java.lang.Number number10 = notStrictlyPositiveException8.getMin();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable3 = convergenceException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
        java.lang.Object[] objArray7 = mathIllegalArgumentException6.getArguments();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable3, objArray7);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable3, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable13, objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable3, objArray14);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (-20.32515112776791d), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray22 = numberIsTooSmallException21.getSuppressed();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(throwable0, localizable1, (java.lang.Object[]) throwableArray22);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.10516633568161556d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.acos(76.48788695911851d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.tanh(9.331123969810432E-48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.331123969810432E-48d + "'", double1 == 9.331123969810432E-48d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.6252948841919718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6252948841919719d + "'", double1 == 0.6252948841919719d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5530611949430921d, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5530611949430921d + "'", double2 == 0.5530611949430921d);
    }

//    @Test
//    public void test371() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test371");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double7 = randomDataImpl0.nextT(5.298342365610589d);
//        randomDataImpl0.reSeed((long) (short) -1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 79 + "'", int5 == 79);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3643932802642205d + "'", double7 == 0.3643932802642205d);
//    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test372");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        double double11 = randomDataImpl0.nextExponential(20.138852114085488d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("473ddaf351cb63cab9c9cd31436464daa72aa816abbf3a1faa79244af67f4abbaa8690178c59a11623ca78f81b50796dd1af", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 8 + "'", int5 == 8);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.7209179372603965E-17d + "'", double9 == 4.7209179372603965E-17d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.891811089141791d + "'", double11 == 10.891811089141791d);
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) -1, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.08966721745884815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4810085152958163d + "'", double1 == 1.4810085152958163d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.01094247885554892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22200967719867387d + "'", double1 == 0.22200967719867387d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 0);
        double double7 = normalDistributionImpl2.getStandardDeviation();
        normalDistributionImpl2.reseedRandomGenerator((long) 7);
        normalDistributionImpl2.reseedRandomGenerator((long) 2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 35.0d + "'", double7 == 35.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 59L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1006052018952572E25d + "'", double1 == 2.1006052018952572E25d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 4.0f, 3994.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.001001501918542427d + "'", double2 == 0.001001501918542427d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.9836065573770492d };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable14, objArray25);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 1, (java.lang.Number) 2, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 74.20994852478785d, true);
        java.lang.Throwable[] throwableArray35 = numberIsTooSmallException34.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.990273425901318d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 457.80894445968283d + "'", double1 == 457.80894445968283d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.String str4 = convergenceException3.getPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-53.40321167064011d), 1.0703681598182642d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test386() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test386");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        try {
//            int int6 = randomDataImpl0.nextZipf(0, 0.7806925186793796d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.94444820012561d + "'", double2 == 2.94444820012561d);
//    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        float float1 = org.apache.commons.math.util.FastMath.abs(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.5491895702039902d, (double) 8);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999227492454965d + "'", double2 == 0.9999227492454965d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 32.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.4810085152958163d, 10.21763731027119d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9998682257117821d + "'", double2 == 0.9998682257117821d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable1, (java.lang.Number) 0L, (java.lang.Number) 1.0d, true);
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException(localizable1, objArray11);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.718281828459045d + "'", number4.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (2.718)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (2.718)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.718281828459045d + "'", number6.equals(2.718281828459045d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(7.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.000000000000001d + "'", double1 == 7.000000000000001d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.04323229440977d), (double) 49L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.021287238992100076d) + "'", double2 == (-0.021287238992100076d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        java.lang.Number number9 = notStrictlyPositiveException8.getMin();
        java.lang.Throwable throwable10 = null;
        try {
            notStrictlyPositiveException8.addSuppressed(throwable10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable6 = convergenceException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray8);
        java.lang.Object[] objArray10 = mathIllegalArgumentException9.getArguments();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable6, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable17, objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray18);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable14, objArray18);
        java.lang.Object[] objArray22 = convergenceException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException4, localizable6, objArray22);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable0, objArray22);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        double double12 = randomDataImpl0.nextUniform(0.0d, 0.5772156649015329d);
//        try {
//            double double15 = randomDataImpl0.nextF(20.30766683149986d, (-53.40321167064011d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -53.403 is smaller than, or equal to, the minimum (0): degrees of freedom (-53.403)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 3L + "'", long7 == 3L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2450c6d761a4a579908f50b4b89c4bc7ad12a85880aade88d069b4ef54cace5d40939bb47de43768b27cc0fd51ede4e94072" + "'", str9.equals("2450c6d761a4a579908f50b4b89c4bc7ad12a85880aade88d069b4ef54cace5d40939bb47de43768b27cc0fd51ede4e94072"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.559702779611307d + "'", double12 == 0.559702779611307d);
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) -1);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable8, objArray9);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException(localizable6, objArray9);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "hi!", objArray9);
        java.lang.String str13 = mathException12.getPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "hi!" + "'", str13.equals("hi!"));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.9836065573770492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6849166814234299d + "'", double1 == 0.6849166814234299d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        float float2 = org.apache.commons.math.util.FastMath.min(4.0f, (float) 7);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 77);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-105.77959572529313d), (double) 32.0f, 0.37665202364295614d);
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability(0.7806925186793796d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math.util.FastMath.rint(19.13879622348371d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.0d + "'", double1 == 19.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.3011434712524428d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 176.27281293080128d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.2335150624571722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.86227174349645d + "'", double1 == 1.86227174349645d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) -1, (java.lang.Number) 0.9999999958776927d);
        org.apache.commons.math.exception.util.Localizable localizable20 = outOfRangeException19.getGeneralPattern();
        java.lang.Number number21 = outOfRangeException19.getLo();
        java.lang.String str22 = outOfRangeException19.toString();
        java.lang.Number number23 = outOfRangeException19.getLo();
        java.lang.Class<?> wildcardClass24 = outOfRangeException19.getClass();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (byte) -1 + "'", number21.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed" + "'", str22.equals("org.apache.commons.math.exception.OutOfRangeException: 100 out of [-1, 1] range: convergence failed"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (byte) -1 + "'", number23.equals((byte) -1));
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1));
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2);
        java.lang.Throwable[] throwableArray4 = convergenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.log1p(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.58351893845611d + "'", double1 == 3.58351893845611d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-0.8813735870195429d), (java.lang.Number) 100.0d, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Throwable throwable6 = null;
        try {
            numberIsTooLargeException4.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray21 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException22 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable20, objArray21);
        int int23 = maxIterationsExceededException22.getMaxIterations();
        int int24 = maxIterationsExceededException22.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable27 = convergenceException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, objArray29);
        java.lang.Object[] objArray31 = mathIllegalArgumentException30.getArguments();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException(localizable27, objArray31);
        java.lang.Class<?> wildcardClass33 = objArray31.getClass();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException22, "{0}", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, "0677005e3d382fbbcd891ecbfd9ab61b57a635f1dacb3e8ce78627be324eee87f23258b87e9b9f2d0ebadff07ae4ad76de12", objArray31);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable1, objArray31);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        java.lang.Object[] objArray40 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, objArray40);
        java.lang.Object[] objArray42 = mathIllegalArgumentException41.getArguments();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException(localizable38, objArray42);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooLargeException49.getGeneralPattern();
        convergenceException36.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        org.apache.commons.math.exception.util.Localizable localizable52 = convergenceException36.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.140641475065075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2887874901850618d + "'", double1 == 1.2887874901850618d);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        randomDataImpl1.reSeed();
//        long long7 = randomDataImpl1.nextPoisson(48.80259668333492d);
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0579790307787205d + "'", double4 == 1.0579790307787205d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 37L + "'", long7 == 37L);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        java.lang.Class<?> wildcardClass3 = randomDataImpl0.getClass();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7669549644331817d + "'", double2 == 0.7669549644331817d);
//        org.junit.Assert.assertNotNull(wildcardClass3);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.tanh(31.58115167922982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray4);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5", objArray4);
        java.lang.String str8 = mathException7.getPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5" + "'", str8.equals("1a4fcce3be3bfd560ebf7c32dc5826e0216b8afee515babde06329fdeb12b34af4f011bb5945a631fdd80b86f2253d6baad5"));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.9385886680003617E-4d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 49, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeedSecure(0L);
        int int5 = randomDataImpl0.nextZipf(91, 76.48788695911851d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        int int2 = org.apache.commons.math.util.FastMath.min(49, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49 + "'", int2 == 49);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double15 = normalDistributionImpl8.getMean();
//        double double17 = normalDistributionImpl8.density(7.960870902199058d);
//        double double18 = normalDistributionImpl8.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 54.049069546911674d + "'", double12 == 54.049069546911674d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.011379022424360976d + "'", double17 == 0.011379022424360976d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        int int10 = randomDataImpl0.nextZipf(13, (double) 49L);
//        randomDataImpl0.reSeed(8L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9836065573770492d, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2128932128133587d + "'", double2 == 1.2128932128133587d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.sin((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.48500216304847765d) + "'", double1 == (-0.48500216304847765d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.140641475065075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.504891555284088d + "'", double1 == 8.504891555284088d);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test432");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        randomDataImpl0.reSeedSecure((long) '4');
//        double double21 = randomDataImpl0.nextChiSquare(0.3643932802642205d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.14739687503825846d + "'", double2 == 0.14739687503825846d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.598038170041665d + "'", double6 == 6.598038170041665d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 91.13649087589248d + "'", double17 == 91.13649087589248d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.6252513384600495d + "'", double21 == 0.6252513384600495d);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(26.111155375796386d, 0.21406959939352824d);
        try {
            double[] doubleArray4 = normalDistributionImpl2.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.atan((-11.735926445149872d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.4857932097669169d) + "'", double1 == (-1.4857932097669169d));
    }

//    @Test
//    public void test435() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test435");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double19 = normalDistributionImpl9.cumulativeProbability(176.27281293080128d);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12561884147837188d + "'", double2 == 0.12561884147837188d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.485439059818002d + "'", double6 == 7.485439059818002d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 33.05187538338818d + "'", double17 == 33.05187538338818d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.9999989861899106d + "'", double19 == 0.9999989861899106d);
//    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test436");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double15 = normalDistributionImpl8.getMean();
//        double double17 = normalDistributionImpl8.density(0.004655363473036653d);
//        normalDistributionImpl8.reseedRandomGenerator((long) 3);
//        normalDistributionImpl8.reseedRandomGenerator((long) (byte) -1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 60.16716521718691d + "'", double12 == 60.16716521718691d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.010942894613315412d + "'", double17 == 0.010942894613315412d);
//    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-105.77959572529313d), (double) 32.0f, 0.37665202364295614d);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-105.77959572529313d) + "'", double4 == (-105.77959572529313d));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable1, objArray2);
        int int4 = maxIterationsExceededException3.getMaxIterations();
        int int5 = maxIterationsExceededException3.getMaxIterations();
        java.lang.Object[] objArray6 = maxIterationsExceededException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) (short) -1, (java.lang.Number) 10, true);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException17 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable15, objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable13, objArray16);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException11, "hi!", objArray16);
        boolean boolean20 = numberIsTooLargeException11.getBoundIsAllowed();
        maxIterationsExceededException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        boolean boolean22 = numberIsTooLargeException11.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextF(1.5707963267948966d, 10.0d);
//        double double13 = randomDataImpl0.nextChiSquare((double) 4);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl0.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.409690003384423d + "'", double11 == 3.409690003384423d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.7052050846137536d + "'", double13 == 2.7052050846137536d);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.440892098500626E-16d) + "'", double1 == (-4.440892098500626E-16d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.062082127705336d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2733259238202086d + "'", double1 == 1.2733259238202086d);
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextBeta((double) '#', (double) 7);
//        double double9 = randomDataImpl0.nextWeibull(176.27281293080128d, 1.9385886680003617E-4d);
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.8085268581205644d + "'", double6 == 0.8085268581205644d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.941393916153892E-4d + "'", double9 == 1.941393916153892E-4d);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) (short) 100);
//        randomDataImpl0.reSeedSecure((long) 4);
//        try {
//            double double14 = randomDataImpl0.nextGamma(0.004655363473036653d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "93e29eacbc13b65e1b80ae6b960ca1cae175502b449ff3d73a1fa83779b22e5238f2f6bfa94082595a2f82a50051d3f822a8" + "'", str9.equals("93e29eacbc13b65e1b80ae6b960ca1cae175502b449ff3d73a1fa83779b22e5238f2f6bfa94082595a2f82a50051d3f822a8"));
//    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 100);
        normalDistributionImpl2.reseedRandomGenerator((long) (byte) 0);
        double double7 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 10.0d + "'", double7 == 10.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.21406959939352824d, number1, (java.lang.Number) 1.5574077246549023d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeed();
//        double double11 = randomDataImpl0.nextCauchy(1.2335150624571722d, 3.2300693823966125d);
//        int int14 = randomDataImpl0.nextPascal((int) (byte) 1, 0.0d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 9.70732464415742d + "'", double11 == 9.70732464415742d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
//    }

//    @Test
//    public void test448() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test448");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double3 = normalDistributionImpl2.getStandardDeviation();
//        double double4 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.getStandardDeviation();
//        double double7 = normalDistributionImpl2.cumulativeProbability(33.63261756898911d);
//        double double9 = normalDistributionImpl2.density(8.881784197001252E-16d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.0d + "'", double3 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 51.07285574583457d + "'", double4 == 51.07285574583457d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.0d + "'", double5 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.7502312510692009d + "'", double7 == 0.7502312510692009d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.01094247885554892d + "'", double9 == 0.01094247885554892d);
//    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 49L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 49 + "'", int1 == 49);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable11, objArray12);
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable1, objArray12);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException(localizable1, number16, (java.lang.Number) 5.551115123125783E-17d, (java.lang.Number) 0.010942894613315412d);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Object[] objArray5 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 32.0f);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.417595318551267d, (java.lang.Number) (short) 0, false);
        java.lang.Object[] objArray13 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray13);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 8.447150561318425d, (java.lang.Number) 100, false);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable20 = convergenceException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        java.lang.Object[] objArray22 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, objArray22);
        java.lang.Object[] objArray24 = mathIllegalArgumentException23.getArguments();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable20, objArray24);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException27 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable20, (java.lang.Number) 32.0f);
        java.lang.Number number28 = notStrictlyPositiveException27.getMin();
        boolean boolean29 = notStrictlyPositiveException27.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException27.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable32, objArray33);
        int int35 = maxIterationsExceededException34.getMaxIterations();
        int int36 = maxIterationsExceededException34.getMaxIterations();
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable39 = convergenceException38.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray41 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray41);
        java.lang.Object[] objArray43 = mathIllegalArgumentException42.getArguments();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable39, objArray43);
        java.lang.Class<?> wildcardClass45 = objArray43.getClass();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException34, "{0}", objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException18, localizable30, objArray43);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable51, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable49, objArray52);
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable58, objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(localizable56, objArray59);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54, localizable55, objArray59);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable48, objArray59);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException14, localizable30, objArray59);
        java.lang.String str65 = mathException64.toString();
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math.MathException: convergence failed" + "'", str65.equals("org.apache.commons.math.MathException: convergence failed"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 47, 35.82675781532156d, (double) 97L, 47);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.011904799882570002d + "'", double4 == 0.011904799882570002d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Double.NEGATIVE_INFINITY, number1, false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + Double.NEGATIVE_INFINITY + "'", number6.equals(Double.NEGATIVE_INFINITY));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-7.170036909513635d), 1.1204773664933685E-9d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) ' ');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            double double19 = randomDataImpl0.nextChiSquare((-105.77959572529313d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -52.89 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3686714918686587d + "'", double2 == 0.3686714918686587d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.1609784339719265d + "'", double6 == 3.1609784339719265d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-57.44300458215182d) + "'", double17 == (-57.44300458215182d));
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 60.16716521718691d, (java.lang.Number) 0.6896086545712306d, true);
    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        long long7 = randomDataImpl0.nextPoisson((double) (byte) 1);
//        double double9 = randomDataImpl0.nextChiSquare((double) 97.0f);
//        try {
//            double double12 = randomDataImpl0.nextWeibull((double) 2147483647, (-7.170036909513635d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -7.17 is smaller than, or equal to, the minimum (0): scale (-7.17)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2L + "'", long7 == 2L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 113.79963403056368d + "'", double9 == 113.79963403056368d);
//    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        int int12 = randomDataImpl0.nextZipf(97, (double) 4);
//        int int15 = randomDataImpl0.nextZipf(3, (double) 97L);
//        try {
//            double double18 = randomDataImpl0.nextF(0.0d, (double) (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.0d, (double) 3L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0000000000000002d + "'", double2 == 1.0000000000000002d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.011379022424360976d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011379022424360976d + "'", double1 == 0.011379022424360976d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 10, (java.lang.Number) 2.718281828459045d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.MathIllegalArgumentException: convergence failed", objArray8);
        java.lang.Object[] objArray10 = mathException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, localizable6, objArray10);
        java.lang.Number number12 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.718281828459045d + "'", number4.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (2.718)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than, or equal to, the maximum (2.718)"));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2.718281828459045d + "'", number12.equals(2.718281828459045d));
    }

//    @Test
//    public void test466() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test466");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        randomDataImpl0.reSeedSecure((long) (short) -1);
//        int int12 = randomDataImpl0.nextZipf(97, (double) 4);
//        int int15 = randomDataImpl0.nextZipf(3, (double) 97L);
//        try {
//            int int18 = randomDataImpl0.nextBinomial((int) (byte) -1, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of trials (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//    }

//    @Test
//    public void test467() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test467");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double9 = normalDistributionImpl8.getStandardDeviation();
//        double double11 = normalDistributionImpl8.cumulativeProbability(2.718281828459045d);
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        double[] doubleArray14 = normalDistributionImpl8.sample((int) 'a');
//        double double15 = normalDistributionImpl8.getMean();
//        double double17 = normalDistributionImpl8.density(0.004655363473036653d);
//        double double18 = normalDistributionImpl8.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 9 + "'", int5 == 9);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.417595318551267d + "'", double11 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 39.106169829075185d + "'", double12 == 39.106169829075185d);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10.0d + "'", double15 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.010942894613315412d + "'", double17 == 0.010942894613315412d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
//    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.6252948841919718d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8687969548680085d + "'", double1 == 0.8687969548680085d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7712985484622012d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.880878861002552d + "'", double1 == 0.880878861002552d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        double double5 = randomDataImpl0.nextWeibull(Double.POSITIVE_INFINITY, (double) 32.0f);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.MathException: convergence failed", "e");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: e");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36390580887682866d + "'", double2 == 0.36390580887682866d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 0);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test473");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        randomDataImpl1.reSeedSecure((long) (byte) -1);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7611641989808992d + "'", double4 == 0.7611641989808992d);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.5491895702039902d);
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        double double8 = normalDistributionImpl7.getStandardDeviation();
//        double double10 = normalDistributionImpl7.cumulativeProbability(2.718281828459045d);
//        double double11 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        try {
//            long long13 = randomDataImpl1.nextPoisson((-0.021287238992100076d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.021 is smaller than, or equal to, the minimum (0): mean (-0.021)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.7566662827817023d + "'", double4 == 0.7566662827817023d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 35.0d + "'", double8 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.417595318551267d + "'", double10 == 0.417595318551267d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 64.02097392297023d + "'", double11 == 64.02097392297023d);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable3, objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable1, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException12 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable10, objArray11);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException(localizable8, objArray11);
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable7, objArray11);
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException(localizable0, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException15.getGeneralPattern();
        java.lang.String str17 = mathException15.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.MathException: " + "'", str17.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.atanh(7.990273425901318d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.0167501573306144d, (java.lang.Number) 0.5772156649015329d, false);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        long long1 = org.apache.commons.math.util.FastMath.abs(41L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 41L + "'", long1 == 41L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.6295941819582136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.9385886680003617E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5158.968754299618d) + "'", double1 == (-5158.968754299618d));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1114875376100244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0358611199105672d + "'", double1 == 1.0358611199105672d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double2 = org.apache.commons.math.util.FastMath.atan2(130.5771703460862d, 3994.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03268169191673955d + "'", double2 == 0.03268169191673955d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        float float2 = org.apache.commons.math.util.FastMath.min((-1.0f), (float) (short) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test485");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        int[] intArray3 = randomDataImpl0.nextPermutation((int) (short) 10, (int) (byte) 1);
//        double double6 = randomDataImpl0.nextWeibull((double) 1.0f, (double) (short) 100);
//        int int9 = randomDataImpl0.nextSecureInt((int) ' ', 100);
//        try {
//            int int12 = randomDataImpl0.nextBinomial(2147483647, 8.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 8 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertNotNull(intArray3);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 79.72230058600704d + "'", double6 == 79.72230058600704d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 93 + "'", int9 == 93);
//    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.021287238992100076d), 1.234062677915823d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.021287238992100072d) + "'", double2 == (-0.021287238992100072d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8344894259657916d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8344894259657916d + "'", double1 == 0.8344894259657916d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable2 = convergenceException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray4);
        java.lang.Object[] objArray6 = mathIllegalArgumentException5.getArguments();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(localizable2, objArray6);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable2, (java.lang.Number) 32.0f);
        java.lang.Number number10 = notStrictlyPositiveException9.getMin();
        boolean boolean11 = notStrictlyPositiveException9.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException9.getSpecificPattern();
        org.apache.commons.math.ConvergenceException convergenceException13 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable14 = convergenceException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray16 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray16);
        java.lang.Object[] objArray18 = mathIllegalArgumentException17.getArguments();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable14, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable12, objArray18);
        org.apache.commons.math.exception.util.Localizable localizable21 = maxIterationsExceededException20.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0 + "'", number10.equals(0));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9389941379013969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double4 = randomDataImpl1.nextF((double) (byte) 100, (double) 100L);
//        double double6 = randomDataImpl1.nextChiSquare(0.984807753012208d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.528420857175716d + "'", double4 == 0.528420857175716d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.589102415530562d + "'", double6 == 0.589102415530562d);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9403358822257634d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.370200520658798d + "'", double1 == 1.370200520658798d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.special.Erf.erf(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9723704937007157d + "'", double1 == 0.9723704937007157d);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure(0L);
//        int int5 = randomDataImpl0.nextSecureInt((int) (byte) 0, (int) 'a');
//        double double8 = randomDataImpl0.nextGamma(1.059187939427762d, 7.0d);
//        try {
//            double double10 = randomDataImpl0.nextChiSquare((double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 96 + "'", int5 == 96);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9937846841125784d + "'", double8 == 1.9937846841125784d);
//    }

//    @Test
//    public void test494() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test494");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        randomDataImpl0.reSeedSecure((long) (byte) 1);
//        int int5 = randomDataImpl0.nextSecureInt((int) (short) 0, (int) (short) 10);
//        randomDataImpl0.reSeedSecure((long) (short) 100);
//        double double9 = randomDataImpl0.nextExponential(1.1102230246251565E-16d);
//        long long12 = randomDataImpl0.nextLong((-1L), (long) 35);
//        try {
//            randomDataImpl0.setSecureAlgorithm("a96ffb6c81a563cbdc1668901786fdbfef4c242b7b95e26e01780bdb4a7614ca9f4b3520894defb9abc72303382821f8b", "0");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.6559489674994477E-16d + "'", double9 == 1.6559489674994477E-16d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 6L + "'", long12 == 6L);
//    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 77, 0.0d, 0.9848077530122081d, 7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, localizable1, objArray2);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 100.0f, true);
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException7.getSuppressed();
        java.lang.Number number9 = numberIsTooSmallException7.getArgument();
        boolean boolean10 = numberIsTooSmallException7.getBoundIsAllowed();
        maxIterationsExceededException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0L + "'", number9.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999092042625951d + "'", double1 == 0.9999092042625951d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.03268169191673955d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.032675876863609975d + "'", double1 == 0.032675876863609975d);
    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test499");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential(1.5574077246549023d);
//        randomDataImpl0.reSeed();
//        double double6 = randomDataImpl0.nextF(32.0d, 2.649558242894909d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10L, (double) 35);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 100);
//        normalDistributionImpl9.reseedRandomGenerator((long) (byte) 0);
//        double double14 = normalDistributionImpl9.getStandardDeviation();
//        normalDistributionImpl9.reseedRandomGenerator((long) 7);
//        double double17 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            randomDataImpl0.setSecureAlgorithm("{0}", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2904276390528056d + "'", double2 == 2.2904276390528056d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6561688437407488d + "'", double6 == 0.6561688437407488d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 35.0d + "'", double14 == 35.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-18.510777981640718d) + "'", double17 == (-18.510777981640718d));
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.6252513384600495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.20394536991302709d) + "'", double1 == (-0.20394536991302709d));
    }
}

