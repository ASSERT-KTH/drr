import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        double double9 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation2.addChromosome(chromosome10);
        try {
            elitisticListPopulation2.setElitismRate((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (short) 100, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) (byte) 1, (java.lang.Number) 10);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = localizedFormats0.getLocalizedString(locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, number2, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        java.lang.Object obj7 = null;
        exceptionContext5.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)", obj7);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double13 = elitisticListPopulation12.getElitismRate();
        elitisticListPopulation12.setPopulationLimit(0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int19 = elitisticListPopulation18.getPopulationSize();
        int int20 = elitisticListPopulation18.getPopulationLimit();
        elitisticListPopulation18.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList26 = elitisticListPopulation25.getChromosomes();
        elitisticListPopulation25.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population29 = elitisticListPopulation25.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList30 = elitisticListPopulation25.getChromosomes();
        elitisticListPopulation18.setChromosomes(chromosomeList30);
        elitisticListPopulation12.setChromosomes(chromosomeList30);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor33 = elitisticListPopulation12.iterator();
        exceptionContext5.setValue("iterator exhausted", (java.lang.Object) chromosomeItor33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation38 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int39 = elitisticListPopulation38.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList40 = elitisticListPopulation38.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor41 = elitisticListPopulation38.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation44 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int45 = elitisticListPopulation44.getPopulationSize();
        int int46 = elitisticListPopulation44.getPopulationLimit();
        elitisticListPopulation44.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList49 = elitisticListPopulation44.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList49, (int) 'a', 0.0d);
        elitisticListPopulation38.setChromosomes(chromosomeList49);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor54 = elitisticListPopulation38.iterator();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor55 = elitisticListPopulation38.iterator();
        java.lang.Object[] objArray56 = new java.lang.Object[] { elitisticListPopulation38 };
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, objArray56);
        java.lang.String str58 = localizedFormats35.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(chromosomeList26);
        org.junit.Assert.assertNotNull(population29);
        org.junit.Assert.assertNotNull(chromosomeList30);
        org.junit.Assert.assertNotNull(chromosomeItor33);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(chromosomeList40);
        org.junit.Assert.assertNotNull(chromosomeItor41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 10 + "'", int46 == 10);
        org.junit.Assert.assertNotNull(chromosomeList49);
        org.junit.Assert.assertNotNull(chromosomeItor54);
        org.junit.Assert.assertNotNull(chromosomeItor55);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "not positive definite matrix: diagonal element at ({1},{1}) is smaller than {2} ({0})" + "'", str58.equals("not positive definite matrix: diagonal element at ({1},{1}) is smaller than {2} ({0})"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, number2, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) (-1.0f), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        java.lang.String str18 = numberIsTooLargeException16.toString();
        java.lang.String str19 = numberIsTooLargeException16.toString();
        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        java.lang.String str34 = numberIsTooLargeException32.toString();
        java.lang.String str35 = numberIsTooLargeException32.toString();
        mathIllegalArgumentException28.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        boolean boolean37 = numberIsTooLargeException32.getBoundIsAllowed();
        numberIsTooLargeException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        java.lang.Number number40 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException44);
        boolean boolean46 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number47 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 10 + "'", number17.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str18.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 10 + "'", number33.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str34.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (short) 10 + "'", number40.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (short) 10 + "'", number47.equals((short) 10));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) (byte) -1, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        int int5 = elitisticListPopulation2.getPopulationLimit();
        java.lang.String str6 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList6, (int) (byte) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertNotNull(chromosomeList6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        int int18 = elitisticListPopulation2.getPopulationLimit();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome19 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 100 + "'", int18 == 100);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 0L, (java.lang.Number) 10L, (java.lang.Number) (byte) 1);
        java.lang.Throwable[] throwableArray6 = outOfRangeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) (-1.0d));
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) notPositiveException10);
        boolean boolean12 = notPositiveException10.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        java.lang.Object obj3 = exceptionContext1.getValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean9 = numberIsTooLargeException8.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        java.lang.String str23 = numberIsTooLargeException21.toString();
        java.lang.String str24 = numberIsTooLargeException21.toString();
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = numberIsTooLargeException30.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        java.lang.String str39 = numberIsTooLargeException37.toString();
        java.lang.String str40 = numberIsTooLargeException37.toString();
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        boolean boolean42 = numberIsTooLargeException37.getBoundIsAllowed();
        numberIsTooLargeException21.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Class<?> wildcardClass45 = numberIsTooLargeException8.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray50 = numberIsTooLargeException49.getSuppressed();
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        boolean boolean52 = numberIsTooLargeException49.getBoundIsAllowed();
        exceptionContext1.setValue("not positive definite matrix: diagonal element at ({1},{1}) is smaller than {2} ({0})", (java.lang.Object) numberIsTooLargeException49);
        java.util.Set<java.lang.String> strSet54 = exceptionContext1.getKeys();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 10 + "'", number22.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (short) 10 + "'", number38.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNotNull(strSet54);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) (-1L), true);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population32 = elitisticListPopulation28.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = elitisticListPopulation28.getChromosomes();
        exceptionContext4.setValue("hi!", (java.lang.Object) elitisticListPopulation28);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation37 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int38 = elitisticListPopulation37.getPopulationSize();
        int int39 = elitisticListPopulation37.getPopulationLimit();
        elitisticListPopulation37.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList42 = elitisticListPopulation37.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList42, (int) 'a', 0.0d);
        elitisticListPopulation28.setChromosomes(chromosomeList42);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation49 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList42, (int) 'a', (double) 0L);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(population32);
        org.junit.Assert.assertNotNull(chromosomeList33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(chromosomeList42);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean6 = numberIsTooLargeException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException5.getSuppressed();
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException10);
        java.lang.Throwable throwable12 = exceptionContext11.getThrowable();
        java.lang.Throwable throwable13 = exceptionContext11.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwable12);
        org.junit.Assert.assertNotNull(throwable13);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("{0} is smaller than, or equal to, the minimum ({1})");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Number) 100.0d, (java.lang.Number) (short) 1, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = numberIsTooSmallException17.getContext();
        java.util.Set<java.lang.String> strSet19 = exceptionContext18.getKeys();
        java.lang.Throwable throwable20 = exceptionContext18.getThrowable();
        java.lang.Throwable throwable21 = exceptionContext18.getThrowable();
        java.lang.Object obj23 = exceptionContext18.getValue("This distribution does not have a density function implemented");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) 10, (java.lang.Number) (short) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean34 = numberIsTooLargeException33.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean40 = numberIsTooLargeException39.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray41 = numberIsTooLargeException39.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number47 = numberIsTooLargeException46.getArgument();
        java.lang.String str48 = numberIsTooLargeException46.toString();
        java.lang.String str49 = numberIsTooLargeException46.toString();
        mathIllegalArgumentException42.addSuppressed((java.lang.Throwable) numberIsTooLargeException46);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean56 = numberIsTooLargeException55.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray57 = numberIsTooLargeException55.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats51, (java.lang.Object[]) throwableArray57);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number63 = numberIsTooLargeException62.getArgument();
        java.lang.String str64 = numberIsTooLargeException62.toString();
        java.lang.String str65 = numberIsTooLargeException62.toString();
        mathIllegalArgumentException58.addSuppressed((java.lang.Throwable) numberIsTooLargeException62);
        boolean boolean67 = numberIsTooLargeException62.getBoundIsAllowed();
        numberIsTooLargeException46.addSuppressed((java.lang.Throwable) numberIsTooLargeException62);
        numberIsTooLargeException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException46);
        java.lang.Throwable[] throwableArray70 = numberIsTooLargeException33.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Object[]) throwableArray70);
        exceptionContext18.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) throwableArray70);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray70);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertNotNull(strSet19);
        org.junit.Assert.assertNotNull(throwable20);
        org.junit.Assert.assertNotNull(throwable21);
        org.junit.Assert.assertNull(obj23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + (short) 10 + "'", number47.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str48.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str49.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + (short) 10 + "'", number63.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str64 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str64.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str65.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(throwableArray70);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray8 = numberIsTooLargeException6.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray8);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        java.lang.Object obj5 = exceptionContext3.getValue("permutation k ({0}) must be positive");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = outOfRangeException16.getContext();
        outOfRangeException11.addSuppressed((java.lang.Throwable) outOfRangeException16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = outOfRangeException11.getContext();
        exceptionContext3.setValue("{0} wide hole between models time ranges", (java.lang.Object) exceptionContext19);
        java.util.Set<java.lang.String> strSet21 = exceptionContext3.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertNotNull(strSet21);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit(1);
        java.lang.String str6 = elitisticListPopulation2.toString();
        int int7 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setPopulationLimit((int) (short) 1);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) ' ', (double) 0.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray4 = outOfRangeException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1, (java.lang.Number) 0.0f, true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number11 = outOfRangeException10.getLo();
        java.lang.Number number12 = outOfRangeException10.getLo();
        java.lang.Number number13 = outOfRangeException10.getHi();
        java.lang.Number number14 = outOfRangeException10.getHi();
        java.lang.Number number15 = outOfRangeException10.getLo();
        java.lang.Class<?> wildcardClass16 = outOfRangeException10.getClass();
        exceptionContext5.setValue("the closest orthogonal matrix has a negative determinant {0}", (java.lang.Object) outOfRangeException10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0f + "'", number11.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.0f + "'", number12.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 10 + "'", number13.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (short) 10 + "'", number14.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0f + "'", number15.equals(1.0f));
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1L), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN;
        java.lang.Number number9 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) 1.0f, number9, (java.lang.Number) (-1.0d));
        exceptionContext5.setValue("{0} out of ({1}, {2}] range", (java.lang.Object) 1.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList5 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList5, (int) '4', (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeList5);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (byte) 10, (double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor18 = elitisticListPopulation2.iterator();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor19 = elitisticListPopulation2.iterator();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome20 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertNotNull(chromosomeItor18);
        org.junit.Assert.assertNotNull(chromosomeItor19);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) 'a', (double) 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0d + "'", number5.equals(100.0d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        boolean boolean7 = notPositiveException6.getBoundIsAllowed();
        java.lang.Number number8 = notPositiveException6.getMin();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0f);
        notPositiveException6.addSuppressed((java.lang.Throwable) notPositiveException10);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) notPositiveException10);
        java.lang.Number number13 = notPositiveException10.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 10.0f + "'", number13.equals(10.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Throwable[] throwableArray7 = notPositiveException6.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooSmallException12.getMin();
        notPositiveException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        outOfRangeException3.addSuppressed((java.lang.Throwable) notPositiveException6);
        java.lang.String str17 = outOfRangeException3.toString();
        java.lang.Number number18 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0L + "'", number14.equals(0L));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: 10 out of [1, 10] range" + "'", str17.equals("org.apache.commons.math3.exception.OutOfRangeException: 10 out of [1, 10] range"));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.0f + "'", number18.equals(1.0f));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        java.lang.String str25 = throwable24.toString();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (1)"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = notPositiveException2.getContext();
        boolean boolean6 = notPositiveException2.getBoundIsAllowed();
        java.lang.String str7 = notPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: row index 10 out of allowed range [0, {2}]" + "'", str7.equals("org.apache.commons.math3.exception.NotPositiveException: row index 10 out of allowed range [0, {2}]"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        try {
            elitisticListPopulation2.setElitismRate((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) (byte) 0, (java.lang.Number) 1.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) -1, (java.lang.Number) 1.0f, false);
        java.lang.Class<?> wildcardClass4 = numberIsTooSmallException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (-1.0d), true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) 0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, (java.lang.Number) (-1), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1) + "'", number6.equals((-1)));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Throwable[] throwableArray2 = notPositiveException1.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean8 = numberIsTooSmallException7.getBoundIsAllowed();
        java.lang.Number number9 = numberIsTooSmallException7.getMin();
        notPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Throwable[] throwableArray11 = notPositiveException1.getSuppressed();
        java.lang.Number number12 = notPositiveException1.getMin();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0L + "'", number9.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0 + "'", number12.equals(0));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population32 = elitisticListPopulation28.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = elitisticListPopulation28.getChromosomes();
        exceptionContext4.setValue("hi!", (java.lang.Object) elitisticListPopulation28);
        java.lang.Object obj36 = exceptionContext4.getValue("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        java.lang.String str38 = localizedFormats37.getSourceString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean44 = numberIsTooLargeException43.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException43.getSuppressed();
        java.lang.Object[] objArray46 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray45);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats39, objArray46);
        java.lang.Object[] objArray48 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray46);
        java.lang.Object[] objArray49 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray48);
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, objArray48);
        java.lang.Number number52 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats37, (java.lang.Number) 10L, number52, (java.lang.Number) (-1));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(population32);
        org.junit.Assert.assertNotNull(chromosomeList33);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Continued fraction convergents failed to converge (in less than {0} iterations) for value {1}" + "'", str38.equals("Continued fraction convergents failed to converge (in less than {0} iterations) for value {1}"));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray49);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) (short) -1, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation2.getChromosomes();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(chromosomeList11);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        exceptionContext1.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)", (java.lang.Object) localizedFormats3);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean9 = numberIsTooLargeException8.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        java.lang.String str23 = numberIsTooLargeException21.toString();
        java.lang.String str24 = numberIsTooLargeException21.toString();
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = numberIsTooLargeException30.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        java.lang.String str39 = numberIsTooLargeException37.toString();
        java.lang.String str40 = numberIsTooLargeException37.toString();
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        boolean boolean42 = numberIsTooLargeException37.getBoundIsAllowed();
        numberIsTooLargeException21.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException8.getSuppressed();
        java.lang.Class<?> wildcardClass46 = throwableArray45.getClass();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext48 = mathIllegalArgumentException47.getContext();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation52 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList53 = elitisticListPopulation52.getChromosomes();
        elitisticListPopulation52.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList56 = elitisticListPopulation52.getChromosomes();
        elitisticListPopulation52.setPopulationLimit((int) (short) -1);
        elitisticListPopulation52.setPopulationLimit(1);
        exceptionContext48.setValue("", (java.lang.Object) elitisticListPopulation52);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 10 + "'", number22.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (short) 10 + "'", number38.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertNotNull(exceptionContext48);
        org.junit.Assert.assertNotNull(chromosomeList53);
        org.junit.Assert.assertNotNull(chromosomeList56);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_MANY_REGRESSORS));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (short) 100, true);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) (short) 100, (double) (byte) 1);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation23 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, 0, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) 1.0f, false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) 0L, true);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray7 = outOfRangeException6.getSuppressed();
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, (java.lang.Object[]) throwableArray7);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_COUNT_EXCEEDED));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, (java.lang.Number) 0, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX;
        exceptionContext4.setValue("", (java.lang.Object) localizedFormats7);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = numberIsTooSmallException14.getContext();
        java.lang.String str16 = numberIsTooSmallException14.toString();
        java.lang.Number number17 = numberIsTooSmallException14.getMin();
        boolean boolean18 = numberIsTooSmallException14.getBoundIsAllowed();
        exceptionContext4.setValue("org.apache.commons.math3.exception.NotPositiveException: spline partition must have at least 1 points, got 0", (java.lang.Object) numberIsTooSmallException14);
        java.lang.Number number20 = numberIsTooSmallException14.getMin();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str16.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0f + "'", number17.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0f + "'", number20.equals(0.0f));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = outOfRangeException9.getContext();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = outOfRangeException4.getContext();
        java.lang.Object obj14 = exceptionContext12.getValue("{0} wide hole between models time ranges");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (short) -1);
        elitisticListPopulation2.setPopulationLimit(1);
        double double11 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit((int) (short) 1);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int17 = elitisticListPopulation16.getPopulationSize();
        int int18 = elitisticListPopulation16.getPopulationLimit();
        elitisticListPopulation16.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome21 = null;
        elitisticListPopulation16.addChromosome(chromosome21);
        int int23 = elitisticListPopulation16.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList24 = elitisticListPopulation16.getChromosomes();
        int int25 = elitisticListPopulation16.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList26 = elitisticListPopulation16.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList26);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 10 + "'", int18 == 10);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList26);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (byte) 0, true);
        numberIsTooSmallException8.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Number number15 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10.0f + "'", number15.equals(10.0f));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(chromosomeList10);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) 100, (java.lang.Number) 10.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        java.lang.Number number8 = numberIsTooLargeException4.getArgument();
        java.lang.String str9 = numberIsTooLargeException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str9.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0d, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0f, (java.lang.Number) (short) -1, (java.lang.Number) 0);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) -1 + "'", number4.equals((short) -1));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        java.lang.String str8 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setElitismRate((double) 1.0f);
        double double11 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (-1L));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean16 = numberIsTooLargeException15.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray17 = numberIsTooLargeException15.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number23 = numberIsTooLargeException22.getArgument();
        java.lang.String str24 = numberIsTooLargeException22.toString();
        java.lang.String str25 = numberIsTooLargeException22.toString();
        mathIllegalArgumentException18.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean32 = numberIsTooLargeException31.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray33 = numberIsTooLargeException31.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number39 = numberIsTooLargeException38.getArgument();
        java.lang.String str40 = numberIsTooLargeException38.toString();
        java.lang.String str41 = numberIsTooLargeException38.toString();
        mathIllegalArgumentException34.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        boolean boolean43 = numberIsTooLargeException38.getBoundIsAllowed();
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        java.lang.Throwable[] throwableArray45 = numberIsTooLargeException22.getSuppressed();
        exceptionContext9.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray45);
        exceptionContext4.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: array size cannot be greater than 100", (java.lang.Object) exceptionContext9);
        java.lang.Object obj49 = exceptionContext4.getValue("all ordinatae must be finite real numbers, but {0}-th is {1}");
        java.util.Set<java.lang.String> strSet50 = exceptionContext4.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (short) 10 + "'", number39.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str41.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNull(obj49);
        org.junit.Assert.assertNotNull(strSet50);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND;
        org.apache.commons.math3.exception.util.Localizable localizable7 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray14 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable7, objArray17);
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray17);
        java.lang.Object[] objArray21 = null;
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray21);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) 1, (java.lang.Number) (byte) 1, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LOWER_BOUND_NOT_BELOW_UPPER_BOUND));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList0 = null;
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation3 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList0, (int) 'a', (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation7.nextGeneration();
        elitisticListPopulation7.setPopulationLimit((int) '#');
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation7.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList11);
        org.apache.commons.math3.genetics.Chromosome chromosome13 = null;
        elitisticListPopulation2.addChromosome(chromosome13);
        int int15 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(population8);
        org.junit.Assert.assertNotNull(chromosomeList11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chromosomeList16);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (-1L));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray6 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, number2, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), (java.lang.Number) (byte) 0, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-1L), (java.lang.Number) 10L, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.Number number6 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (10)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (10)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, number2, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException7);
        java.lang.Object obj10 = exceptionContext8.getValue("index {0} out of allowed range [{1}, {2}]");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, true);
        boolean boolean6 = numberIsTooSmallException5.getBoundIsAllowed();
        java.lang.Object[] objArray7 = new java.lang.Object[] { numberIsTooSmallException5 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 100, true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: sample contains 0 observed points, at least 100 are required" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: sample contains 0 observed points, at least 100 are required"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        double double9 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation2.addChromosome(chromosome10);
        java.lang.String str12 = elitisticListPopulation2.toString();
        try {
            elitisticListPopulation2.setElitismRate((double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null, null]" + "'", str12.equals("[null, null]"));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray8 = numberIsTooLargeException6.getSuppressed();
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray11);
        java.lang.Number number16 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100, number16, true);
        java.lang.Number number19 = numberIsTooLargeException18.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(number19);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        java.lang.Number number8 = numberIsTooLargeException4.getMax();
        java.lang.Number number9 = numberIsTooLargeException4.getMax();
        java.lang.Number number10 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = numberIsTooLargeException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 100L + "'", number10.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_TOURNAMENT_ARITY;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, number2, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_TOURNAMENT_ARITY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_TOURNAMENT_ARITY));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = mathIllegalArgumentException7.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException7);
        java.util.Set<java.lang.String> strSet18 = exceptionContext17.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertNotNull(strSet18);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Object obj8 = exceptionContext5.getValue("");
        java.util.Set<java.lang.String> strSet9 = exceptionContext5.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Number) (-1.0d), (java.lang.Number) (short) 100, (java.lang.Number) 0);
        exceptionContext5.setValue("out of bounds quantile value: {0}, must be in (0, 100]", (java.lang.Object) (-1.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        int int9 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setElitismRate(0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, (java.lang.Number) 100.0d, false);
        java.lang.Class<?> wildcardClass5 = numberIsTooLargeException4.getClass();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0d + "'", number6.equals(100.0d));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, (java.lang.Number) (short) 10, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1, number2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj10 = exceptionContext8.getValue("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.SCALE;
        exceptionContext8.setValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.", (java.lang.Object) localizedFormats12);
        java.lang.Object obj15 = exceptionContext8.getValue("hi!");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0f + "'", number7.equals(0.0f));
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SCALE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SCALE));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1, (java.lang.Number) (short) 10);
        java.lang.String str5 = outOfRangeException4.toString();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: wrong array shape (block length = null, expected 1)" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: wrong array shape (block length = null, expected 1)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1 + "'", number6.equals(1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor4 = elitisticListPopulation2.iterator();
        double double5 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeItor4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        java.lang.String str8 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setElitismRate((double) 1.0f);
        org.apache.commons.math3.genetics.Population population11 = elitisticListPopulation2.nextGeneration();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertNotNull(population11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, (java.lang.Number) (short) 1, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 1 + "'", number6.equals((short) 1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor16 = elitisticListPopulation2.iterator();
        int int17 = elitisticListPopulation2.getPopulationSize();
        double double18 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertNotNull(chromosomeItor16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(100, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 100, number2, false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) (byte) 1, (java.lang.Number) 10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number7 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) 100.0d, number7, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = numberIsTooLargeException9.getContext();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation14 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList15 = elitisticListPopulation14.getChromosomes();
        elitisticListPopulation14.setPopulationLimit((int) (byte) 100);
        org.apache.commons.math3.genetics.Chromosome chromosome18 = null;
        elitisticListPopulation14.addChromosome(chromosome18);
        exceptionContext10.setValue("two or more values required in each category, one has {0}", (java.lang.Object) chromosome18);
        java.lang.Throwable throwable21 = exceptionContext10.getThrowable();
        outOfRangeException4.addSuppressed(throwable21);
        java.lang.Number number23 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(chromosomeList15);
        org.junit.Assert.assertNotNull(throwable21);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 10 + "'", number23.equals(10));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        int int8 = elitisticListPopulation2.getPopulationSize();
        int int9 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = null;
        elitisticListPopulation2.setChromosomes(chromosomeList10);
        try {
            org.apache.commons.math3.genetics.Population population12 = elitisticListPopulation2.nextGeneration();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, (java.lang.Number) 1.0d, false);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException7 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "number of microsphere elements must be positive, but got {0}" + "'", str5.equals("number of microsphere elements must be positive, but got {0}"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) (short) 10, 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation21 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) (short) 100, 1.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) '4', (double) (byte) 1);
        int int25 = elitisticListPopulation24.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 52 + "'", int25 == 52);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (short) 10, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Object obj8 = exceptionContext5.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        java.lang.Class<?> wildcardClass10 = localizedFormats9.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 100L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean6 = numberIsTooLargeException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (-1L), false);
        java.lang.Number number15 = numberIsTooLargeException14.getArgument();
        boolean boolean16 = numberIsTooLargeException14.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 10L + "'", number15.equals(10L));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        int int8 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) (-1.0f), false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        elitisticListPopulation2.setPopulationLimit((int) (short) 0);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.junit.Assert.assertNotNull(population3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        int int8 = elitisticListPopulation2.getPopulationSize();
        int int9 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = null;
        elitisticListPopulation2.setChromosomes(chromosomeList10);
        elitisticListPopulation2.setPopulationLimit((int) '4');
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList17 = elitisticListPopulation16.getChromosomes();
        org.apache.commons.math3.genetics.Population population18 = elitisticListPopulation16.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList19 = elitisticListPopulation16.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(chromosomeList17);
        org.junit.Assert.assertNotNull(population18);
        org.junit.Assert.assertNotNull(chromosomeList19);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 100);
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(0, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation2.iterator();
        java.lang.String str11 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.STANDARD_DEVIATION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (-1), true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.STANDARD_DEVIATION));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable5);
        java.lang.Object obj8 = exceptionContext6.getValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean14 = numberIsTooLargeException13.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean20 = numberIsTooLargeException19.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray21 = numberIsTooLargeException19.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray21);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number27 = numberIsTooLargeException26.getArgument();
        java.lang.String str28 = numberIsTooLargeException26.toString();
        java.lang.String str29 = numberIsTooLargeException26.toString();
        mathIllegalArgumentException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException26);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean36 = numberIsTooLargeException35.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray37 = numberIsTooLargeException35.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats31, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number43 = numberIsTooLargeException42.getArgument();
        java.lang.String str44 = numberIsTooLargeException42.toString();
        java.lang.String str45 = numberIsTooLargeException42.toString();
        mathIllegalArgumentException38.addSuppressed((java.lang.Throwable) numberIsTooLargeException42);
        boolean boolean47 = numberIsTooLargeException42.getBoundIsAllowed();
        numberIsTooLargeException26.addSuppressed((java.lang.Throwable) numberIsTooLargeException42);
        numberIsTooLargeException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException26);
        java.lang.Class<?> wildcardClass50 = numberIsTooLargeException13.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray55 = numberIsTooLargeException54.getSuppressed();
        numberIsTooLargeException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException54);
        boolean boolean57 = numberIsTooLargeException54.getBoundIsAllowed();
        exceptionContext6.setValue("not positive definite matrix: diagonal element at ({1},{1}) is smaller than {2} ({0})", (java.lang.Object) numberIsTooLargeException54);
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException54);
        java.lang.Number number60 = numberIsTooLargeException54.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (short) 10 + "'", number27.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str28.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + (short) 10 + "'", number43.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str44.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str45.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (short) 0 + "'", number60.equals((short) 0));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException(number7, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Class<?> wildcardClass12 = outOfRangeException10.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean6 = numberIsTooLargeException5.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number19 = numberIsTooLargeException18.getArgument();
        java.lang.String str20 = numberIsTooLargeException18.toString();
        java.lang.String str21 = numberIsTooLargeException18.toString();
        mathIllegalArgumentException14.addSuppressed((java.lang.Throwable) numberIsTooLargeException18);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean28 = numberIsTooLargeException27.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray29 = numberIsTooLargeException27.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, (java.lang.Object[]) throwableArray29);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number35 = numberIsTooLargeException34.getArgument();
        java.lang.String str36 = numberIsTooLargeException34.toString();
        java.lang.String str37 = numberIsTooLargeException34.toString();
        mathIllegalArgumentException30.addSuppressed((java.lang.Throwable) numberIsTooLargeException34);
        boolean boolean39 = numberIsTooLargeException34.getBoundIsAllowed();
        numberIsTooLargeException18.addSuppressed((java.lang.Throwable) numberIsTooLargeException34);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooLargeException18);
        java.lang.Number number42 = numberIsTooLargeException5.getArgument();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        numberIsTooLargeException5.addSuppressed((java.lang.Throwable) numberIsTooLargeException46);
        boolean boolean48 = numberIsTooLargeException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray49 = numberIsTooLargeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray49);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} != {1}" + "'", str1.equals("{0} != {1}"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 10 + "'", number19.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str21.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + (short) 10 + "'", number35.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str36.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str37.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (short) 10 + "'", number42.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = notPositiveException2.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean17 = numberIsTooLargeException16.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray18 = numberIsTooLargeException16.getSuppressed();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray19);
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray21);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray21);
        java.util.Set<java.lang.String> strSet24 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(strSet24);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) '#', (double) 1);
        java.lang.String str3 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[]" + "'", str3.equals("[]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) 100.0f, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100, (java.lang.Number) (-1L), true);
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException8);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) 1, (java.lang.Number) (-1L));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        elitisticListPopulation2.setPopulationLimit(35);
        try {
            elitisticListPopulation2.setElitismRate((double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) (short) 1);
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (byte) 100, (java.lang.Number) 1.0d, (java.lang.Number) (short) 100);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0f), (java.lang.Number) 10.0d, (java.lang.Number) (byte) 100);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray22 = numberIsTooLargeException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number28 = numberIsTooLargeException27.getArgument();
        java.lang.String str29 = numberIsTooLargeException27.toString();
        java.lang.String str30 = numberIsTooLargeException27.toString();
        mathIllegalArgumentException23.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        boolean boolean32 = numberIsTooLargeException27.getBoundIsAllowed();
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean39 = numberIsTooSmallException38.getBoundIsAllowed();
        java.lang.Number number40 = numberIsTooSmallException38.getMin();
        numberIsTooLargeException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException38);
        java.lang.Number number42 = numberIsTooLargeException27.getArgument();
        java.lang.Throwable[] throwableArray43 = numberIsTooLargeException27.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext44 = numberIsTooLargeException27.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats46, (java.lang.Number) 0L, (java.lang.Number) 35, (java.lang.Number) (-1L));
        exceptionContext44.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: tournament arity (10) cannot be bigger than population size (null)", (java.lang.Object) 35);
        java.util.Set<java.lang.String> strSet52 = exceptionContext44.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str30.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0L + "'", number40.equals(0L));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (short) 10 + "'", number42.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(exceptionContext44);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE));
        org.junit.Assert.assertNotNull(strSet52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalArgumentException7.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        double double5 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100, (java.lang.Number) (short) 0, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_SYMMETRIC_MATRIX));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) 10, (double) (short) 1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertNotNull(chromosomeList3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1, (java.lang.Number) (short) 10);
        java.lang.String str5 = outOfRangeException4.toString();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: wrong array shape (block length = null, expected 1)" + "'", str5.equals("org.apache.commons.math3.exception.OutOfRangeException: wrong array shape (block length = null, expected 1)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        double double9 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f, number2, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        int int5 = elitisticListPopulation2.getPopulationSize();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        int int7 = elitisticListPopulation2.getPopulationLimit();
        java.lang.Class<?> wildcardClass8 = elitisticListPopulation2.getClass();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation2.iterator();
        java.lang.String str9 = elitisticListPopulation2.toString();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome10 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 10.0f, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Number) 0, (java.lang.Number) (-1L), (java.lang.Number) 0.0d);
        java.lang.Number number9 = outOfRangeException8.getLo();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) outOfRangeException8);
        java.lang.Number number11 = outOfRangeException8.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + (-1L) + "'", number9.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.0d + "'", number11.equals(0.0d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, (int) (short) 1, 1.0d);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation5.addChromosome(chromosome6);
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation5.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(population8);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number19 = numberIsTooLargeException18.getArgument();
        java.lang.String str20 = numberIsTooLargeException18.toString();
        java.lang.String str21 = numberIsTooLargeException18.toString();
        mathIllegalArgumentException14.addSuppressed((java.lang.Throwable) numberIsTooLargeException18);
        java.lang.Number number23 = numberIsTooLargeException18.getMax();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException18);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Number) 0, (java.lang.Number) 1.0f, true);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException29);
        java.lang.Number number31 = numberIsTooLargeException4.getMax();
        boolean boolean32 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 10 + "'", number19.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str21.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-1.0d) + "'", number23.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 1.0f + "'", number31.equals(1.0f));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 1L, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0}" + "'", str1.equals("{0}"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        java.lang.Object obj5 = exceptionContext3.getValue("permutation k ({0}) must be positive");
        java.util.Set<java.lang.String> strSet6 = exceptionContext3.getKeys();
        java.util.Set<java.lang.String> strSet7 = exceptionContext3.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(strSet7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray22 = numberIsTooLargeException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number28 = numberIsTooLargeException27.getArgument();
        java.lang.String str29 = numberIsTooLargeException27.toString();
        java.lang.String str30 = numberIsTooLargeException27.toString();
        mathIllegalArgumentException23.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        boolean boolean32 = numberIsTooLargeException27.getBoundIsAllowed();
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean39 = numberIsTooSmallException38.getBoundIsAllowed();
        java.lang.Number number40 = numberIsTooSmallException38.getMin();
        numberIsTooLargeException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException38);
        boolean boolean42 = numberIsTooLargeException27.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext43 = numberIsTooLargeException27.getContext();
        java.lang.Object obj45 = null;
        exceptionContext43.setValue("{0} is smaller than, or equal to, the minimum ({1})", obj45);
        java.lang.Class<?> wildcardClass47 = exceptionContext43.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str30.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0L + "'", number40.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(exceptionContext43);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation2.nextGeneration();
        java.lang.String str9 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertNotNull(population8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 0.0d, false);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SET_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number26 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) 100.0d, number26, true);
        numberIsTooLargeException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException28);
        java.lang.Number number30 = numberIsTooLargeException17.getArgument();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + (short) 10 + "'", number30.equals((short) 10));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 100);
        java.lang.Throwable[] throwableArray2 = notPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        boolean boolean6 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), (java.lang.Number) (byte) 0, false);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "number of points ({0})" + "'", str5.equals("number of points ({0})"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1);
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "sample contains {0} observed points, at least {1} are required" + "'", str3.equals("sample contains {0} observed points, at least {1} are required"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        int int11 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome12 = null;
        elitisticListPopulation2.addChromosome(chromosome12);
        org.apache.commons.math3.genetics.Chromosome chromosome14 = null;
        elitisticListPopulation2.addChromosome(chromosome14);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), number2, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 35, (java.lang.Number) 35, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList6, 52, 1.0d);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertNotNull(chromosomeList6);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        java.lang.Throwable throwable6 = exceptionContext5.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwable6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, (java.lang.Number) (short) 1, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 1 + "'", number6.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 1 + "'", number7.equals((short) 1));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f);
        boolean boolean7 = notPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0L, (java.lang.Number) 100.0d, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) (short) 10, 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation21 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) (short) 100, 1.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) '4', (double) (byte) 1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = null;
        elitisticListPopulation24.setChromosomes(chromosomeList25);
        try {
            elitisticListPopulation24.setElitismRate((double) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, (java.lang.Number) (byte) 100, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooLargeException8.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) (short) 10, true);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean13 = numberIsTooLargeException12.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray14 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray17);
        java.lang.String str19 = mathIllegalArgumentException18.toString();
        java.lang.String str20 = mathIllegalArgumentException18.toString();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = numberIsTooLargeException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.MathIllegalArgumentException: array sums to zero" + "'", str19.equals("org.apache.commons.math3.exception.MathIllegalArgumentException: array sums to zero"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.MathIllegalArgumentException: array sums to zero" + "'", str20.equals("org.apache.commons.math3.exception.MathIllegalArgumentException: array sums to zero"));
        org.junit.Assert.assertNotNull(exceptionContext22);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) 10L, (java.lang.Number) (byte) 1);
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        java.lang.String str7 = localizedFormats6.getSourceString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray13 = outOfRangeException12.getSuppressed();
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        java.lang.Object[] objArray19 = null;
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction." + "'", str7.equals("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction."));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10, (java.lang.Number) 1.0f, true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit(0);
        java.lang.String str12 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray13 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList14, chromosomeArray13);
        elitisticListPopulation2.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList14);
        int int17 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome chromosome19 = null;
        elitisticListPopulation2.addChromosome(chromosome19);
        elitisticListPopulation2.setPopulationLimit((int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null]" + "'", str12.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(chromosomeList18);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        java.lang.String str4 = notPositiveException1.toString();
        java.lang.String str5 = notPositiveException1.toString();
        java.lang.Class<?> wildcardClass6 = notPositiveException1.getClass();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)" + "'", str4.equals("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)" + "'", str5.equals("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)"));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.Number number7 = outOfRangeException4.getHi();
        java.lang.Throwable[] throwableArray8 = outOfRangeException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100 + "'", number6.equals(100));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100 + "'", number7.equals(100));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (byte) 0, true);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext9);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        double double6 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int10 = elitisticListPopulation9.getPopulationSize();
        int int11 = elitisticListPopulation9.getPopulationLimit();
        double double12 = elitisticListPopulation9.getElitismRate();
        java.lang.String str13 = elitisticListPopulation9.toString();
        double double14 = elitisticListPopulation9.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList15 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList15);
        elitisticListPopulation2.setPopulationLimit((int) '#');
        org.apache.commons.math3.genetics.Population population19 = elitisticListPopulation2.nextGeneration();
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[]" + "'", str13.equals("[]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList15);
        org.junit.Assert.assertNotNull(population19);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(1, (double) 0L);
        java.lang.String str3 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[]" + "'", str3.equals("[]"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 1L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        try {
            elitisticListPopulation2.setElitismRate((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(population5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (byte) 100);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit((int) (short) 1);
        int int13 = elitisticListPopulation2.getPopulationLimit();
        int int14 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationLimit();
        int int4 = elitisticListPopulation2.getPopulationSize();
        int int5 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.Population population6 = elitisticListPopulation2.nextGeneration();
        double double7 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(population6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertNotNull(chromosomeItor9);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean9 = numberIsTooLargeException8.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray10 = numberIsTooLargeException8.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray10);
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray14);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0L, (java.lang.Number) (byte) 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10, (java.lang.Number) 0, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException5.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray22 = numberIsTooLargeException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number28 = numberIsTooLargeException27.getArgument();
        java.lang.String str29 = numberIsTooLargeException27.toString();
        java.lang.String str30 = numberIsTooLargeException27.toString();
        mathIllegalArgumentException23.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        boolean boolean32 = numberIsTooLargeException27.getBoundIsAllowed();
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean39 = numberIsTooSmallException38.getBoundIsAllowed();
        java.lang.Number number40 = numberIsTooSmallException38.getMin();
        numberIsTooLargeException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException38);
        java.lang.Number number42 = numberIsTooLargeException27.getArgument();
        java.lang.Throwable[] throwableArray43 = numberIsTooLargeException27.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext44 = numberIsTooLargeException27.getContext();
        java.lang.Throwable throwable45 = exceptionContext44.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str30.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0L + "'", number40.equals(0L));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (short) 10 + "'", number42.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(exceptionContext44);
        org.junit.Assert.assertNotNull(throwable45);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        java.lang.Object obj7 = exceptionContext5.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)");
        java.lang.Object obj9 = exceptionContext5.getValue("out of range");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        elitisticListPopulation2.setElitismRate((double) 0L);
        double double6 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        elitisticListPopulation2.setPopulationLimit((int) (short) -1);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray8 = numberIsTooLargeException6.getSuppressed();
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray14);
        java.lang.Number number17 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, number17, true);
        mathIllegalArgumentException15.addSuppressed((java.lang.Throwable) numberIsTooLargeException19);
        java.lang.Number number21 = numberIsTooLargeException19.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 10.0f + "'", number21.equals(10.0f));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean6 = numberIsTooLargeException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException5.getSuppressed();
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException10);
        java.lang.Throwable throwable12 = exceptionContext11.getThrowable();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwable12);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(35, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (-1L), (java.lang.Number) (byte) 1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet10 = exceptionContext9.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(strSet10);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        double double8 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setElitismRate((double) 1L);
        int int11 = elitisticListPopulation2.getPopulationLimit();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome12 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException4 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean8 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) (-1.0f), true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "two or more values required in each category, one has {0}" + "'", str1.equals("two or more values required in each category, one has {0}"));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.WHOLE_FORMAT;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WHOLE_FORMAT));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "whole format" + "'", str1.equals("whole format"));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0f, (java.lang.Number) 100, (java.lang.Number) (byte) 1);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) 100, true);
        boolean boolean8 = numberIsTooSmallException7.getBoundIsAllowed();
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooSmallException7.getContext();
        java.lang.Object obj11 = exceptionContext9.getValue("empty selected column index array");
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNull(obj11);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        int int5 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setPopulationLimit(35);
        int int8 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) 0L, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        exceptionContext6.setValue("", (java.lang.Object) (byte) -1);
        java.lang.Object obj11 = exceptionContext6.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean19 = numberIsTooLargeException18.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray20 = numberIsTooLargeException18.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Object[]) throwableArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray20);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray20);
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray20);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray20);
        java.lang.Class<?> wildcardClass26 = exceptionContext6.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + (byte) -1 + "'", obj11.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        java.lang.String str8 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome9 = null;
        elitisticListPopulation2.addChromosome(chromosome9);
        org.apache.commons.math3.genetics.Population population11 = elitisticListPopulation2.nextGeneration();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertNotNull(population11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0L);
        java.lang.Number number7 = notPositiveException6.getMin();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) notPositiveException6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0 + "'", number7.equals(0));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 0.0f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEFINITE_MATRIX));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(10);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.apache.commons.math3.genetics.Chromosome chromosome8 = null;
        elitisticListPopulation2.addChromosome(chromosome8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, (int) (short) 1, 1.0d);
        elitisticListPopulation5.setPopulationLimit(100);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation10 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) 10, (double) (short) 1);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation13 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double14 = elitisticListPopulation13.getElitismRate();
        elitisticListPopulation13.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int20 = elitisticListPopulation19.getPopulationSize();
        int int21 = elitisticListPopulation19.getPopulationLimit();
        elitisticListPopulation19.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation26 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList27 = elitisticListPopulation26.getChromosomes();
        elitisticListPopulation26.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population30 = elitisticListPopulation26.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList31 = elitisticListPopulation26.getChromosomes();
        elitisticListPopulation19.setChromosomes(chromosomeList31);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation35 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList31, (int) (short) 10, 0.0d);
        elitisticListPopulation13.setChromosomes(chromosomeList31);
        elitisticListPopulation10.setChromosomes(chromosomeList31);
        elitisticListPopulation5.setChromosomes(chromosomeList31);
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 10 + "'", int21 == 10);
        org.junit.Assert.assertNotNull(chromosomeList27);
        org.junit.Assert.assertNotNull(population30);
        org.junit.Assert.assertNotNull(chromosomeList31);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Object obj8 = exceptionContext5.getValue("");
        java.util.Set<java.lang.String> strSet9 = exceptionContext5.getKeys();
        java.lang.Throwable throwable10 = exceptionContext5.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.ELITISM_RATE;
        java.lang.Number number13 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException14 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, number13);
        exceptionContext5.setValue("empty selected column index array", (java.lang.Object) localizedFormats12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertNotNull(strSet9);
        org.junit.Assert.assertNotNull(throwable10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ELITISM_RATE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ELITISM_RATE));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0d, (java.lang.Number) 0L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 100.0d, (java.lang.Number) 1.0d, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException15 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 10.0d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException15);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean23 = numberIsTooLargeException22.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray24 = numberIsTooLargeException22.getSuppressed();
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray24);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray25);
        exceptionContext16.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray27);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE;
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, number2, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SHAPE));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int8 = elitisticListPopulation7.getPopulationSize();
        int int9 = elitisticListPopulation7.getPopulationLimit();
        elitisticListPopulation7.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome12 = null;
        elitisticListPopulation7.addChromosome(chromosome12);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation7.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        double double16 = elitisticListPopulation2.getElitismRate();
        int int17 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome18 = null;
        elitisticListPopulation2.addChromosome(chromosome18);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population6 = elitisticListPopulation2.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        int int8 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population6);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        java.lang.Object obj3 = exceptionContext1.getValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean9 = numberIsTooLargeException8.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        java.lang.String str23 = numberIsTooLargeException21.toString();
        java.lang.String str24 = numberIsTooLargeException21.toString();
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = numberIsTooLargeException30.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        java.lang.String str39 = numberIsTooLargeException37.toString();
        java.lang.String str40 = numberIsTooLargeException37.toString();
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        boolean boolean42 = numberIsTooLargeException37.getBoundIsAllowed();
        numberIsTooLargeException21.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Class<?> wildcardClass45 = numberIsTooLargeException8.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray50 = numberIsTooLargeException49.getSuppressed();
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        boolean boolean52 = numberIsTooLargeException49.getBoundIsAllowed();
        exceptionContext1.setValue("not positive definite matrix: diagonal element at ({1},{1}) is smaller than {2} ({0})", (java.lang.Object) numberIsTooLargeException49);
        java.lang.Object obj55 = exceptionContext1.getValue("org.apache.commons.math3.exception.MathIllegalArgumentException: illegal state");
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 10 + "'", number22.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (short) 10 + "'", number38.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(obj55);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        int int10 = elitisticListPopulation2.getPopulationLimit();
        int int11 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setElitismRate((double) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        java.lang.Throwable throwable6 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        java.lang.Class<?> wildcardClass9 = localizedFormats8.getClass();
        exceptionContext4.setValue("degrees of freedom must be positive ({0})", (java.lang.Object) localizedFormats8);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) '#', (double) 1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation6 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList3, 10, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) (short) 10, 0.0d);
        int int19 = elitisticListPopulation18.getPopulationLimit();
        java.lang.String str20 = elitisticListPopulation18.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "[]" + "'", str20.equals("[]"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1.0f, false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalArgumentException8.getContext();
        java.util.Set<java.lang.String> strSet10 = exceptionContext9.getKeys();
        java.lang.Throwable throwable11 = exceptionContext9.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Number) 10L, (java.lang.Number) 100.0f, false);
        java.lang.Number number18 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, number18, (java.lang.Number) 1.0f, true);
        exceptionContext9.setValue("initial row {1} after final row {0}", (java.lang.Object) numberIsTooLargeException21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(strSet10);
        org.junit.Assert.assertNotNull(throwable11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean6 = numberIsTooLargeException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (-1L), false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) 10.0f, true);
        java.lang.Number number19 = numberIsTooSmallException18.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) -1 + "'", number19.equals((short) -1));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100, (java.lang.Number) 10, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0d, (java.lang.Number) 100.0f, true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext24 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException17);
        java.util.Set<java.lang.String> strSet25 = exceptionContext24.getKeys();
        java.util.Set<java.lang.String> strSet26 = exceptionContext24.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean35 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray36 = numberIsTooLargeException34.getSuppressed();
        java.lang.Object[] objArray37 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray37);
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray37);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, objArray39);
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray39);
        exceptionContext24.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray39);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(strSet25);
        org.junit.Assert.assertNotNull(strSet26);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray41);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooLargeException4.getArgument();
        java.lang.Class<?> wildcardClass9 = numberIsTooLargeException4.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        java.lang.String str8 = elitisticListPopulation2.toString();
        int int9 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[null]" + "'", str8.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population32 = elitisticListPopulation28.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = elitisticListPopulation28.getChromosomes();
        exceptionContext4.setValue("hi!", (java.lang.Object) elitisticListPopulation28);
        int int35 = elitisticListPopulation28.getPopulationSize();
        java.lang.String str36 = elitisticListPopulation28.toString();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome37 = elitisticListPopulation28.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(population32);
        org.junit.Assert.assertNotNull(chromosomeList33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "[]" + "'", str36.equals("[]"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Number number7 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = numberIsTooSmallException4.getContext();
        java.lang.Throwable[] throwableArray9 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0d + "'", number7.equals(1.0d));
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList5 = null;
        elitisticListPopulation2.setChromosomes(chromosomeList5);
        elitisticListPopulation2.setPopulationLimit((int) 'a');
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setPopulationLimit((int) '4');
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome13 = null;
        elitisticListPopulation8.addChromosome(chromosome13);
        java.lang.String str15 = elitisticListPopulation8.toString();
        java.lang.String str16 = elitisticListPopulation8.toString();
        elitisticListPopulation8.setPopulationLimit((int) (short) 1);
        elitisticListPopulation8.setPopulationLimit((int) (short) 10);
        org.apache.commons.math3.genetics.Chromosome chromosome21 = null;
        elitisticListPopulation8.addChromosome(chromosome21);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList26 = elitisticListPopulation25.getChromosomes();
        org.apache.commons.math3.genetics.Population population27 = elitisticListPopulation25.nextGeneration();
        int int28 = elitisticListPopulation25.getPopulationSize();
        org.apache.commons.math3.genetics.Population population29 = elitisticListPopulation25.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList30 = elitisticListPopulation25.getChromosomes();
        elitisticListPopulation8.setChromosomes(chromosomeList30);
        elitisticListPopulation2.setChromosomes(chromosomeList30);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "[null]" + "'", str15.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "[null]" + "'", str16.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeList26);
        org.junit.Assert.assertNotNull(population27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(population29);
        org.junit.Assert.assertNotNull(chromosomeList30);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        java.lang.String str5 = numberIsTooLargeException3.toString();
        java.lang.String str6 = numberIsTooLargeException3.toString();
        boolean boolean7 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        double double8 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome chromosome4 = null;
        elitisticListPopulation2.addChromosome(chromosome4);
        int int6 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.Population population7 = elitisticListPopulation2.nextGeneration();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 10);
        int int10 = elitisticListPopulation2.getPopulationSize();
        int int11 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(population7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        java.lang.Object[] objArray8 = null;
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean17 = numberIsTooLargeException16.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray18 = numberIsTooLargeException16.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (byte) 0, (java.lang.Number) (-1L));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(1, (double) 1);
        double double3 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = outOfRangeException9.getContext();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        java.lang.Number number12 = outOfRangeException9.getHi();
        java.lang.String str13 = outOfRangeException9.toString();
        java.lang.Number number14 = outOfRangeException9.getHi();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100 + "'", number12.equals(100));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: endpoints do not specify an interval: [-1, -1]" + "'", str13.equals("org.apache.commons.math3.exception.OutOfRangeException: endpoints do not specify an interval: [-1, -1]"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 100 + "'", number14.equals(100));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        java.lang.Number number7 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100L + "'", number7.equals(100L));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, (java.lang.Number) (byte) 100, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 10.0d, true);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)" + "'", str4.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, number2, false);
        java.lang.Number number5 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) 0, (java.lang.Number) (byte) 100, false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100, (java.lang.Number) 1.0f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        java.lang.Throwable throwable25 = exceptionContext4.getThrowable();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(throwable25);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double8 = elitisticListPopulation7.getElitismRate();
        elitisticListPopulation7.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation13 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int14 = elitisticListPopulation13.getPopulationSize();
        int int15 = elitisticListPopulation13.getPopulationLimit();
        elitisticListPopulation13.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = elitisticListPopulation20.getChromosomes();
        elitisticListPopulation20.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population24 = elitisticListPopulation20.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = elitisticListPopulation20.getChromosomes();
        elitisticListPopulation13.setChromosomes(chromosomeList25);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation29 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList25, (int) (short) 10, 0.0d);
        elitisticListPopulation7.setChromosomes(chromosomeList25);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation33 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList25, (int) '#', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList25);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation37 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList25, (int) (short) 0, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chromosomeList21);
        org.junit.Assert.assertNotNull(population24);
        org.junit.Assert.assertNotNull(chromosomeList25);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome5 = null;
        elitisticListPopulation2.addChromosome(chromosome5);
        java.lang.String str7 = elitisticListPopulation2.toString();
        java.lang.String str8 = elitisticListPopulation2.toString();
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[null]" + "'", str7.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[null]" + "'", str8.equals("[null]"));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalArgumentException8.getContext();
        java.lang.Throwable throwable10 = exceptionContext9.getThrowable();
        java.lang.Throwable throwable11 = exceptionContext9.getThrowable();
        java.lang.Object obj13 = exceptionContext9.getValue("{0}");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(throwable10);
        org.junit.Assert.assertNotNull(throwable11);
        org.junit.Assert.assertNull(obj13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        int int5 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10, (java.lang.Number) (byte) -1, false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 0, false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (short) -1);
        elitisticListPopulation2.setPopulationLimit(1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) '4');
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor14 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int18 = elitisticListPopulation17.getPopulationSize();
        int int19 = elitisticListPopulation17.getPopulationLimit();
        elitisticListPopulation17.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList22 = elitisticListPopulation17.getChromosomes();
        int int23 = elitisticListPopulation17.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor24 = elitisticListPopulation17.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = elitisticListPopulation17.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList25);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertNotNull(chromosomeList11);
        org.junit.Assert.assertNotNull(chromosomeItor14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertNotNull(chromosomeList22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor24);
        org.junit.Assert.assertNotNull(chromosomeList25);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.lang.Class<?> wildcardClass3 = elitisticListPopulation2.getClass();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation6 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double7 = elitisticListPopulation6.getElitismRate();
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation6.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation6.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation6.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList10);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = null;
        elitisticListPopulation2.setChromosomes(chromosomeList12);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(population8);
        org.junit.Assert.assertNotNull(chromosomeItor9);
        org.junit.Assert.assertNotNull(chromosomeList10);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) 1L, false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) (byte) 100, (java.lang.Number) (byte) 0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException3);
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = outOfRangeException11.getContext();
        java.lang.Throwable[] throwableArray13 = outOfRangeException11.getSuppressed();
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = outOfRangeException3.getHi();
        java.lang.Number number8 = outOfRangeException3.getLo();
        java.lang.Number number9 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 10 + "'", number7.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(population5);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationLimit();
        int int4 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setElitismRate((double) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (byte) 1, true);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, (java.lang.Number) 1.0d, (java.lang.Number) 1.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) 10L, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) '#', (double) 1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation6 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation6.getChromosomes();
        elitisticListPopulation6.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation6.getChromosomes();
        java.lang.String str11 = elitisticListPopulation6.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor12 = elitisticListPopulation6.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation6.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) (byte) 100, (double) 1);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[]" + "'", str11.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor12);
        org.junit.Assert.assertNotNull(chromosomeList13);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, number2, false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), (java.lang.Number) 10.0f, (java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor16 = elitisticListPopulation2.iterator();
        int int17 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertNotNull(chromosomeItor16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 1.0f, true);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) 1.0d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation15.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population19 = elitisticListPopulation15.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation8.setChromosomes(chromosomeList20);
        elitisticListPopulation2.setChromosomes(chromosomeList20);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor23 = elitisticListPopulation2.iterator();
        double double24 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertNotNull(population19);
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(chromosomeItor23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        int int10 = elitisticListPopulation2.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor11 = elitisticListPopulation2.iterator();
        try {
            org.apache.commons.math3.genetics.Population population12 = elitisticListPopulation2.nextGeneration();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(chromosomeItor11);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0.0d);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(1, (double) 0L);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor3 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int8 = elitisticListPopulation7.getPopulationSize();
        int int9 = elitisticListPopulation7.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double13 = elitisticListPopulation12.getElitismRate();
        elitisticListPopulation12.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int19 = elitisticListPopulation18.getPopulationSize();
        int int20 = elitisticListPopulation18.getPopulationLimit();
        elitisticListPopulation18.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList26 = elitisticListPopulation25.getChromosomes();
        elitisticListPopulation25.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population29 = elitisticListPopulation25.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList30 = elitisticListPopulation25.getChromosomes();
        elitisticListPopulation18.setChromosomes(chromosomeList30);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation34 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList30, (int) (short) 10, 0.0d);
        elitisticListPopulation12.setChromosomes(chromosomeList30);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation38 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList30, (int) '#', 0.0d);
        elitisticListPopulation7.setChromosomes(chromosomeList30);
        elitisticListPopulation2.setChromosomes(chromosomeList30);
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList46 = elitisticListPopulation45.getChromosomes();
        elitisticListPopulation45.setPopulationLimit((int) (byte) 100);
        elitisticListPopulation45.setPopulationLimit((int) (byte) 10);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList51 = elitisticListPopulation45.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList51);
        org.junit.Assert.assertNotNull(chromosomeItor3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
        org.junit.Assert.assertNotNull(chromosomeList26);
        org.junit.Assert.assertNotNull(population29);
        org.junit.Assert.assertNotNull(chromosomeList30);
        org.junit.Assert.assertNotNull(chromosomeList46);
        org.junit.Assert.assertNotNull(chromosomeList51);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        java.lang.Object obj5 = exceptionContext3.getValue("permutation k ({0}) must be positive");
        java.util.Set<java.lang.String> strSet6 = exceptionContext3.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (byte) 0, (java.lang.Number) 10L, false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number16 = outOfRangeException15.getLo();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException18 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Throwable[] throwableArray19 = notPositiveException18.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats20, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean25 = numberIsTooSmallException24.getBoundIsAllowed();
        java.lang.Number number26 = numberIsTooSmallException24.getMin();
        notPositiveException18.addSuppressed((java.lang.Throwable) numberIsTooSmallException24);
        outOfRangeException15.addSuppressed((java.lang.Throwable) notPositiveException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = outOfRangeException15.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, (java.lang.Number) 10.0f, (java.lang.Number) (short) 100, (java.lang.Number) 100.0d);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean39 = numberIsTooLargeException38.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray40 = numberIsTooLargeException38.getSuppressed();
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray40);
        exceptionContext29.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray41);
        org.apache.commons.math3.exception.util.Localizable localizable44 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext49 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException48);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        java.lang.String str51 = localizedFormats50.getSourceString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray57 = outOfRangeException56.getSuppressed();
        java.lang.Object[] objArray58 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray57);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats52, (java.lang.Object[]) throwableArray57);
        java.lang.Object[] objArray60 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray57);
        exceptionContext49.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats50, objArray60);
        exceptionContext29.setValue("the closest orthogonal matrix has a negative determinant {0}", (java.lang.Object) objArray60);
        exceptionContext3.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray60);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.0f + "'", number16.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0L + "'", number26.equals(0L));
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats50.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction." + "'", str51.equals("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction."));
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats52.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        double double6 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population7 = elitisticListPopulation2.nextGeneration();
        java.lang.String str8 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertNotNull(population7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation2.iterator();
        java.lang.String str9 = elitisticListPopulation2.toString();
        try {
            elitisticListPopulation2.setElitismRate((double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException11.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertNotNull(throwableArray16);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation2.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeItor7);
        org.junit.Assert.assertNotNull(chromosomeList8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double8 = elitisticListPopulation7.getElitismRate();
        elitisticListPopulation7.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation13 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int14 = elitisticListPopulation13.getPopulationSize();
        int int15 = elitisticListPopulation13.getPopulationLimit();
        elitisticListPopulation13.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList21 = elitisticListPopulation20.getChromosomes();
        elitisticListPopulation20.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population24 = elitisticListPopulation20.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = elitisticListPopulation20.getChromosomes();
        elitisticListPopulation13.setChromosomes(chromosomeList25);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation29 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList25, (int) (short) 10, 0.0d);
        elitisticListPopulation7.setChromosomes(chromosomeList25);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation33 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList25, (int) '#', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList25);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList35 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(chromosomeList21);
        org.junit.Assert.assertNotNull(population24);
        org.junit.Assert.assertNotNull(chromosomeList25);
        org.junit.Assert.assertNotNull(chromosomeList35);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 100.0f, (java.lang.Number) 100L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation2.getChromosomes();
        int int11 = elitisticListPopulation2.getPopulationLimit();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome12 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        boolean boolean7 = notPositiveException6.getBoundIsAllowed();
        java.lang.Number number8 = notPositiveException6.getMin();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0f);
        notPositiveException6.addSuppressed((java.lang.Throwable) notPositiveException10);
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) notPositiveException10);
        java.lang.Number number13 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double29 = elitisticListPopulation28.getElitismRate();
        org.apache.commons.math3.genetics.Population population30 = elitisticListPopulation28.nextGeneration();
        exceptionContext4.setValue("", (java.lang.Object) population30);
        java.lang.Throwable throwable32 = exceptionContext4.getThrowable();
        java.lang.Throwable throwable33 = null;
        try {
            throwable32.addSuppressed(throwable33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(population30);
        org.junit.Assert.assertNotNull(throwable32);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, number2, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        java.lang.Class<?> wildcardClass6 = outOfRangeException4.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation2.iterator();
        elitisticListPopulation2.setElitismRate(0.0d);
        elitisticListPopulation2.setPopulationLimit((int) (byte) 1);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertNotNull(chromosomeItor6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, (java.lang.Number) (short) 1, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 0L, (java.lang.Number) (-1), (java.lang.Number) 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 0, (java.lang.Number) 0.0d, (java.lang.Number) (byte) 100);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 52, (java.lang.Number) 10, (java.lang.Number) 10.0d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1, (java.lang.Number) (short) 10);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, (java.lang.Number) 1, (java.lang.Number) (byte) -1);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray13);
        java.lang.String str15 = mathIllegalArgumentException14.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math3.exception.MathIllegalArgumentException: wrong array shape (block length = {0}, expected {1})" + "'", str15.equals("org.apache.commons.math3.exception.MathIllegalArgumentException: wrong array shape (block length = {0}, expected {1})"));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        int int11 = elitisticListPopulation2.getPopulationSize();
        try {
            elitisticListPopulation2.setElitismRate((double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) (-1L), true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(35, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        exceptionContext5.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 100 is smaller than the minimum (10)", (java.lang.Object) localizedFormats7);
        java.lang.String str9 = localizedFormats7.getSourceString();
        java.lang.String str10 = localizedFormats7.getSourceString();
        java.lang.Class<?> wildcardClass11 = localizedFormats7.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "initial row {1} after final row {0}" + "'", str9.equals("initial row {1} after final row {0}"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "initial row {1} after final row {0}" + "'", str10.equals("initial row {1} after final row {0}"));
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        java.lang.Object[] objArray0 = null;
        java.lang.Object[] objArray1 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray0);
        java.lang.Object[] objArray2 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray0);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) -1, (java.lang.Number) 1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1 + "'", number4.equals(1));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0, (java.lang.Number) 10L, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10L + "'", number5.equals(10L));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation15.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population19 = elitisticListPopulation15.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation8.setChromosomes(chromosomeList20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) (short) 10, 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) '#', 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation31 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) (short) 100, 0.0d);
        elitisticListPopulation31.setElitismRate(1.0d);
        java.lang.Class<?> wildcardClass34 = elitisticListPopulation31.getClass();
        org.apache.commons.math3.genetics.Population population35 = elitisticListPopulation31.nextGeneration();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertNotNull(population19);
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(population35);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) (short) 10, true);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException9 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (byte) 10);
        boolean boolean10 = notPositiveException9.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = notPositiveException9.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = notPositiveException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean20 = numberIsTooLargeException19.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray21 = numberIsTooLargeException19.getSuppressed();
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray21);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats15, objArray22);
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray24);
        exceptionContext12.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray24);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 0L, (java.lang.Number) (byte) 100);
        java.lang.Number number5 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0L + "'", number5.equals(0L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) 10L, (java.lang.Number) 10.0d);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10.0d + "'", number5.equals(10.0d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 0.0f, (java.lang.Number) 0.0d);
        java.lang.Throwable[] throwableArray6 = outOfRangeException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        java.lang.Throwable throwable4 = exceptionContext3.getThrowable();
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (byte) -1, (java.lang.Number) (short) 10, true);
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException10.getSuppressed();
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray11);
        exceptionContext3.addMessage(localizable5, (java.lang.Object[]) throwableArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(throwable4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList9 = elitisticListPopulation2.getChromosomes();
        int int10 = elitisticListPopulation2.getPopulationLimit();
        int int11 = elitisticListPopulation2.getPopulationSize();
        double double12 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(10);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation10 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int11 = elitisticListPopulation10.getPopulationSize();
        int int12 = elitisticListPopulation10.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population16 = elitisticListPopulation15.nextGeneration();
        elitisticListPopulation15.setPopulationLimit((int) '#');
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList19 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation10.setChromosomes(chromosomeList19);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor21 = elitisticListPopulation10.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = elitisticListPopulation24.getChromosomes();
        elitisticListPopulation24.setPopulationLimit(1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList28 = elitisticListPopulation24.getChromosomes();
        elitisticListPopulation10.setChromosomes(chromosomeList28);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation32 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList28, 10, (double) 1.0f);
        elitisticListPopulation2.setChromosomes(chromosomeList28);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation36 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList28, 0, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertNotNull(population16);
        org.junit.Assert.assertNotNull(chromosomeList19);
        org.junit.Assert.assertNotNull(chromosomeItor21);
        org.junit.Assert.assertNotNull(chromosomeList25);
        org.junit.Assert.assertNotNull(chromosomeList28);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        double double6 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int10 = elitisticListPopulation9.getPopulationSize();
        int int11 = elitisticListPopulation9.getPopulationLimit();
        double double12 = elitisticListPopulation9.getElitismRate();
        java.lang.String str13 = elitisticListPopulation9.toString();
        double double14 = elitisticListPopulation9.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList15 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList15);
        elitisticListPopulation2.setElitismRate(0.0d);
        int int19 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[]" + "'", str13.equals("[]"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation15.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population19 = elitisticListPopulation15.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation8.setChromosomes(chromosomeList20);
        elitisticListPopulation2.setChromosomes(chromosomeList20);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList23 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertNotNull(population19);
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(chromosomeList23);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooSmallException7.getContext();
        java.lang.Class<?> wildcardClass10 = exceptionContext9.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) (-1.0f), false);
        exceptionContext9.setValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.", (java.lang.Object) 10L);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "denominator must be different from 0" + "'", str1.equals("denominator must be different from 0"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) 0, (java.lang.Number) (short) 1);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("degrees of freedom must be positive ({0})", (java.lang.Object) number22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean30 = numberIsTooLargeException29.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray31 = numberIsTooLargeException29.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number37 = numberIsTooLargeException36.getArgument();
        java.lang.String str38 = numberIsTooLargeException36.toString();
        java.lang.String str39 = numberIsTooLargeException36.toString();
        mathIllegalArgumentException32.addSuppressed((java.lang.Throwable) numberIsTooLargeException36);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean46 = numberIsTooLargeException45.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray47 = numberIsTooLargeException45.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, (java.lang.Object[]) throwableArray47);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        java.lang.String str54 = numberIsTooLargeException52.toString();
        java.lang.String str55 = numberIsTooLargeException52.toString();
        mathIllegalArgumentException48.addSuppressed((java.lang.Throwable) numberIsTooLargeException52);
        boolean boolean57 = numberIsTooLargeException52.getBoundIsAllowed();
        numberIsTooLargeException36.addSuppressed((java.lang.Throwable) numberIsTooLargeException52);
        exceptionContext4.setValue("cost relative tolerance is too small ({0}), no further reduction in the sum of squares is possible", (java.lang.Object) numberIsTooLargeException36);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext60 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException36);
        java.util.Set<java.lang.String> strSet61 = exceptionContext60.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (short) 10 + "'", number37.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str38.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (short) 10 + "'", number53.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str54.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str55.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(strSet61);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException(number7, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = outOfRangeException3.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertNotNull(exceptionContext12);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (short) 1, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, true);
        java.lang.Throwable[] throwableArray10 = numberIsTooSmallException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
        org.junit.Assert.assertNotNull(throwableArray10);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        exceptionContext5.setValue("hi!", (java.lang.Object) localizedFormats8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        exceptionContext5.setValue("hi!", (java.lang.Object) localizedFormats11);
        java.util.Set<java.lang.String> strSet13 = exceptionContext5.getKeys();
        java.util.Set<java.lang.String> strSet14 = exceptionContext5.getKeys();
        java.lang.Class<?> wildcardClass15 = exceptionContext5.getClass();
        java.util.Set<java.lang.String> strSet16 = exceptionContext5.getKeys();
        java.lang.Object obj18 = exceptionContext5.getValue("cannot compute beta density at 1 when beta = %.3g");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertNull(obj18);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation2.iterator();
        elitisticListPopulation2.setPopulationLimit((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeItor7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) 100.0f, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) 1L, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) (short) 0, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 0 + "'", number6.equals((short) 0));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) 0 + "'", number7.equals((short) 0));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Throwable[] throwableArray2 = notPositiveException1.getSuppressed();
        boolean boolean3 = notPositiveException1.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = notPositiveException1.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException1);
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        elitisticListPopulation2.setPopulationLimit((int) (short) -1);
        java.lang.String str8 = elitisticListPopulation2.toString();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome9 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10L, (java.lang.Number) 0L, (java.lang.Number) 1.0d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10, (java.lang.Number) 0, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException5);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (-1.0f), (java.lang.Number) (-1.0d), true);
        java.lang.Object[] objArray12 = null;
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.lang.Object obj15 = exceptionContext6.getValue("degrees of freedom must be positive ({0})");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNull(obj15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) (short) 10, number2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        double double4 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList5 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) (byte) -1, (java.lang.Number) 100);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100);
        boolean boolean11 = notPositiveException10.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean8 = numberIsTooLargeException7.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException7.getSuppressed();
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray9);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray12);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray12);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray12);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        double double8 = elitisticListPopulation2.getElitismRate();
        int int9 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), number2, false);
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number5, (java.lang.Number) (byte) 0, (java.lang.Number) 35);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ORIG_AND_PERMUTED_DATA));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) 10.0d, true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationLimit();
        java.lang.String str4 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double8 = elitisticListPopulation7.getElitismRate();
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation7.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation7.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation7.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList11);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertNotNull(chromosomeList11);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1);
        java.lang.Number number3 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList4);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population6 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation2.iterator();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome8 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(population6);
        org.junit.Assert.assertNotNull(chromosomeItor7);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        elitisticListPopulation2.setPopulationLimit((int) (byte) 10);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        int int9 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (-1L));
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException3.getContext();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Number number7 = outOfRangeException3.getHi();
        java.lang.Number number8 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) (-1), (java.lang.Number) 10.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARITHMETIC_EXCEPTION));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 52, false);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) 10L, (java.lang.Number) (byte) 1);
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) 10L, (java.lang.Number) 1.0d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10L + "'", number4.equals(10L));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 10.0f, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray19 = numberIsTooLargeException17.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number25 = numberIsTooLargeException24.getArgument();
        java.lang.String str26 = numberIsTooLargeException24.toString();
        java.lang.String str27 = numberIsTooLargeException24.toString();
        mathIllegalArgumentException20.addSuppressed((java.lang.Throwable) numberIsTooLargeException24);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean34 = numberIsTooLargeException33.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray35 = numberIsTooLargeException33.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Object[]) throwableArray35);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number41 = numberIsTooLargeException40.getArgument();
        java.lang.String str42 = numberIsTooLargeException40.toString();
        java.lang.String str43 = numberIsTooLargeException40.toString();
        mathIllegalArgumentException36.addSuppressed((java.lang.Throwable) numberIsTooLargeException40);
        boolean boolean45 = numberIsTooLargeException40.getBoundIsAllowed();
        numberIsTooLargeException24.addSuppressed((java.lang.Throwable) numberIsTooLargeException40);
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException24);
        java.lang.Throwable[] throwableArray48 = numberIsTooLargeException11.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray48);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray48);
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_DIGIT));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (short) 10 + "'", number25.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str26.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str27.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + (short) 10 + "'", number41.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str42.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str43.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(throwableArray48);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 1);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ELITISM_RATE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, (java.lang.Number) 0L, (java.lang.Number) 10);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) 100, (java.lang.Number) 0.0d, false);
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = outOfRangeException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ELITISM_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ELITISM_RATE));
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList9 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation2.addChromosome(chromosome10);
        elitisticListPopulation2.setPopulationLimit((int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList9);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation2.getChromosomes();
        int int11 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList12 = elitisticListPopulation2.getChromosomes();
        double double13 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) -1, (java.lang.Number) (-1), (java.lang.Number) (-1));
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 0.0d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean7 = numberIsTooLargeException6.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray8 = numberIsTooLargeException6.getSuppressed();
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray11);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray11);
        java.lang.Throwable[] throwableArray14 = mathIllegalArgumentException13.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation12.getChromosomes();
        double double14 = elitisticListPopulation12.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome15 = null;
        elitisticListPopulation12.addChromosome(chromosome15);
        org.apache.commons.math3.genetics.Population population17 = elitisticListPopulation12.nextGeneration();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int21 = elitisticListPopulation20.getPopulationSize();
        int int22 = elitisticListPopulation20.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation25 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population26 = elitisticListPopulation25.nextGeneration();
        elitisticListPopulation25.setPopulationLimit((int) '#');
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation25.getChromosomes();
        elitisticListPopulation20.setChromosomes(chromosomeList29);
        elitisticListPopulation12.setChromosomes(chromosomeList29);
        elitisticListPopulation2.setChromosomes(chromosomeList29);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertNotNull(population17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertNotNull(population26);
        org.junit.Assert.assertNotNull(chromosomeList29);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) 10.0d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "not enough data ({0} rows) for this many predictors ({1} predictors)" + "'", str1.equals("not enough data ({0} rows) for this many predictors ({1} predictors)"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        int int16 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome17 = null;
        elitisticListPopulation2.addChromosome(chromosome17);
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome19 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooSmallException7.getContext();
        java.lang.Throwable[] throwableArray10 = numberIsTooSmallException7.getSuppressed();
        boolean boolean11 = numberIsTooSmallException7.getBoundIsAllowed();
        boolean boolean12 = numberIsTooSmallException7.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        java.lang.Object obj8 = exceptionContext5.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        java.lang.Class<?> wildcardClass10 = localizedFormats9.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray16);
        java.util.Set<java.lang.String> strSet18 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNull(obj8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertNotNull(strSet18);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 52, (java.lang.Number) (byte) 100, false);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationLimit();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Throwable[] throwableArray7 = notPositiveException6.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooSmallException12.getMin();
        notPositiveException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        outOfRangeException3.addSuppressed((java.lang.Throwable) notPositiveException6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = outOfRangeException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException20 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, (java.lang.Number) (-1.0d));
        java.lang.Number number21 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, number21, (java.lang.Number) (byte) 0, false);
        java.lang.String str25 = numberIsTooSmallException24.toString();
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException24);
        java.lang.Class<?> wildcardClass27 = outOfRangeException3.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0L + "'", number14.equals(0L));
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: cannot format a null instance as a complex number" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot format a null instance as a complex number"));
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) -1, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.String str5 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: -1 is larger than the maximum (-1)"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        java.util.Locale locale8 = null;
        try {
            java.lang.String str9 = localizedFormats0.getLocalizedString(locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10L, (java.lang.Number) 1, (java.lang.Number) (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10L, number1, (java.lang.Number) 0.0f);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        java.lang.Throwable throwable5 = exceptionContext4.getThrowable();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwable5);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.lang.Object obj7 = exceptionContext5.getValue("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10.0d);
        java.lang.Object[] objArray11 = null;
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        double double8 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation2.nextGeneration();
        java.lang.String str10 = elitisticListPopulation2.toString();
        double double11 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population12 = elitisticListPopulation2.nextGeneration();
        int int13 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(population12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 100L, (java.lang.Number) 100.0f);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException3.getContext();
        java.lang.Number number6 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0f + "'", number4.equals(100.0f));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.0f + "'", number6.equals(100.0f));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0, (java.lang.Number) (-1.0d), (java.lang.Number) (short) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) 10.0f, true);
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException8);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit(0);
        java.lang.String str12 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray13 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean15 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList14, chromosomeArray13);
        elitisticListPopulation2.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList14);
        int int17 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList18 = elitisticListPopulation2.getChromosomes();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList19 = elitisticListPopulation2.getChromosomes();
        java.lang.String str20 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null]" + "'", str12.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(chromosomeList18);
        org.junit.Assert.assertNotNull(chromosomeList19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "[]" + "'", str20.equals("[]"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        exceptionContext5.setValue("hi!", (java.lang.Object) localizedFormats8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        exceptionContext5.setValue("hi!", (java.lang.Object) localizedFormats11);
        java.util.Set<java.lang.String> strSet13 = exceptionContext5.getKeys();
        java.util.Set<java.lang.String> strSet14 = exceptionContext5.getKeys();
        java.lang.Class<?> wildcardClass15 = exceptionContext5.getClass();
        java.lang.Object obj17 = exceptionContext5.getValue("the difference between the upper and lower bound must be larger than twice the initial trust region radius ({0})");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (short) 1);
        java.lang.Number number2 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation13 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList10, (int) (byte) 0, (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: list of chromosomes bigger than maxPopulationSize");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(chromosomeList10);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        int int7 = elitisticListPopulation2.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor8);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setElitismRate((double) 0.0f);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (byte) -1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, number1, (java.lang.Number) 100);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        exceptionContext6.setValue("", (java.lang.Object) (byte) -1);
        java.lang.Object obj11 = exceptionContext6.getValue("hi!");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray19 = numberIsTooLargeException17.getSuppressed();
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray20);
        java.lang.Throwable throwable24 = exceptionContext6.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwable24);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor7);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList5 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeList5);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, number1, false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray16);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = mathIllegalArgumentException18.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext20);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome5 = null;
        elitisticListPopulation2.addChromosome(chromosome5);
        java.lang.String str7 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit((int) (short) 0);
        elitisticListPopulation2.setPopulationLimit((int) ' ');
        elitisticListPopulation2.setPopulationLimit((int) (short) 0);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[null]" + "'", str7.equals("[null]"));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10, (java.lang.Number) (byte) 10, false);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        java.lang.Object obj3 = exceptionContext1.getValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean9 = numberIsTooLargeException8.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        java.lang.String str23 = numberIsTooLargeException21.toString();
        java.lang.String str24 = numberIsTooLargeException21.toString();
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = numberIsTooLargeException30.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        java.lang.String str39 = numberIsTooLargeException37.toString();
        java.lang.String str40 = numberIsTooLargeException37.toString();
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        boolean boolean42 = numberIsTooLargeException37.getBoundIsAllowed();
        numberIsTooLargeException21.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Class<?> wildcardClass45 = numberIsTooLargeException8.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray50 = numberIsTooLargeException49.getSuppressed();
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        boolean boolean52 = numberIsTooLargeException49.getBoundIsAllowed();
        exceptionContext1.setValue("not positive definite matrix: diagonal element at ({1},{1}) is smaller than {2} ({0})", (java.lang.Object) numberIsTooLargeException49);
        java.lang.Throwable throwable54 = exceptionContext1.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats56, (java.lang.Number) 0L, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext61 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException60);
        java.util.Set<java.lang.String> strSet62 = exceptionContext61.getKeys();
        java.lang.Object obj64 = exceptionContext61.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        java.lang.Class<?> wildcardClass66 = localizedFormats65.getClass();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean71 = numberIsTooLargeException70.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray72 = numberIsTooLargeException70.getSuppressed();
        exceptionContext61.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats65, (java.lang.Object[]) throwableArray72);
        exceptionContext1.setValue("two or more values required in each category, one has {0}", (java.lang.Object) exceptionContext61);
        java.lang.Object obj76 = exceptionContext61.getValue("{0} out of ({1}, {2}] range");
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 10 + "'", number22.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (short) 10 + "'", number38.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertNull(throwable54);
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats56.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(strSet62);
        org.junit.Assert.assertNull(obj64);
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats65.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertNull(obj76);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 10L, true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 100L, (java.lang.Number) (short) -1, false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (-1.0f), true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(1, (double) 0L);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = null;
        elitisticListPopulation2.setChromosomes(chromosomeList3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number5, (java.lang.Number) 100, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 1, true);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException12);
        java.lang.Number number15 = numberIsTooLargeException8.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1 + "'", number13.equals(1));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 100 + "'", number15.equals(100));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = notPositiveException2.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        java.lang.Number number7 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, number7, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean17 = numberIsTooLargeException16.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray18 = numberIsTooLargeException16.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray18);
        java.lang.Class<?> wildcardClass25 = localizedFormats6.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 35);
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "zero not allowed here" + "'", str3.equals("zero not allowed here"));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException2.getContext();
        java.lang.Object obj5 = exceptionContext3.getValue("cost relative tolerance is too small ({0}), no further reduction in the sum of squares is possible");
        java.util.Set<java.lang.String> strSet6 = exceptionContext3.getKeys();
        java.lang.Throwable throwable7 = exceptionContext3.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertNotNull(throwable7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        java.lang.Number number9 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), number9, (java.lang.Number) (short) -1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray16);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException18);
        java.lang.Number number20 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.0f + "'", number20.equals(1.0f));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        java.lang.String str18 = numberIsTooLargeException16.toString();
        java.lang.String str19 = numberIsTooLargeException16.toString();
        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        java.lang.String str34 = numberIsTooLargeException32.toString();
        java.lang.String str35 = numberIsTooLargeException32.toString();
        mathIllegalArgumentException28.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        boolean boolean37 = numberIsTooLargeException32.getBoundIsAllowed();
        numberIsTooLargeException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        java.lang.Class<?> wildcardClass40 = numberIsTooLargeException3.getClass();
        java.lang.String str41 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 10 + "'", number17.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str18.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 10 + "'", number33.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str34.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str41.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0, number1, (java.lang.Number) (short) 0);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        exceptionContext5.addMessage(localizable6, objArray17);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray24 = outOfRangeException23.getSuppressed();
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray24);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) throwableArray24);
        java.lang.Class<?> wildcardClass27 = throwableArray24.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(wildcardClass27);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) (-1L), (java.lang.Number) 0.0d);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "unknown mode {0}, known modes: {1} ({2}), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}) and {11} ({12})" + "'", str5.equals("unknown mode {0}, known modes: {1} ({2}), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}) and {11} ({12})"));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray0 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList1 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean2 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, chromosomeArray0);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation5 = new org.apache.commons.math3.genetics.ElitisticListPopulation((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList1, (int) (short) 1, 1.0d);
        int int6 = elitisticListPopulation5.getPopulationLimit();
        double double7 = elitisticListPopulation5.getElitismRate();
        java.lang.String str8 = elitisticListPopulation5.toString();
        org.junit.Assert.assertNotNull(chromosomeArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        exceptionContext1.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("cannot convert NaN value");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0L, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException12);
        java.util.Set<java.lang.String> strSet14 = exceptionContext13.getKeys();
        exceptionContext1.setValue("", (java.lang.Object) exceptionContext13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        java.lang.String str17 = localizedFormats16.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean22 = numberIsTooLargeException21.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext23 = numberIsTooLargeException21.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean32 = numberIsTooLargeException31.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray33 = numberIsTooLargeException31.getSuppressed();
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray34);
        java.lang.Object[] objArray36 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray34);
        java.lang.Object[] objArray37 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray36);
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable25, objArray39);
        exceptionContext23.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, objArray39);
        java.lang.Throwable throwable42 = exceptionContext23.getThrowable();
        java.lang.Throwable[] throwableArray43 = throwable42.getSuppressed();
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray43);
        java.lang.Class<?> wildcardClass45 = exceptionContext1.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{0}" + "'", str17.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        elitisticListPopulation2.setPopulationLimit(35);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation2.getChromosomes();
        java.lang.String str12 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null]" + "'", str12.equals("[null]"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0f);
        java.lang.Number number2 = notPositiveException1.getMin();
        java.lang.Number number3 = notPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) 0.0d, (java.lang.Number) (-1.0f));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number8 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number8, (java.lang.Number) (short) -1, false);
        java.lang.Number number12 = numberIsTooLargeException11.getMax();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) -1 + "'", number12.equals((short) -1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0.0d, (java.lang.Number) 100.0f, true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) (-1L), false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) (byte) 0, (java.lang.Number) (short) -1, false);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException9);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SIZE_EXCEEDS_MAX_VARIABLES));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, number2, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        exceptionContext5.setValue("hi!", (java.lang.Object) localizedFormats8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        exceptionContext5.setValue("hi!", (java.lang.Object) localizedFormats11);
        java.util.Set<java.lang.String> strSet13 = exceptionContext5.getKeys();
        java.util.Set<java.lang.String> strSet14 = exceptionContext5.getKeys();
        java.lang.Class<?> wildcardClass15 = exceptionContext5.getClass();
        java.util.Set<java.lang.String> strSet16 = exceptionContext5.getKeys();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1L, (java.lang.Number) (short) 0, false);
        java.lang.String str22 = numberIsTooLargeException21.toString();
        boolean boolean23 = numberIsTooLargeException21.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext24 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException21);
        exceptionContext5.setValue("permutation k ({0}) must be positive", (java.lang.Object) exceptionContext24);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean33 = numberIsTooLargeException32.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray34 = numberIsTooLargeException32.getSuppressed();
        java.lang.Object[] objArray35 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray34);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray35);
        java.lang.Object[] objArray37 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray35);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray37);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray37);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, (java.lang.Number) 0, (java.lang.Number) 1.0f, true);
        java.lang.Number number45 = numberIsTooSmallException44.getMin();
        java.lang.Throwable[] throwableArray46 = numberIsTooSmallException44.getSuppressed();
        exceptionContext24.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray46);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(strSet16);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (0)" + "'", str22.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 1 is larger than, or equal to, the maximum (0)"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1.0f + "'", number45.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray46);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor7 = elitisticListPopulation2.iterator();
        try {
            elitisticListPopulation2.setElitismRate((double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeItor7);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor4 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeItor4);
        org.junit.Assert.assertNotNull(population5);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) (-1), (java.lang.Number) (-1L));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        java.lang.Throwable throwable6 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray12 = null;
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.lang.Object[] objArray14 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext16 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException15);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) -1, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_LEFT;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 0);
        java.lang.String str3 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 52, (java.lang.Number) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_LEFT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_LEFT));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0} out of ({1}, {2}] range" + "'", str3.equals("{0} out of ({1}, {2}] range"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray17);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable4, objArray17);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray20);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit(1);
        java.lang.String str6 = elitisticListPopulation2.toString();
        int int7 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation10 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int11 = elitisticListPopulation10.getPopulationSize();
        int int12 = elitisticListPopulation10.getPopulationLimit();
        elitisticListPopulation10.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation17 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int18 = elitisticListPopulation17.getPopulationSize();
        int int19 = elitisticListPopulation17.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double23 = elitisticListPopulation22.getElitismRate();
        elitisticListPopulation22.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int29 = elitisticListPopulation28.getPopulationSize();
        int int30 = elitisticListPopulation28.getPopulationLimit();
        elitisticListPopulation28.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation35 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList36 = elitisticListPopulation35.getChromosomes();
        elitisticListPopulation35.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population39 = elitisticListPopulation35.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList40 = elitisticListPopulation35.getChromosomes();
        elitisticListPopulation28.setChromosomes(chromosomeList40);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation44 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList40, (int) (short) 10, 0.0d);
        elitisticListPopulation22.setChromosomes(chromosomeList40);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation48 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList40, (int) '#', 0.0d);
        elitisticListPopulation17.setChromosomes(chromosomeList40);
        elitisticListPopulation10.setChromosomes(chromosomeList40);
        elitisticListPopulation2.setChromosomes(chromosomeList40);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor52 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 10 + "'", int12 == 10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 10 + "'", int30 == 10);
        org.junit.Assert.assertNotNull(chromosomeList36);
        org.junit.Assert.assertNotNull(population39);
        org.junit.Assert.assertNotNull(chromosomeList40);
        org.junit.Assert.assertNotNull(chromosomeItor52);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Cumulative probability function returned NaN for argument {0} p = {1}" + "'", str1.equals("Cumulative probability function returned NaN for argument {0} p = {1}"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population32 = elitisticListPopulation28.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = elitisticListPopulation28.getChromosomes();
        exceptionContext4.setValue("hi!", (java.lang.Object) elitisticListPopulation28);
        int int35 = elitisticListPopulation28.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor36 = elitisticListPopulation28.iterator();
        elitisticListPopulation28.setPopulationLimit(52);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(population32);
        org.junit.Assert.assertNotNull(chromosomeList33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor36);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10.0f, (java.lang.Number) 35, (java.lang.Number) 10.0f);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.util.Locale locale2 = null;
        try {
            java.lang.String str3 = localizedFormats0.getLocalizedString(locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "not enough data ({0} rows) for this many predictors ({1} predictors)" + "'", str1.equals("not enough data ({0} rows) for this many predictors ({1} predictors)"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (short) 10, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (short) 1, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.USER_EXCEPTION));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) 35, (java.lang.Number) (-1L));
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Throwable[] throwableArray6 = outOfRangeException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10, (java.lang.Number) 0L, (java.lang.Number) 35);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        boolean boolean2 = notPositiveException1.getBoundIsAllowed();
        java.lang.Number number3 = notPositiveException1.getMin();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException5 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 10.0f);
        notPositiveException1.addSuppressed((java.lang.Throwable) notPositiveException5);
        java.lang.Number number7 = notPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1L) + "'", number7.equals((-1L)));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        java.lang.String str8 = localizedFormats0.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) (short) 1, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "initial column {1} after final column {0}" + "'", str8.equals("initial column {1} after final column {0}"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, number2, true);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 10, (java.lang.Number) 1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        int int8 = elitisticListPopulation2.getPopulationLimit();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation2.iterator();
        java.lang.String str10 = elitisticListPopulation2.toString();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(chromosomeItor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        try {
            elitisticListPopulation2.setElitismRate((double) 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (-1L));
        java.lang.Number number12 = outOfRangeException11.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = outOfRangeException11.getContext();
        java.lang.Number number14 = outOfRangeException11.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = outOfRangeException11.getContext();
        java.lang.Number number16 = outOfRangeException11.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = outOfRangeException11.getContext();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
        org.junit.Assert.assertNotNull(exceptionContext17);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        int int7 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setPopulationLimit(1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        int int7 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        java.lang.Object obj3 = exceptionContext1.getValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray10 = outOfRangeException9.getSuppressed();
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray10);
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray10);
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray13);
        java.lang.Throwable throwable15 = exceptionContext1.getThrowable();
        org.apache.commons.math3.exception.util.Localizable localizable16 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean27 = numberIsTooLargeException26.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray28 = numberIsTooLargeException26.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number34 = numberIsTooLargeException33.getArgument();
        java.lang.String str35 = numberIsTooLargeException33.toString();
        java.lang.String str36 = numberIsTooLargeException33.toString();
        mathIllegalArgumentException29.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean43 = numberIsTooLargeException42.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray44 = numberIsTooLargeException42.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats38, (java.lang.Object[]) throwableArray44);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number50 = numberIsTooLargeException49.getArgument();
        java.lang.String str51 = numberIsTooLargeException49.toString();
        java.lang.String str52 = numberIsTooLargeException49.toString();
        mathIllegalArgumentException45.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        boolean boolean54 = numberIsTooLargeException49.getBoundIsAllowed();
        numberIsTooLargeException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        numberIsTooLargeException20.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext57 = numberIsTooLargeException33.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        exceptionContext57.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)", (java.lang.Object) localizedFormats59);
        java.lang.Object obj62 = exceptionContext57.getValue("");
        org.apache.commons.math3.exception.util.Localizable localizable63 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number66 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats64, (java.lang.Number) 100.0d, number66, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext69 = numberIsTooLargeException68.getContext();
        java.util.Set<java.lang.String> strSet70 = exceptionContext69.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        exceptionContext69.setValue("hi!", (java.lang.Object) localizedFormats72);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats75 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        exceptionContext69.setValue("hi!", (java.lang.Object) localizedFormats75);
        java.util.Set<java.lang.String> strSet77 = exceptionContext69.getKeys();
        java.util.Set<java.lang.String> strSet78 = exceptionContext69.getKeys();
        java.lang.Class<?> wildcardClass79 = exceptionContext69.getClass();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats80 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats81 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats82 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException86 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean87 = numberIsTooLargeException86.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray88 = numberIsTooLargeException86.getSuppressed();
        java.lang.Object[] objArray89 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray88);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats82, objArray89);
        java.lang.Object[] objArray91 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray89);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException92 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats81, objArray91);
        exceptionContext69.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats80, objArray91);
        exceptionContext57.addMessage(localizable63, objArray91);
        java.lang.Object[] objArray95 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray91);
        exceptionContext1.addMessage(localizable16, objArray91);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(throwable15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (short) 10 + "'", number34.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str36.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + (short) 10 + "'", number50.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str51.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str52.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(exceptionContext57);
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats59.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertNull(obj62);
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats64.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext69);
        org.junit.Assert.assertNotNull(strSet70);
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats72.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats75 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats75.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
        org.junit.Assert.assertNotNull(strSet77);
        org.junit.Assert.assertNotNull(strSet78);
        org.junit.Assert.assertNotNull(wildcardClass79);
        org.junit.Assert.assertTrue("'" + localizedFormats80 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats80.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
        org.junit.Assert.assertTrue("'" + localizedFormats81 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats81.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats82 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats82.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(throwableArray88);
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(objArray91);
        org.junit.Assert.assertNotNull(objArray95);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math3.exception.util.Localizable localizable6 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray14);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray14);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        exceptionContext5.addMessage(localizable6, objArray17);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray24 = outOfRangeException23.getSuppressed();
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray24);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Object[]) throwableArray24);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Number) 10.0d, (java.lang.Number) 1, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException30);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        java.lang.String str7 = elitisticListPopulation2.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation2.iterator();
        double double9 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation2.addChromosome(chromosome10);
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "[]" + "'", str7.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 35, (java.lang.Number) 1.0f);
        java.lang.String str5 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "unable to perform Q.R decomposition on the {0}x{1} jacobian matrix" + "'", str5.equals("unable to perform Q.R decomposition on the {0}x{1} jacobian matrix"));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1.0d, false);
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray5);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 100, (java.lang.Number) 0, (java.lang.Number) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, number1, true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        elitisticListPopulation2.setPopulationLimit((int) (byte) 10);
        org.apache.commons.math3.genetics.Chromosome chromosome8 = null;
        elitisticListPopulation2.addChromosome(chromosome8);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation2.iterator();
        java.lang.String str11 = elitisticListPopulation2.toString();
        java.lang.String str12 = elitisticListPopulation2.toString();
        int int13 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[null]" + "'", str11.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "[null]" + "'", str12.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 1, (java.lang.Number) 10.0d, (java.lang.Number) (-1.0f));
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0d + "'", number4.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0f) + "'", number5.equals((-1.0f)));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray22 = numberIsTooLargeException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number28 = numberIsTooLargeException27.getArgument();
        java.lang.String str29 = numberIsTooLargeException27.toString();
        java.lang.String str30 = numberIsTooLargeException27.toString();
        mathIllegalArgumentException23.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        boolean boolean32 = numberIsTooLargeException27.getBoundIsAllowed();
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        boolean boolean34 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.String str35 = numberIsTooLargeException11.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str30.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 100.0f, false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(0, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, (java.lang.Number) (-1), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean27 = numberIsTooLargeException26.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray28 = numberIsTooLargeException26.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats22, (java.lang.Object[]) throwableArray28);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number34 = numberIsTooLargeException33.getArgument();
        java.lang.String str35 = numberIsTooLargeException33.toString();
        java.lang.String str36 = numberIsTooLargeException33.toString();
        mathIllegalArgumentException29.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        boolean boolean38 = numberIsTooLargeException33.getBoundIsAllowed();
        numberIsTooLargeException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException33);
        boolean boolean40 = numberIsTooLargeException17.getBoundIsAllowed();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1) + "'", number5.equals((-1)));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (short) 10 + "'", number34.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str36.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation9 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation9.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation9.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList14 = elitisticListPopulation9.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList14);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList14, (int) (short) 10, 0.0d);
        int int19 = elitisticListPopulation18.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation22 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int23 = elitisticListPopulation22.getPopulationSize();
        int int24 = elitisticListPopulation22.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation27 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double28 = elitisticListPopulation27.getElitismRate();
        elitisticListPopulation27.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation33 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int34 = elitisticListPopulation33.getPopulationSize();
        int int35 = elitisticListPopulation33.getPopulationLimit();
        elitisticListPopulation33.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation40 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList41 = elitisticListPopulation40.getChromosomes();
        elitisticListPopulation40.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population44 = elitisticListPopulation40.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList45 = elitisticListPopulation40.getChromosomes();
        elitisticListPopulation33.setChromosomes(chromosomeList45);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation49 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList45, (int) (short) 10, 0.0d);
        elitisticListPopulation27.setChromosomes(chromosomeList45);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation53 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList45, (int) '#', 0.0d);
        elitisticListPopulation22.setChromosomes(chromosomeList45);
        elitisticListPopulation18.setChromosomes(chromosomeList45);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(population13);
        org.junit.Assert.assertNotNull(chromosomeList14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 10 + "'", int19 == 10);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 10 + "'", int24 == 10);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 10 + "'", int35 == 10);
        org.junit.Assert.assertNotNull(chromosomeList41);
        org.junit.Assert.assertNotNull(population44);
        org.junit.Assert.assertNotNull(chromosomeList45);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean8 = numberIsTooLargeException7.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException7.getSuppressed();
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray9);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray12);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray12);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray12);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, (java.lang.Number) 100, (java.lang.Number) 0L);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj10 = exceptionContext8.getValue("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        java.lang.Object[] objArray12 = null;
        exceptionContext8.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray12);
        java.util.Locale locale14 = null;
        try {
            java.lang.String str15 = localizedFormats11.getLocalizedString(locale14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0f + "'", number7.equals(0.0f));
        org.junit.Assert.assertNull(obj10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1.0d));
        java.lang.Class<?> wildcardClass2 = notPositiveException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList0 = null;
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation3 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList0, (int) (short) 10, (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) 1.0f, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        java.lang.Class<?> wildcardClass7 = throwableArray6.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (-1L));
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Throwable[] throwableArray5 = outOfRangeException3.getSuppressed();
        java.lang.Number number6 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        int int5 = elitisticListPopulation2.getPopulationSize();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        int int8 = elitisticListPopulation2.getPopulationLimit();
        int int9 = elitisticListPopulation2.getPopulationLimit();
        try {
            org.apache.commons.math3.genetics.Population population10 = elitisticListPopulation2.nextGeneration();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit((int) (short) -1);
        elitisticListPopulation2.setPopulationLimit(1);
        double double11 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setElitismRate((double) (short) 0);
        java.lang.String str14 = elitisticListPopulation2.toString();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(chromosomeList6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[]" + "'", str14.equals("[]"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        java.lang.Number number7 = numberIsTooSmallException4.getMin();
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (byte) 1 + "'", number6.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 1 + "'", number7.equals((byte) 1));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (byte) 1 + "'", number8.equals((byte) 1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number5, (java.lang.Number) 100, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 1, true);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException12);
        java.lang.Number number15 = numberIsTooLargeException12.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1 + "'", number13.equals(1));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1 + "'", number15.equals(1));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0d, (java.lang.Number) (short) 0, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 0 + "'", number4.equals((short) 0));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor18 = elitisticListPopulation2.iterator();
        elitisticListPopulation2.setPopulationLimit(0);
        double double21 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertNotNull(chromosomeItor18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        double double6 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        java.lang.String str4 = elitisticListPopulation2.toString();
        int int5 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[]" + "'", str4.equals("[]"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooSmallException4.getContext();
        java.lang.Throwable throwable7 = exceptionContext6.getThrowable();
        java.util.Set<java.lang.String> strSet8 = exceptionContext6.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(throwable7);
        org.junit.Assert.assertNotNull(strSet8);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = outOfRangeException9.getContext();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100.0d, (java.lang.Number) 100.0d, false);
        boolean boolean17 = numberIsTooLargeException16.getBoundIsAllowed();
        outOfRangeException4.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        java.lang.Number number19 = outOfRangeException4.getLo();
        java.lang.Number number20 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (-1.0d) + "'", number19.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.0d) + "'", number20.equals((-1.0d)));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Throwable[] throwableArray6 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0f + "'", number5.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1), (java.lang.Number) 0.0f, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 0.0d, true);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 10L, (java.lang.Number) (byte) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.lang.Throwable throwable6 = exceptionContext5.getThrowable();
        java.lang.Throwable throwable7 = exceptionContext5.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertNotNull(throwable7);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList9 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation12 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList9, (-1), (double) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: list of chromosomes bigger than maxPopulationSize");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        java.lang.String str2 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "points {0} and {1} are not decreasing ({2} < {3})" + "'", str2.equals("points {0} and {1} are not decreasing ({2} < {3})"));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor18 = elitisticListPopulation2.iterator();
        elitisticListPopulation2.setPopulationLimit(0);
        java.lang.String str21 = elitisticListPopulation2.toString();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertNotNull(chromosomeItor18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "[]" + "'", str21.equals("[]"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0d, (java.lang.Number) 0.0d, (java.lang.Number) (-1L));
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException3.getContext();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Number number7 = outOfRangeException3.getLo();
        java.lang.Throwable[] throwableArray8 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.0d + "'", number7.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        elitisticListPopulation2.setPopulationLimit((int) '#');
        java.lang.String str6 = elitisticListPopulation2.toString();
        int int7 = elitisticListPopulation2.getPopulationLimit();
        java.lang.String str8 = elitisticListPopulation2.toString();
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1.0f), number1, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) (byte) 100, false);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        boolean boolean9 = numberIsTooSmallException7.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        double double8 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setElitismRate((double) 1L);
        int int11 = elitisticListPopulation2.getPopulationLimit();
        java.lang.Class<?> wildcardClass12 = elitisticListPopulation2.getClass();
        org.apache.commons.math3.genetics.Population population13 = elitisticListPopulation2.nextGeneration();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 10 + "'", int11 == 10);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(population13);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException2.getContext();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        exceptionContext3.setValue("", (java.lang.Object) true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = notPositiveException1.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray4 = null;
        exceptionContext2.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (byte) 10);
        boolean boolean9 = notPositiveException8.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray10 = notPositiveException8.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = notPositiveException8.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean23 = numberIsTooLargeException22.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray24 = numberIsTooLargeException22.getSuppressed();
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray24);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats18, objArray25);
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray25);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray27);
        exceptionContext11.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray27);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray35 = numberIsTooLargeException34.getSuppressed();
        java.lang.String str36 = numberIsTooLargeException34.toString();
        boolean boolean37 = numberIsTooLargeException34.getBoundIsAllowed();
        java.lang.Number number38 = numberIsTooLargeException34.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext39 = numberIsTooLargeException34.getContext();
        java.lang.Throwable[] throwableArray40 = numberIsTooLargeException34.getSuppressed();
        exceptionContext2.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Object[]) throwableArray40);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str36.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 100L + "'", number38.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext39);
        org.junit.Assert.assertNotNull(throwableArray40);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 0.0f, (java.lang.Number) 1L);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0f + "'", number4.equals(0.0f));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        java.lang.String str18 = numberIsTooLargeException16.toString();
        java.lang.String str19 = numberIsTooLargeException16.toString();
        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        java.lang.String str34 = numberIsTooLargeException32.toString();
        java.lang.String str35 = numberIsTooLargeException32.toString();
        mathIllegalArgumentException28.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        boolean boolean37 = numberIsTooLargeException32.getBoundIsAllowed();
        numberIsTooLargeException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext40 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 10 + "'", number17.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str18.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 10 + "'", number33.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str34.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertNotNull(population8);
        org.junit.Assert.assertNotNull(chromosomeItor9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        java.lang.Throwable throwable6 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (short) 10, (java.lang.Number) (byte) -1, (java.lang.Number) 1.0d);
        java.lang.Object[] objArray12 = null;
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray12);
        java.lang.Object obj15 = exceptionContext4.getValue("the difference between the upper and lower bound must be larger than twice the initial trust region radius ({0})");
        java.lang.Object obj17 = exceptionContext4.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: cannot format a null instance as a complex number");
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE));
        org.junit.Assert.assertNull(obj15);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.0f, (java.lang.Number) 1.0d, (java.lang.Number) 0.0f);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (-1), (java.lang.Number) 10.0f, false);
        java.lang.Throwable[] throwableArray11 = numberIsTooSmallException10.getSuppressed();
        outOfRangeException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0d + "'", number4.equals(1.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.0d + "'", number5.equals(1.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertNotNull(throwableArray11);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (short) 10, (double) (short) 1);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        org.apache.commons.math3.genetics.Chromosome chromosome4 = null;
        elitisticListPopulation2.addChromosome(chromosome4);
        org.junit.Assert.assertNotNull(population3);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) (byte) -1, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100.0d, (java.lang.Number) (-1L), (java.lang.Number) (byte) -1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) 10.0f, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
        java.lang.String str10 = numberIsTooLargeException8.toString();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException8);
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str10.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertNotNull(throwableArray12);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) (byte) -1, (java.lang.Number) 100);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0f, (java.lang.Number) 100.0f, false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) 100, (java.lang.Number) 100.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.0f, (java.lang.Number) (short) 1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 1.0f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = outOfRangeException9.getContext();
        outOfRangeException4.addSuppressed((java.lang.Throwable) outOfRangeException9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException4);
        java.util.Set<java.lang.String> strSet13 = exceptionContext12.getKeys();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext19 = numberIsTooSmallException18.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        java.lang.String str34 = numberIsTooLargeException32.toString();
        java.lang.String str35 = numberIsTooLargeException32.toString();
        mathIllegalArgumentException28.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        java.lang.Number number37 = numberIsTooLargeException32.getMax();
        exceptionContext19.setValue("degrees of freedom must be positive ({0})", (java.lang.Object) number37);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean45 = numberIsTooLargeException44.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray46 = numberIsTooLargeException44.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, (java.lang.Object[]) throwableArray46);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number52 = numberIsTooLargeException51.getArgument();
        java.lang.String str53 = numberIsTooLargeException51.toString();
        java.lang.String str54 = numberIsTooLargeException51.toString();
        mathIllegalArgumentException47.addSuppressed((java.lang.Throwable) numberIsTooLargeException51);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats56 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean61 = numberIsTooLargeException60.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray62 = numberIsTooLargeException60.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats56, (java.lang.Object[]) throwableArray62);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number68 = numberIsTooLargeException67.getArgument();
        java.lang.String str69 = numberIsTooLargeException67.toString();
        java.lang.String str70 = numberIsTooLargeException67.toString();
        mathIllegalArgumentException63.addSuppressed((java.lang.Throwable) numberIsTooLargeException67);
        boolean boolean72 = numberIsTooLargeException67.getBoundIsAllowed();
        numberIsTooLargeException51.addSuppressed((java.lang.Throwable) numberIsTooLargeException67);
        exceptionContext19.setValue("cost relative tolerance is too small ({0}), no further reduction in the sum of squares is possible", (java.lang.Object) numberIsTooLargeException51);
        java.lang.Throwable throwable75 = exceptionContext19.getThrowable();
        exceptionContext12.setValue("number of points ({0})", (java.lang.Object) exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(strSet13);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 10 + "'", number33.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str34.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (-1.0d) + "'", number37.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + (short) 10 + "'", number52.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str53.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str54.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats56 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats56.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(throwableArray62);
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + (short) 10 + "'", number68.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str69.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str70.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(throwable75);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        int int9 = elitisticListPopulation2.getPopulationLimit();
        java.lang.String str10 = elitisticListPopulation2.toString();
        try {
            elitisticListPopulation2.setElitismRate((double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1.0f, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0f, (java.lang.Number) 100.0f, (java.lang.Number) 100.0f);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        java.lang.String str8 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome9 = null;
        elitisticListPopulation2.addChromosome(chromosome9);
        java.lang.String str11 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit(0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "[]" + "'", str8.equals("[]"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "[null]" + "'", str11.equals("[null]"));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_REAL_FINITE_ORDINATE));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 100.0d, (java.lang.Number) (-1L), (java.lang.Number) (byte) -1);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1L) + "'", number4.equals((-1L)));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 100.0d, true);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        java.lang.Object[] objArray5 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray4);
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray5);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean6 = numberIsTooLargeException5.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray7 = numberIsTooLargeException5.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10L, (java.lang.Number) (-1L), false);
        java.lang.Number number15 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number15, (java.lang.Number) 100L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.Class<?> wildcardClass15 = mathIllegalArgumentException14.getClass();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException14);
        boolean boolean17 = numberIsTooSmallException4.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext18 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, (java.lang.Number) 0, (java.lang.Number) 100, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException26 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) (byte) 10);
        boolean boolean27 = notPositiveException26.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray28 = notPositiveException26.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext29 = notPositiveException26.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean41 = numberIsTooLargeException40.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray42 = numberIsTooLargeException40.getSuppressed();
        java.lang.Object[] objArray43 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray42);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats36, objArray43);
        java.lang.Object[] objArray45 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray43);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats35, objArray45);
        exceptionContext29.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray45);
        java.lang.Object[] objArray48 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray45);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray45);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException55 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean56 = numberIsTooLargeException55.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray57 = numberIsTooLargeException55.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats51, (java.lang.Object[]) throwableArray57);
        java.lang.Object[] objArray59 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray57);
        java.lang.Object[] objArray60 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray59);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats50, objArray60);
        java.lang.Object[] objArray62 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray60);
        exceptionContext18.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray60);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(exceptionContext18);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertNotNull(exceptionContext29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(throwableArray42);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats50.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray62);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        java.lang.Throwable throwable6 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable6);
        java.lang.Object obj9 = exceptionContext7.getValue("{0}");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = numberIsTooSmallException13.getContext();
        java.util.Set<java.lang.String> strSet15 = exceptionContext14.getKeys();
        java.lang.Throwable throwable16 = exceptionContext14.getThrowable();
        java.lang.Object obj18 = exceptionContext14.getValue("cannot compute beta density at 1 when beta = %.3g");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number24 = outOfRangeException23.getLo();
        java.lang.Number number25 = outOfRangeException23.getLo();
        java.lang.Number number26 = outOfRangeException23.getHi();
        exceptionContext14.setValue("cost relative tolerance is too small ({0}), no further reduction in the sum of squares is possible", (java.lang.Object) number26);
        java.util.Set<java.lang.String> strSet28 = exceptionContext14.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Throwable[] throwableArray35 = outOfRangeException34.getSuppressed();
        java.lang.Object[] objArray36 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray35);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats30, (java.lang.Object[]) throwableArray35);
        java.lang.Object[] objArray38 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray35);
        exceptionContext14.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, objArray38);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext44 = numberIsTooSmallException43.getContext();
        java.lang.Throwable[] throwableArray45 = numberIsTooSmallException43.getSuppressed();
        java.lang.Object[] objArray46 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray45);
        exceptionContext7.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Object[]) throwableArray45);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(throwable6);
        org.junit.Assert.assertNull(obj9);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertNotNull(strSet15);
        org.junit.Assert.assertNotNull(throwable16);
        org.junit.Assert.assertNull(obj18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.0f + "'", number24.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0f + "'", number25.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (short) 10 + "'", number26.equals((short) 10));
        org.junit.Assert.assertNotNull(strSet28);
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(exceptionContext44);
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray46);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        java.lang.Number number5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number5, (java.lang.Number) 100, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 1, true);
        java.lang.Number number13 = numberIsTooLargeException12.getMax();
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException12);
        boolean boolean15 = numberIsTooLargeException8.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1 + "'", number13.equals(1));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        exceptionContext1.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)", (java.lang.Object) localizedFormats3);
        java.lang.Object obj6 = exceptionContext1.getValue("cannot convert NaN value");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) 0L, (java.lang.Number) (byte) 10, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException12);
        java.util.Set<java.lang.String> strSet14 = exceptionContext13.getKeys();
        exceptionContext1.setValue("", (java.lang.Object) exceptionContext13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        java.lang.String str17 = localizedFormats16.getSourceString();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean22 = numberIsTooLargeException21.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext23 = numberIsTooLargeException21.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.apache.commons.math3.exception.util.Localizable localizable25 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean32 = numberIsTooLargeException31.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray33 = numberIsTooLargeException31.getSuppressed();
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray34);
        java.lang.Object[] objArray36 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray34);
        java.lang.Object[] objArray37 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray36);
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray36);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable25, objArray39);
        exceptionContext23.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, objArray39);
        java.lang.Throwable throwable42 = exceptionContext23.getThrowable();
        java.lang.Throwable[] throwableArray43 = throwable42.getSuppressed();
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray43);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        java.lang.Number number46 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, number46, (java.lang.Number) 1, (java.lang.Number) (short) 10);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, (java.lang.Number) (byte) 10, (java.lang.Number) 1, (java.lang.Number) (byte) -1);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray58 = numberIsTooLargeException57.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats61 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats62 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException66 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean67 = numberIsTooLargeException66.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray68 = numberIsTooLargeException66.getSuppressed();
        java.lang.Object[] objArray69 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray68);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats62, objArray69);
        java.lang.Object[] objArray71 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray69);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats61, objArray71);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats60, objArray71);
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, objArray71);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(obj6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertNotNull(strSet14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "{0}" + "'", str17.equals("{0}"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(throwable42);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats60.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERMUTATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats61 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats61.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
        org.junit.Assert.assertTrue("'" + localizedFormats62 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats62.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertNotNull(objArray71);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        double double9 = elitisticListPopulation2.getElitismRate();
        int int10 = elitisticListPopulation2.getPopulationSize();
        int int11 = elitisticListPopulation2.getPopulationSize();
        double double12 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.Population population14 = elitisticListPopulation2.nextGeneration();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: population limit has to be positive");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList13);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) 1L, false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0L);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = notPositiveException1.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.lang.Object[] objArray4 = null;
        exceptionContext2.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, objArray4);
        java.util.Locale locale6 = null;
        try {
            java.lang.String str7 = localizedFormats3.getLocalizedString(locale6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }
}

