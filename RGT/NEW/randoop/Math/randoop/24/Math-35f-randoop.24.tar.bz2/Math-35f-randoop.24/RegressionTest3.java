import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test01");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(100, (double) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test02");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean12 = numberIsTooLargeException11.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException11.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Object[]) throwableArray13);
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray13);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray13);
        java.lang.String str17 = localizedFormats6.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_SUPPORTED_IN_DIMENSION_N));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "method not supported in dimension {0}" + "'", str17.equals("method not supported in dimension {0}"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test03");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (byte) 1, (java.lang.Number) 10.0f, false);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test04");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, (java.lang.Number) 0.0f, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean9 = numberIsTooLargeException8.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean15 = numberIsTooLargeException14.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray16 = numberIsTooLargeException14.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray16);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number22 = numberIsTooLargeException21.getArgument();
        java.lang.String str23 = numberIsTooLargeException21.toString();
        java.lang.String str24 = numberIsTooLargeException21.toString();
        mathIllegalArgumentException17.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean31 = numberIsTooLargeException30.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray32 = numberIsTooLargeException30.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats26, (java.lang.Object[]) throwableArray32);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number38 = numberIsTooLargeException37.getArgument();
        java.lang.String str39 = numberIsTooLargeException37.toString();
        java.lang.String str40 = numberIsTooLargeException37.toString();
        mathIllegalArgumentException33.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        boolean boolean42 = numberIsTooLargeException37.getBoundIsAllowed();
        numberIsTooLargeException21.addSuppressed((java.lang.Throwable) numberIsTooLargeException37);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException21);
        java.lang.Number number45 = numberIsTooLargeException8.getArgument();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        numberIsTooLargeException8.addSuppressed((java.lang.Throwable) numberIsTooLargeException49);
        java.lang.Throwable[] throwableArray51 = numberIsTooLargeException49.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (short) 10 + "'", number22.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + (short) 10 + "'", number38.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + (short) 10 + "'", number45.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray51);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test05");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 10.0d, (java.lang.Number) 0.0f, (java.lang.Number) (byte) 100);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test06");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(35, (double) 1L);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test07");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number2, (java.lang.Number) (-1.0f), true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_UNSUPPORTED_METHOD));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test08");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population32 = elitisticListPopulation28.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = elitisticListPopulation28.getChromosomes();
        exceptionContext4.setValue("hi!", (java.lang.Object) elitisticListPopulation28);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation37 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int38 = elitisticListPopulation37.getPopulationSize();
        int int39 = elitisticListPopulation37.getPopulationLimit();
        elitisticListPopulation37.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList42 = elitisticListPopulation37.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation45 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList42, (int) 'a', 0.0d);
        elitisticListPopulation28.setChromosomes(chromosomeList42);
        java.lang.String str47 = elitisticListPopulation28.toString();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor48 = elitisticListPopulation28.iterator();
        int int49 = elitisticListPopulation28.getPopulationLimit();
        double double50 = elitisticListPopulation28.getElitismRate();
        org.apache.commons.math3.genetics.Population population51 = elitisticListPopulation28.nextGeneration();
        try {
            elitisticListPopulation28.setElitismRate((double) (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(population32);
        org.junit.Assert.assertNotNull(chromosomeList33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
        org.junit.Assert.assertNotNull(chromosomeList42);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "[]" + "'", str47.equals("[]"));
        org.junit.Assert.assertNotNull(chromosomeItor48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(population51);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test09");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10, (java.lang.Number) (short) -1, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test10");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        int int8 = elitisticListPopulation2.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation2.iterator();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList10 = elitisticListPopulation2.getChromosomes();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation14 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList11, (int) (byte) -1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: list of chromosomes bigger than maxPopulationSize");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor9);
        org.junit.Assert.assertNotNull(chromosomeList10);
        org.junit.Assert.assertNotNull(chromosomeList11);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test11");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1), (java.lang.Number) 10.0d, (java.lang.Number) 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test12");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor4 = elitisticListPopulation2.iterator();
        double double5 = elitisticListPopulation2.getElitismRate();
        int int6 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeItor4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test13");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(10);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation15 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList16 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation15.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population19 = elitisticListPopulation15.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation15.getChromosomes();
        elitisticListPopulation8.setChromosomes(chromosomeList20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) (short) 10, 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) '#', 0.0d);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation31 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) (short) 100, 0.0d);
        elitisticListPopulation31.setElitismRate(1.0d);
        java.lang.String str34 = elitisticListPopulation31.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList16);
        org.junit.Assert.assertNotNull(population19);
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "[]" + "'", str34.equals("[]"));
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test14");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(10);
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        java.lang.Class<?> wildcardClass8 = elitisticListPopulation2.getClass();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(chromosomeItor9);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test15");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 100, number1, true);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test16");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) (short) 100, (java.lang.Number) 10L);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test17");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit((int) (short) 1);
        elitisticListPopulation2.setPopulationLimit((int) (short) 10);
        org.apache.commons.math3.genetics.Chromosome chromosome15 = null;
        elitisticListPopulation2.addChromosome(chromosome15);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation19.getChromosomes();
        org.apache.commons.math3.genetics.Population population21 = elitisticListPopulation19.nextGeneration();
        int int22 = elitisticListPopulation19.getPopulationSize();
        org.apache.commons.math3.genetics.Population population23 = elitisticListPopulation19.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList24 = elitisticListPopulation19.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList24);
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList24, (int) (short) -1, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: list of chromosomes bigger than maxPopulationSize");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(population21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(population23);
        org.junit.Assert.assertNotNull(chromosomeList24);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test18");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
        java.lang.Object obj3 = exceptionContext1.getValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.0d, (java.lang.Number) (short) 0, true);
        java.lang.Throwable[] throwableArray9 = numberIsTooLargeException8.getSuppressed();
        exceptionContext1.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray9);
        java.lang.String str11 = localizedFormats4.getSourceString();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "cannot format a {0} instance as a complex number" + "'", str11.equals("cannot format a {0} instance as a complex number"));
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test19");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) 0, false);
        java.util.Locale locale5 = null;
        try {
            java.lang.String str6 = localizedFormats0.getLocalizedString(locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test20");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        double double3 = elitisticListPopulation2.getElitismRate();
        elitisticListPopulation2.setPopulationLimit(0);
        elitisticListPopulation2.setPopulationLimit(35);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor8 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeItor8);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test21");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation2.getChromosomes();
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation14 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList11, (int) 'a', (double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeList11);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test22");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) 0.0f, (java.lang.Number) (short) 0);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test23");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 1L, number1, (java.lang.Number) 0L);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) outOfRangeException3);
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Throwable[] throwableArray7 = outOfRangeException3.getSuppressed();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0L + "'", number6.equals(0L));
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test24");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        boolean boolean7 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooSmallException4.getMin();
        java.lang.String str9 = numberIsTooSmallException4.toString();
        java.lang.Number number10 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0f + "'", number8.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str9.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0f + "'", number10.equals(0.0f));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test25");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("degrees of freedom must be positive ({0})", (java.lang.Object) number22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean30 = numberIsTooLargeException29.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray31 = numberIsTooLargeException29.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number37 = numberIsTooLargeException36.getArgument();
        java.lang.String str38 = numberIsTooLargeException36.toString();
        java.lang.String str39 = numberIsTooLargeException36.toString();
        mathIllegalArgumentException32.addSuppressed((java.lang.Throwable) numberIsTooLargeException36);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean46 = numberIsTooLargeException45.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray47 = numberIsTooLargeException45.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, (java.lang.Object[]) throwableArray47);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number53 = numberIsTooLargeException52.getArgument();
        java.lang.String str54 = numberIsTooLargeException52.toString();
        java.lang.String str55 = numberIsTooLargeException52.toString();
        mathIllegalArgumentException48.addSuppressed((java.lang.Throwable) numberIsTooLargeException52);
        boolean boolean57 = numberIsTooLargeException52.getBoundIsAllowed();
        numberIsTooLargeException36.addSuppressed((java.lang.Throwable) numberIsTooLargeException52);
        exceptionContext4.setValue("cost relative tolerance is too small ({0}), no further reduction in the sum of squares is possible", (java.lang.Object) numberIsTooLargeException36);
        boolean boolean60 = numberIsTooLargeException36.getBoundIsAllowed();
        java.lang.Number number61 = numberIsTooLargeException36.getMax();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (short) 10 + "'", number37.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str38.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + (short) 10 + "'", number53.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str54.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str55.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + (-1.0d) + "'", number61.equals((-1.0d)));
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test26");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        elitisticListPopulation2.setPopulationLimit(1);
        elitisticListPopulation2.setPopulationLimit(0);
        org.apache.commons.math3.genetics.Chromosome chromosome8 = null;
        elitisticListPopulation2.addChromosome(chromosome8);
        org.apache.commons.math3.genetics.Chromosome chromosome10 = null;
        elitisticListPopulation2.addChromosome(chromosome10);
        org.junit.Assert.assertNotNull(chromosomeList3);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test27");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation13 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int14 = elitisticListPopulation13.getPopulationSize();
        int int15 = elitisticListPopulation13.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation18 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population19 = elitisticListPopulation18.nextGeneration();
        elitisticListPopulation18.setPopulationLimit((int) '#');
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList22 = elitisticListPopulation18.getChromosomes();
        elitisticListPopulation13.setChromosomes(chromosomeList22);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor24 = elitisticListPopulation13.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation27 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList28 = elitisticListPopulation27.getChromosomes();
        elitisticListPopulation27.setPopulationLimit(1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList31 = elitisticListPopulation27.getChromosomes();
        elitisticListPopulation13.setChromosomes(chromosomeList31);
        elitisticListPopulation2.setChromosomes(chromosomeList31);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 10 + "'", int15 == 10);
        org.junit.Assert.assertNotNull(population19);
        org.junit.Assert.assertNotNull(chromosomeList22);
        org.junit.Assert.assertNotNull(chromosomeItor24);
        org.junit.Assert.assertNotNull(chromosomeList28);
        org.junit.Assert.assertNotNull(chromosomeList31);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test28");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor18 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.Chromosome chromosome19 = null;
        elitisticListPopulation2.addChromosome(chromosome19);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor21 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList25 = elitisticListPopulation24.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList25);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertNotNull(chromosomeItor18);
        org.junit.Assert.assertNotNull(chromosomeItor21);
        org.junit.Assert.assertNotNull(chromosomeList25);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test29");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        java.lang.Number number7 = numberIsTooLargeException4.getMax();
        java.lang.Number number8 = numberIsTooLargeException4.getMax();
        java.lang.Number number9 = numberIsTooLargeException4.getMax();
        java.lang.Number number10 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 1.0f + "'", number10.equals(1.0f));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test30");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 1L, (java.lang.Number) (short) -1);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test31");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 0L);
        java.lang.Number number3 = notPositiveException2.getMin();
        boolean boolean4 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test32");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EXPONENT;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EXPONENT));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test33");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.String str6 = numberIsTooLargeException4.toString();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = numberIsTooLargeException4.getContext();
        boolean boolean10 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number11 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 100L + "'", number8.equals(100L));
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 100L + "'", number11.equals(100L));
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test34");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 1, (java.lang.Number) (short) 10);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test35");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList4 = elitisticListPopulation2.getChromosomes();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor5 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation8 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int9 = elitisticListPopulation8.getPopulationSize();
        int int10 = elitisticListPopulation8.getPopulationLimit();
        elitisticListPopulation8.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList13 = elitisticListPopulation8.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList13, (int) 'a', 0.0d);
        elitisticListPopulation2.setChromosomes(chromosomeList13);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor18 = elitisticListPopulation2.iterator();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome19 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(chromosomeList4);
        org.junit.Assert.assertNotNull(chromosomeItor5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 10 + "'", int10 == 10);
        org.junit.Assert.assertNotNull(chromosomeList13);
        org.junit.Assert.assertNotNull(chromosomeItor18);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test36");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number2, (java.lang.Number) (short) 10, false);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 1, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test37");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10, (java.lang.Number) (-1.0d), false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test38");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10);
        boolean boolean3 = notPositiveException2.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray4 = notPositiveException2.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = notPositiveException2.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean17 = numberIsTooLargeException16.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray18 = numberIsTooLargeException16.getSuppressed();
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray18);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray19);
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray21);
        exceptionContext5.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray21);
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test39");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = outOfRangeException4.getContext();
        java.util.Set<java.lang.String> strSet6 = exceptionContext5.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test40");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1L), true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test41");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 1L);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test42");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) (-1L));
        java.lang.Throwable[] throwableArray7 = notPositiveException6.getSuppressed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        java.lang.Number number14 = numberIsTooSmallException12.getMin();
        notPositiveException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException12);
        outOfRangeException3.addSuppressed((java.lang.Throwable) notPositiveException6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = outOfRangeException3.getContext();
        java.lang.Number number18 = outOfRangeException3.getArgument();
        java.lang.Number number19 = outOfRangeException3.getHi();
        java.lang.Number number20 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0L + "'", number14.equals(0L));
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) 10 + "'", number19.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (short) 10 + "'", number20.equals((short) 10));
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test43");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, (java.lang.Number) 100, true);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L);
        boolean boolean7 = notPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test44");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100.0d, (java.lang.Number) 100, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100 + "'", number5.equals(100));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test45");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation10 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList7, (int) 'a', 0.0d);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor11 = elitisticListPopulation10.iterator();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertNotNull(chromosomeItor11);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test46");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList9 = elitisticListPopulation2.getChromosomes();
        int int10 = elitisticListPopulation2.getPopulationLimit();
        int int11 = elitisticListPopulation2.getPopulationSize();
        int int12 = elitisticListPopulation2.getPopulationLimit();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test47");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation7 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation7.nextGeneration();
        elitisticListPopulation7.setPopulationLimit((int) '#');
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList11 = elitisticListPopulation7.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList11);
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor13 = elitisticListPopulation2.iterator();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation16 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList17 = elitisticListPopulation16.getChromosomes();
        elitisticListPopulation16.setPopulationLimit(1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation16.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList20);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation24 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, 10, (double) 1.0f);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation27 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList20, (int) ' ', 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(population8);
        org.junit.Assert.assertNotNull(chromosomeList11);
        org.junit.Assert.assertNotNull(chromosomeItor13);
        org.junit.Assert.assertNotNull(chromosomeList17);
        org.junit.Assert.assertNotNull(chromosomeList20);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test48");
        try {
            org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(52, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test49");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 100, (java.lang.Number) (byte) 10, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test50");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean16 = numberIsTooLargeException15.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray17 = numberIsTooLargeException15.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number23 = numberIsTooLargeException22.getArgument();
        java.lang.String str24 = numberIsTooLargeException22.toString();
        java.lang.String str25 = numberIsTooLargeException22.toString();
        mathIllegalArgumentException18.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean32 = numberIsTooLargeException31.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray33 = numberIsTooLargeException31.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number39 = numberIsTooLargeException38.getArgument();
        java.lang.String str40 = numberIsTooLargeException38.toString();
        java.lang.String str41 = numberIsTooLargeException38.toString();
        mathIllegalArgumentException34.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        boolean boolean43 = numberIsTooLargeException38.getBoundIsAllowed();
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext46 = numberIsTooLargeException22.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats47, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray52 = numberIsTooLargeException51.getSuppressed();
        java.lang.String str53 = numberIsTooLargeException51.toString();
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException51);
        java.lang.Throwable[] throwableArray55 = numberIsTooLargeException51.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext58 = mathIllegalArgumentException57.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (short) 10 + "'", number39.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str41.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(exceptionContext46);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats47.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str53.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(exceptionContext58);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test51");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        int int11 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Chromosome chromosome12 = null;
        elitisticListPopulation2.addChromosome(chromosome12);
        try {
            elitisticListPopulation2.setElitismRate((double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: elitism rate (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test52");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d));
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) notPositiveException2);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        java.lang.String str18 = numberIsTooLargeException16.toString();
        java.lang.String str19 = numberIsTooLargeException16.toString();
        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        java.lang.String str34 = numberIsTooLargeException32.toString();
        java.lang.String str35 = numberIsTooLargeException32.toString();
        mathIllegalArgumentException28.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        boolean boolean37 = numberIsTooLargeException32.getBoundIsAllowed();
        numberIsTooLargeException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        java.lang.Throwable[] throwableArray39 = numberIsTooLargeException16.getSuppressed();
        exceptionContext3.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Object[]) throwableArray39);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats4, (java.lang.Number) (byte) 100, (java.lang.Number) (byte) 0, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 10 + "'", number17.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str18.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 10 + "'", number33.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str34.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(throwableArray39);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test53");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        java.lang.String str5 = elitisticListPopulation2.toString();
        org.apache.commons.math3.genetics.Chromosome chromosome6 = null;
        elitisticListPopulation2.addChromosome(chromosome6);
        elitisticListPopulation2.setPopulationLimit(35);
        int int10 = elitisticListPopulation2.getPopulationLimit();
        try {
            org.apache.commons.math3.genetics.Chromosome chromosome11 = elitisticListPopulation2.getFittestChromosome();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 35 + "'", int10 == 35);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test54");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) (-1.0d), (java.lang.Number) 100);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) 0L, true);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) 100.0d, true);
        java.lang.Throwable[] throwableArray13 = numberIsTooLargeException12.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test55");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 1, number1, false);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test56");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.Population population5 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(population5);
        org.junit.Assert.assertNotNull(chromosomeItor6);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test57");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) 0.0f, (java.lang.Number) 100.0d);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test58");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (-1L), (java.lang.Number) (byte) 1, (java.lang.Number) (-1.0d));
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test59");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 10, (java.lang.Number) 1.0f, (java.lang.Number) (short) 10);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getHi();
        java.lang.Number number7 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math3.exception.OutOfRangeException(number7, (java.lang.Number) (-1.0f), (java.lang.Number) 10.0f);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException10);
        java.lang.Number number12 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 10 + "'", number6.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test60");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test61");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        org.apache.commons.math3.genetics.Population population8 = elitisticListPopulation2.nextGeneration();
        elitisticListPopulation2.setPopulationLimit((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(population8);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test62");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome7 = null;
        elitisticListPopulation2.addChromosome(chromosome7);
        java.lang.String str9 = elitisticListPopulation2.toString();
        java.lang.String str10 = elitisticListPopulation2.toString();
        elitisticListPopulation2.setPopulationLimit((int) (short) 1);
        elitisticListPopulation2.setPopulationLimit((int) (short) 10);
        org.apache.commons.math3.genetics.Chromosome chromosome15 = null;
        elitisticListPopulation2.addChromosome(chromosome15);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation19 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList20 = elitisticListPopulation19.getChromosomes();
        org.apache.commons.math3.genetics.Population population21 = elitisticListPopulation19.nextGeneration();
        int int22 = elitisticListPopulation19.getPopulationSize();
        org.apache.commons.math3.genetics.Population population23 = elitisticListPopulation19.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList24 = elitisticListPopulation19.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList24);
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit((int) (byte) 100);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList32 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit((int) (short) -1);
        elitisticListPopulation28.setPopulationLimit(1);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList37 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation2.setChromosomes(chromosomeList37);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "[null]" + "'", str9.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "[null]" + "'", str10.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeList20);
        org.junit.Assert.assertNotNull(population21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(population23);
        org.junit.Assert.assertNotNull(chromosomeList24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(chromosomeList32);
        org.junit.Assert.assertNotNull(chromosomeList37);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test63");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) 0.0d, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray13);
        java.lang.Object[] objArray15 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray13);
        java.lang.Object[] objArray16 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray15);
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray17);
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SINGULAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test64");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (-1.0d), false);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test65");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean11 = numberIsTooLargeException10.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray12 = numberIsTooLargeException10.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) throwableArray12);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number18 = numberIsTooLargeException17.getArgument();
        java.lang.String str19 = numberIsTooLargeException17.toString();
        java.lang.String str20 = numberIsTooLargeException17.toString();
        mathIllegalArgumentException13.addSuppressed((java.lang.Throwable) numberIsTooLargeException17);
        java.lang.Number number22 = numberIsTooLargeException17.getMax();
        exceptionContext4.setValue("", (java.lang.Object) numberIsTooLargeException17);
        java.lang.Throwable throwable24 = exceptionContext4.getThrowable();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation28 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList29 = elitisticListPopulation28.getChromosomes();
        elitisticListPopulation28.setPopulationLimit(1);
        org.apache.commons.math3.genetics.Population population32 = elitisticListPopulation28.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList33 = elitisticListPopulation28.getChromosomes();
        exceptionContext4.setValue("hi!", (java.lang.Object) elitisticListPopulation28);
        java.lang.Object obj36 = exceptionContext4.getValue("org.apache.commons.math3.exception.NotPositiveException: -1 is smaller than the minimum (0)");
        java.lang.Object obj38 = exceptionContext4.getValue("a {0}x{1} matrix cannot be a rotation matrix");
        java.lang.Throwable throwable39 = exceptionContext4.getThrowable();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (short) 10 + "'", number18.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str20.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + (-1.0d) + "'", number22.equals((-1.0d)));
        org.junit.Assert.assertNotNull(throwable24);
        org.junit.Assert.assertNotNull(chromosomeList29);
        org.junit.Assert.assertNotNull(population32);
        org.junit.Assert.assertNotNull(chromosomeList33);
        org.junit.Assert.assertNull(obj36);
        org.junit.Assert.assertNull(obj38);
        org.junit.Assert.assertNotNull(throwable39);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test66");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray1);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean8 = numberIsTooLargeException7.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean14 = numberIsTooLargeException13.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray15 = numberIsTooLargeException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number21 = numberIsTooLargeException20.getArgument();
        java.lang.String str22 = numberIsTooLargeException20.toString();
        java.lang.String str23 = numberIsTooLargeException20.toString();
        mathIllegalArgumentException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean30 = numberIsTooLargeException29.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray31 = numberIsTooLargeException29.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException32 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, (java.lang.Object[]) throwableArray31);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number37 = numberIsTooLargeException36.getArgument();
        java.lang.String str38 = numberIsTooLargeException36.toString();
        java.lang.String str39 = numberIsTooLargeException36.toString();
        mathIllegalArgumentException32.addSuppressed((java.lang.Throwable) numberIsTooLargeException36);
        boolean boolean41 = numberIsTooLargeException36.getBoundIsAllowed();
        numberIsTooLargeException20.addSuppressed((java.lang.Throwable) numberIsTooLargeException36);
        numberIsTooLargeException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException20);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext44 = numberIsTooLargeException20.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        exceptionContext44.setValue("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)", (java.lang.Object) localizedFormats46);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats49 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats49, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray54 = numberIsTooLargeException53.getSuppressed();
        exceptionContext44.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats48, (java.lang.Object[]) throwableArray54);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) throwableArray54);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) mathIllegalArgumentException56);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILLEGAL_STATE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) 10 + "'", number21.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str22.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + (short) 10 + "'", number37.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str38.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str39.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(exceptionContext44);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY + "'", localizedFormats48.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_SUBSTITUTE_ELEMENT_FROM_EMPTY_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats49 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats49.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray54);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test67");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList3 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population4 = elitisticListPopulation2.nextGeneration();
        int int5 = elitisticListPopulation2.getPopulationSize();
        org.apache.commons.math3.genetics.Population population6 = elitisticListPopulation2.nextGeneration();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation10 = new org.apache.commons.math3.genetics.ElitisticListPopulation(chromosomeList7, (int) ' ', (double) 1.0f);
        int int11 = elitisticListPopulation10.getPopulationSize();
        org.junit.Assert.assertNotNull(chromosomeList3);
        org.junit.Assert.assertNotNull(population4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(population6);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test68");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number12 = numberIsTooLargeException11.getArgument();
        java.lang.String str13 = numberIsTooLargeException11.toString();
        java.lang.String str14 = numberIsTooLargeException11.toString();
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) numberIsTooLargeException11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray22 = numberIsTooLargeException20.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, (java.lang.Object[]) throwableArray22);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number28 = numberIsTooLargeException27.getArgument();
        java.lang.String str29 = numberIsTooLargeException27.toString();
        java.lang.String str30 = numberIsTooLargeException27.toString();
        mathIllegalArgumentException23.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        boolean boolean32 = numberIsTooLargeException27.getBoundIsAllowed();
        numberIsTooLargeException11.addSuppressed((java.lang.Throwable) numberIsTooLargeException27);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats34, (java.lang.Number) (byte) 100, (java.lang.Number) 0L, true);
        boolean boolean39 = numberIsTooSmallException38.getBoundIsAllowed();
        java.lang.Number number40 = numberIsTooSmallException38.getMin();
        numberIsTooLargeException27.addSuppressed((java.lang.Throwable) numberIsTooSmallException38);
        java.lang.Number number42 = numberIsTooLargeException27.getArgument();
        java.lang.Throwable[] throwableArray43 = numberIsTooLargeException27.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext44 = numberIsTooLargeException27.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats46 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException50 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats46, (java.lang.Number) 0L, (java.lang.Number) 35, (java.lang.Number) (-1L));
        exceptionContext44.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: tournament arity (10) cannot be bigger than population size (null)", (java.lang.Object) 35);
        java.lang.Object obj53 = exceptionContext44.getValue("initial row {1} after final row {0}");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 10 + "'", number12.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str13.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str14.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + (short) 10 + "'", number28.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str30.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0L + "'", number40.equals(0L));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + (short) 10 + "'", number42.equals((short) 10));
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertNotNull(exceptionContext44);
        org.junit.Assert.assertTrue("'" + localizedFormats46 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats46.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_PARSE));
        org.junit.Assert.assertNull(obj53);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test69");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = mathIllegalArgumentException3.getContext();
        java.lang.Throwable[] throwableArray5 = mathIllegalArgumentException3.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray5);
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test70");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException(number0, (java.lang.Number) (short) 1, true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test71");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray11 = numberIsTooLargeException9.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) throwableArray11);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number17 = numberIsTooLargeException16.getArgument();
        java.lang.String str18 = numberIsTooLargeException16.toString();
        java.lang.String str19 = numberIsTooLargeException16.toString();
        mathIllegalArgumentException12.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean26 = numberIsTooLargeException25.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray27 = numberIsTooLargeException25.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats21, (java.lang.Object[]) throwableArray27);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number33 = numberIsTooLargeException32.getArgument();
        java.lang.String str34 = numberIsTooLargeException32.toString();
        java.lang.String str35 = numberIsTooLargeException32.toString();
        mathIllegalArgumentException28.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        boolean boolean37 = numberIsTooLargeException32.getBoundIsAllowed();
        numberIsTooLargeException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException32);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException16);
        java.lang.Number number40 = numberIsTooLargeException3.getArgument();
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        numberIsTooLargeException3.addSuppressed((java.lang.Throwable) numberIsTooLargeException44);
        boolean boolean46 = numberIsTooLargeException3.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray47 = numberIsTooLargeException3.getSuppressed();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext52 = numberIsTooSmallException51.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean59 = numberIsTooLargeException58.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray60 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException61 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats54, (java.lang.Object[]) throwableArray60);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number66 = numberIsTooLargeException65.getArgument();
        java.lang.String str67 = numberIsTooLargeException65.toString();
        java.lang.String str68 = numberIsTooLargeException65.toString();
        mathIllegalArgumentException61.addSuppressed((java.lang.Throwable) numberIsTooLargeException65);
        java.lang.Number number70 = numberIsTooLargeException65.getMax();
        exceptionContext52.setValue("", (java.lang.Object) numberIsTooLargeException65);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number74 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException76 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats72, (java.lang.Number) 100.0d, number74, true);
        numberIsTooLargeException65.addSuppressed((java.lang.Throwable) numberIsTooLargeException76);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext78 = numberIsTooLargeException76.getContext();
        java.lang.Throwable throwable79 = exceptionContext78.getThrowable();
        java.lang.Throwable[] throwableArray80 = throwable79.getSuppressed();
        numberIsTooLargeException3.addSuppressed(throwable79);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + (short) 10 + "'", number17.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str18.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str19.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + (short) 10 + "'", number33.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str34.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str35.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + (short) 10 + "'", number40.equals((short) 10));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(exceptionContext52);
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats54.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(throwableArray60);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + (short) 10 + "'", number66.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str67.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str68.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + (-1.0d) + "'", number70.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats72.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertNotNull(exceptionContext78);
        org.junit.Assert.assertNotNull(throwable79);
        org.junit.Assert.assertNotNull(throwableArray80);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test72");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100.0d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) (byte) 1, (java.lang.Number) 35);
        java.lang.Class<?> wildcardClass9 = outOfRangeException8.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test73");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException4.getContext();
        exceptionContext6.setValue("", (java.lang.Object) (byte) -1);
        java.lang.Object obj11 = exceptionContext6.getValue("hi!");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean18 = numberIsTooLargeException17.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray19 = numberIsTooLargeException17.getSuppressed();
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray20);
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Number) 1, (java.lang.Number) 35, false);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException33 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats29, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext34 = numberIsTooSmallException33.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext35 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException33);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        java.lang.Object[] objArray37 = null;
        exceptionContext35.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats36, objArray37);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean46 = numberIsTooLargeException45.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray47 = numberIsTooLargeException45.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats41, (java.lang.Object[]) throwableArray47);
        java.lang.Object[] objArray49 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray47);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats40, (java.lang.Object[]) throwableArray47);
        java.lang.Object[] objArray51 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray47);
        exceptionContext35.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats39, (java.lang.Object[]) throwableArray47);
        exceptionContext6.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats24, (java.lang.Object[]) throwableArray47);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats55 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats55, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, false);
        java.lang.Number number60 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats55, number60, (java.lang.Number) 100, false);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 10L, (java.lang.Number) 1, true);
        java.lang.Number number68 = numberIsTooLargeException67.getMax();
        numberIsTooLargeException63.addSuppressed((java.lang.Throwable) numberIsTooLargeException67);
        exceptionContext6.setValue("brightness exponent should be positive or null, but got {0}", (java.lang.Object) numberIsTooLargeException63);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj11);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext34);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats41.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(throwableArray47);
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizedFormats55 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats55.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
        org.junit.Assert.assertTrue("'" + number68 + "' != '" + 1 + "'", number68.equals(1));
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test74");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (byte) -1, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        java.lang.Object[] objArray6 = null;
        exceptionContext4.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test75");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        elitisticListPopulation2.setPopulationLimit((-1));
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList7 = elitisticListPopulation2.getChromosomes();
        int int8 = elitisticListPopulation2.getPopulationSize();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor9 = elitisticListPopulation2.iterator();
        int int10 = elitisticListPopulation2.getPopulationLimit();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation13 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int14 = elitisticListPopulation13.getPopulationSize();
        org.apache.commons.math3.genetics.Population population15 = elitisticListPopulation13.nextGeneration();
        double double16 = elitisticListPopulation13.getElitismRate();
        org.apache.commons.math3.genetics.Population population17 = elitisticListPopulation13.nextGeneration();
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation20 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int21 = elitisticListPopulation20.getPopulationSize();
        int int22 = elitisticListPopulation20.getPopulationLimit();
        elitisticListPopulation20.setPopulationLimit((-1));
        org.apache.commons.math3.genetics.Chromosome chromosome25 = null;
        elitisticListPopulation20.addChromosome(chromosome25);
        java.lang.String str27 = elitisticListPopulation20.toString();
        elitisticListPopulation20.setPopulationLimit(0);
        java.lang.String str30 = elitisticListPopulation20.toString();
        org.apache.commons.math3.genetics.Chromosome[] chromosomeArray31 = new org.apache.commons.math3.genetics.Chromosome[] {};
        java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome> chromosomeList32 = new java.util.ArrayList<org.apache.commons.math3.genetics.Chromosome>();
        boolean boolean33 = java.util.Collections.addAll((java.util.Collection<org.apache.commons.math3.genetics.Chromosome>) chromosomeList32, chromosomeArray31);
        elitisticListPopulation20.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList32);
        elitisticListPopulation13.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList32);
        elitisticListPopulation2.setChromosomes((java.util.List<org.apache.commons.math3.genetics.Chromosome>) chromosomeList32);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(chromosomeList7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(chromosomeItor9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(population15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(population17);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "[null]" + "'", str27.equals("[null]"));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "[null]" + "'", str30.equals("[null]"));
        org.junit.Assert.assertNotNull(chromosomeArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test76");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException2.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_OBSERVED_POINTS_IN_SAMPLE));
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test77");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        java.lang.String str5 = elitisticListPopulation2.toString();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList6 = null;
        elitisticListPopulation2.setChromosomes(chromosomeList6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "[]" + "'", str5.equals("[]"));
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test78");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (-1), (java.lang.Number) (-1));
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean10 = numberIsTooLargeException9.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean16 = numberIsTooLargeException15.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray17 = numberIsTooLargeException15.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number23 = numberIsTooLargeException22.getArgument();
        java.lang.String str24 = numberIsTooLargeException22.toString();
        java.lang.String str25 = numberIsTooLargeException22.toString();
        mathIllegalArgumentException18.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean32 = numberIsTooLargeException31.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray33 = numberIsTooLargeException31.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, (java.lang.Object[]) throwableArray33);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number39 = numberIsTooLargeException38.getArgument();
        java.lang.String str40 = numberIsTooLargeException38.toString();
        java.lang.String str41 = numberIsTooLargeException38.toString();
        mathIllegalArgumentException34.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        boolean boolean43 = numberIsTooLargeException38.getBoundIsAllowed();
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException38);
        numberIsTooLargeException9.addSuppressed((java.lang.Throwable) numberIsTooLargeException22);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext46 = numberIsTooLargeException22.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats47, (java.lang.Number) 100L, (java.lang.Number) 1.0f, false);
        java.lang.Throwable[] throwableArray52 = numberIsTooLargeException51.getSuppressed();
        java.lang.String str53 = numberIsTooLargeException51.toString();
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException51);
        java.lang.Throwable[] throwableArray55 = numberIsTooLargeException51.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable5, (java.lang.Object[]) throwableArray55);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray55);
        java.lang.Object[] objArray58 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray55);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (short) 10 + "'", number23.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str24.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str25.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + (short) 10 + "'", number39.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str40.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str41.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(exceptionContext46);
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE + "'", localizedFormats47.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CROSSOVER_RATE));
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)" + "'", str53.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: crossover rate (100)"));
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertNotNull(objArray58);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test79");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation((int) 'a', 0.0d);
        int int3 = elitisticListPopulation2.getPopulationSize();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test80");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.BETA;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BETA + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BETA));
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test81");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) -1, (java.lang.Number) (short) 100, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test82");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.INDEX;
        exceptionContext4.setValue("", (java.lang.Object) localizedFormats7);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats10, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext15 = numberIsTooSmallException14.getContext();
        java.lang.String str16 = numberIsTooSmallException14.toString();
        java.lang.Number number17 = numberIsTooSmallException14.getMin();
        boolean boolean18 = numberIsTooSmallException14.getBoundIsAllowed();
        exceptionContext4.setValue("org.apache.commons.math3.exception.NotPositiveException: spline partition must have at least 1 points, got 0", (java.lang.Object) numberIsTooSmallException14);
        java.lang.Object obj21 = exceptionContext4.getValue("brightness exponent should be positive or null, but got {0}");
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INDEX + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str16.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0f + "'", number17.equals(0.0f));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(obj21);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test83");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0d), (java.lang.Number) (short) 100, (java.lang.Number) 0);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, (java.lang.Number) (byte) -1, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test84");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        int int3 = elitisticListPopulation2.getPopulationSize();
        int int4 = elitisticListPopulation2.getPopulationLimit();
        double double5 = elitisticListPopulation2.getElitismRate();
        java.lang.String str6 = elitisticListPopulation2.toString();
        double double7 = elitisticListPopulation2.getElitismRate();
        java.util.List<org.apache.commons.math3.genetics.Chromosome> chromosomeList8 = elitisticListPopulation2.getChromosomes();
        org.apache.commons.math3.genetics.Population population9 = elitisticListPopulation2.nextGeneration();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor10 = elitisticListPopulation2.iterator();
        double double11 = elitisticListPopulation2.getElitismRate();
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor12 = elitisticListPopulation2.iterator();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "[]" + "'", str6.equals("[]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeList8);
        org.junit.Assert.assertNotNull(population9);
        org.junit.Assert.assertNotNull(chromosomeItor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertNotNull(chromosomeItor12);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test85");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0, (java.lang.Number) (-1L), (java.lang.Number) 0.0d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        java.lang.String str7 = outOfRangeException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNKNOWN_MODE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.OutOfRangeException: unknown mode 0, known modes: -1 (0), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}) and {11} ({12})" + "'", str7.equals("org.apache.commons.math3.exception.OutOfRangeException: unknown mode 0, known modes: -1 (0), {3} ({4}), {5} ({6}), {7} ({8}), {9} ({10}) and {11} ({12})"));
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test86");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f, (java.lang.Number) 0.0f, true);
        java.lang.String str5 = numberIsTooSmallException4.toString();
        java.lang.String str6 = numberIsTooSmallException4.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0" + "'", str6.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 != 0"));
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test87");
        org.apache.commons.math3.genetics.ElitisticListPopulation elitisticListPopulation2 = new org.apache.commons.math3.genetics.ElitisticListPopulation(10, (double) 1.0f);
        org.apache.commons.math3.genetics.Population population3 = elitisticListPopulation2.nextGeneration();
        elitisticListPopulation2.setPopulationLimit((int) '#');
        java.util.Iterator<org.apache.commons.math3.genetics.Chromosome> chromosomeItor6 = elitisticListPopulation2.iterator();
        int int7 = elitisticListPopulation2.getPopulationSize();
        elitisticListPopulation2.setPopulationLimit((int) (short) 100);
        org.junit.Assert.assertNotNull(population3);
        org.junit.Assert.assertNotNull(chromosomeItor6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test88");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (byte) 0, false);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException6 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 10.0f);
        org.apache.commons.math3.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test89");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.lang.Throwable throwable5 = exceptionContext4.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats7, (java.lang.Number) (byte) -1, (java.lang.Number) 100.0d, false);
        boolean boolean12 = numberIsTooSmallException11.getBoundIsAllowed();
        exceptionContext4.setValue("contraction criteria ({0}) smaller than the expansion factor ({1}).  This would lead to a never ending loop of expansion and contraction as a newly expanded internal storage array would immediately satisfy the criteria for contraction.", (java.lang.Object) numberIsTooSmallException11);
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwable5);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.MISMATCHED_LOESS_ABSCISSA_ORDINATE_ARRAYS));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test90");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test91");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) 1.0f, false);
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test92");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) (short) 100, (java.lang.Number) (short) 0, (java.lang.Number) (byte) 10);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 100 + "'", number4.equals((short) 100));
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test93");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = numberIsTooSmallException6.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        boolean boolean14 = numberIsTooLargeException13.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray15 = numberIsTooLargeException13.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray15);
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 10, (java.lang.Number) (-1.0d), true);
        java.lang.Number number21 = numberIsTooLargeException20.getArgument();
        java.lang.String str22 = numberIsTooLargeException20.toString();
        java.lang.String str23 = numberIsTooLargeException20.toString();
        mathIllegalArgumentException16.addSuppressed((java.lang.Throwable) numberIsTooLargeException20);
        java.lang.Number number25 = numberIsTooLargeException20.getMax();
        exceptionContext7.setValue("", (java.lang.Object) numberIsTooLargeException20);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        java.lang.Number number29 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math3.exception.NumberIsTooLargeException((org.apache.commons.math3.exception.util.Localizable) localizedFormats27, (java.lang.Number) 100.0d, number29, true);
        numberIsTooLargeException20.addSuppressed((java.lang.Throwable) numberIsTooLargeException31);
        notPositiveException2.addSuppressed((java.lang.Throwable) numberIsTooLargeException20);
        java.lang.Number number34 = notPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + (short) 10 + "'", number21.equals((short) 10));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str22.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)" + "'", str23.equals("org.apache.commons.math3.exception.NumberIsTooLargeException: 10 is larger than the maximum (-1)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + (-1.0d) + "'", number25.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0 + "'", number34.equals(0));
    }
}

