import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(10.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        java.lang.Class<?> wildcardClass5 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION_CONVERSION_OVERFLOW));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ROWS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray6 = new double[] { 100, (short) -1 };
        double[] doubleArray8 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair9 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray8);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = null;
        try {
            boolean boolean11 = simpleVectorialValueChecker2.converged((int) (byte) 0, vectorialPointValuePair9, vectorialPointValuePair10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_EVALUATIONS_EXCEEDED));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint0 = null;
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray1 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint0 };
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser2 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_ROW_INDEX_ARRAY));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SCALE));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROOTS_OF_UNITY_NOT_COMPUTED_YET));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_UPPER_BOUND));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_COMPUTE_COVARIANCE_SINGULAR_PROBLEM));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONVERGENCE_FAILED));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) '4', (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-48.0d) + "'", double2 == (-48.0d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math.exception.ConvergenceException convergenceException0 = new org.apache.commons.math.exception.ConvergenceException();
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_BRACKET_OPTIMUM_IN_LINE_SEARCH));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_FRACTION_NUMBER));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_CONVERT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_ONE_PREVIOUS_POINT));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_INVALID_PARAMETERS_ORDER));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray4 = new double[] { 100, (short) -1 };
        double[] doubleArray6 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair7 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray6);
        try {
            double double8 = parametric0.value((double) '4', doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 2 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray4);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.RANDOMKEY_MUTATION_WRONG_CLASS));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ITERATIONS_LIMITS));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DISCRETE_CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_COMPLEX_NUMBER));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_CATEGORIES_REQUIRED));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COVARIANCE_MATRIX));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_MUST_HAVE_AT_LEAST_ONE_ELEMENT));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 100L, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PROPAGATION_DIRECTION_MISMATCH));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_FRACTION_TO_DIVIDE_BY));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_INCREMENT_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_INFINITY_DIVERGENCE));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.085536923187668d + "'", double1 == 19.085536923187668d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) -1, 1.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CUMULATIVE_PROBABILITY_RETURNED_NAN));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_COMPLEX));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ALPHA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ALPHA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ALPHA));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_REAL_VECTOR));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_FINITE_NUMBER));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNKNOWN_MODE));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_REAL_FINITE_ABSCISSA));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_SEQUENCE));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray3 = new java.lang.Object[] { localizedFormats0, localizedFormats1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException(objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException13.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DEGREES_OF_FREEDOM));
    }

//    @Test
//    public void test100() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test100");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.29071993270111873d + "'", double0 == 0.29071993270111873d);
//    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) '#', (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.57625987E17f + "'", float2 == 1.57625987E17f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.7615941559557649d));
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) outOfRangeException3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 0, 19.085536923187668d, (double) 100L, 0.17453292519943295d, (double) 0.0f);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker8 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_MICROSPHERE_ELEMENTS));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) (short) 1, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_SIZE));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBSERVED_COUNTS_ALL_ZERO));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SINGULAR_MATRIX));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker0 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker();
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_RESULT_AVAILABLE));
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_CONVERGENCE_WITH_ANY_START_POINT));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        long long1 = org.apache.commons.math.util.FastMath.abs(1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 1, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9646843920620416d + "'", double2 == 0.9646843920620416d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_DENSITY_FOR_THIS_DISTRIBUTION));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 3, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FACTORIAL_NEGATIVE_PARAMETER));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681399d + "'", double1 == 0.5403023058681399d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESS_LARGER_THAN_POPULATION_SIZE));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.START_POSITION));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray4);
        java.lang.String str7 = optimizationException6.getPattern();
        java.lang.Object[] objArray8 = optimizationException6.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable9 = optimizationException6.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(localizable9);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double2 = org.apache.commons.math.util.FastMath.min((double) '#', 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLEX_NEED_ONE_POINT));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        try {
            double[] doubleArray7 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) '4');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 10, (java.lang.Number) 0L, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_POLYNOMIALS_COEFFICIENTS_ARRAY));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-48.0d));
        java.lang.Number number2 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-48.0d) + "'", number2.equals((-48.0d)));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LOESS_EXPECTS_AT_LEAST_ONE_POINT));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (short) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (short) 1, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_CONVERGENT_CONTINUED_FRACTION));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.141592653589793d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3536398454434488d + "'", double2 == 1.3536398454434488d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SYMMETRIC_MATRIX));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_BRIGHTNESS_EXPONENT));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNPARSEABLE_REAL_VECTOR));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        int int5 = levenbergMarquardtOptimizer3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) -1, (java.lang.Number) 1.5707963267948966d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int2 = org.apache.commons.math.util.FastMath.max(5, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ENDPOINTS_NOT_AN_INTERVAL));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_NOT_POSITIVE));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        float float2 = org.apache.commons.math.util.FastMath.scalb(0.0f, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10.0f, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6704649792860586d + "'", double2 == 1.6704649792860586d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUND_SIGNIFICANCE_LEVEL));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_INTEGRATION_INTERVAL));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray4 = null;
        double[] doubleArray7 = new double[] { 100, (short) -1 };
        double[] doubleArray9 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray9);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray9, true);
        double[] doubleArray15 = new double[] { 100, (short) -1 };
        double[] doubleArray17 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        boolean boolean19 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair12, vectorialPointValuePair18);
        double double20 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BANDWIDTH));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter7 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        curveFitter7.addObservedPoint(0.0d, (double) (short) -1);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer15 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter16 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer15);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric17 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray20 = new double[] { 100, (short) -1 };
        double[] doubleArray22 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray22);
        double[] doubleArray26 = new double[] { 100, (short) -1 };
        double[] doubleArray28 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray28);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray26);
        double[] doubleArray31 = gaussianFitter16.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray26);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker34 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray36 = null;
        double[] doubleArray39 = new double[] { 100, (short) -1 };
        double[] doubleArray41 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray41);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray41, true);
        double[] doubleArray47 = new double[] { 100, (short) -1 };
        double[] doubleArray49 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray49);
        boolean boolean51 = simpleVectorialValueChecker34.converged((int) (short) 10, vectorialPointValuePair44, vectorialPointValuePair50);
        double[] doubleArray52 = vectorialPointValuePair44.getValue();
        try {
            double[] doubleArray53 = curveFitter7.fit(10, (org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.814697265606496E-6d + "'", double1 == 3.814697265606496E-6d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer0 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SUBARRAY_ENDS_AFTER_ARRAY_END));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray0 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] {};
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser1 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2924316695611777d + "'", double1 == 2.2924316695611777d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        float float2 = org.apache.commons.math.util.FastMath.max(3.8146973E-6f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.8146973E-6f + "'", float2 == 3.8146973E-6f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_EXPONENT));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float2 = org.apache.commons.math.util.FastMath.max(10.0f, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.0d, (java.lang.Number) (byte) 10, true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_TRIALS));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        long long1 = org.apache.commons.math.util.FastMath.round((double) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (short) -1, (-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.23840584404423515d) + "'", double2 == (-0.23840584404423515d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.599840626818533d + "'", double1 == 0.599840626818533d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 95.71059313749964d + "'", double1 == 95.71059313749964d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_STRING_FOR_IMAGINARY_CHARACTER));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNBOUNDED_SOLUTION));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 5, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.cos(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764534d) + "'", double1 == (-0.8390715290764534d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.3536398454434488d, (double) 1, 0.0d, (double) (short) -1, 3.141592653589793d);
        org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction differentiableMultivariateVectorialFunction7 = null;
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker10 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray12 = null;
        double[] doubleArray15 = new double[] { 100, (short) -1 };
        double[] doubleArray17 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray17, true);
        double[] doubleArray23 = new double[] { 100, (short) -1 };
        double[] doubleArray25 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray25);
        boolean boolean27 = simpleVectorialValueChecker10.converged((int) (short) 10, vectorialPointValuePair20, vectorialPointValuePair26);
        double[] doubleArray28 = vectorialPointValuePair20.getValueRef();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker31 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray33 = null;
        double[] doubleArray36 = new double[] { 100, (short) -1 };
        double[] doubleArray38 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray38);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray38, true);
        double[] doubleArray44 = new double[] { 100, (short) -1 };
        double[] doubleArray46 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray46);
        boolean boolean48 = simpleVectorialValueChecker31.converged((int) (short) 10, vectorialPointValuePair41, vectorialPointValuePair47);
        double[] doubleArray49 = vectorialPointValuePair47.getPointRef();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer53 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter54 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer53);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric55 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray58 = new double[] { 100, (short) -1 };
        double[] doubleArray60 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair61 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray58, doubleArray60);
        double[] doubleArray64 = new double[] { 100, (short) -1 };
        double[] doubleArray66 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair67 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray64, doubleArray66);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair68 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray60, doubleArray64);
        double[] doubleArray69 = gaussianFitter54.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric55, doubleArray64);
        try {
            org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair70 = levenbergMarquardtOptimizer5.optimize((int) (short) 10, differentiableMultivariateVectorialFunction7, doubleArray28, doubleArray49, doubleArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_OPERATION));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long2 = org.apache.commons.math.util.FastMath.max(32L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_FRACTION));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_MAX_ITERATIONS));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 3, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 100L, (int) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.50359963E17f + "'", float2 == 4.50359963E17f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ILLEGAL_STATE));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 0.0f, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_SUCH_MATRIX_ENTRY));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_ROW_AFTER_FINAL_ROW));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double2 = org.apache.commons.math.util.FastMath.scalb(3.814697265606496E-6d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.814697265606496E-6d + "'", double2 == 3.814697265606496E-6d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_ONE));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_DISCARD_NEGATIVE_NUMBER_OF_ELEMENTS));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.9E-324d, (java.lang.Number) 0.9646843920620416d, (java.lang.Number) 1L);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.String str5 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1L + "'", number4.equals(1L));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 0 out of [0.965, 1] range" + "'", str5.equals("org.apache.commons.math.exception.OutOfRangeException: 0 out of [0.965, 1] range"));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_COST_RELATIVE_TOLERANCE));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 32L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-51) + "'", int1 == (-51));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (byte) -1, 3.141592653589793d, (double) '#', 0.0d, 0.0d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.VECTOR_LENGTH_MISMATCH));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WEIGHT_AT_LEAST_ONE_NON_ZERO));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "weigth array must contain at least one non-zero value" + "'", str1.equals("weigth array must contain at least one non-zero value"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double2 = org.apache.commons.math.util.FastMath.atan2(95.71059313749964d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000001d + "'", double1 == 97.00000000000001d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.POWER_NEGATIVE_PARAMETERS));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) ' ', 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5491388641509722d + "'", double2 == 1.5491388641509722d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = null;
        gaussianFitter4.addObservedPoint(weightedObservedPoint5);
        try {
            double[] doubleArray7 = gaussianFitter4.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.6931471805599453d);
        java.lang.String str2 = tooManyEvaluationsException1.toString();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) tooManyEvaluationsException1);
        java.lang.String str4 = tooManyEvaluationsException1.toString();
        java.lang.Number number5 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations" + "'", str2.equals("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations" + "'", str4.equals("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.6931471805599453d + "'", number5.equals(0.6931471805599453d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10L, (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_MANY_ELEMENTS_TO_DISCARD_FROM_ARRAY));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_LARGE_CUTOFF_SINGULAR_VALUE));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double2 = org.apache.commons.math.util.FastMath.pow((-48.0d), 3.1622776601683795d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTERNAL_ERROR));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5091784786580567d + "'", double1 == 2.5091784786580567d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41032129904824216d) + "'", double1 == (-0.41032129904824216d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray4 = null;
        double[] doubleArray7 = new double[] { 100, (short) -1 };
        double[] doubleArray9 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray9);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray9, true);
        double[] doubleArray15 = new double[] { 100, (short) -1 };
        double[] doubleArray17 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        boolean boolean19 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair12, vectorialPointValuePair18);
        double[] doubleArray21 = null;
        double[] doubleArray24 = new double[] { 100, (short) -1 };
        double[] doubleArray26 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair27 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray26, true);
        double[] doubleArray32 = new double[] { 100, (short) -1 };
        double[] doubleArray34 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray34);
        boolean boolean36 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair29, vectorialPointValuePair35);
        double[] doubleArray37 = vectorialPointValuePair35.getPointRef();
        double[] doubleArray40 = new double[] { 100, (short) -1 };
        double[] doubleArray42 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray42);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray42, false);
        double[] doubleArray46 = vectorialPointValuePair45.getValue();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.apache.commons.math.analysis.function.Gaussian gaussian3 = new org.apache.commons.math.analysis.function.Gaussian((double) 3L, 0.5403023058681399d, 0.599840626818533d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_WINDOW_SIZE));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, (float) 5);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 3, (double) 0.0f, Double.NaN, (double) (short) 1, (-0.23840584404423515d));
        try {
            double[] doubleArray6 = levenbergMarquardtOptimizer5.guessParametersErrors();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than, or equal to, the minimum (0): no degrees of freedom (0 measurements, 0 parameters)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017451520651465824d) + "'", double1 == (-0.017451520651465824d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray7 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray7);
        org.apache.commons.math.exception.ConvergenceException convergenceException9 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray7);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException1, localizable2, objArray7);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray16 = new java.lang.Object[] { localizedFormats13, localizedFormats14, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException(objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray23 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray23);
        org.apache.commons.math.optimization.OptimizationException optimizationException25 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray23);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException17, (org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray23);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException27 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException1, (org.apache.commons.math.exception.util.Localizable) localizedFormats11, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray23);
        java.lang.String str28 = localizedFormats12.getSourceString();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (byte) 1, (java.lang.Number) 3.0d, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "class ({0}) does not implement Comparable" + "'", str28.equals("class ({0}) does not implement Comparable"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.5091784786580567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SIZES_SHOULD_HAVE_DIFFERENCE_1));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.3536398454434488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1107370937723096d + "'", double1 == 1.1107370937723096d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) '#', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ConvergenceException convergenceException2 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray8);
        org.apache.commons.math.exception.ConvergenceException convergenceException10 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, localizable3, objArray8);
        java.lang.Object[] objArray12 = convergenceException11.getArguments();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException("", objArray12);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats17, localizedFormats18, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException(objArray20);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray27 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray27);
        org.apache.commons.math.optimization.OptimizationException optimizationException29 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray27);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException21, (org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray27);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException31 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 100.0d, objArray27);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13, "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations", objArray27);
        java.lang.String str33 = mathException32.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations" + "'", str33.equals("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_ARRAY_ELEMENT));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (short) -1, 1.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = gaussian2.derivative();
        double double5 = gaussian2.value((double) 10L);
        org.junit.Assert.assertNotNull(univariateRealFunction3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.1188192535093538E-27d + "'", double5 == 2.1188192535093538E-27d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ITERATOR_EXHAUSTED));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Number number2 = zeroException1.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double double1 = org.apache.commons.math.util.FastMath.asinh(19.085536923187668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.642763621377997d + "'", double1 == 3.642763621377997d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.USER_EXCEPTION));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = null;
        gaussianFitter4.addObservedPoint(weightedObservedPoint5);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker9 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray11 = null;
        double[] doubleArray14 = new double[] { 100, (short) -1 };
        double[] doubleArray16 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray16, true);
        double[] doubleArray22 = new double[] { 100, (short) -1 };
        double[] doubleArray24 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray24);
        boolean boolean26 = simpleVectorialValueChecker9.converged((int) (short) 10, vectorialPointValuePair19, vectorialPointValuePair25);
        double[] doubleArray28 = null;
        double[] doubleArray31 = new double[] { 100, (short) -1 };
        double[] doubleArray33 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray33);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair36 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray33, true);
        double[] doubleArray39 = new double[] { 100, (short) -1 };
        double[] doubleArray41 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair42 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray41);
        boolean boolean43 = simpleVectorialValueChecker9.converged((int) (short) 10, vectorialPointValuePair36, vectorialPointValuePair42);
        double[] doubleArray44 = vectorialPointValuePair42.getPointRef();
        try {
            double[] doubleArray45 = gaussianFitter4.fit(doubleArray44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NULL_NOT_ALLOWED));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        float float1 = org.apache.commons.math.util.FastMath.ulp(100.00001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17260374626909167d) + "'", double1 == (-0.17260374626909167d));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) (short) 0, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5491388641509722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9997654863225975d + "'", double1 == 0.9997654863225975d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_FORMAT_INSTANCE_AS_3D_VECTOR));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric5 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray8 = new double[] { 100, (short) -1 };
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        double[] doubleArray14 = new double[] { 100, (short) -1 };
        double[] doubleArray16 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray14);
        double[] doubleArray19 = gaussianFitter4.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric5, doubleArray14);
        double[] doubleArray22 = new double[] { 100, (short) -1 };
        double[] doubleArray24 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray24);
        double[] doubleArray28 = new double[] { 100, (short) -1 };
        double[] doubleArray30 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair32 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray28);
        double[] doubleArray33 = gaussianFitter4.fit(doubleArray24);
        try {
            double[] doubleArray34 = gaussianFitter4.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-1L), (double) 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker4 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray6 = null;
        double[] doubleArray9 = new double[] { 100, (short) -1 };
        double[] doubleArray11 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray11);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray11, true);
        double[] doubleArray17 = new double[] { 100, (short) -1 };
        double[] doubleArray19 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray19);
        boolean boolean21 = simpleVectorialValueChecker4.converged((int) (short) 10, vectorialPointValuePair14, vectorialPointValuePair20);
        double[] doubleArray22 = vectorialPointValuePair20.getPointRef();
        try {
            double double23 = parametric0.value(4.440892098500626E-16d, doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 2 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LENGTH));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.642763621377997d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06357821906491815d + "'", double1 == 0.06357821906491815d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (byte) 1, (int) (short) 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_BRACKETING_PARAMETERS));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray2 = new double[] { 100, (short) -1 };
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair5 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray4);
        double[] doubleArray8 = new double[] { 100, (short) -1 };
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray8);
        double[] doubleArray13 = null;
        double[] doubleArray16 = new double[] { 100, (short) -1 };
        double[] doubleArray18 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray18, true);
        double[] doubleArray22 = vectorialPointValuePair21.getValue();
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5491388641509722d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9357556018037847d + "'", double1 == 0.9357556018037847d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (short) 0, (double) 0L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.9997654863225975d, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5841916485303856E29d + "'", double2 == 1.5841916485303856E29d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(52.0d, 0.0d, (double) (-0.99999994f));
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker4 = levenbergMarquardtOptimizer3.getConvergenceChecker();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        float float2 = org.apache.commons.math.util.FastMath.min(10.0f, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-51));
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 100.0f, (java.lang.Number) (-0.7615941559557649d), (java.lang.Number) (byte) 100);
        tooManyEvaluationsException1.addSuppressed((java.lang.Throwable) outOfRangeException6);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.WHOLE_FORMAT));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268069E13d + "'", double1 == 7.896296018268069E13d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.516965807543256d + "'", double1 == 0.516965807543256d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_DATA_FOR_NUMBER_OF_PREDICTORS));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray4);
        java.lang.Object[] objArray7 = optimizationException6.getArguments();
        java.lang.Object[] objArray8 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray7);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray3 = new java.lang.Object[] { localizedFormats0, localizedFormats1, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException(objArray3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray10 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray10);
        org.apache.commons.math.optimization.OptimizationException optimizationException12 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray10);
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray10);
        java.lang.String str14 = mathException13.getPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}x{1} and {2}x{3} matrices are not addition compatible" + "'", str14.equals("{0}x{1} and {2}x{3} matrices are not addition compatible"));
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_LARGER_THAN_MAX));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR_OVERFLOW_AFTER_MULTIPLY));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999999d + "'", double1 == 0.9999999999999999d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 0, 100.00001f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MINIMAL_STEPSIZE_REACHED_DURING_INTEGRATION));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(5, 100);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100.00001f, 97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8006254509038478d + "'", double2 == 0.8006254509038478d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FIRST_ELEMENT_NOT_ZERO));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray3 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException4 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalStateException4);
        java.lang.String str6 = convergenceException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = convergenceException5.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 97.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer differentiableMultivariateVectorialOptimizer0 = null;
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter1 = new org.apache.commons.math.optimization.fitting.CurveFitter(differentiableMultivariateVectorialOptimizer0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(1.3536398454434488d, (double) 1, 0.0d, (double) (short) -1, 3.141592653589793d);
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        java.lang.Object[] objArray2 = null;
        java.lang.Object[] objArray3 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 7.6293945E-6f, objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric5 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray8 = new double[] { 100, (short) -1 };
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        double[] doubleArray14 = new double[] { 100, (short) -1 };
        double[] doubleArray16 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray14);
        double[] doubleArray19 = gaussianFitter4.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric5, doubleArray14);
        gaussianFitter4.addObservedPoint((double) 3, (double) 0);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer26 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter27 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer26);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric28 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray31 = new double[] { 100, (short) -1 };
        double[] doubleArray33 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair34 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray31, doubleArray33);
        double[] doubleArray37 = new double[] { 100, (short) -1 };
        double[] doubleArray39 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair40 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray39);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair41 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray33, doubleArray37);
        double[] doubleArray42 = gaussianFitter27.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric28, doubleArray37);
        double[] doubleArray45 = new double[] { 100, (short) -1 };
        double[] doubleArray47 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair48 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray45, doubleArray47);
        double[] doubleArray51 = new double[] { 100, (short) -1 };
        double[] doubleArray53 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair54 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray51, doubleArray53);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair55 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray47, doubleArray51);
        double[] doubleArray56 = gaussianFitter27.fit(doubleArray47);
        try {
            double[] doubleArray57 = gaussianFitter4.fit(doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DUPLICATED_ABSCISSA));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FUNCTION_NOT_DIFFERENTIABLE));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 19.085536923187668d, (java.lang.Number) (byte) 10, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3536398454434488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.871491546971512d + "'", double1 == 3.871491546971512d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1, 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 1, (java.lang.Number) 1L, (java.lang.Number) (byte) 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 0.6931471805599453d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 1, (double) 10.0f);
        levenbergMarquardtOptimizer3.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker6);
        double double8 = simpleVectorialValueChecker6.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-0.41032129904824216d), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-420.1690102254d) + "'", double2 == (-420.1690102254d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double2 = org.apache.commons.math.util.FastMath.max(3.0d, 2.5091784786580567d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double double3 = simpleVectorialValueChecker2.getAbsoluteThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.0d) + "'", double3 == (-1.0d));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray4);
        java.lang.String str7 = optimizationException6.getPattern();
        java.lang.Object[] objArray8 = optimizationException6.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) optimizationException6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ConvergenceException convergenceException14 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray20);
        org.apache.commons.math.exception.ConvergenceException convergenceException22 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable15, objArray20);
        java.lang.Object[] objArray24 = convergenceException23.getArguments();
        java.lang.Object[] objArray25 = convergenceException23.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = optimizationException6.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(localizable27);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((-57.29577951308232d), (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 39.70422048691768d + "'", double2 == 39.70422048691768d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_SEQUENCE));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.8390715290764534d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1135504256558595d) + "'", double1 == (-1.1135504256558595d));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double1 = org.apache.commons.math.util.FastMath.sin(3.871491546971512d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6667942895314218d) + "'", double1 == (-0.6667942895314218d));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 1, (double) 10.0f);
        levenbergMarquardtOptimizer3.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker6);
        int int8 = levenbergMarquardtOptimizer3.getEvaluations();
        int int9 = levenbergMarquardtOptimizer3.getEvaluations();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(9.536743E-7f, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.536744E-7f + "'", float2 == 9.536744E-7f);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray4 = null;
        double[] doubleArray7 = new double[] { 100, (short) -1 };
        double[] doubleArray9 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray9);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray9, true);
        double[] doubleArray15 = new double[] { 100, (short) -1 };
        double[] doubleArray17 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        boolean boolean19 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair12, vectorialPointValuePair18);
        double[] doubleArray21 = null;
        double[] doubleArray24 = new double[] { 100, (short) -1 };
        double[] doubleArray26 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair27 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray26, true);
        double[] doubleArray32 = new double[] { 100, (short) -1 };
        double[] doubleArray34 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray34);
        boolean boolean36 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair29, vectorialPointValuePair35);
        double[] doubleArray37 = vectorialPointValuePair29.getPoint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(doubleArray37);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 1, (java.lang.Number) (byte) 1, (java.lang.Number) (-0.7615941559557649d));
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ConvergenceException convergenceException10 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray16 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException17 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray16);
        org.apache.commons.math.exception.ConvergenceException convergenceException18 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, objArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException10, localizable11, objArray16);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray25 = new java.lang.Object[] { localizedFormats22, localizedFormats23, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException(objArray25);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray32 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, objArray32);
        org.apache.commons.math.optimization.OptimizationException optimizationException34 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray32);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException26, (org.apache.commons.math.exception.util.Localizable) localizedFormats27, objArray32);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException36 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException10, (org.apache.commons.math.exception.util.Localizable) localizedFormats20, (org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray32);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException37 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 0.5403023058681399d, objArray32);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathRuntimeException4, (org.apache.commons.math.exception.util.Localizable) localizedFormats5, (org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_TRANSFORM_TO_DOUBLE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERCENTILE_IMPLEMENTATION_CANNOT_ACCESS_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray6);
        org.apache.commons.math.optimization.OptimizationException optimizationException8 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray6);
        java.lang.String str9 = optimizationException8.getPattern();
        java.lang.String str10 = optimizationException8.getPattern();
        java.lang.Object[] objArray11 = optimizationException8.getArguments();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException12 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.5841916485303856E29d, objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "hi!" + "'", str10.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray11);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        float float1 = org.apache.commons.math.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '4', (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        float float2 = org.apache.commons.math.util.FastMath.copySign(9.536744E-7f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.536744E-7f + "'", float2 == 9.536744E-7f);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.017453292519943295d, (double) 4.50359963E17f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.017453292519943295d + "'", double2 == 0.017453292519943295d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double2 = org.apache.commons.math.util.FastMath.scalb(19.085536923187668d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.19717569116915E10d + "'", double2 == 8.19717569116915E10d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray4 = null;
        double[] doubleArray7 = new double[] { 100, (short) -1 };
        double[] doubleArray9 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair10 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray7, doubleArray9);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray9, true);
        double[] doubleArray15 = new double[] { 100, (short) -1 };
        double[] doubleArray17 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        boolean boolean19 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair12, vectorialPointValuePair18);
        double[] doubleArray21 = null;
        double[] doubleArray24 = new double[] { 100, (short) -1 };
        double[] doubleArray26 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair27 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray24, doubleArray26);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray26, true);
        double[] doubleArray32 = new double[] { 100, (short) -1 };
        double[] doubleArray34 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair35 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray32, doubleArray34);
        boolean boolean36 = simpleVectorialValueChecker2.converged((int) (short) 10, vectorialPointValuePair29, vectorialPointValuePair35);
        double[] doubleArray37 = vectorialPointValuePair35.getPointRef();
        double[] doubleArray40 = new double[] { 100, (short) -1 };
        double[] doubleArray42 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray42);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray42, false);
        double[] doubleArray48 = new double[] { 100, (short) -1 };
        double[] doubleArray50 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair51 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray48, doubleArray50);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair52 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray48);
        double[] doubleArray53 = vectorialPointValuePair52.getPoint();
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NOT_ALLOWED));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.17260374626909167d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 3, (double) 0.0f, Double.NaN, (double) (short) 1, (-0.23840584404423515d));
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker6 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker6);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer(52.0d, 0.0d, (double) (-0.99999994f));
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter4 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint8 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) (byte) 100, 0.0d, 1.5841916485303856E29d);
        curveFitter4.addObservedPoint(weightedObservedPoint8);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948961d + "'", double1 == 1.5707963267948961d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.8813735870195429d), (java.lang.Number) (byte) 1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) 1 + "'", number4.equals((byte) 1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.lang.Object[] objArray10 = new java.lang.Object[] { "", (byte) 10, (short) 0, 0.0f, (-1L), localizedFormats9 };
        org.apache.commons.math.exception.ConvergenceException convergenceException11 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray10);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray10);
        org.apache.commons.math.exception.ConvergenceException convergenceException13 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray10);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.141592653589793d, 1.1107370937723096d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5661762614720725d + "'", double2 == 3.5661762614720725d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.PERMUTATION_EXCEEDS_N));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_0TH_ROOT_OF_UNITY));
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric5 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray8 = new double[] { 100, (short) -1 };
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        double[] doubleArray14 = new double[] { 100, (short) -1 };
        double[] doubleArray16 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray14);
        double[] doubleArray19 = gaussianFitter4.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric5, doubleArray14);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker23 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray25 = null;
        double[] doubleArray28 = new double[] { 100, (short) -1 };
        double[] doubleArray30 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray25, doubleArray30, true);
        double[] doubleArray36 = new double[] { 100, (short) -1 };
        double[] doubleArray38 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray38);
        boolean boolean40 = simpleVectorialValueChecker23.converged((int) (short) 10, vectorialPointValuePair33, vectorialPointValuePair39);
        double[] doubleArray42 = null;
        double[] doubleArray45 = new double[] { 100, (short) -1 };
        double[] doubleArray47 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair48 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray45, doubleArray47);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray42, doubleArray47, true);
        double[] doubleArray53 = new double[] { 100, (short) -1 };
        double[] doubleArray55 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair56 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray53, doubleArray55);
        boolean boolean57 = simpleVectorialValueChecker23.converged((int) (short) 10, vectorialPointValuePair50, vectorialPointValuePair56);
        double[] doubleArray58 = vectorialPointValuePair56.getPointRef();
        double[] doubleArray61 = new double[] { 100, (short) -1 };
        double[] doubleArray63 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair64 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray61, doubleArray63);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair66 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray58, doubleArray63, false);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer70 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter71 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer70);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric72 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray75 = new double[] { 100, (short) -1 };
        double[] doubleArray77 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair78 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray75, doubleArray77);
        double[] doubleArray81 = new double[] { 100, (short) -1 };
        double[] doubleArray83 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair84 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray81, doubleArray83);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair85 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray77, doubleArray81);
        double[] doubleArray86 = gaussianFitter71.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric72, doubleArray81);
        double[] doubleArray89 = new double[] { 100, (short) -1 };
        double[] doubleArray91 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair92 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray89, doubleArray91);
        double[] doubleArray93 = gaussianFitter71.fit(doubleArray89);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair95 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray63, doubleArray93, true);
        try {
            double double96 = parametric5.value(0.0d, doubleArray63);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertNotNull(doubleArray93);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ConvergenceException convergenceException2 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, objArray8);
        org.apache.commons.math.exception.ConvergenceException convergenceException10 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, localizable3, objArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats14, localizedFormats15, (-1.0d) };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException18 = new org.apache.commons.math.exception.MathIllegalStateException(objArray17);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, objArray24);
        org.apache.commons.math.optimization.OptimizationException optimizationException26 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray24);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalStateException18, (org.apache.commons.math.exception.util.Localizable) localizedFormats19, objArray24);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) convergenceException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats12, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray24);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray24);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.9E-324d, (java.lang.Number) 0.9646843920620416d, (java.lang.Number) 1L);
        mathException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer42 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        int int43 = levenbergMarquardtOptimizer42.getJacobianEvaluations();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter44 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer42);
        curveFitter44.addObservedPoint(0.0d, (double) (short) -1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray48 = curveFitter44.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException49 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathException29, (org.apache.commons.math.exception.util.Localizable) localizedFormats35, (org.apache.commons.math.exception.util.Localizable) localizedFormats36, (java.lang.Object[]) weightedObservedPointArray48);
        try {
            org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser parameterGuesser50 = new org.apache.commons.math.optimization.fitting.GaussianFitter.ParameterGuesser(weightedObservedPointArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 1 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.CLASS_DOESNT_IMPLEMENT_COMPARABLE));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ADDITION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.POLYNOMIAL));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray48);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.1188192535093538E-27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1188192535093538E-27d + "'", double1 == 2.1188192535093538E-27d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9997654863225975d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9997654863225977d + "'", double1 == 0.9997654863225977d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(2.1188192535093538E-27d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-89) + "'", int1 == (-89));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException3 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.99999994f), objArray2);
        java.lang.Object[] objArray4 = maxCountExceededException3.getArguments();
        java.lang.Number number5 = maxCountExceededException3.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DENOMINATOR_FORMAT));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-0.99999994f) + "'", number5.equals((-0.99999994f)));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric0 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker4 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray6 = null;
        double[] doubleArray9 = new double[] { 100, (short) -1 };
        double[] doubleArray11 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray9, doubleArray11);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray6, doubleArray11, true);
        double[] doubleArray17 = new double[] { 100, (short) -1 };
        double[] doubleArray19 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray17, doubleArray19);
        boolean boolean21 = simpleVectorialValueChecker4.converged((int) (short) 10, vectorialPointValuePair14, vectorialPointValuePair20);
        double[] doubleArray23 = null;
        double[] doubleArray26 = new double[] { 100, (short) -1 };
        double[] doubleArray28 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray28);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray28, true);
        double[] doubleArray34 = new double[] { 100, (short) -1 };
        double[] doubleArray36 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair37 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray34, doubleArray36);
        boolean boolean38 = simpleVectorialValueChecker4.converged((int) (short) 10, vectorialPointValuePair31, vectorialPointValuePair37);
        double[] doubleArray39 = vectorialPointValuePair37.getPointRef();
        double[] doubleArray42 = new double[] { 100, (short) -1 };
        double[] doubleArray44 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray42, doubleArray44);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray39, doubleArray44, false);
        try {
            double double48 = parametric0.value((double) (byte) 10, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (short) -1, 1.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = gaussian2.derivative();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = gaussian2.derivative();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = gaussian2.derivative();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = gaussian2.derivative();
        double double8 = gaussian2.value(3.814697265606496E-6d);
        org.junit.Assert.assertNotNull(univariateRealFunction3);
        org.junit.Assert.assertNotNull(univariateRealFunction4);
        org.junit.Assert.assertNotNull(univariateRealFunction5);
        org.junit.Assert.assertNotNull(univariateRealFunction6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.24196980147408217d + "'", double8 == 0.24196980147408217d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.814697265606496E-6d, (double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.814696974568212E-8d + "'", double2 == 3.814696974568212E-8d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 10, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        java.lang.Number number2 = zeroException1.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION_FAILED));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 0, 19.085536923187668d, (double) 100L, 0.17453292519943295d, (double) 0.0f);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker10 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray12 = null;
        double[] doubleArray15 = new double[] { 100, (short) -1 };
        double[] doubleArray17 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray15, doubleArray17);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair20 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray12, doubleArray17, true);
        double[] doubleArray23 = new double[] { 100, (short) -1 };
        double[] doubleArray25 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair26 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray25);
        boolean boolean27 = simpleVectorialValueChecker10.converged((int) (short) 10, vectorialPointValuePair20, vectorialPointValuePair26);
        levenbergMarquardtOptimizer5.setConvergenceChecker((org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair>) simpleVectorialValueChecker10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer9 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        int int10 = levenbergMarquardtOptimizer9.getJacobianEvaluations();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter11 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer9);
        curveFitter11.addObservedPoint(0.0d, (double) (short) -1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray15 = curveFitter11.getObservations();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Object[]) weightedObservedPointArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray21);
        org.apache.commons.math.exception.ConvergenceException convergenceException23 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray28 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException29 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray28);
        org.apache.commons.math.optimization.OptimizationException optimizationException30 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray28);
        java.lang.String str31 = optimizationException30.getPattern();
        java.lang.Object[] objArray32 = optimizationException30.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) optimizationException30);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        java.lang.Throwable throwable36 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats47 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.lang.Object[] objArray48 = new java.lang.Object[] { "", (byte) 10, (short) 0, 0.0f, (-1L), localizedFormats47 };
        org.apache.commons.math.exception.ConvergenceException convergenceException49 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, objArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException50 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray48);
        org.apache.commons.math.exception.ConvergenceException convergenceException51 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats38, objArray48);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(throwable36, "{0}", objArray48);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException53 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) mathRuntimeException33, (org.apache.commons.math.exception.util.Localizable) localizedFormats34, localizable35, objArray48);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray48);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException2, (org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray48);
        java.lang.Number number56 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_CONSIDER_PADDING));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_0_FOR_SOME_ALPHA));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats47.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 0 + "'", number56.equals(0));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double2 = org.apache.commons.math.util.FastMath.copySign((-0.017451520651465824d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.017451520651465824d) + "'", double2 == (-0.017451520651465824d));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 5, 9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.180339887498947d + "'", double2 == 11.180339887498947d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        try {
            org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) 9.536744E-7f, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_FEASIBLE_SOLUTION));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math.util.FastMath.ulp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        long long1 = org.apache.commons.math.util.FastMath.abs(35L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (short) -1, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) 1.5491388641509722d, false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(2.2924316695611777d, (double) 100.0f, (double) '#');
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        double double6 = levenbergMarquardtOptimizer5.getRMS();
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.exp(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.192092966562089E-7d + "'", double1 == 1.192092966562089E-7d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_FIRST_GUESS_HARMONIC_COEFFICIENTS));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.6704649792860586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950371902099892d + "'", double1 == 0.9950371902099892d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0f), (java.lang.Number) (byte) -1, (java.lang.Number) 10L);
        org.apache.commons.math.optimization.OptimizationException optimizationException4 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) outOfRangeException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = optimizationException4.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer3 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter4 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer3);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric5 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray8 = new double[] { 100, (short) -1 };
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        double[] doubleArray14 = new double[] { 100, (short) -1 };
        double[] doubleArray16 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair17 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray14, doubleArray16);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair18 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray10, doubleArray14);
        double[] doubleArray19 = gaussianFitter4.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric5, doubleArray14);
        double[] doubleArray22 = new double[] { 100, (short) -1 };
        double[] doubleArray24 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair25 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray24);
        double[] doubleArray26 = gaussianFitter4.fit(doubleArray22);
        try {
            double[] doubleArray27 = gaussianFitter4.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooSmallException; message: 0 is smaller than the minimum (3)");
        } catch (org.apache.commons.math.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math.exception.ConvergenceException convergenceException1 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-89), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        float float1 = org.apache.commons.math.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.5403023058681399d, (double) 10);
        double double3 = simpleVectorialValueChecker2.getRelativeThreshold();
        double double4 = simpleVectorialValueChecker2.getRelativeThreshold();
        double double5 = simpleVectorialValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5403023058681399d + "'", double3 == 0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5403023058681399d + "'", double4 == 0.5403023058681399d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5403023058681399d + "'", double5 == 0.5403023058681399d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.6931471805599453d);
        java.lang.String str2 = tooManyEvaluationsException1.toString();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) tooManyEvaluationsException1);
        org.apache.commons.math.optimization.OptimizationException optimizationException4 = new org.apache.commons.math.optimization.OptimizationException((java.lang.Throwable) tooManyEvaluationsException1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.TooManyEvaluationsException: evaluations" + "'", str2.equals("org.apache.commons.math.exception.TooManyEvaluationsException: evaluations"));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) 3.642763621377997d, (java.lang.Number) 35L);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.LCM_OVERFLOW_64_BITS));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray2 = new double[] { 100, (short) -1 };
        double[] doubleArray4 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair5 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray2, doubleArray4);
        double[] doubleArray8 = new double[] { 100, (short) -1 };
        double[] doubleArray10 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair11 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray10);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair12 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray4, doubleArray8);
        double[] doubleArray13 = null;
        double[] doubleArray16 = new double[] { 100, (short) -1 };
        double[] doubleArray18 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair19 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray16, doubleArray18);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair21 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray13, doubleArray18, true);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray13, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 1, 2.2924316695611777d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.ZeroException zeroException1 = new org.apache.commons.math.exception.ZeroException((org.apache.commons.math.exception.util.Localizable) localizedFormats0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 35L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray4 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException5 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray4);
        org.apache.commons.math.optimization.OptimizationException optimizationException6 = new org.apache.commons.math.optimization.OptimizationException("hi!", objArray4);
        java.lang.String str7 = optimizationException6.getPattern();
        java.lang.Object[] objArray8 = optimizationException6.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) optimizationException6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 3.141592653589793d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.ConvergenceException convergenceException14 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats13);
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray20 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray20);
        org.apache.commons.math.exception.ConvergenceException convergenceException22 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray20);
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException14, localizable15, objArray20);
        java.lang.Object[] objArray24 = convergenceException23.getArguments();
        java.lang.Object[] objArray25 = convergenceException23.getArguments();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) optimizationException6, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable27 = optimizationException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = optimizationException6.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "hi!" + "'", str7.equals("hi!"));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertNotNull(localizable28);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter7 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        curveFitter7.addObservedPoint(0.0d, (double) (short) -1);
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray11 = curveFitter7.getObservations();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer15 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter16 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer15);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric17 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray20 = new double[] { 100, (short) -1 };
        double[] doubleArray22 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair23 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray20, doubleArray22);
        double[] doubleArray26 = new double[] { 100, (short) -1 };
        double[] doubleArray28 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair29 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray26, doubleArray28);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray22, doubleArray26);
        double[] doubleArray31 = gaussianFitter16.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray26);
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer35 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter36 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer35);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric37 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray40 = new double[] { 100, (short) -1 };
        double[] doubleArray42 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair43 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray40, doubleArray42);
        double[] doubleArray46 = new double[] { 100, (short) -1 };
        double[] doubleArray48 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair49 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray46, doubleArray48);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair50 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray42, doubleArray46);
        double[] doubleArray51 = gaussianFitter36.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric37, doubleArray46);
        double[] doubleArray54 = new double[] { 100, (short) -1 };
        double[] doubleArray56 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair57 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray54, doubleArray56);
        double[] doubleArray60 = new double[] { 100, (short) -1 };
        double[] doubleArray62 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair63 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray60, doubleArray62);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair64 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray56, doubleArray60);
        double[] doubleArray65 = gaussianFitter36.fit(doubleArray56);
        try {
            double[] doubleArray66 = curveFitter7.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric17, doubleArray56);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(weightedObservedPointArray11);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 0, 19.085536923187668d, (double) 100L, 0.17453292519943295d, (double) 0.0f);
        double double6 = levenbergMarquardtOptimizer5.getChiSquare();
        org.apache.commons.math.optimization.ConvergenceChecker<org.apache.commons.math.optimization.VectorialPointValuePair> vectorialPointValuePairConvergenceChecker7 = levenbergMarquardtOptimizer5.getConvergenceChecker();
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter8 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(vectorialPointValuePairConvergenceChecker7);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math.optimization.fitting.WeightedObservedPoint((double) (byte) 100, 0.0d, 1.5841916485303856E29d);
        double double4 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double2 = org.apache.commons.math.util.FastMath.max(0.516965807543256d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.516965807543256d + "'", double2 == 0.516965807543256d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer5 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        int int6 = levenbergMarquardtOptimizer5.getJacobianEvaluations();
        org.apache.commons.math.optimization.fitting.CurveFitter curveFitter7 = new org.apache.commons.math.optimization.fitting.CurveFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer5);
        curveFitter7.addObservedPoint((double) 5, (double) 32L, (-0.7615941559557649d));
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric12 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer16 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) 100L, 0.0d, (double) 1L);
        org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter17 = new org.apache.commons.math.optimization.fitting.GaussianFitter((org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer) levenbergMarquardtOptimizer16);
        org.apache.commons.math.analysis.function.Gaussian.Parametric parametric18 = new org.apache.commons.math.analysis.function.Gaussian.Parametric();
        double[] doubleArray21 = new double[] { 100, (short) -1 };
        double[] doubleArray23 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair24 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray21, doubleArray23);
        double[] doubleArray27 = new double[] { 100, (short) -1 };
        double[] doubleArray29 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair30 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray27, doubleArray29);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray23, doubleArray27);
        double[] doubleArray32 = gaussianFitter17.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric18, doubleArray27);
        double[] doubleArray35 = new double[] { 100, (short) -1 };
        double[] doubleArray37 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair38 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray35, doubleArray37);
        double[] doubleArray41 = new double[] { 100, (short) -1 };
        double[] doubleArray43 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair44 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray41, doubleArray43);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair45 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray37, doubleArray41);
        double[] doubleArray46 = gaussianFitter17.fit(doubleArray37);
        try {
            double[] doubleArray47 = curveFitter7.fit((org.apache.commons.math.analysis.ParametricUnivariateRealFunction) parametric12, doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: dimensions mismatch: 1 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double2 = org.apache.commons.math.util.FastMath.copySign(Double.NEGATIVE_INFINITY, 8.19717569116915E10d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        float float1 = org.apache.commons.math.util.FastMath.abs((-1.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1.57625987E17f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.optimization.OptimizationException optimizationException2 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROBUSTNESS_ITERATIONS));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.SAME_SIGN_AT_ENDPOINTS));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        float float2 = org.apache.commons.math.util.FastMath.scalb((-1.0f), 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.2676506E30f) + "'", float2 == (-1.2676506E30f));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6483608274590866d + "'", double1 == 0.6483608274590866d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker2 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker((double) (short) 1, (double) 10.0f);
        org.apache.commons.math.optimization.SimpleVectorialValueChecker simpleVectorialValueChecker6 = new org.apache.commons.math.optimization.SimpleVectorialValueChecker(0.0d, (double) (byte) -1);
        double[] doubleArray8 = null;
        double[] doubleArray11 = new double[] { 100, (short) -1 };
        double[] doubleArray13 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair14 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray11, doubleArray13);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair16 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray8, doubleArray13, true);
        double[] doubleArray19 = new double[] { 100, (short) -1 };
        double[] doubleArray21 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair22 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray19, doubleArray21);
        boolean boolean23 = simpleVectorialValueChecker6.converged((int) (short) 10, vectorialPointValuePair16, vectorialPointValuePair22);
        double[] doubleArray25 = null;
        double[] doubleArray28 = new double[] { 100, (short) -1 };
        double[] doubleArray30 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair31 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray28, doubleArray30);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair33 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray25, doubleArray30, true);
        double[] doubleArray36 = new double[] { 100, (short) -1 };
        double[] doubleArray38 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair39 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray36, doubleArray38);
        boolean boolean40 = simpleVectorialValueChecker6.converged((int) (short) 10, vectorialPointValuePair33, vectorialPointValuePair39);
        double[] doubleArray41 = null;
        double[] doubleArray44 = new double[] { 100, (short) -1 };
        double[] doubleArray46 = new double[] { 10 };
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair47 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray44, doubleArray46);
        org.apache.commons.math.optimization.VectorialPointValuePair vectorialPointValuePair49 = new org.apache.commons.math.optimization.VectorialPointValuePair(doubleArray41, doubleArray46, true);
        boolean boolean50 = simpleVectorialValueChecker2.converged((int) (byte) 10, vectorialPointValuePair33, vectorialPointValuePair49);
        double[] doubleArray51 = vectorialPointValuePair33.getValueRef();
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.analysis.function.Gaussian gaussian2 = new org.apache.commons.math.analysis.function.Gaussian((double) (short) -1, 1.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = gaussian2.derivative();
        double double5 = gaussian2.value((-0.017453292519943295d));
        org.junit.Assert.assertNotNull(univariateRealFunction3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.246193479685452d + "'", double5 == 0.246193479685452d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { (-1), '#' };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, objArray6);
        org.apache.commons.math.exception.ConvergenceException convergenceException8 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT;
        org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer levenbergMarquardtOptimizer17 = new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer((double) (short) 10, 0.0d, (double) (short) 10, 1.0d, 0.0d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED;
        java.lang.Object[] objArray25 = new java.lang.Object[] { "", (byte) 10, (short) 0, 0.0f, (-1L), localizedFormats24 };
        org.apache.commons.math.exception.ConvergenceException convergenceException26 = new org.apache.commons.math.exception.ConvergenceException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, objArray25);
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats2, false, localizedFormats10, localizedFormats11, (short) 10, objArray25 };
        org.apache.commons.math.optimization.OptimizationException optimizationException28 = new org.apache.commons.math.optimization.OptimizationException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable0, objArray27);
        java.lang.Object[] objArray30 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.HOLE_BETWEEN_MODELS_TIME_RANGES));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_ENOUGH_POINTS_IN_SPLINE_PARTITION));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.EMPTY_SELECTED_COLUMN_INDEX_ARRAY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.EXPONENT));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_POSITIVE_DEFINITE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.ASSYMETRIC_EIGEN_NOT_SUPPORTED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray30);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 3.141592653589793d);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        boolean boolean4 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NAN_VALUE_CONVERSION));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.log(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }
}

