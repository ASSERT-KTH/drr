import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = openMapRealVector10.copy();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector10.mapSubtractToSelf(9.536743164069727E-7d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(openMapRealVector11);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double2 = org.apache.commons.math.util.FastMath.max(1.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getNorm();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector7.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double double14 = openMapRealVector4.getL1Distance(openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor16 = openMapRealVector15.sparseIterator();
        boolean boolean17 = openMapRealVector15.isNaN();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector15.mapMultiplyToSelf(1.4711276743037347d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector15.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector7.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector21.append(0.5403023058681398d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor24 = openMapRealVector23.sparseIterator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertNotNull(entryItor24);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        double[] doubleArray24 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix21.preMultiply(doubleArray24);
        double double27 = array2DRowRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix21.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix21.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix21);
        try {
            double double33 = array2DRowRealMatrix21.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.scalarMultiply(0.8813735870195429d);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        double[][] doubleArray16 = array2DRowRealMatrix10.getData();
        double double17 = array2DRowRealMatrix10.getFrobeniusNorm();
        double[] doubleArray19 = new double[] { 10.0f };
        double[] doubleArray21 = new double[] { 10.0f };
        double[][] doubleArray22 = new double[][] { doubleArray19, doubleArray21 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22, false);
        double[] doubleArray26 = array2DRowRealMatrix24.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26, (double) 9.094947E-13f);
        double[] doubleArray29 = array2DRowRealMatrix10.operate(doubleArray26);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector46 = array2DRowRealMatrix36.getColumnVector((int) (short) 0);
        java.lang.String str47 = array2DRowRealMatrix36.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix3.add(array2DRowRealMatrix48);
        double[] doubleArray51 = new double[] { 10.0f };
        double[] doubleArray53 = new double[] { 10.0f };
        double[][] doubleArray54 = new double[][] { doubleArray51, doubleArray53 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54, true);
        int int59 = array2DRowRealMatrix58.getRowDimension();
        double[] doubleArray61 = new double[] { 10.0f };
        double[] doubleArray63 = new double[] { 10.0f };
        double[][] doubleArray64 = new double[][] { doubleArray61, doubleArray63 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray64, false);
        double[] doubleArray69 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray69);
        double[] doubleArray71 = array2DRowRealMatrix66.preMultiply(doubleArray69);
        double[] doubleArray72 = array2DRowRealMatrix58.preMultiply(doubleArray69);
        double[] doubleArray73 = array2DRowRealMatrix48.preMultiply(doubleArray69);
        int int74 = array2DRowRealMatrix48.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 14.142135623730951d + "'", double17 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str47.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector0.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector0.mapMultiplyToSelf(97.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector24.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(openMapRealVector27);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector2.mapAdd(20.0d);
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray13 = array2DRowRealMatrix11.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13, (double) 9.094947E-13f);
        double double16 = openMapRealVector2.getL1Distance(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor19 = openMapRealVector17.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int21 = openMapRealVector20.getMinIndex();
        int int22 = openMapRealVector20.getDimension();
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector20.mapDivideToSelf((double) (-1));
        int int25 = openMapRealVector20.getMinIndex();
        double double26 = openMapRealVector17.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector17.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector17.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int31 = openMapRealVector30.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double35 = openMapRealVector34.getNorm();
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector30.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector34);
        boolean boolean37 = openMapRealVector30.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor40 = openMapRealVector38.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int42 = openMapRealVector41.getMinIndex();
        int int43 = openMapRealVector41.getDimension();
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector41.mapDivideToSelf((double) (-1));
        int int46 = openMapRealVector41.getMinIndex();
        double double47 = openMapRealVector38.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector30.projection((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector30.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector30.mapMultiplyToSelf(97.0d);
        double double53 = openMapRealVector29.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector30.copy();
        try {
            double double55 = openMapRealVector2.dotProduct(openMapRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 10.0d + "'", double16 == 10.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(entryItor19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(entryItor40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector54);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-18));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 4.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.289917197127753d + "'", double1 == 27.289917197127753d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(6, (-17));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -17 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double double13 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray22 = array2DRowRealMatrix20.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22, (double) 9.094947E-13f);
        double[] doubleArray25 = array2DRowRealMatrix6.operate(doubleArray22);
        double[] doubleArray27 = new double[] { 10.0f };
        double[] doubleArray29 = new double[] { 10.0f };
        double[][] doubleArray30 = new double[][] { doubleArray27, doubleArray29 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30, false);
        double[] doubleArray35 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray37 = array2DRowRealMatrix32.preMultiply(doubleArray35);
        double double38 = array2DRowRealMatrix32.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix32.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector42 = array2DRowRealMatrix32.getColumnVector((int) (short) 0);
        java.lang.String str43 = array2DRowRealMatrix32.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix32);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor45 = null;
        try {
            double double50 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor45, (-127), 32, (-127), (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 14.142135623730951d + "'", double13 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 14.142135623730951d + "'", double38 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix40);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str43.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector2.mapAdd(20.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor9 = openMapRealVector7.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        int int12 = openMapRealVector10.getDimension();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector10.mapDivideToSelf((double) (-1));
        int int15 = openMapRealVector10.getMinIndex();
        double double16 = openMapRealVector7.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector10);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor17 = openMapRealVector7.iterator();
        double double18 = openMapRealVector7.getL1Norm();
        try {
            org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector2.combine(0.0d, 0.0d, (org.apache.commons.math.linear.RealVector) openMapRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(entryItor9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4657359027997265d + "'", double1 == 3.4657359027997265d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(97, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.scalarMultiply((-0.6193819415085411d));
        boolean boolean7 = array2DRowRealMatrix3.equals((java.lang.Object) 1.0E-12d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double2 = org.apache.commons.math.util.FastMath.hypot(5.267884728309446d, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.326111131569071d + "'", double2 == 5.326111131569071d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.8551464208140986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9991040211506196d + "'", double1 == 0.9991040211506196d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap0 = new org.apache.commons.math.util.OpenIntToDoubleHashMap();
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator1 = openIntToDoubleHashMap0.iterator();
        int int2 = openIntToDoubleHashMap0.size();
        double double4 = openIntToDoubleHashMap0.get((int) (short) -1);
        org.junit.Assert.assertNotNull(iterator1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        int int2 = org.apache.commons.math.util.FastMath.min(97, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(100, (double) 100.00001f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[][] doubleArray5 = array2DRowRealMatrix3.getData();
        double[][] doubleArray6 = array2DRowRealMatrix3.getDataRef();
        int int7 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double[][] doubleArray20 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { 10.0f };
        double[] doubleArray25 = new double[] { 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26, false);
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix28.preMultiply(doubleArray31);
        array2DRowRealMatrix14.setRow(0, doubleArray33);
        double double35 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix3.add(array2DRowRealMatrix14);
        double[][] doubleArray37 = array2DRowRealMatrix3.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor39 = null;
        try {
            double double44 = array2DRowRealMatrix38.walkInOptimizedOrder(realMatrixChangingVisitor39, (-127), (int) (byte) 100, (int) (short) 10, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 14.142135623730951d + "'", double35 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix38 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int39 = openMapRealMatrix38.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix40 = openMapRealMatrix35.add(openMapRealMatrix38);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix41 = openMapRealMatrix32.add(openMapRealMatrix35);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix44 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int51 = openMapRealMatrix50.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = openMapRealMatrix47.add(openMapRealMatrix50);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix53 = openMapRealMatrix44.add(openMapRealMatrix47);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix56 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix59 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix62 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int63 = openMapRealMatrix62.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix64 = openMapRealMatrix59.add(openMapRealMatrix62);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix65 = openMapRealMatrix56.add(openMapRealMatrix59);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix66 = openMapRealMatrix44.subtract(openMapRealMatrix59);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix67 = openMapRealMatrix41.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix44);
        openMapRealMatrix67.addToEntry((int) '4', 0, 0.6483608274590866d);
        try {
            array2DRowRealMatrix6.setColumnMatrix(0, (org.apache.commons.math.linear.RealMatrix) openMapRealMatrix67);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x32 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 97 + "'", int39 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix40);
        org.junit.Assert.assertNotNull(openMapRealMatrix41);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 97 + "'", int51 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix52);
        org.junit.Assert.assertNotNull(openMapRealMatrix53);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 97 + "'", int63 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix64);
        org.junit.Assert.assertNotNull(openMapRealMatrix65);
        org.junit.Assert.assertNotNull(openMapRealMatrix66);
        org.junit.Assert.assertNotNull(openMapRealMatrix67);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.scalarMultiply(0.8813735870195429d);
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double[][] doubleArray20 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { 10.0f };
        double[] doubleArray25 = new double[] { 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26, false);
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix28.preMultiply(doubleArray31);
        array2DRowRealMatrix14.setRow(0, doubleArray33);
        double double35 = array2DRowRealMatrix14.getFrobeniusNorm();
        double[] doubleArray37 = array2DRowRealMatrix14.getRow((int) (short) 0);
        double[] doubleArray38 = array2DRowRealMatrix3.operate(doubleArray37);
        try {
            org.apache.commons.math.linear.RealVector realVector40 = array2DRowRealMatrix3.getColumnVector((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 14.142135623730951d + "'", double35 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int3 = openMapRealVector2.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double7 = openMapRealVector6.getNorm();
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector2.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector6);
        boolean boolean9 = openMapRealVector2.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor12 = openMapRealVector10.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        int int15 = openMapRealVector13.getDimension();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapDivideToSelf((double) (-1));
        int int18 = openMapRealVector13.getMinIndex();
        double double19 = openMapRealVector10.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int22 = openMapRealVector21.getMinIndex();
        int int23 = openMapRealVector21.getDimension();
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector21.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector2.append((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        double[] doubleArray27 = openMapRealVector26.getData();
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector1.projection(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(entryItor12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        int int44 = openMapRealVector42.getDimension();
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector42.mapDivideToSelf((double) (-1));
        int int47 = openMapRealVector42.getMinIndex();
        double double48 = openMapRealVector39.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor49 = openMapRealVector39.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector39.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector37.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor53 = openMapRealVector37.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int55 = openMapRealVector54.getMinIndex();
        int int56 = openMapRealVector54.getDimension();
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector54.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector(realVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double61 = openMapRealVector59.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector60);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector37.append((org.apache.commons.math.linear.RealVector) openMapRealVector60);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor63 = openMapRealVector60.iterator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(entryItor53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertNotNull(entryItor63);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix14.copy();
        double[] doubleArray28 = new double[] { 10.0f };
        double[] doubleArray30 = new double[] { 10.0f };
        double[][] doubleArray31 = new double[][] { doubleArray28, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, false);
        double[] doubleArray36 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray38 = array2DRowRealMatrix33.preMultiply(doubleArray36);
        double[][] doubleArray39 = array2DRowRealMatrix33.getData();
        double double40 = array2DRowRealMatrix33.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix41 = openMapRealMatrix14.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x32 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 14.142135623730951d + "'", double40 == 14.142135623730951d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        long long1 = org.apache.commons.math.util.FastMath.round(Double.NaN);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector0.mapAddToSelf(0.0d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor5 = openMapRealVector4.sparseIterator();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(openMapRealVector4);
        org.junit.Assert.assertNotNull(entryItor5);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, (double) 100.00001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor1 = openMapRealVector0.sparseIterator();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double8 = openMapRealVector7.getNorm();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector3.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector7);
        boolean boolean10 = openMapRealVector0.equals((java.lang.Object) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector0.mapAdd(0.0d);
        double[] doubleArray13 = openMapRealVector12.toArray();
        int int14 = openMapRealVector12.getMinIndex();
        double double15 = openMapRealVector12.getNorm();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector12.mapMultiply((double) (short) 100);
        org.junit.Assert.assertNotNull(entryItor1);
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(openMapRealVector12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double7 = openMapRealVector5.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector6);
        double double8 = openMapRealVector5.getLInfNorm();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(1, (int) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double8 = openMapRealVector7.getNorm();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector3.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector7);
        boolean boolean10 = openMapRealVector3.isNaN();
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector3.mapMultiply((double) (short) 100);
        try {
            double double13 = openMapRealVector2.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realVector12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        double double5 = openIntToDoubleHashMap1.put((int) (short) 1, 0.8342233605065102d);
        boolean boolean7 = openIntToDoubleHashMap1.containsKey((int) (short) 1);
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        double double1 = org.apache.commons.math.util.FastMath.acos((-16.999999999999996d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        double[][] doubleArray16 = array2DRowRealMatrix10.getData();
        double double17 = array2DRowRealMatrix10.getFrobeniusNorm();
        double[] doubleArray19 = new double[] { 10.0f };
        double[] doubleArray21 = new double[] { 10.0f };
        double[][] doubleArray22 = new double[][] { doubleArray19, doubleArray21 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22, false);
        double[] doubleArray26 = array2DRowRealMatrix24.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26, (double) 9.094947E-13f);
        double[] doubleArray29 = array2DRowRealMatrix10.operate(doubleArray26);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector46 = array2DRowRealMatrix36.getColumnVector((int) (short) 0);
        java.lang.String str47 = array2DRowRealMatrix36.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix3.add(array2DRowRealMatrix48);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor50 = null;
        try {
            double double51 = array2DRowRealMatrix3.walkInRowOrder(realMatrixChangingVisitor50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 14.142135623730951d + "'", double17 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str47.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999329299739067d + "'", double1 == 0.999329299739067d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector0.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector0.mapMultiplyToSelf(97.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int24 = openMapRealVector23.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double28 = openMapRealVector27.getNorm();
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector23.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector27);
        boolean boolean30 = openMapRealVector23.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int32 = openMapRealVector31.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor33 = openMapRealVector31.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int35 = openMapRealVector34.getMinIndex();
        int int36 = openMapRealVector34.getDimension();
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector34.mapDivideToSelf((double) (-1));
        int int39 = openMapRealVector34.getMinIndex();
        double double40 = openMapRealVector31.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.RealVector realVector41 = openMapRealVector23.projection((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.RealVector realVector43 = openMapRealVector23.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector23.mapMultiplyToSelf(97.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = openMapRealVector0.subtract(openMapRealVector23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(entryItor33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(openMapRealVector46);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix5.subtract(openMapRealMatrix39);
        int int51 = openMapRealMatrix39.getRowDimension();
        double double54 = openMapRealMatrix39.getEntry(35, 0);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix57 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix60 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix63 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int64 = openMapRealMatrix63.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix65 = openMapRealMatrix60.add(openMapRealMatrix63);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix66 = openMapRealMatrix57.add(openMapRealMatrix60);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix67 = openMapRealMatrix39.multiply(openMapRealMatrix60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 97");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 97 + "'", int51 == 97);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 97 + "'", int64 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix65);
        org.junit.Assert.assertNotNull(openMapRealMatrix66);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix2.subtract(openMapRealMatrix17);
        java.lang.String str25 = openMapRealMatrix17.toString();
        double[] doubleArray28 = new double[] { 10.0f };
        double[] doubleArray30 = new double[] { 10.0f };
        double[][] doubleArray31 = new double[][] { doubleArray28, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, false);
        double[] doubleArray36 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray38 = array2DRowRealMatrix33.preMultiply(doubleArray36);
        double double39 = array2DRowRealMatrix33.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix33.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix43 = array2DRowRealMatrix33.scalarAdd((double) (short) 100);
        double[] doubleArray45 = new double[] { 10.0f };
        double[] doubleArray47 = new double[] { 10.0f };
        double[][] doubleArray48 = new double[][] { doubleArray45, doubleArray47 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48, false);
        double[] doubleArray53 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        double[] doubleArray55 = array2DRowRealMatrix50.preMultiply(doubleArray53);
        double[][] doubleArray56 = array2DRowRealMatrix50.getData();
        double[] doubleArray59 = new double[] { 10.0f };
        double[] doubleArray61 = new double[] { 10.0f };
        double[][] doubleArray62 = new double[][] { doubleArray59, doubleArray61 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62, false);
        double[] doubleArray67 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix68 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray67);
        double[] doubleArray69 = array2DRowRealMatrix64.preMultiply(doubleArray67);
        array2DRowRealMatrix50.setRow(0, doubleArray69);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = array2DRowRealMatrix33.subtract(array2DRowRealMatrix50);
        double[] doubleArray74 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray74);
        double double76 = array2DRowRealMatrix75.getNorm();
        int int77 = array2DRowRealMatrix75.getColumnDimension();
        double[] doubleArray79 = new double[] { 10.0f };
        double[] doubleArray81 = new double[] { 10.0f };
        double[][] doubleArray82 = new double[][] { doubleArray79, doubleArray81 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix84 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray82, false);
        double double85 = array2DRowRealMatrix84.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix86 = array2DRowRealMatrix75.add(array2DRowRealMatrix84);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix87 = array2DRowRealMatrix50.add(array2DRowRealMatrix75);
        try {
            openMapRealMatrix17.setRowMatrix((int) '#', (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix87);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 1x32");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 14.142135623730951d + "'", double39 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.0d + "'", double76 == 1.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 1 + "'", int77 == 1);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 20.0d + "'", double85 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix86);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix87);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6821738184917203d + "'", double1 == 2.6821738184917203d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix5.subtract(openMapRealMatrix39);
        int int51 = openMapRealMatrix39.getRowDimension();
        int int52 = openMapRealMatrix39.getRowDimension();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 97 + "'", int51 == 97);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 97 + "'", int52 == 97);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        org.apache.commons.math.linear.RealVector realVector3 = openMapRealVector0.mapMultiply(5.298292365610485d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int5 = openMapRealVector4.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor6 = openMapRealVector4.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        int int9 = openMapRealVector7.getDimension();
        org.apache.commons.math.linear.RealVector realVector11 = openMapRealVector7.mapDivideToSelf((double) (-1));
        int int12 = openMapRealVector7.getMinIndex();
        double double13 = openMapRealVector4.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        double double14 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int16 = openMapRealVector15.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double20 = openMapRealVector19.getNorm();
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector15.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector19);
        boolean boolean22 = openMapRealVector15.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int24 = openMapRealVector23.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor25 = openMapRealVector23.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int27 = openMapRealVector26.getMinIndex();
        int int28 = openMapRealVector26.getDimension();
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector26.mapDivideToSelf((double) (-1));
        int int31 = openMapRealVector26.getMinIndex();
        double double32 = openMapRealVector23.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector15.projection((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector15.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector15.mapMultiplyToSelf(97.0d);
        int int38 = openMapRealVector15.getDimension();
        double double39 = openMapRealVector0.dotProduct(openMapRealVector15);
        double[] doubleArray43 = new double[] { 10.0f };
        double[] doubleArray45 = new double[] { 10.0f };
        double[][] doubleArray46 = new double[][] { doubleArray43, doubleArray45 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46, false);
        double[] doubleArray50 = array2DRowRealMatrix48.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50, (double) 9.094947E-13f);
        try {
            org.apache.commons.math.linear.RealVector realVector53 = openMapRealVector0.combineToSelf(52.009614495783374d, (-1.0d), doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(entryItor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(entryItor25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6916735960213485E41d + "'", double1 == 6.6916735960213485E41d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (short) 1, 10000.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix2.subtract(openMapRealMatrix17);
        double[] doubleArray26 = new double[] { 10.0f };
        double[] doubleArray28 = new double[] { 10.0f };
        double[][] doubleArray29 = new double[][] { doubleArray26, doubleArray28 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29);
        java.lang.String str37 = array2DRowRealMatrix36.toString();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix38 = openMapRealMatrix17.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str37.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 9.0949465E-13f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 1.5430806348152437d);
        org.apache.commons.math.linear.RealVector realVector11 = openMapRealVector9.mapMultiply((double) 3.8146977E-6f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double17 = openMapRealVector16.getNorm();
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector12.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector16);
        boolean boolean19 = openMapRealVector12.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int21 = openMapRealVector20.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor22 = openMapRealVector20.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int24 = openMapRealVector23.getMinIndex();
        int int25 = openMapRealVector23.getDimension();
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector23.mapDivideToSelf((double) (-1));
        int int28 = openMapRealVector23.getMinIndex();
        double double29 = openMapRealVector20.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector12.projection((org.apache.commons.math.linear.RealVector) openMapRealVector23);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int32 = openMapRealVector31.getMinIndex();
        int int33 = openMapRealVector31.getDimension();
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector31.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = openMapRealVector12.append((org.apache.commons.math.linear.RealVector) openMapRealVector31);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int38 = openMapRealVector37.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor39 = openMapRealVector37.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int41 = openMapRealVector40.getMinIndex();
        int int42 = openMapRealVector40.getDimension();
        org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector40.mapDivideToSelf((double) (-1));
        int int45 = openMapRealVector40.getMinIndex();
        double double46 = openMapRealVector37.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector40);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor47 = openMapRealVector37.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector37.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector12.append(openMapRealVector49);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int52 = openMapRealVector51.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor53 = openMapRealVector51.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int55 = openMapRealVector54.getMinIndex();
        int int56 = openMapRealVector54.getDimension();
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector54.mapDivideToSelf((double) (-1));
        int int59 = openMapRealVector54.getMinIndex();
        double double60 = openMapRealVector51.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor61 = openMapRealVector51.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector63 = openMapRealVector51.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector49.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor65 = openMapRealVector49.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int67 = openMapRealVector66.getMinIndex();
        int int68 = openMapRealVector66.getDimension();
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector66.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = new org.apache.commons.math.linear.OpenMapRealVector(realVector70);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double73 = openMapRealVector71.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = openMapRealVector49.append((org.apache.commons.math.linear.RealVector) openMapRealVector72);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int76 = openMapRealVector75.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector79 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double80 = openMapRealVector79.getNorm();
        org.apache.commons.math.linear.RealVector realVector81 = openMapRealVector75.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector79);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector82 = openMapRealVector49.append(openMapRealVector79);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector83 = openMapRealVector9.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(entryItor22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(openMapRealVector36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(entryItor39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor47);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(entryItor53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor61);
        org.junit.Assert.assertNotNull(openMapRealVector63);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(entryItor65);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector74);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-1) + "'", int76 == (-1));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(realVector81);
        org.junit.Assert.assertNotNull(openMapRealVector82);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        double[][] doubleArray16 = array2DRowRealMatrix10.getData();
        double double17 = array2DRowRealMatrix10.getFrobeniusNorm();
        double[] doubleArray19 = new double[] { 10.0f };
        double[] doubleArray21 = new double[] { 10.0f };
        double[][] doubleArray22 = new double[][] { doubleArray19, doubleArray21 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22, false);
        double[] doubleArray26 = array2DRowRealMatrix24.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26, (double) 9.094947E-13f);
        double[] doubleArray29 = array2DRowRealMatrix10.operate(doubleArray26);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector46 = array2DRowRealMatrix36.getColumnVector((int) (short) 0);
        java.lang.String str47 = array2DRowRealMatrix36.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix3.add(array2DRowRealMatrix48);
        double[] doubleArray51 = new double[] { 10.0f };
        double[] doubleArray53 = new double[] { 10.0f };
        double[][] doubleArray54 = new double[][] { doubleArray51, doubleArray53 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54, true);
        int int59 = array2DRowRealMatrix58.getRowDimension();
        double[] doubleArray61 = new double[] { 10.0f };
        double[] doubleArray63 = new double[] { 10.0f };
        double[][] doubleArray64 = new double[][] { doubleArray61, doubleArray63 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix66 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray64, false);
        double[] doubleArray69 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray69);
        double[] doubleArray71 = array2DRowRealMatrix66.preMultiply(doubleArray69);
        double[] doubleArray72 = array2DRowRealMatrix58.preMultiply(doubleArray69);
        double[] doubleArray73 = array2DRowRealMatrix48.preMultiply(doubleArray69);
        org.apache.commons.math.linear.RealVector realVector74 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector75 = array2DRowRealMatrix48.operate(realVector74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 14.142135623730951d + "'", double17 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str47.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 2 + "'", int59 == 2);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray73);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix16.preMultiply(doubleArray19);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector3.add(doubleArray21);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        boolean boolean3 = iterator2.hasNext();
        boolean boolean4 = iterator2.hasNext();
        boolean boolean5 = iterator2.hasNext();
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, 1.1102230246251565E-16d);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double[][] doubleArray42 = array2DRowRealMatrix36.getData();
        double[] doubleArray45 = new double[] { 10.0f };
        double[] doubleArray47 = new double[] { 10.0f };
        double[][] doubleArray48 = new double[][] { doubleArray45, doubleArray47 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48, false);
        double[] doubleArray53 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        double[] doubleArray55 = array2DRowRealMatrix50.preMultiply(doubleArray53);
        array2DRowRealMatrix36.setRow(0, doubleArray55);
        double double57 = array2DRowRealMatrix36.getFrobeniusNorm();
        double[] doubleArray59 = array2DRowRealMatrix36.getRow((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector29.append(doubleArray59);
        double[] doubleArray63 = array2DRowRealMatrix6.operate(doubleArray59);
        int int64 = array2DRowRealMatrix6.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor65 = null;
        try {
            double double70 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor65, 4, (int) (short) 100, (int) ' ', 97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (4)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 14.142135623730951d + "'", double57 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(1, (int) '#');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int12 = openMapRealMatrix11.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix8.add(openMapRealMatrix11);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int24 = openMapRealMatrix23.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix25 = openMapRealMatrix20.add(openMapRealMatrix23);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = openMapRealMatrix8.add(openMapRealMatrix17);
        boolean boolean28 = openMapRealMatrix17.isSquare();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int31 = openMapRealVector30.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double35 = openMapRealVector34.getNorm();
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector30.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector34);
        boolean boolean37 = openMapRealVector30.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor40 = openMapRealVector38.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int42 = openMapRealVector41.getMinIndex();
        int int43 = openMapRealVector41.getDimension();
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector41.mapDivideToSelf((double) (-1));
        int int46 = openMapRealVector41.getMinIndex();
        double double47 = openMapRealVector38.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector30.projection((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.RealVector realVector50 = openMapRealVector30.mapMultiply((double) 10.0f);
        double double51 = openMapRealVector29.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector30);
        boolean boolean52 = openMapRealMatrix17.equals((java.lang.Object) openMapRealVector30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix55 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix58 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix61 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int62 = openMapRealMatrix61.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix63 = openMapRealMatrix58.add(openMapRealMatrix61);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix64 = openMapRealMatrix55.add(openMapRealMatrix58);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix67 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix70 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix73 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int74 = openMapRealMatrix73.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix70.add(openMapRealMatrix73);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix76 = openMapRealMatrix67.add(openMapRealMatrix70);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix77 = openMapRealMatrix58.add(openMapRealMatrix67);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix78 = openMapRealMatrix77.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix79 = openMapRealMatrix17.subtract(openMapRealMatrix77);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix80 = openMapRealMatrix77.copy();
        boolean boolean81 = array2DRowRealMatrix2.equals((java.lang.Object) openMapRealMatrix77);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 97 + "'", int12 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
        org.junit.Assert.assertNotNull(openMapRealMatrix14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 97 + "'", int24 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix25);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertNotNull(openMapRealMatrix27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(entryItor40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 97 + "'", int62 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix63);
        org.junit.Assert.assertNotNull(openMapRealMatrix64);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 97 + "'", int74 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix75);
        org.junit.Assert.assertNotNull(openMapRealMatrix76);
        org.junit.Assert.assertNotNull(openMapRealMatrix77);
        org.junit.Assert.assertNotNull(openMapRealMatrix78);
        org.junit.Assert.assertNotNull(openMapRealMatrix79);
        org.junit.Assert.assertNotNull(openMapRealMatrix80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.8342233605065102d, (java.lang.Number) 1L, (java.lang.Number) (short) -1);
        java.lang.Throwable[] throwableArray5 = outOfRangeException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 0, 1);
        java.lang.String str3 = dimensionMismatchException2.toString();
        java.lang.Number number4 = dimensionMismatchException2.getArgument();
        java.lang.Number number5 = dimensionMismatchException2.getArgument();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: 0 != 1" + "'", str3.equals("org.apache.commons.math.exception.DimensionMismatchException: 0 != 1"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0 + "'", number5.equals(0));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, 200.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 200.0f + "'", float2 == 200.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((-127), 2.0000000000000004d);
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector2.mapMultiply((double) 7.6293945E-6f);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor5 = openMapRealVector2.sparseIterator();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(entryItor5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double[] doubleArray3 = new double[] { 2.0f, (byte) 1, (byte) 100 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray3);
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector4.mapDivide((-0.8414709848078965d));
        double double7 = openMapRealVector4.getSparsity();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix5.subtract(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix51 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix50);
        double[] doubleArray53 = openMapRealMatrix51.getColumn(1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.append((double) 1L);
        org.apache.commons.math.linear.RealVector realVector5 = openMapRealVector3.mapDivide(0.661011522946662d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int7 = openMapRealVector6.getMinIndex();
        int int8 = openMapRealVector6.getDimension();
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector6.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(realVector10);
        int int12 = openMapRealVector11.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector13.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector11.append(realVector15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor19 = openMapRealVector17.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int21 = openMapRealVector20.getMinIndex();
        boolean boolean23 = openMapRealVector20.equals((java.lang.Object) 0.8342233605065102d);
        double double24 = openMapRealVector17.getL1Distance(openMapRealVector20);
        int int25 = openMapRealVector20.getMaxIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor26 = openMapRealVector20.iterator();
        double double27 = openMapRealVector11.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector3.append(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(entryItor19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(entryItor26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector28);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor40 = openMapRealVector39.sparseIterator();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double47 = openMapRealVector46.getNorm();
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector42.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector46);
        boolean boolean49 = openMapRealVector39.equals((java.lang.Object) openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector39.mapAdd(0.0d);
        double[] doubleArray52 = openMapRealVector51.toArray();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(entryItor40);
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        java.lang.String str51 = openMapRealMatrix50.toString();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix50);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector2.mapAdd(20.0d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor5 = openMapRealVector4.sparseIterator();
        org.junit.Assert.assertNotNull(openMapRealVector4);
        org.junit.Assert.assertNotNull(entryItor5);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.3369844095223624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.035090330572526d + "'", double1 == 2.035090330572526d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.scalarMultiply(0.8813735870195429d);
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double[][] doubleArray20 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { 10.0f };
        double[] doubleArray25 = new double[] { 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26, false);
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix28.preMultiply(doubleArray31);
        array2DRowRealMatrix14.setRow(0, doubleArray33);
        double double35 = array2DRowRealMatrix14.getFrobeniusNorm();
        double[] doubleArray37 = array2DRowRealMatrix14.getRow((int) (short) 0);
        double[] doubleArray38 = array2DRowRealMatrix3.operate(doubleArray37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double44 = openMapRealVector43.getNorm();
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector39.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector43);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int47 = openMapRealVector46.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double51 = openMapRealVector50.getNorm();
        org.apache.commons.math.linear.RealVector realVector52 = openMapRealVector46.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector50);
        double double53 = openMapRealVector43.getL1Distance(openMapRealVector46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor55 = openMapRealVector54.sparseIterator();
        boolean boolean56 = openMapRealVector54.isNaN();
        org.apache.commons.math.linear.RealVector realVector58 = openMapRealVector54.mapMultiplyToSelf(1.4711276743037347d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector54.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = openMapRealVector46.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        try {
            org.apache.commons.math.linear.RealVector realVector61 = array2DRowRealMatrix3.preMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 14.142135623730951d + "'", double35 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(realVector52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(openMapRealVector59);
        org.junit.Assert.assertNotNull(openMapRealVector60);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        double[] doubleArray40 = new double[] { 10.0f };
        double[] doubleArray42 = new double[] { 10.0f };
        double[][] doubleArray43 = new double[][] { doubleArray40, doubleArray42 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43, false);
        double[] doubleArray48 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48);
        double[] doubleArray50 = array2DRowRealMatrix45.preMultiply(doubleArray48);
        try {
            double double51 = openMapRealVector0.cosine(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix14.subtract(openMapRealMatrix27);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double34 = openMapRealMatrix14.walkInRowOrder(realMatrixChangingVisitor29, 97, (-127), 97, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean2 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapMultiplyToSelf(5.885277250018028d);
        double double5 = openMapRealVector0.getMinValue();
        int int6 = openMapRealVector0.getMinIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector7.mapAdd(20.0d);
        boolean boolean10 = openMapRealVector9.isInfinite();
        openMapRealVector3.setSubVector(2, (org.apache.commons.math.linear.RealVector) openMapRealVector9);
        double double12 = openMapRealVector3.getL1Norm();
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 9920.0d + "'", double12 == 9920.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        double[] doubleArray25 = openMapRealVector24.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector((int) 'a', (int) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int32 = openMapRealVector31.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double36 = openMapRealVector35.getNorm();
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector31.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector35);
        boolean boolean38 = openMapRealVector31.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        int int44 = openMapRealVector42.getDimension();
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector42.mapDivideToSelf((double) (-1));
        int int47 = openMapRealVector42.getMinIndex();
        double double48 = openMapRealVector39.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector31.projection((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector42.mapAdd(6.926634720831213E25d);
        openMapRealVector29.setSubVector((int) (byte) 1, (org.apache.commons.math.linear.RealVector) openMapRealVector42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector42.mapAdd(1.7724538509055159d);
        double double55 = openMapRealVector24.dotProduct(openMapRealVector54);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        int int1 = org.apache.commons.math.util.FastMath.abs((-18));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 18 + "'", int1 == 18);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix16.preMultiply(doubleArray19);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector3.add(doubleArray21);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector3.mapDivideToSelf((double) 96.99999f);
        double double25 = openMapRealVector3.getNorm();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.exp(48.21273601220948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.680109574028384E20d + "'", double1 == 8.680109574028384E20d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.multiplyEntry(0, (-17), 0.4097902774810791d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (0)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int33 = openMapRealMatrix32.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = openMapRealMatrix29.add(openMapRealMatrix32);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix26.add(openMapRealMatrix29);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix14.subtract(openMapRealMatrix29);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = openMapRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix14);
        double double40 = openMapRealMatrix14.getEntry(0, (int) (byte) 0);
        int[] intArray43 = new int[] { (short) 10, '#' };
        int[] intArray46 = new int[] { 2, ' ' };
        double[] doubleArray48 = new double[] { 10.0f };
        double[] doubleArray50 = new double[] { 10.0f };
        double[][] doubleArray51 = new double[][] { doubleArray48, doubleArray50 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix55 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray51, false);
        double[][] doubleArray58 = array2DRowRealMatrix57.getData();
        try {
            openMapRealMatrix14.copySubMatrix(intArray43, intArray46, doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix34);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        java.lang.String str12 = array2DRowRealMatrix11.toString();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix11.createMatrix((-127), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -127 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str12.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        int int6 = openMapRealVector5.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor7 = openMapRealVector5.iterator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(entryItor7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        openMapRealMatrix2.multiplyEntry((int) (short) 0, 0, 5.298292365610485d);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix2.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = openMapRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getData();
        double[][] doubleArray7 = array2DRowRealMatrix4.getDataRef();
        java.lang.Class<?> wildcardClass8 = doubleArray7.getClass();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException9 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException9.getContext();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix2.subtract(openMapRealMatrix17);
        java.lang.String str25 = openMapRealMatrix17.toString();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix27 = openMapRealMatrix17.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (97x32) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        int int26 = openMapRealMatrix14.getColumnDimension();
        double double27 = openMapRealMatrix14.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int30 = openMapRealVector29.getMinIndex();
        boolean boolean32 = openMapRealVector29.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int35 = openMapRealVector34.getMinIndex();
        int int36 = openMapRealVector34.getDimension();
        double double37 = openMapRealVector33.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector29.add(openMapRealVector33);
        double[] doubleArray41 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.RealVector realVector43 = openMapRealVector29.add(doubleArray41);
        try {
            openMapRealMatrix14.setRow(32, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x2 but expected 1x32");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector43);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) 'a', (int) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int5 = openMapRealVector4.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double9 = openMapRealVector8.getNorm();
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector4.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector8);
        boolean boolean11 = openMapRealVector4.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor14 = openMapRealVector12.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int16 = openMapRealVector15.getMinIndex();
        int int17 = openMapRealVector15.getDimension();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector15.mapDivideToSelf((double) (-1));
        int int20 = openMapRealVector15.getMinIndex();
        double double21 = openMapRealVector12.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector4.projection((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector15.mapAdd(6.926634720831213E25d);
        openMapRealVector2.setSubVector((int) (byte) 1, (org.apache.commons.math.linear.RealVector) openMapRealVector15);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector15.mapAdd(1.7724538509055159d);
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector15.mapSubtractToSelf((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(entryItor14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector27);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        int int13 = array2DRowRealMatrix6.getRowDimension();
        double[][] doubleArray14 = array2DRowRealMatrix6.getData();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getSparsity();
        org.apache.commons.math.linear.RealVector realVector3 = openMapRealVector0.mapMultiply(Double.NaN);
        org.apache.commons.math.linear.RealVector realVector5 = openMapRealVector0.mapDivideToSelf((double) (-1.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double2 = org.apache.commons.math.util.FastMath.hypot(9.999999999999998d, 229.1831180523293d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 229.40118046816565d + "'", double2 == 229.40118046816565d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray14 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix11.preMultiply(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        double[] doubleArray18 = array2DRowRealMatrix3.preMultiply(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(realVector23);
        int int25 = openMapRealVector24.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector26.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector24.append(realVector28);
        try {
            org.apache.commons.math.linear.RealVector realVector30 = array2DRowRealMatrix3.preMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealVector29);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 9.094947E-13f, 5.326111131569071d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.094947017729282E-13d + "'", double2 == 9.094947017729282E-13d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 4, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector7.mapAdd(20.0d);
        boolean boolean10 = openMapRealVector9.isInfinite();
        openMapRealVector3.setSubVector(2, (org.apache.commons.math.linear.RealVector) openMapRealVector9);
        openMapRealVector9.set(5.267884728309446d);
        openMapRealVector9.set((double) (-1L));
        double double16 = openMapRealVector9.getNorm();
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException0 = new org.apache.commons.math.exception.MathArithmeticException();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathArithmeticException0.getContext();
        java.lang.String str2 = mathArithmeticException0.toString();
        java.lang.Throwable throwable3 = null;
        try {
            mathArithmeticException0.addSuppressed(throwable3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.MathArithmeticException: arithmetic exception" + "'", str2.equals("org.apache.commons.math.exception.MathArithmeticException: arithmetic exception"));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor51 = null;
        try {
            double double52 = openMapRealMatrix30.walkInRowOrder(realMatrixPreservingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 52.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getNorm();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector7.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double double14 = openMapRealVector4.getL1Distance(openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int16 = openMapRealVector15.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double20 = openMapRealVector19.getNorm();
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector15.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector19);
        boolean boolean22 = openMapRealVector15.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int24 = openMapRealVector23.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor25 = openMapRealVector23.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int27 = openMapRealVector26.getMinIndex();
        int int28 = openMapRealVector26.getDimension();
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector26.mapDivideToSelf((double) (-1));
        int int31 = openMapRealVector26.getMinIndex();
        double double32 = openMapRealVector23.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector15.projection((org.apache.commons.math.linear.RealVector) openMapRealVector26);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int35 = openMapRealVector34.getMinIndex();
        int int36 = openMapRealVector34.getDimension();
        org.apache.commons.math.linear.RealVector realVector38 = openMapRealVector34.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector15.append((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int41 = openMapRealVector40.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor42 = openMapRealVector40.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int44 = openMapRealVector43.getMinIndex();
        int int45 = openMapRealVector43.getDimension();
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector43.mapDivideToSelf((double) (-1));
        int int48 = openMapRealVector43.getMinIndex();
        double double49 = openMapRealVector40.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector43);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor50 = openMapRealVector40.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector40.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = openMapRealVector15.append(openMapRealVector52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int55 = openMapRealVector54.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor56 = openMapRealVector54.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector57 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int58 = openMapRealVector57.getMinIndex();
        int int59 = openMapRealVector57.getDimension();
        org.apache.commons.math.linear.RealVector realVector61 = openMapRealVector57.mapDivideToSelf((double) (-1));
        int int62 = openMapRealVector57.getMinIndex();
        double double63 = openMapRealVector54.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector57);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor64 = openMapRealVector54.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = openMapRealVector54.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = openMapRealVector52.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector54);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor68 = openMapRealVector52.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector69 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int70 = openMapRealVector69.getMinIndex();
        int int71 = openMapRealVector69.getDimension();
        org.apache.commons.math.linear.RealVector realVector73 = openMapRealVector69.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector(realVector73);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector75 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double76 = openMapRealVector74.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector77 = openMapRealVector52.append((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = openMapRealVector7.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector75);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(entryItor25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(openMapRealVector39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNotNull(entryItor42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor50);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(openMapRealVector53);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(entryItor56);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor64);
        org.junit.Assert.assertNotNull(openMapRealVector66);
        org.junit.Assert.assertNotNull(openMapRealVector67);
        org.junit.Assert.assertNotNull(entryItor68);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1) + "'", int70 == (-1));
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector77);
        org.junit.Assert.assertNotNull(openMapRealVector78);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int33 = openMapRealMatrix32.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = openMapRealMatrix29.add(openMapRealMatrix32);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix26.add(openMapRealMatrix29);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix14.subtract(openMapRealMatrix29);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = openMapRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix38 = new org.apache.commons.math.linear.OpenMapRealMatrix(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix41 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix44 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int48 = openMapRealMatrix47.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix44.add(openMapRealMatrix47);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix41.add(openMapRealMatrix44);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix53 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix56 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix59 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int60 = openMapRealMatrix59.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix61 = openMapRealMatrix56.add(openMapRealMatrix59);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix62 = openMapRealMatrix53.add(openMapRealMatrix56);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix63 = openMapRealMatrix44.add(openMapRealMatrix53);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix66 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix69 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix72 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int73 = openMapRealMatrix72.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix74 = openMapRealMatrix69.add(openMapRealMatrix72);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix66.add(openMapRealMatrix69);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix78 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix81 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix84 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int85 = openMapRealMatrix84.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix86 = openMapRealMatrix81.add(openMapRealMatrix84);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix87 = openMapRealMatrix78.add(openMapRealMatrix81);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix88 = openMapRealMatrix69.add(openMapRealMatrix78);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix89 = openMapRealMatrix63.add(openMapRealMatrix69);
        java.lang.String str90 = openMapRealMatrix89.toString();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix91 = openMapRealMatrix14.add(openMapRealMatrix89);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix34);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix37);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 97 + "'", int48 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 97 + "'", int60 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix61);
        org.junit.Assert.assertNotNull(openMapRealMatrix62);
        org.junit.Assert.assertNotNull(openMapRealMatrix63);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 97 + "'", int73 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix74);
        org.junit.Assert.assertNotNull(openMapRealMatrix75);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 97 + "'", int85 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix86);
        org.junit.Assert.assertNotNull(openMapRealMatrix87);
        org.junit.Assert.assertNotNull(openMapRealMatrix88);
        org.junit.Assert.assertNotNull(openMapRealMatrix89);
        org.junit.Assert.assertNotNull(openMapRealMatrix91);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, 1.1102230246251565E-16d);
        double[] doubleArray4 = new double[] { 10.0f };
        double[] doubleArray6 = new double[] { 10.0f };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, false);
        double[] doubleArray12 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray14 = array2DRowRealMatrix9.preMultiply(doubleArray12);
        double[][] doubleArray15 = array2DRowRealMatrix9.getData();
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        array2DRowRealMatrix9.setRow(0, doubleArray28);
        double double30 = array2DRowRealMatrix9.getFrobeniusNorm();
        double[] doubleArray32 = array2DRowRealMatrix9.getRow((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector2.append(doubleArray32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray32, (double) 3.8146973E-6f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        int int40 = openMapRealVector38.getDimension();
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector38.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(realVector42);
        double[] doubleArray46 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector43.append(doubleArray46);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector48.copy();
        double double50 = openMapRealVector49.getLInfNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector49);
        double[] doubleArray53 = new double[] { 10.0f };
        double[] doubleArray55 = new double[] { 10.0f };
        double[][] doubleArray56 = new double[][] { doubleArray53, doubleArray55 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56, false);
        double[] doubleArray61 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix62 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray61);
        double[] doubleArray63 = array2DRowRealMatrix58.preMultiply(doubleArray61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector49.ebeDivide(doubleArray61);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = openMapRealVector37.projection(doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 14.142135623730951d + "'", double30 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(openMapRealVector65);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.rint(8.680109574028384E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.680109574028384E20d + "'", double1 == 8.680109574028384E20d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, 1.1102230246251565E-16d);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double[][] doubleArray42 = array2DRowRealMatrix36.getData();
        double[] doubleArray45 = new double[] { 10.0f };
        double[] doubleArray47 = new double[] { 10.0f };
        double[][] doubleArray48 = new double[][] { doubleArray45, doubleArray47 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray48, false);
        double[] doubleArray53 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray53);
        double[] doubleArray55 = array2DRowRealMatrix50.preMultiply(doubleArray53);
        array2DRowRealMatrix36.setRow(0, doubleArray55);
        double double57 = array2DRowRealMatrix36.getFrobeniusNorm();
        double[] doubleArray59 = array2DRowRealMatrix36.getRow((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = openMapRealVector29.append(doubleArray59);
        double[] doubleArray63 = array2DRowRealMatrix6.operate(doubleArray59);
        int int64 = array2DRowRealMatrix6.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector((int) 'a', (int) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int71 = openMapRealVector70.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector74 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double75 = openMapRealVector74.getNorm();
        org.apache.commons.math.linear.RealVector realVector76 = openMapRealVector70.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector74);
        boolean boolean77 = openMapRealVector70.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int79 = openMapRealVector78.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor80 = openMapRealVector78.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int82 = openMapRealVector81.getMinIndex();
        int int83 = openMapRealVector81.getDimension();
        org.apache.commons.math.linear.RealVector realVector85 = openMapRealVector81.mapDivideToSelf((double) (-1));
        int int86 = openMapRealVector81.getMinIndex();
        double double87 = openMapRealVector78.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector81);
        org.apache.commons.math.linear.RealVector realVector88 = openMapRealVector70.projection((org.apache.commons.math.linear.RealVector) openMapRealVector81);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector90 = openMapRealVector81.mapAdd(6.926634720831213E25d);
        openMapRealVector68.setSubVector((int) (byte) 1, (org.apache.commons.math.linear.RealVector) openMapRealVector81);
        try {
            array2DRowRealMatrix6.setColumnVector(0, (org.apache.commons.math.linear.RealVector) openMapRealVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x1 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 14.142135623730951d + "'", double57 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(openMapRealVector62);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1) + "'", int71 == (-1));
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(realVector76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(entryItor80);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + (-1) + "'", int86 == (-1));
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(realVector88);
        org.junit.Assert.assertNotNull(openMapRealVector90);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((-18), (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -18 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(97, Double.NaN);
        int int3 = openMapRealVector2.getMaxIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        int int6 = openMapRealVector5.getDimension();
        boolean boolean7 = openMapRealVector2.equals((java.lang.Object) openMapRealVector5);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 100 + "'", int6 == 100);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        double[] doubleArray25 = openMapRealVector24.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector26.mapSubtract(1.570796326795186d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector28);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, (-17.0d));
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[] doubleArray14 = new double[] { 10.0f };
        double[] doubleArray16 = new double[] { 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        double[] doubleArray22 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray24 = array2DRowRealMatrix19.preMultiply(doubleArray22);
        double[][] doubleArray25 = array2DRowRealMatrix19.getData();
        double[] doubleArray28 = new double[] { 10.0f };
        double[] doubleArray30 = new double[] { 10.0f };
        double[][] doubleArray31 = new double[][] { doubleArray28, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, false);
        double[] doubleArray36 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray38 = array2DRowRealMatrix33.preMultiply(doubleArray36);
        array2DRowRealMatrix19.setRow(0, doubleArray38);
        double double40 = array2DRowRealMatrix19.getFrobeniusNorm();
        double[] doubleArray42 = array2DRowRealMatrix19.getRow((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42, 1.000000000001819d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42, 0.5514266812416906d);
        double[] doubleArray48 = array2DRowRealMatrix6.operate(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 14.142135623730951d + "'", double40 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double2 = org.apache.commons.math.util.FastMath.copySign(Double.NEGATIVE_INFINITY, 8.680109574028384E20d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        int int26 = openMapRealMatrix14.getColumnDimension();
        double double27 = openMapRealMatrix14.getNorm();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = openMapRealMatrix14.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix31 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int38 = openMapRealMatrix37.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = openMapRealMatrix34.add(openMapRealMatrix37);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix40 = openMapRealMatrix31.add(openMapRealMatrix34);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix41 = openMapRealMatrix28.multiply(openMapRealMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 97");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealMatrix28);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 97 + "'", int38 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix39);
        org.junit.Assert.assertNotNull(openMapRealMatrix40);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int5 = openMapRealVector4.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double9 = openMapRealVector8.getNorm();
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector4.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector8);
        boolean boolean11 = openMapRealVector4.isNaN();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector4.mapMultiply((double) (short) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector1.append((org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector1.mapMultiply((double) '#');
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector19.append(57.29577951308232d);
        double[] doubleArray28 = new double[] { 10.0f };
        double[] doubleArray30 = new double[] { 10.0f };
        double[][] doubleArray31 = new double[][] { doubleArray28, doubleArray30 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31, true);
        int int36 = array2DRowRealMatrix35.getRowDimension();
        double[] doubleArray38 = new double[] { 10.0f };
        double[] doubleArray40 = new double[] { 10.0f };
        double[][] doubleArray41 = new double[][] { doubleArray38, doubleArray40 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41, false);
        double[] doubleArray46 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46);
        double[] doubleArray48 = array2DRowRealMatrix43.preMultiply(doubleArray46);
        double[] doubleArray49 = array2DRowRealMatrix35.preMultiply(doubleArray46);
        try {
            double double50 = openMapRealVector26.dotProduct(doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(openMapRealVector26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2 + "'", int36 == 2);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        double[] doubleArray47 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        double double49 = array2DRowRealMatrix48.getNorm();
        int int50 = array2DRowRealMatrix48.getColumnDimension();
        double[] doubleArray52 = new double[] { 10.0f };
        double[] doubleArray54 = new double[] { 10.0f };
        double[][] doubleArray55 = new double[][] { doubleArray52, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double double58 = array2DRowRealMatrix57.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = array2DRowRealMatrix48.add(array2DRowRealMatrix57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = array2DRowRealMatrix23.add(array2DRowRealMatrix48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int62 = openMapRealVector61.getMinIndex();
        int int63 = openMapRealVector61.getDimension();
        org.apache.commons.math.linear.RealVector realVector65 = openMapRealVector61.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector66 = new org.apache.commons.math.linear.OpenMapRealVector(realVector65);
        double[] doubleArray69 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector71 = openMapRealVector66.append(doubleArray69);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector72 = openMapRealVector71.copy();
        try {
            org.apache.commons.math.linear.RealVector realVector73 = array2DRowRealMatrix48.operate((org.apache.commons.math.linear.RealVector) openMapRealVector72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20.0d + "'", double58 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix59);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix60);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(openMapRealVector71);
        org.junit.Assert.assertNotNull(openMapRealVector72);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 2.718281828459045d, 1.4711276743037347d, 0.8813735870195429d, 0.36787944117144233d, 100.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int10 = openMapRealVector9.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double14 = openMapRealVector13.getNorm();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector9.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector13);
        boolean boolean16 = openMapRealVector9.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double22 = openMapRealVector21.getNorm();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector17.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
        boolean boolean24 = openMapRealVector17.isNaN();
        double double25 = openMapRealVector9.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector17);
        double double26 = openMapRealVector17.getLInfNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = openMapRealVector17.mapAddToSelf(0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double30 = openMapRealVector29.getNorm();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector29.mapMultiply(5.298292365610485d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int34 = openMapRealVector33.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector33.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int37 = openMapRealVector36.getMinIndex();
        int int38 = openMapRealVector36.getDimension();
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector36.mapDivideToSelf((double) (-1));
        int int41 = openMapRealVector36.getMinIndex();
        double double42 = openMapRealVector33.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        double double43 = openMapRealVector29.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector45.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int49 = openMapRealVector48.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double53 = openMapRealVector52.getNorm();
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector48.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector52);
        boolean boolean55 = openMapRealVector48.isNaN();
        org.apache.commons.math.linear.RealVector realVector57 = openMapRealVector48.mapMultiply((double) (short) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector45.append((org.apache.commons.math.linear.RealVector) openMapRealVector48);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = openMapRealVector36.append(openMapRealVector58);
        double double60 = openMapRealVector17.getDistance(openMapRealVector58);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector61 = openMapRealVector8.append(openMapRealVector58);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(openMapRealVector59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector61);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.4097902774810791d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.007152189584706006d + "'", double1 == 0.007152189584706006d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        int int6 = openMapRealVector5.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector7.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(realVector9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor13 = openMapRealVector11.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int15 = openMapRealVector14.getMinIndex();
        boolean boolean17 = openMapRealVector14.equals((java.lang.Object) 0.8342233605065102d);
        double double18 = openMapRealVector11.getL1Distance(openMapRealVector14);
        int int19 = openMapRealVector14.getMaxIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor20 = openMapRealVector14.iterator();
        double double21 = openMapRealVector5.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector5);
        int int23 = openMapRealVector5.getMaxIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(entryItor13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(entryItor20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        int int26 = openMapRealMatrix14.getColumnDimension();
        try {
            double[] doubleArray28 = openMapRealMatrix14.getColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        int int44 = openMapRealVector42.getDimension();
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector42.mapDivideToSelf((double) (-1));
        int int47 = openMapRealVector42.getMinIndex();
        double double48 = openMapRealVector39.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor49 = openMapRealVector39.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector39.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector37.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector39.mapAddToSelf(9.094947017729282E-13d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(openMapRealVector54);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix29 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix32 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int33 = openMapRealMatrix32.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = openMapRealMatrix29.add(openMapRealMatrix32);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix26.add(openMapRealMatrix29);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix14.subtract(openMapRealMatrix29);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = openMapRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix14);
        double[] doubleArray39 = new double[] { 10.0f };
        double[] doubleArray41 = new double[] { 10.0f };
        double[][] doubleArray42 = new double[][] { doubleArray39, doubleArray41 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42, false);
        double[] doubleArray47 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix44.preMultiply(doubleArray47);
        double[][] doubleArray50 = array2DRowRealMatrix44.getData();
        double double51 = array2DRowRealMatrix44.getFrobeniusNorm();
        double[] doubleArray53 = new double[] { 10.0f };
        double[] doubleArray55 = new double[] { 10.0f };
        double[][] doubleArray56 = new double[][] { doubleArray53, doubleArray55 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix58 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray56, false);
        double[] doubleArray60 = array2DRowRealMatrix58.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector62 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray60, (double) 9.094947E-13f);
        double[] doubleArray63 = array2DRowRealMatrix44.operate(doubleArray60);
        double[] doubleArray65 = new double[] { 10.0f };
        double[] doubleArray67 = new double[] { 10.0f };
        double[][] doubleArray68 = new double[][] { doubleArray65, doubleArray67 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray68, false);
        double[] doubleArray73 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray73);
        double[] doubleArray75 = array2DRowRealMatrix70.preMultiply(doubleArray73);
        double double76 = array2DRowRealMatrix70.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix78 = array2DRowRealMatrix70.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector80 = array2DRowRealMatrix70.getColumnVector((int) (short) 0);
        java.lang.String str81 = array2DRowRealMatrix70.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix82 = array2DRowRealMatrix44.subtract(array2DRowRealMatrix70);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix83 = openMapRealMatrix37.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix82);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x32 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix34);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertNotNull(openMapRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 14.142135623730951d + "'", double51 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 14.142135623730951d + "'", double76 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix78);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertTrue("'" + str81 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str81.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix82);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int6 = openMapRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix13 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix16 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int17 = openMapRealMatrix16.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix18 = openMapRealMatrix13.add(openMapRealMatrix16);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix10.add(openMapRealMatrix13);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix25 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix28 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int29 = openMapRealMatrix28.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = openMapRealMatrix25.add(openMapRealMatrix28);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix31 = openMapRealMatrix22.add(openMapRealMatrix25);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix34 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix37 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix40 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int41 = openMapRealMatrix40.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = openMapRealMatrix37.add(openMapRealMatrix40);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix43 = openMapRealMatrix34.add(openMapRealMatrix37);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix44 = openMapRealMatrix22.subtract(openMapRealMatrix37);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = openMapRealMatrix19.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix22);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix46 = openMapRealMatrix7.multiply(openMapRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 97");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 97 + "'", int17 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix18);
        org.junit.Assert.assertNotNull(openMapRealMatrix19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 97 + "'", int29 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix30);
        org.junit.Assert.assertNotNull(openMapRealMatrix31);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 97 + "'", int41 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix42);
        org.junit.Assert.assertNotNull(openMapRealMatrix43);
        org.junit.Assert.assertNotNull(openMapRealMatrix44);
        org.junit.Assert.assertNotNull(openMapRealMatrix45);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((-127), 96);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix5.subtract(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix53 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        openMapRealMatrix53.multiplyEntry((int) (short) 0, 0, 5.298292365610485d);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix58 = openMapRealMatrix53.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix59 = openMapRealMatrix50.subtract(openMapRealMatrix58);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix62 = openMapRealMatrix58.createMatrix(1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertNotNull(openMapRealMatrix58);
        org.junit.Assert.assertNotNull(openMapRealMatrix59);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix16.preMultiply(doubleArray19);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector3.add(doubleArray21);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28, 0.0d);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector30.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector30.unitVector();
        openMapRealVector33.unitize();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector3.append(openMapRealVector33);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(openMapRealVector35);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.log1p(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix16.preMultiply(doubleArray19);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector3.add(doubleArray21);
        java.lang.Double[] doubleArray28 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray28, 0.0d);
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector30.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector30.unitVector();
        openMapRealVector33.unitize();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector3.append(openMapRealVector33);
        java.lang.Double[] doubleArray41 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41, 1.5430806348152437d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41, (double) 9.536743E-7f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = openMapRealVector47.copy();
        openMapRealVector48.setEntry(2, (double) '4');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector33.add(openMapRealVector48);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor53 = openMapRealVector48.sparseIterator();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(openMapRealVector48);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(entryItor53);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        double[] doubleArray22 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        double double24 = array2DRowRealMatrix23.getFrobeniusNorm();
        double[][] doubleArray25 = array2DRowRealMatrix23.getData();
        double[][] doubleArray26 = array2DRowRealMatrix23.getDataRef();
        try {
            array2DRowRealMatrix14.copySubMatrix((int) (short) -1, (int) (short) 0, (int) ' ', 6, doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        int int26 = openMapRealMatrix14.getColumnDimension();
        double double27 = openMapRealMatrix14.getNorm();
        double[] doubleArray29 = new double[] { 10.0f };
        double[] doubleArray31 = new double[] { 10.0f };
        double[][] doubleArray32 = new double[][] { doubleArray29, doubleArray31 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32, false);
        double[] doubleArray37 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        double[] doubleArray39 = array2DRowRealMatrix34.preMultiply(doubleArray37);
        double[][] doubleArray40 = array2DRowRealMatrix34.getData();
        double double41 = array2DRowRealMatrix34.getFrobeniusNorm();
        double[] doubleArray43 = new double[] { 10.0f };
        double[] doubleArray45 = new double[] { 10.0f };
        double[][] doubleArray46 = new double[][] { doubleArray43, doubleArray45 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray46, false);
        double[] doubleArray50 = array2DRowRealMatrix48.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray50, (double) 9.094947E-13f);
        double[] doubleArray53 = array2DRowRealMatrix34.operate(doubleArray50);
        double[] doubleArray55 = new double[] { 10.0f };
        double[] doubleArray57 = new double[] { 10.0f };
        double[][] doubleArray58 = new double[][] { doubleArray55, doubleArray57 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray58, false);
        double[] doubleArray63 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix64 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray63);
        double[] doubleArray65 = array2DRowRealMatrix60.preMultiply(doubleArray63);
        double double66 = array2DRowRealMatrix60.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix68 = array2DRowRealMatrix60.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector70 = array2DRowRealMatrix60.getColumnVector((int) (short) 0);
        java.lang.String str71 = array2DRowRealMatrix60.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = array2DRowRealMatrix34.subtract(array2DRowRealMatrix60);
        org.apache.commons.math.linear.RealMatrix realMatrix73 = array2DRowRealMatrix72.copy();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix74 = openMapRealMatrix14.multiply(realMatrix73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 14.142135623730951d + "'", double41 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 14.142135623730951d + "'", double66 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix68);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str71.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix72);
        org.junit.Assert.assertNotNull(realMatrix73);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        int int19 = openMapRealVector11.getMaxIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int28 = openMapRealVector27.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double32 = openMapRealVector31.getNorm();
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector27.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector31);
        boolean boolean34 = openMapRealVector27.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int36 = openMapRealVector35.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor37 = openMapRealVector35.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        int int40 = openMapRealVector38.getDimension();
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector38.mapDivideToSelf((double) (-1));
        int int43 = openMapRealVector38.getMinIndex();
        double double44 = openMapRealVector35.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector27.projection((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector27.mapMultiply((double) 10.0f);
        double double48 = openMapRealVector26.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        boolean boolean49 = openMapRealMatrix14.equals((java.lang.Object) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix55 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix58 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int59 = openMapRealMatrix58.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix60 = openMapRealMatrix55.add(openMapRealMatrix58);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix61 = openMapRealMatrix52.add(openMapRealMatrix55);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix64 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix67 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix70 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int71 = openMapRealMatrix70.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix72 = openMapRealMatrix67.add(openMapRealMatrix70);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix73 = openMapRealMatrix64.add(openMapRealMatrix67);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix74 = openMapRealMatrix55.add(openMapRealMatrix64);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix74.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix76 = openMapRealMatrix14.subtract(openMapRealMatrix74);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor77 = null;
        try {
            double double82 = openMapRealMatrix74.walkInRowOrder(realMatrixChangingVisitor77, 96, (-17), 0, 32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-17)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(entryItor37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 97 + "'", int59 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix60);
        org.junit.Assert.assertNotNull(openMapRealMatrix61);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 97 + "'", int71 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix72);
        org.junit.Assert.assertNotNull(openMapRealMatrix73);
        org.junit.Assert.assertNotNull(openMapRealMatrix74);
        org.junit.Assert.assertNotNull(openMapRealMatrix75);
        org.junit.Assert.assertNotNull(openMapRealMatrix76);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[][] doubleArray5 = array2DRowRealMatrix3.getData();
        double[][] doubleArray6 = array2DRowRealMatrix3.getDataRef();
        int int7 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double[][] doubleArray20 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { 10.0f };
        double[] doubleArray25 = new double[] { 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26, false);
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix28.preMultiply(doubleArray31);
        array2DRowRealMatrix14.setRow(0, doubleArray33);
        double double35 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix3.add(array2DRowRealMatrix14);
        org.apache.commons.math.linear.RealMatrix realMatrix39 = array2DRowRealMatrix3.createMatrix(2, (int) (byte) 1);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor40 = null;
        try {
            double double45 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixPreservingVisitor40, (int) (short) 10, 0, (-17), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 14.142135623730951d + "'", double35 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(realMatrix39);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) (short) 10, (-127));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double6 = openMapRealVector5.getNorm();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector1.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector5);
        boolean boolean8 = openMapRealVector1.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int10 = openMapRealVector9.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor11 = openMapRealVector9.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        int int14 = openMapRealVector12.getDimension();
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector12.mapDivideToSelf((double) (-1));
        int int17 = openMapRealVector12.getMinIndex();
        double double18 = openMapRealVector9.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector1.projection((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector1.mapMultiply((double) 10.0f);
        double double22 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        boolean boolean23 = openMapRealVector1.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(entryItor11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix((int) (byte) 1, 100);
        try {
            double double5 = array2DRowRealMatrix2.getEntry(96, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (96)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        try {
            int int3 = iterator2.key();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.014686439244896978d) + "'", double1 == (-0.014686439244896978d));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2102032422537643d + "'", double1 == 1.2102032422537643d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        long long1 = org.apache.commons.math.util.FastMath.round(97.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.5514266812416906d, 1.9386704022751977d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0155679877997423d + "'", double2 == 2.0155679877997423d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double double19 = array2DRowRealMatrix18.getNorm();
        int int20 = array2DRowRealMatrix18.getColumnDimension();
        double[] doubleArray22 = new double[] { 10.0f };
        double[] doubleArray24 = new double[] { 10.0f };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, false);
        double double28 = array2DRowRealMatrix27.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix18.add(array2DRowRealMatrix27);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix36.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix36);
        try {
            double double51 = array2DRowRealMatrix14.getEntry(4, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (4)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 20.0d + "'", double28 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(0, 0.8414709848078965d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        double double4 = openMapRealVector1.getL1Norm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int7 = openMapRealVector6.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double11 = openMapRealVector10.getNorm();
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector6.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector10);
        boolean boolean13 = openMapRealVector6.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int15 = openMapRealVector14.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor16 = openMapRealVector14.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        int int19 = openMapRealVector17.getDimension();
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector17.mapDivideToSelf((double) (-1));
        int int22 = openMapRealVector17.getMinIndex();
        double double23 = openMapRealVector14.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector6.projection((org.apache.commons.math.linear.RealVector) openMapRealVector17);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector6.mapMultiply((double) 10.0f);
        openMapRealVector1.setSubVector(1, (org.apache.commons.math.linear.RealVector) openMapRealVector6);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction28 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector6.mapToSelf(univariateRealFunction28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10000.0d + "'", double4 == 10000.0d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(entryItor16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.scalarMultiply((-0.6193819415085411d));
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix3.copy();
        double[][] doubleArray7 = array2DRowRealMatrix3.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, true);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor10, (int) 'a', (-18), (int) (byte) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(1, 0.3806180584914589d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix6.getColumnVector(0);
        double[][] doubleArray10 = array2DRowRealMatrix6.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor14 = openMapRealVector12.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int16 = openMapRealVector15.getMinIndex();
        int int17 = openMapRealVector15.getDimension();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector15.mapDivideToSelf((double) (-1));
        int int20 = openMapRealVector15.getMinIndex();
        double double21 = openMapRealVector12.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector15);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor22 = openMapRealVector12.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector12.mapAddToSelf((double) (-127));
        java.lang.Double[] doubleArray30 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray30, 0.0d);
        org.apache.commons.math.linear.RealVector realVector34 = openMapRealVector32.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = openMapRealVector12.append((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray36 = openMapRealVector32.toArray();
        try {
            array2DRowRealMatrix6.setRow(97, doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(entryItor14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor22);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(openMapRealVector35);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.acos(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        double[] doubleArray3 = new double[] { 10.0f };
        double[] doubleArray5 = new double[] { 10.0f };
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException14 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix51 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = openMapRealMatrix24.multiply(openMapRealMatrix51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double1 = org.apache.commons.math.util.FastMath.log10(27.289917197127753d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4360022179386742d + "'", double1 == 1.4360022179386742d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException(localizable1, (-1), 0);
        java.lang.Throwable[] throwableArray5 = dimensionMismatchException4.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray5);
        try {
            java.lang.String str7 = mathIllegalArgumentException6.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        try {
            double[] doubleArray18 = array2DRowRealMatrix6.getColumn(97);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix14.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int28 = openMapRealVector27.getMinIndex();
        int int29 = openMapRealVector27.getDimension();
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector27.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(realVector31);
        int int33 = openMapRealVector32.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector34.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector32.append(realVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor40 = openMapRealVector38.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int42 = openMapRealVector41.getMinIndex();
        boolean boolean44 = openMapRealVector41.equals((java.lang.Object) 0.8342233605065102d);
        double double45 = openMapRealVector38.getL1Distance(openMapRealVector41);
        int int46 = openMapRealVector41.getMaxIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor47 = openMapRealVector41.iterator();
        double double48 = openMapRealVector32.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector32);
        try {
            org.apache.commons.math.linear.RealVector realVector50 = openMapRealMatrix14.operate((org.apache.commons.math.linear.RealVector) openMapRealVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 32");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(entryItor40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNotNull(entryItor47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        int int10 = openMapRealVector8.getDimension();
        org.apache.commons.math.linear.RealVector realVector12 = openMapRealVector8.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector(realVector12);
        int int14 = openMapRealVector13.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector15.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = openMapRealVector13.append(realVector17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor21 = openMapRealVector19.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int23 = openMapRealVector22.getMinIndex();
        boolean boolean25 = openMapRealVector22.equals((java.lang.Object) 0.8342233605065102d);
        double double26 = openMapRealVector19.getL1Distance(openMapRealVector22);
        int int27 = openMapRealVector22.getMaxIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor28 = openMapRealVector22.iterator();
        double double29 = openMapRealVector13.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector13);
        double double31 = openMapRealVector0.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(openMapRealVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(entryItor21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(entryItor28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double double13 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[][] doubleArray14 = array2DRowRealMatrix6.getDataRef();
        org.apache.commons.math.linear.RealVector realVector16 = array2DRowRealMatrix6.getColumnVector(0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 14.142135623730951d + "'", double13 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.2609231332651425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.966152246792274d + "'", double1 == 0.966152246792274d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        double[] doubleArray10 = new double[] { 10.0f };
        double[] doubleArray12 = new double[] { 10.0f };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, false);
        int int16 = array2DRowRealMatrix15.getColumnDimension();
        try {
            array2DRowRealMatrix6.setColumnMatrix(10, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        int int2 = org.apache.commons.math.util.FastMath.min(2, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) 'a', 100.0d);
        int int3 = openIntToDoubleHashMap2.size();
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap4 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap2);
        int int5 = openIntToDoubleHashMap2.size();
        double double7 = openIntToDoubleHashMap2.get(4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getNorm();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector7.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double double14 = openMapRealVector4.getL1Distance(openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor16 = openMapRealVector15.sparseIterator();
        boolean boolean17 = openMapRealVector15.isNaN();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector15.mapMultiplyToSelf(1.4711276743037347d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector15.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector7.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector21.append(0.5403023058681398d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double27 = openMapRealVector26.getSparsity();
        double double28 = openMapRealVector26.getL1Norm();
        double double29 = openMapRealVector26.getL1Norm();
        double[] doubleArray30 = openMapRealVector26.getData();
        try {
            org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector23.combine(6.691673596021348E41d, 1.7320508075688772d, doubleArray30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertEquals((double) double27, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap0 = new org.apache.commons.math.util.OpenIntToDoubleHashMap();
        boolean boolean2 = openIntToDoubleHashMap0.containsKey((-17));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        java.lang.String str51 = openMapRealMatrix50.toString();
        double[] doubleArray54 = new double[] { 10.0f };
        double[] doubleArray56 = new double[] { 10.0f };
        double[][] doubleArray57 = new double[][] { doubleArray54, doubleArray56 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray57, false);
        double[] doubleArray62 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray62);
        double[] doubleArray64 = array2DRowRealMatrix59.preMultiply(doubleArray62);
        double[][] doubleArray65 = array2DRowRealMatrix59.getData();
        double[] doubleArray68 = new double[] { 10.0f };
        double[] doubleArray70 = new double[] { 10.0f };
        double[][] doubleArray71 = new double[][] { doubleArray68, doubleArray70 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray71, false);
        double[] doubleArray76 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray76);
        double[] doubleArray78 = array2DRowRealMatrix73.preMultiply(doubleArray76);
        array2DRowRealMatrix59.setRow(0, doubleArray78);
        try {
            openMapRealMatrix50.setColumn((int) (short) 0, doubleArray78);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 97x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix2.subtract(openMapRealMatrix17);
        int int25 = openMapRealMatrix17.getColumnDimension();
        try {
            openMapRealMatrix17.setEntry((-17), (-1023), (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-17)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 32 + "'", int25 == 32);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix14.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int28 = openMapRealVector27.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double32 = openMapRealVector31.getNorm();
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector27.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector31);
        boolean boolean34 = openMapRealVector27.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int36 = openMapRealVector35.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor37 = openMapRealVector35.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        int int40 = openMapRealVector38.getDimension();
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector38.mapDivideToSelf((double) (-1));
        int int43 = openMapRealVector38.getMinIndex();
        double double44 = openMapRealVector35.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor45 = openMapRealVector35.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = openMapRealVector35.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector48 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int49 = openMapRealVector48.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double53 = openMapRealVector52.getNorm();
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector48.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector52);
        boolean boolean55 = openMapRealVector48.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int57 = openMapRealVector56.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor58 = openMapRealVector56.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector59 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int60 = openMapRealVector59.getMinIndex();
        int int61 = openMapRealVector59.getDimension();
        org.apache.commons.math.linear.RealVector realVector63 = openMapRealVector59.mapDivideToSelf((double) (-1));
        int int64 = openMapRealVector59.getMinIndex();
        double double65 = openMapRealVector56.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        org.apache.commons.math.linear.RealVector realVector66 = openMapRealVector48.projection((org.apache.commons.math.linear.RealVector) openMapRealVector59);
        org.apache.commons.math.linear.RealVector realVector68 = openMapRealVector48.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector70 = openMapRealVector48.mapMultiplyToSelf(97.0d);
        double double71 = openMapRealVector47.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector48);
        double double72 = openMapRealVector27.dotProduct(openMapRealVector48);
        try {
            org.apache.commons.math.linear.RealVector realVector73 = openMapRealMatrix14.preMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 97");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(openMapRealMatrix26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(entryItor37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor45);
        org.junit.Assert.assertNotNull(openMapRealVector47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-1) + "'", int57 == (-1));
        org.junit.Assert.assertNotNull(entryItor58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1) + "'", int64 == (-1));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        int int13 = array2DRowRealMatrix6.getRowDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor15 = null;
        try {
            double double20 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor15, (int) (short) 10, (int) ' ', 4, 18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double double13 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray22 = array2DRowRealMatrix20.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22, (double) 9.094947E-13f);
        double[] doubleArray25 = array2DRowRealMatrix6.operate(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector27.mapSubtractToSelf((double) '#');
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector26.ebeDivide(realVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 14.142135623730951d + "'", double13 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector29);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector(10, 97);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        int int26 = openMapRealMatrix14.getColumnDimension();
        double double27 = openMapRealMatrix14.getNorm();
        double[] doubleArray30 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        double double32 = array2DRowRealMatrix31.getNorm();
        double[] doubleArray34 = new double[] { 10.0f };
        double[] doubleArray36 = new double[] { 10.0f };
        double[][] doubleArray37 = new double[][] { doubleArray34, doubleArray36 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37, false);
        double[] doubleArray42 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        double[] doubleArray44 = array2DRowRealMatrix39.preMultiply(doubleArray42);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray42);
        double[] doubleArray46 = array2DRowRealMatrix31.preMultiply(doubleArray42);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix47 = openMapRealMatrix14.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x32 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) 'a', (int) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector5 = openMapRealVector3.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = openMapRealVector3.mapAddToSelf(0.0d);
        try {
            double double8 = openMapRealVector2.dotProduct(openMapRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(openMapRealVector7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getData();
        double[][] doubleArray7 = array2DRowRealMatrix4.getDataRef();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, false);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[][] doubleArray5 = array2DRowRealMatrix3.getData();
        double[][] doubleArray6 = array2DRowRealMatrix3.getDataRef();
        int int7 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double[][] doubleArray20 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { 10.0f };
        double[] doubleArray25 = new double[] { 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26, false);
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix28.preMultiply(doubleArray31);
        array2DRowRealMatrix14.setRow(0, doubleArray33);
        double double35 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix3.add(array2DRowRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int43 = openMapRealMatrix42.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix44 = openMapRealMatrix39.add(openMapRealMatrix42);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix45 = array2DRowRealMatrix3.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 97x32");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 14.142135623730951d + "'", double35 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 97 + "'", int43 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix44);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, (-17), 1.2089258196146292E24d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(4, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        double[] doubleArray24 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix21.preMultiply(doubleArray24);
        double double27 = array2DRowRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix21.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix21.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int34 = openMapRealVector33.getMinIndex();
        int int35 = openMapRealVector33.getDimension();
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector33.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(realVector37);
        boolean boolean39 = array2DRowRealMatrix32.equals((java.lang.Object) openMapRealVector38);
        double[] doubleArray42 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix43 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42);
        double double44 = array2DRowRealMatrix43.getNorm();
        int int45 = array2DRowRealMatrix43.getColumnDimension();
        double[] doubleArray47 = new double[] { 10.0f };
        double[] doubleArray49 = new double[] { 10.0f };
        double[][] doubleArray50 = new double[][] { doubleArray47, doubleArray49 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix52 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray50, false);
        double double53 = array2DRowRealMatrix52.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = array2DRowRealMatrix43.add(array2DRowRealMatrix52);
        double[] doubleArray56 = new double[] { 10.0f };
        double[] doubleArray58 = new double[] { 10.0f };
        double[][] doubleArray59 = new double[][] { doubleArray56, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        double[] doubleArray64 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray64);
        double[] doubleArray66 = array2DRowRealMatrix61.preMultiply(doubleArray64);
        double double67 = array2DRowRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix69 = array2DRowRealMatrix61.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix71 = array2DRowRealMatrix61.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix72 = array2DRowRealMatrix54.subtract(array2DRowRealMatrix61);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector73 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int74 = openMapRealVector73.getMinIndex();
        int int75 = openMapRealVector73.getDimension();
        org.apache.commons.math.linear.RealVector realVector77 = openMapRealVector73.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector78 = new org.apache.commons.math.linear.OpenMapRealVector(realVector77);
        boolean boolean79 = array2DRowRealMatrix72.equals((java.lang.Object) openMapRealVector78);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix80 = array2DRowRealMatrix32.add(array2DRowRealMatrix72);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor81 = null;
        try {
            double double86 = array2DRowRealMatrix72.walkInColumnOrder(realMatrixChangingVisitor81, 100, (int) (short) 1, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 20.0d + "'", double53 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 14.142135623730951d + "'", double67 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1) + "'", int74 == (-1));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix80);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-1), (double) 1L);
        int int3 = openIntToDoubleHashMap2.size();
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap2.iterator();
        try {
            double double6 = openIntToDoubleHashMap2.get((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01538287103360378d + "'", double1 == 0.01538287103360378d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.5689240493544077d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5689240493544075d) + "'", double1 == (-0.5689240493544075d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int3 = openMapRealVector2.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double7 = openMapRealVector6.getNorm();
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector2.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector6);
        boolean boolean9 = openMapRealVector2.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor12 = openMapRealVector10.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        int int15 = openMapRealVector13.getDimension();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapDivideToSelf((double) (-1));
        int int18 = openMapRealVector13.getMinIndex();
        double double19 = openMapRealVector10.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector2.projection((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int22 = openMapRealVector21.getMinIndex();
        int int23 = openMapRealVector21.getDimension();
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector21.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector2.append((org.apache.commons.math.linear.RealVector) openMapRealVector21);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector1.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 10 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(entryItor12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(openMapRealVector26);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.getColumnMatrix(0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((int) 'a', 100.0d);
        int int3 = openIntToDoubleHashMap2.size();
        double double6 = openIntToDoubleHashMap2.put(6, 0.9991040211506196d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 1.5430806348152437d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1023));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector7.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector7.unitVector();
        openMapRealVector10.unitize();
        double double12 = openMapRealVector10.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        int int15 = openMapRealVector13.getDimension();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(realVector17);
        int int19 = openMapRealVector18.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector20.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector18.append(realVector22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int25 = openMapRealVector24.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor26 = openMapRealVector24.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int28 = openMapRealVector27.getMinIndex();
        boolean boolean30 = openMapRealVector27.equals((java.lang.Object) 0.8342233605065102d);
        double double31 = openMapRealVector24.getL1Distance(openMapRealVector27);
        int int32 = openMapRealVector27.getMaxIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor33 = openMapRealVector27.iterator();
        double double34 = openMapRealVector18.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector(openMapRealVector18);
        try {
            double double36 = openMapRealVector10.dotProduct((org.apache.commons.math.linear.RealVector) openMapRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(openMapRealVector23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(entryItor26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(entryItor33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        try {
            openMapRealMatrix14.addToEntry((int) '#', (int) (short) 100, (double) 52L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-1), (double) 1L);
        int int3 = openIntToDoubleHashMap2.size();
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap2.iterator();
        try {
            double double6 = openIntToDoubleHashMap2.remove((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1023), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray25 = array2DRowRealMatrix23.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix27 = array2DRowRealMatrix23.scalarAdd(1.3369844095223624d);
        double[][] doubleArray28 = array2DRowRealMatrix23.getDataRef();
        try {
            array2DRowRealMatrix14.setSubMatrix(doubleArray28, 4, 6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (4)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector7.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector7.unitVector();
        openMapRealVector10.unitize();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double18 = openMapRealVector17.getNorm();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector13.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector17);
        boolean boolean20 = openMapRealVector13.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int22 = openMapRealVector21.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor23 = openMapRealVector21.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int25 = openMapRealVector24.getMinIndex();
        int int26 = openMapRealVector24.getDimension();
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector24.mapDivideToSelf((double) (-1));
        int int29 = openMapRealVector24.getMinIndex();
        double double30 = openMapRealVector21.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector13.projection((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int33 = openMapRealVector32.getMinIndex();
        int int34 = openMapRealVector32.getDimension();
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector32.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector13.append((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        double[] doubleArray38 = openMapRealVector37.getData();
        try {
            openMapRealVector10.setSubVector((-1), doubleArray38);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(entryItor23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.0155679877997423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        boolean boolean3 = openIntToDoubleHashMap1.containsKey((int) 'a');
        double double5 = openIntToDoubleHashMap1.remove((int) (byte) 0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap6 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(openIntToDoubleHashMap1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getSparsity();
        org.apache.commons.math.linear.RealVector realVector3 = openMapRealVector0.mapMultiply(Double.NaN);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor4 = openMapRealVector0.sparseIterator();
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(entryItor4);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix10.walkInColumnOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 1, 127.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double2 = org.apache.commons.math.util.FastMath.hypot(14.949794313422199d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.983202261653906d + "'", double2 == 14.983202261653906d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.851651944097903E8d, (java.lang.Number) 100.00001f, (java.lang.Number) 100.00001f);
        java.lang.Number number4 = outOfRangeException3.getHi();
        java.lang.Number number5 = outOfRangeException3.getLo();
        java.lang.Number number6 = outOfRangeException3.getLo();
        java.lang.Number number7 = outOfRangeException3.getHi();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 10L, (java.lang.Number) (-1));
        java.lang.Number number12 = outOfRangeException11.getLo();
        java.lang.String str13 = outOfRangeException11.toString();
        java.lang.Number number14 = outOfRangeException11.getArgument();
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException11);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.00001f + "'", number4.equals(100.00001f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.00001f + "'", number5.equals(100.00001f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100.00001f + "'", number6.equals(100.00001f));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.00001f + "'", number7.equals(100.00001f));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10L + "'", number12.equals(10L));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: -1 out of [10, -1] range" + "'", str13.equals("org.apache.commons.math.exception.OutOfRangeException: -1 out of [10, -1] range"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + (-1.0d) + "'", number14.equals((-1.0d)));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray14 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix11.preMultiply(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        double[] doubleArray18 = array2DRowRealMatrix3.preMultiply(doubleArray14);
        double[] doubleArray21 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        double double23 = array2DRowRealMatrix22.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix3.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix22);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix55 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix58 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int59 = openMapRealMatrix58.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix60 = openMapRealMatrix55.add(openMapRealMatrix58);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix61 = openMapRealMatrix52.add(openMapRealMatrix55);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix64 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix67 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix70 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int71 = openMapRealMatrix70.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix72 = openMapRealMatrix67.add(openMapRealMatrix70);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix73 = openMapRealMatrix64.add(openMapRealMatrix67);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix74 = openMapRealMatrix55.add(openMapRealMatrix64);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix30.subtract(openMapRealMatrix64);
        int int76 = openMapRealMatrix64.getRowDimension();
        double double79 = openMapRealMatrix64.getEntry(35, 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix80 = array2DRowRealMatrix22.add((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 97x32");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(realMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 97 + "'", int59 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix60);
        org.junit.Assert.assertNotNull(openMapRealMatrix61);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 97 + "'", int71 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix72);
        org.junit.Assert.assertNotNull(openMapRealMatrix73);
        org.junit.Assert.assertNotNull(openMapRealMatrix74);
        org.junit.Assert.assertNotNull(openMapRealMatrix75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 97 + "'", int76 == 97);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean3 = openMapRealVector0.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        int int7 = openMapRealVector5.getDimension();
        double double8 = openMapRealVector4.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector0.add(openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) -1, 1.3369844095223624d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector12.mapAddToSelf(9.5367431640625E-7d);
        int int15 = openMapRealVector12.getMinIndex();
        boolean boolean16 = openMapRealVector9.equals((java.lang.Object) int15);
        double double17 = openMapRealVector9.getMinValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 52.009614495783374d, (java.lang.Number) 9.999999999999998d, (java.lang.Number) (-0.5544804492206369d));
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 9.999999999999998d + "'", number4.equals(9.999999999999998d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double13 = openMapRealVector12.getNorm();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector8.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector12);
        boolean boolean15 = openMapRealVector8.isNaN();
        double double16 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double22 = openMapRealVector21.getNorm();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector17.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
        boolean boolean24 = openMapRealVector17.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector17.projection((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int37 = openMapRealVector36.getMinIndex();
        int int38 = openMapRealVector36.getDimension();
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector36.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector17.append((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor44 = openMapRealVector42.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int46 = openMapRealVector45.getMinIndex();
        int int47 = openMapRealVector45.getDimension();
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector45.mapDivideToSelf((double) (-1));
        int int50 = openMapRealVector45.getMinIndex();
        double double51 = openMapRealVector42.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor52 = openMapRealVector42.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector42.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector17.append(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector8.append(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector54.mapAdd((double) 2);
        org.apache.commons.math.linear.RealVector realVector60 = openMapRealVector54.mapSubtract((double) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(entryItor44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor52);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
        org.junit.Assert.assertNotNull(openMapRealVector58);
        org.junit.Assert.assertNotNull(realVector60);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { 10.0f };
        double[] doubleArray4 = new double[] { 10.0f };
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray4 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, false);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray5);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 3.141592653589793d, (java.lang.Number) 14.949794313422199d, (java.lang.Number) Double.NaN);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector4.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = openMapRealVector4.mapAddToSelf(0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector1.append((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double[] doubleArray13 = new double[] { 10.0f };
        double[] doubleArray15 = new double[] { 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray13, doubleArray15 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, false);
        double[] doubleArray21 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray23 = array2DRowRealMatrix18.preMultiply(doubleArray21);
        double[][] doubleArray24 = array2DRowRealMatrix18.getData();
        double[] doubleArray27 = new double[] { 10.0f };
        double[] doubleArray29 = new double[] { 10.0f };
        double[][] doubleArray30 = new double[][] { doubleArray27, doubleArray29 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30, false);
        double[] doubleArray35 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        double[] doubleArray37 = array2DRowRealMatrix32.preMultiply(doubleArray35);
        array2DRowRealMatrix18.setRow(0, doubleArray37);
        double double39 = array2DRowRealMatrix18.getFrobeniusNorm();
        double[] doubleArray41 = array2DRowRealMatrix18.getRow((int) (short) 0);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray41);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41, 1.000000000001819d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray41, 0.5514266812416906d);
        try {
            org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector8.combineToSelf((double) 2.0f, 0.9991040211506196d, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(openMapRealVector8);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 14.142135623730951d + "'", double39 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double double13 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[][] doubleArray14 = array2DRowRealMatrix6.getDataRef();
        int int15 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector17 = null;
        try {
            array2DRowRealMatrix6.setColumnVector((int) ' ', realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 14.142135623730951d + "'", double13 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector7.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector7.unitVector();
        openMapRealVector10.unitize();
        double double12 = openMapRealVector10.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double18 = openMapRealVector17.getNorm();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector13.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector17);
        boolean boolean20 = openMapRealVector13.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int22 = openMapRealVector21.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor23 = openMapRealVector21.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int25 = openMapRealVector24.getMinIndex();
        int int26 = openMapRealVector24.getDimension();
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector24.mapDivideToSelf((double) (-1));
        int int29 = openMapRealVector24.getMinIndex();
        double double30 = openMapRealVector21.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector13.projection((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int33 = openMapRealVector32.getMinIndex();
        int int34 = openMapRealVector32.getDimension();
        org.apache.commons.math.linear.RealVector realVector36 = openMapRealVector32.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector13.append((org.apache.commons.math.linear.RealVector) openMapRealVector32);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor40 = openMapRealVector38.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int42 = openMapRealVector41.getMinIndex();
        int int43 = openMapRealVector41.getDimension();
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector41.mapDivideToSelf((double) (-1));
        int int46 = openMapRealVector41.getMinIndex();
        double double47 = openMapRealVector38.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor48 = openMapRealVector38.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector38.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector13.append(openMapRealVector50);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int53 = openMapRealVector52.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor54 = openMapRealVector52.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int56 = openMapRealVector55.getMinIndex();
        int int57 = openMapRealVector55.getDimension();
        org.apache.commons.math.linear.RealVector realVector59 = openMapRealVector55.mapDivideToSelf((double) (-1));
        int int60 = openMapRealVector55.getMinIndex();
        double double61 = openMapRealVector52.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector55);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor62 = openMapRealVector52.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector64 = openMapRealVector52.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector65 = openMapRealVector50.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector52);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector67 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector68 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector67);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector70 = openMapRealVector68.mapAdd(20.0d);
        double[] doubleArray72 = new double[] { 10.0f };
        double[] doubleArray74 = new double[] { 10.0f };
        double[][] doubleArray75 = new double[][] { doubleArray72, doubleArray74 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix77 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray75, false);
        double[] doubleArray79 = array2DRowRealMatrix77.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector81 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray79, (double) 9.094947E-13f);
        double double82 = openMapRealVector68.getL1Distance(doubleArray79);
        org.apache.commons.math.linear.RealVector realVector83 = openMapRealVector52.add(doubleArray79);
        try {
            double double84 = openMapRealVector10.getDistance(doubleArray79);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(entryItor23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(entryItor40);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor48);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(entryItor54);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor62);
        org.junit.Assert.assertNotNull(openMapRealVector64);
        org.junit.Assert.assertNotNull(openMapRealVector65);
        org.junit.Assert.assertNotNull(openMapRealVector70);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 10.0d + "'", double82 == 10.0d);
        org.junit.Assert.assertNotNull(realVector83);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.scalarAdd(1.3369844095223624d);
        double[][] doubleArray11 = array2DRowRealMatrix6.getDataRef();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor12 = null;
        try {
            double double13 = array2DRowRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15);
        double double17 = array2DRowRealMatrix16.getNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix18 = array2DRowRealMatrix6.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(realMatrix18);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        double double7 = openMapRealVector0.getL1Norm();
        double double8 = openMapRealVector0.getNorm();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[][] doubleArray5 = array2DRowRealMatrix3.getData();
        double[][] doubleArray6 = array2DRowRealMatrix3.getDataRef();
        int int7 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double[][] doubleArray20 = array2DRowRealMatrix14.getData();
        double[] doubleArray23 = new double[] { 10.0f };
        double[] doubleArray25 = new double[] { 10.0f };
        double[][] doubleArray26 = new double[][] { doubleArray23, doubleArray25 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26, false);
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        double[] doubleArray33 = array2DRowRealMatrix28.preMultiply(doubleArray31);
        array2DRowRealMatrix14.setRow(0, doubleArray33);
        double double35 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = array2DRowRealMatrix3.add(array2DRowRealMatrix14);
        double[][] doubleArray37 = array2DRowRealMatrix3.getData();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray37);
        java.lang.Double[] doubleArray45 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector47 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray45, 0.0d);
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector47.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector50 = openMapRealVector47.unitVector();
        openMapRealVector50.unitize();
        double double52 = openMapRealVector50.getL1Norm();
        boolean boolean53 = array2DRowRealMatrix39.equals((java.lang.Object) double52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 14.142135623730951d + "'", double35 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix36);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertNotNull(openMapRealVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0d + "'", double52 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9999940395531084d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999940395531084d + "'", double1 == 0.9999940395531084d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix2.subtract(openMapRealMatrix17);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealMatrix24.getRowVector((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1.9073486E-6f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.543080634815244d, (java.lang.Number) 1.4E-45f, (java.lang.Number) 0.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix53 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix56 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix59 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int60 = openMapRealMatrix59.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix61 = openMapRealMatrix56.add(openMapRealMatrix59);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix62 = openMapRealMatrix53.add(openMapRealMatrix56);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix65 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix68 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix71 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int72 = openMapRealMatrix71.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix73 = openMapRealMatrix68.add(openMapRealMatrix71);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix74 = openMapRealMatrix65.add(openMapRealMatrix68);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix77 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix80 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix83 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int84 = openMapRealMatrix83.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix85 = openMapRealMatrix80.add(openMapRealMatrix83);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix86 = openMapRealMatrix77.add(openMapRealMatrix80);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix87 = openMapRealMatrix65.subtract(openMapRealMatrix80);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix88 = openMapRealMatrix62.subtract((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix65);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix89 = openMapRealMatrix30.multiply((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 97");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 97 + "'", int60 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix61);
        org.junit.Assert.assertNotNull(openMapRealMatrix62);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 97 + "'", int72 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix73);
        org.junit.Assert.assertNotNull(openMapRealMatrix74);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 97 + "'", int84 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix85);
        org.junit.Assert.assertNotNull(openMapRealMatrix86);
        org.junit.Assert.assertNotNull(openMapRealMatrix87);
        org.junit.Assert.assertNotNull(openMapRealMatrix88);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 0, 1);
        java.lang.String str3 = dimensionMismatchException2.toString();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = dimensionMismatchException2.getContext();
        java.lang.Throwable[] throwableArray5 = dimensionMismatchException2.getSuppressed();
        java.lang.Number number6 = dimensionMismatchException2.getArgument();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (-1.0d), (java.lang.Number) 10L, (java.lang.Number) (-1));
        dimensionMismatchException2.addSuppressed((java.lang.Throwable) outOfRangeException10);
        int int12 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.DimensionMismatchException: 0 != 1" + "'", str3.equals("org.apache.commons.math.exception.DimensionMismatchException: 0 != 1"));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        int int15 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean3 = openMapRealVector0.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        int int7 = openMapRealVector5.getDimension();
        double double8 = openMapRealVector4.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector0.add(openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor12 = openMapRealVector10.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        int int15 = openMapRealVector13.getDimension();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapDivideToSelf((double) (-1));
        int int18 = openMapRealVector13.getMinIndex();
        double double19 = openMapRealVector10.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor20 = openMapRealVector10.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector10.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        int int27 = openMapRealVector25.getDimension();
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector25.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector22.combineToSelf((double) (byte) 1, (double) (byte) 10, realVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector0.ebeMultiply(realVector30);
        double double32 = openMapRealVector31.getMaxValue();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector31.copy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(entryItor12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertNotNull(openMapRealVector33);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        double[] doubleArray25 = openMapRealVector24.getData();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int28 = openMapRealVector27.getMinIndex();
        int int29 = openMapRealVector27.getDimension();
        org.apache.commons.math.linear.RealVector realVector31 = openMapRealVector27.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector(realVector31);
        double[] doubleArray35 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector32.append(doubleArray35);
        try {
            double double38 = openMapRealVector24.getL1Distance(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        double[][] doubleArray16 = array2DRowRealMatrix10.getData();
        double double17 = array2DRowRealMatrix10.getFrobeniusNorm();
        double[] doubleArray19 = new double[] { 10.0f };
        double[] doubleArray21 = new double[] { 10.0f };
        double[][] doubleArray22 = new double[][] { doubleArray19, doubleArray21 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22, false);
        double[] doubleArray26 = array2DRowRealMatrix24.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray26, (double) 9.094947E-13f);
        double[] doubleArray29 = array2DRowRealMatrix10.operate(doubleArray26);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector46 = array2DRowRealMatrix36.getColumnVector((int) (short) 0);
        java.lang.String str47 = array2DRowRealMatrix36.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix10.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = array2DRowRealMatrix3.add(array2DRowRealMatrix48);
        double[] doubleArray51 = new double[] { 10.0f };
        double[] doubleArray53 = new double[] { 10.0f };
        double[][] doubleArray54 = new double[][] { doubleArray51, doubleArray53 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray54, false);
        double[] doubleArray59 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59);
        double[] doubleArray61 = array2DRowRealMatrix56.preMultiply(doubleArray59);
        double[] doubleArray62 = array2DRowRealMatrix48.preMultiply(doubleArray59);
        int int63 = array2DRowRealMatrix48.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 14.142135623730951d + "'", double17 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str47.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1);
        boolean boolean2 = openMapRealVector1.isNaN();
        double double3 = openMapRealVector1.getMaxValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor45 = null;
        try {
            double double46 = array2DRowRealMatrix23.walkInRowOrder(realMatrixChangingVisitor45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        double[] doubleArray27 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray30 = new double[] { 10.0f };
        double[] doubleArray32 = new double[] { 10.0f };
        double[][] doubleArray33 = new double[][] { doubleArray30, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33, false);
        double[] doubleArray38 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray40 = array2DRowRealMatrix35.preMultiply(doubleArray38);
        double[][] doubleArray41 = array2DRowRealMatrix35.getData();
        double double42 = array2DRowRealMatrix35.getFrobeniusNorm();
        double[] doubleArray44 = new double[] { 10.0f };
        double[] doubleArray46 = new double[] { 10.0f };
        double[][] doubleArray47 = new double[][] { doubleArray44, doubleArray46 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47, false);
        double[] doubleArray51 = array2DRowRealMatrix49.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector53 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray51, (double) 9.094947E-13f);
        double[] doubleArray54 = array2DRowRealMatrix35.operate(doubleArray51);
        double[] doubleArray56 = new double[] { 10.0f };
        double[] doubleArray58 = new double[] { 10.0f };
        double[][] doubleArray59 = new double[][] { doubleArray56, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        double[] doubleArray64 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix65 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray64);
        double[] doubleArray66 = array2DRowRealMatrix61.preMultiply(doubleArray64);
        double double67 = array2DRowRealMatrix61.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix69 = array2DRowRealMatrix61.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector71 = array2DRowRealMatrix61.getColumnVector((int) (short) 0);
        java.lang.String str72 = array2DRowRealMatrix61.toString();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix73 = array2DRowRealMatrix35.subtract(array2DRowRealMatrix61);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix74 = array2DRowRealMatrix28.add(array2DRowRealMatrix73);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix5.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x32 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 14.142135623730951d + "'", double67 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix69);
        org.junit.Assert.assertNotNull(realVector71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str72.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
        org.junit.Assert.assertNotNull(array2DRowRealMatrix73);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix74);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int28 = openMapRealVector27.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double32 = openMapRealVector31.getNorm();
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector27.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector31);
        boolean boolean34 = openMapRealVector27.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector35 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int36 = openMapRealVector35.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor37 = openMapRealVector35.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int39 = openMapRealVector38.getMinIndex();
        int int40 = openMapRealVector38.getDimension();
        org.apache.commons.math.linear.RealVector realVector42 = openMapRealVector38.mapDivideToSelf((double) (-1));
        int int43 = openMapRealVector38.getMinIndex();
        double double44 = openMapRealVector35.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector45 = openMapRealVector27.projection((org.apache.commons.math.linear.RealVector) openMapRealVector38);
        org.apache.commons.math.linear.RealVector realVector47 = openMapRealVector27.mapMultiply((double) 10.0f);
        double double48 = openMapRealVector26.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector27);
        boolean boolean49 = openMapRealMatrix14.equals((java.lang.Object) openMapRealVector27);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix52 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix55 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix58 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int59 = openMapRealMatrix58.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix60 = openMapRealMatrix55.add(openMapRealMatrix58);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix61 = openMapRealMatrix52.add(openMapRealMatrix55);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix64 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix67 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix70 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int71 = openMapRealMatrix70.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix72 = openMapRealMatrix67.add(openMapRealMatrix70);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix73 = openMapRealMatrix64.add(openMapRealMatrix67);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix74 = openMapRealMatrix55.add(openMapRealMatrix64);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = openMapRealMatrix74.copy();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix76 = openMapRealMatrix14.subtract(openMapRealMatrix74);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix77 = openMapRealMatrix14.copy();
        int int78 = openMapRealMatrix14.getColumnDimension();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(entryItor37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertNotNull(realVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 97 + "'", int59 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix60);
        org.junit.Assert.assertNotNull(openMapRealMatrix61);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 97 + "'", int71 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix72);
        org.junit.Assert.assertNotNull(openMapRealMatrix73);
        org.junit.Assert.assertNotNull(openMapRealMatrix74);
        org.junit.Assert.assertNotNull(openMapRealMatrix75);
        org.junit.Assert.assertNotNull(openMapRealMatrix76);
        org.junit.Assert.assertNotNull(openMapRealMatrix77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 32 + "'", int78 == 32);
    }
}

