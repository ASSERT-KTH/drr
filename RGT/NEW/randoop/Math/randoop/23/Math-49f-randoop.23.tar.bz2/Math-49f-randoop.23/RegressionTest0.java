import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-127) + "'", int1 == (-127));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (short) -1, (double) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065102d + "'", double1 == 0.8342233605065102d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 10.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix3.walkInRowOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7724538509055159d + "'", double1 == 1.7724538509055159d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(0.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixChangingVisitor4, (int) 'a', (int) (byte) 100, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray0, doubleArray1, doubleArray2, doubleArray3 };
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.power((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix6.walkInRowOrder(realMatrixChangingVisitor7, 1, (int) (byte) -1, (-127), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray6 = new double[] { 0.36787944117144233d, 100.0f, 1, 100.0f };
        try {
            array2DRowRealMatrix0.setRow((-1), doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray10 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        try {
            array2DRowRealMatrix6.setRowMatrix(10, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.getColumnMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.createMatrix(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        int[] intArray7 = null;
        int[] intArray13 = new int[] { (short) -1, '4', (short) 100, 100, (short) 10 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.getSubMatrix(intArray7, intArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(intArray13);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray4 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            array2DRowRealMatrix0.setColumnMatrix(1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            array2DRowRealMatrix6.addToEntry((int) (byte) 0, 10, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector();
        try {
            double double3 = openMapRealVector0.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.power(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f };
        double[] doubleArray19 = new double[] { 10.0f };
        double[][] doubleArray20 = new double[][] { doubleArray17, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        try {
            array2DRowRealMatrix6.copySubMatrix((int) 'a', (int) ' ', (int) (short) 0, (int) (short) 10, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = array2DRowRealMatrix6.walkInRowOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = openMapRealVector1.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray14 = new double[] { 100.0d, 100, 1L, (short) 10, (byte) 10, 1 };
        try {
            array2DRowRealMatrix6.setRow(1, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 1x6 but expected 1x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        try {
            array2DRowRealMatrix3.addToEntry((int) (short) -1, (-127), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        try {
            double double12 = array2DRowRealMatrix6.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.00001f + "'", float1 == 100.00001f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor4, 0, (int) (byte) 10, (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInRowOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor7, (int) (short) 10, (int) (byte) 1, (int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double[] doubleArray2 = new double[] { 10.0f };
        double[] doubleArray4 = new double[] { 10.0f };
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray4 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, false);
        double[] doubleArray10 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix7.preMultiply(doubleArray10);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector0.projection(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        try {
            array2DRowRealMatrix8.setEntry((int) (short) 10, (int) (short) -1, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3369844095223624d + "'", double1 == 1.3369844095223624d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.536743E-7f + "'", float1 == 9.536743E-7f);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor9, (int) '4', (int) (byte) 10, (int) '#', (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) (short) -1, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixPreservingVisitor4, (int) (short) -1, 100, (int) (short) -1, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        double[] doubleArray9 = new double[] {};
        try {
            double[] doubleArray10 = array2DRowRealMatrix8.preMultiply(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        double[] doubleArray11 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11);
        try {
            array2DRowRealMatrix6.setRowMatrix((int) ' ', (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double8 = openMapRealVector7.getNorm();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector3.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector7);
        try {
            openMapRealVector0.setSubVector((int) ' ', (org.apache.commons.math.linear.RealVector) openMapRealVector3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        double[] doubleArray9 = new double[] {};
        try {
            array2DRowRealMatrix6.setColumn((-1), doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = new double[] { 10.0f };
        double[] doubleArray10 = new double[] { 10.0f };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11, false);
        double[] doubleArray16 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray18 = array2DRowRealMatrix13.preMultiply(doubleArray16);
        try {
            double[] doubleArray19 = array2DRowRealMatrix6.preMultiply(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        float float2 = org.apache.commons.math.util.FastMath.min((float) '#', (float) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double8 = openMapRealVector7.getNorm();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector3.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector7);
        try {
            openMapRealVector0.setSubVector((int) ' ', (org.apache.commons.math.linear.RealVector) openMapRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-1), (double) 1L);
        try {
            boolean boolean4 = openIntToDoubleHashMap2.containsKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor12 = null;
        try {
            double double17 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor12, (int) (short) -1, (int) (byte) 0, (int) (short) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        int int14 = openMapRealVector12.getDimension();
        try {
            org.apache.commons.math.linear.RealVector realVector15 = array2DRowRealMatrix6.operate((org.apache.commons.math.linear.RealVector) openMapRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            double double9 = array2DRowRealMatrix6.getEntry((int) '4', (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        double[] doubleArray10 = new double[] { 10.0f };
        double[] doubleArray12 = new double[] { 10.0f };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, false);
        try {
            array2DRowRealMatrix8.setSubMatrix(doubleArray13, (int) 'a', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        double[] doubleArray10 = new double[] { 10.0f };
        double[] doubleArray12 = new double[] { 10.0f };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, false);
        double double16 = array2DRowRealMatrix15.getNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix8.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 20.0d + "'", double16 == 20.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.getRowMatrix((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.exp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray2 = new double[] { 10.0f };
        double[] doubleArray4 = new double[] { 10.0f };
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray4 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, false);
        double[] doubleArray10 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        double[] doubleArray12 = array2DRowRealMatrix7.preMultiply(doubleArray10);
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = array2DRowRealMatrix0.multiply(array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.expm1(20.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.851651944097903E8d + "'", double1 == 4.851651944097903E8d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1, (int) '4', 0, (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.0f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.RealVector realVector2 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector3 = openMapRealVector1.projection(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            array2DRowRealMatrix0.multiplyEntry((int) '4', (int) (short) 1, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double13 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixChangingVisitor8, (int) (byte) 100, (int) (byte) 100, (int) (byte) 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.536743164063946E-7d + "'", double1 == 9.536743164063946E-7d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealVector realVector2 = array2DRowRealMatrix0.getRowVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        double[] doubleArray8 = null;
        try {
            double[] doubleArray9 = array2DRowRealMatrix6.preMultiply(doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        float float1 = org.apache.commons.math.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        int int7 = openMapRealVector5.getDimension();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector5.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector(realVector9);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector10.append(doubleArray13);
        try {
            array2DRowRealMatrix3.setRow(100, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(openMapRealVector15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int3 = openMapRealVector2.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double7 = openMapRealVector6.getNorm();
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector2.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector6);
        try {
            array2DRowRealMatrix0.setRowVector((int) (byte) 100, (org.apache.commons.math.linear.RealVector) openMapRealVector2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealVector realVector14 = array2DRowRealMatrix6.getRowVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = array2DRowRealMatrix3.multiply(array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray5 = null;
        try {
            double[] doubleArray6 = array2DRowRealMatrix3.preMultiply(doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInOptimizedOrder(realMatrixPreservingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[] doubleArray20 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix17.preMultiply(doubleArray20);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector5.subtract(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-127));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 127.0f + "'", float1 == 127.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor9, (int) '4', (int) (short) 100, (int) (short) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        openMapRealVector5.set(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[] doubleArray13 = null;
        try {
            double[] doubleArray14 = array2DRowRealMatrix6.operate(doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 1, (double) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        float float2 = org.apache.commons.math.util.FastMath.max((-0.99999994f), (float) 10L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix11 = array2DRowRealMatrix6.getSubMatrix(0, 0, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-1), (double) 1L);
        try {
            double double5 = openIntToDoubleHashMap2.put((int) (byte) -1, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -235868385");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) ' ', 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6193819415085411d) + "'", double2 == (-0.6193819415085411d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix16.preMultiply(doubleArray19);
        try {
            array2DRowRealMatrix8.setColumn((int) (byte) -1, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 9.536743E-7f, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.5367431640625E-7d + "'", double2 == 9.5367431640625E-7d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInRowOrder(realMatrixPreservingVisitor9, (int) (byte) 0, (int) (short) -1, 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix2 = array2DRowRealMatrix0.scalarMultiply(0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = new double[] { 10.0f };
        double[] doubleArray10 = new double[] { 10.0f };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11, false);
        double[] doubleArray16 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray18 = array2DRowRealMatrix13.preMultiply(doubleArray16);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix19 = array2DRowRealMatrix6.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((-0.6193819415085411d), (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3806180584914589d + "'", double2 == 0.3806180584914589d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector0.getSubVector((-127), (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 0x0");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        boolean boolean3 = iterator2.hasNext();
        try {
            int int4 = iterator2.key();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double13 = openMapRealVector12.getSparsity();
        boolean boolean14 = openMapRealVector12.isInfinite();
        try {
            openMapRealVector10.setSubVector((int) '4', (org.apache.commons.math.linear.RealVector) openMapRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtractToSelf((double) '#');
        double[] doubleArray4 = new double[] { 10.0f };
        double[] doubleArray6 = new double[] { 10.0f };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, false);
        double[] doubleArray12 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray14 = array2DRowRealMatrix9.preMultiply(doubleArray12);
        try {
            double double15 = openMapRealVector0.cosine(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.getColumnMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 0, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[][] doubleArray4 = new double[][] { doubleArray0, doubleArray1, doubleArray2, doubleArray3 };
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        try {
            array2DRowRealMatrix8.multiplyEntry((int) ' ', (-127), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-1), (double) 1L);
        try {
            boolean boolean4 = openIntToDoubleHashMap2.containsKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        int int13 = array2DRowRealMatrix6.getRowDimension();
        try {
            array2DRowRealMatrix6.multiplyEntry(2, (int) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.power((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector0.iterator();
        try {
            openMapRealVector0.setEntry(0, (double) (-0.99999994f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor10);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector0.mapAddToSelf(0.0d);
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray14 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix11.preMultiply(doubleArray14);
        try {
            double double17 = openMapRealVector0.dotProduct(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(openMapRealVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.3806180584914589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3806180584914589d + "'", double1 == 0.3806180584914589d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getNorm();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector7.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double double14 = openMapRealVector4.getL1Distance(openMapRealVector7);
        org.apache.commons.math.linear.RealVector realVector17 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector7.combineToSelf((double) 0L, 1.3369844095223624d, realVector17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double15 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor10, (int) '#', 100, (int) (short) 1, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        float float2 = org.apache.commons.math.util.FastMath.scalb(100.0f, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 200.0f + "'", float2 == 200.0f);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        java.lang.Double[] doubleArray17 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray17, 0.0d);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector19.mapMultiply((double) '#');
        try {
            org.apache.commons.math.linear.RealVector realVector22 = array2DRowRealMatrix6.operate((org.apache.commons.math.linear.RealVector) openMapRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double13 = openMapRealVector12.getNorm();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector8.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector12);
        boolean boolean15 = openMapRealVector8.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int17 = openMapRealVector16.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor18 = openMapRealVector16.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        int int24 = openMapRealVector19.getMinIndex();
        double double25 = openMapRealVector16.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector8.projection((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector7.add(openMapRealVector8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(entryItor18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2, (-0.99999994f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int10 = openMapRealVector9.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double14 = openMapRealVector13.getNorm();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector9.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector13);
        boolean boolean16 = openMapRealVector9.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor19 = openMapRealVector17.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int21 = openMapRealVector20.getMinIndex();
        int int22 = openMapRealVector20.getDimension();
        org.apache.commons.math.linear.RealVector realVector24 = openMapRealVector20.mapDivideToSelf((double) (-1));
        int int25 = openMapRealVector20.getMinIndex();
        double double26 = openMapRealVector17.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector9.projection((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        try {
            array2DRowRealMatrix6.setColumnVector(2, (org.apache.commons.math.linear.RealVector) openMapRealVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(entryItor19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4012984643248174E-45d + "'", double1 == 1.4012984643248174E-45d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 'a', (double) 200.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray14 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix11.preMultiply(doubleArray14);
        double[][] doubleArray17 = array2DRowRealMatrix11.getData();
        double[] doubleArray20 = new double[] { 10.0f };
        double[] doubleArray22 = new double[] { 10.0f };
        double[][] doubleArray23 = new double[][] { doubleArray20, doubleArray22 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23, false);
        double[] doubleArray28 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray28);
        double[] doubleArray30 = array2DRowRealMatrix25.preMultiply(doubleArray28);
        array2DRowRealMatrix11.setRow(0, doubleArray30);
        try {
            array2DRowRealMatrix3.setRowMatrix((int) (short) 1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 1x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap2 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((-1), (double) 1L);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator3 = openIntToDoubleHashMap2.iterator();
        try {
            int int4 = iterator3.key();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) (short) 100, (-127));
        java.lang.Number number4 = dimensionMismatchException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100 + "'", number4.equals(100));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        float float1 = org.apache.commons.math.util.FastMath.ulp(127.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 7.6293945E-6f + "'", float1 == 7.6293945E-6f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.asin(9.5367431640625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.536743164063946E-7d + "'", double1 == 9.536743164063946E-7d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) -1, (double) 1.0000001f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.851651944097903E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5544804492206369d) + "'", double1 == (-0.5544804492206369d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9913289158005998d + "'", double1 == 0.9913289158005998d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double7 = openMapRealVector5.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector6);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = null;
        try {
            double double9 = openMapRealVector6.getL1Distance(openMapRealVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getSparsity();
        double double2 = openMapRealVector0.getL1Norm();
        double[] doubleArray4 = new double[] { 10.0f };
        double[] doubleArray6 = new double[] { 10.0f };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, false);
        double[] doubleArray12 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray14 = array2DRowRealMatrix9.preMultiply(doubleArray12);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector0.ebeDivide(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.power((int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double[] doubleArray6 = new double[] { 1.0000001f, 1.0d };
        try {
            openMapRealVector0.setSubVector((int) ' ', doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector3.mapDivideToSelf((double) (-1));
        int int8 = openMapRealVector3.getMinIndex();
        double double9 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector0.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector0.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int16 = openMapRealVector15.getMinIndex();
        int int17 = openMapRealVector15.getDimension();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector15.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector12.combineToSelf((double) (byte) 1, (double) (byte) 10, realVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor23 = openMapRealVector22.sparseIterator();
        try {
            openMapRealVector12.setSubVector(10, (org.apache.commons.math.linear.RealVector) openMapRealVector22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertNotNull(openMapRealVector12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(entryItor23);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor1 = openMapRealVector0.sparseIterator();
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector0.getSubVector((int) (byte) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(entryItor1);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        try {
            double double31 = array2DRowRealMatrix6.getEntry((int) (byte) 1, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.414213562373095d + "'", double1 == 1.414213562373095d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = openMapRealVector0.mapAddToSelf(0.0d);
        org.apache.commons.math.linear.RealVector realVector5 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = openMapRealVector4.subtract(realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(openMapRealVector4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor9, 2, (int) '#', 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.414213562373095d, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7320508075688772d + "'", double2 == 1.7320508075688772d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 'a', (double) (-127));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 96.99999f + "'", float2 == 96.99999f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        int int12 = openMapRealVector10.getDimension();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector10.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector(realVector14);
        double[] doubleArray18 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector15.append(doubleArray18);
        try {
            double[] doubleArray21 = array2DRowRealMatrix8.operate(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 0.0f, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 96.99999f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = openMapRealVector0.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) (-0.99999994f), (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999403953552d) + "'", double2 == (-0.9999999403953552d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-17) + "'", int1 == (-17));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        java.lang.Double[] doubleArray35 = new java.lang.Double[] { 2.718281828459045d, 1.4711276743037347d, 0.8813735870195429d, 0.36787944117144233d, 100.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray35);
        try {
            array2DRowRealMatrix6.setRowVector((int) 'a', (org.apache.commons.math.linear.RealVector) openMapRealVector36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtractToSelf((double) '#');
        double double3 = openMapRealVector0.getMaxValue();
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = openMapRealVector0.ebeDivide(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray18 = array2DRowRealMatrix16.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix16.scalarAdd(1.3369844095223624d);
        try {
            array2DRowRealMatrix6.setColumnMatrix((int) (short) 1, (org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double[] doubleArray8 = new double[] { 1.5430806348152437d, (byte) 100, (short) 0, 1.4711276743037347d, 1.7320508075688772d };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix9 = openMapRealVector0.outerProduct(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        java.lang.Double[] doubleArray44 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector46 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray44, 0.0d);
        org.apache.commons.math.linear.RealVector realVector48 = openMapRealVector46.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector46.unitVector();
        try {
            double double50 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(openMapRealVector49);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (double) 35.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.scalarAdd(1.3369844095223624d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        boolean boolean3 = iterator2.hasNext();
        boolean boolean4 = iterator2.hasNext();
        try {
            iterator2.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math.linear.Array2DRowRealMatrix(0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 9.536743E-7f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.53674316406539E-7d + "'", double1 == 9.53674316406539E-7d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.log(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1447298858494002d + "'", double1 == 1.1447298858494002d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        try {
            array2DRowRealMatrix6.setRowVector((int) (short) 10, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int[] intArray11 = new int[] { (-127), 10, 0, (-17), (byte) -1, (byte) -1 };
        int[] intArray12 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix13 = array2DRowRealMatrix3.getSubMatrix(intArray11, intArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(intArray11);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getSparsity();
        double double13 = openMapRealVector11.getL1Norm();
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector10.add(openMapRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray9);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction13 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector12.map(univariateRealFunction13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.7724538509055159d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.885277250018028d + "'", double1 == 5.885277250018028d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.102748784455539d + "'", double1 == 1.102748784455539d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.cos(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        try {
            iterator2.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getSparsity();
        double double2 = openMapRealVector0.getL1Norm();
        double[] doubleArray7 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7);
        try {
            org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector0.combine(0.3806180584914589d, (double) 127.0f, doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double0 = org.apache.commons.math.linear.OpenMapRealVector.DEFAULT_ZERO_TOLERANCE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-12d + "'", double0 == 1.0E-12d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double2 = org.apache.commons.math.util.FastMath.scalb(9.5367431640625E-7d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2089258196146292E24d + "'", double2 == 1.2089258196146292E24d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.2089258196146292E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.926634720831213E25d + "'", double1 == 6.926634720831213E25d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        try {
            double double3 = openMapRealVector0.getEntry(2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray13 = array2DRowRealMatrix11.getRow(0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix3.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        float float2 = org.apache.commons.math.util.FastMath.min(127.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        boolean boolean3 = iterator2.hasNext();
        try {
            iterator2.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int1 = org.apache.commons.math.util.FastMath.getExponent(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        double[] doubleArray40 = new double[] { 10.0f };
        double[] doubleArray42 = new double[] { 10.0f };
        double[][] doubleArray43 = new double[][] { doubleArray40, doubleArray42 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray43, false);
        double[] doubleArray47 = array2DRowRealMatrix45.getRow(0);
        try {
            double double48 = openMapRealVector37.getDistance(doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 52.0f, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.009614495783374d + "'", double2 == 52.009614495783374d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        try {
            org.apache.commons.math.linear.RealVector realVector4 = openMapRealMatrix2.getRowVector((-17));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-17)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double6 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1, (-1), (int) (byte) 10, (int) (byte) 10, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double2 = org.apache.commons.math.util.FastMath.copySign(1.4711276743037347d, (double) 127.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037347d + "'", double2 == 1.4711276743037347d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        int[] intArray15 = null;
        int[] intArray22 = new int[] { (short) -1, 2, '4', '#', 1, (byte) 10 };
        double[] doubleArray24 = new double[] { 10.0f };
        double[] doubleArray26 = new double[] { 10.0f };
        double[][] doubleArray27 = new double[][] { doubleArray24, doubleArray26 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix33 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27, false);
        try {
            array2DRowRealMatrix6.copySubMatrix(intArray15, intArray22, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) (short) 100, (-127));
        java.lang.Throwable[] throwableArray4 = dimensionMismatchException3.getSuppressed();
        int int5 = dimensionMismatchException3.getDimension();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-127) + "'", int5 == (-127));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix3.getColumnMatrix((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector2 = openMapRealVector0.mapSubtractToSelf((double) '#');
        double double3 = openMapRealVector0.getMaxValue();
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray12 = array2DRowRealMatrix10.getRow(0);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector0.ebeMultiply(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) (byte) 0, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        int int13 = array2DRowRealMatrix6.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.createMatrix(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.scalarMultiply((-0.6193819415085411d));
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.power((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = openMapRealVector9.mapAddToSelf((double) (byte) 100);
        try {
            double double12 = openMapRealVector0.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(openMapRealVector11);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int3 = openMapRealVector2.getMinIndex();
        int int4 = openMapRealVector2.getDimension();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector2.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(realVector6);
        double[] doubleArray10 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector7.append(doubleArray10);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = openMapRealVector1.subtract(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(openMapRealVector12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor1 = openMapRealVector0.sparseIterator();
        boolean boolean2 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapMultiplyToSelf(1.4711276743037347d);
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.mapDivideToSelf(0.8813735870195429d);
        org.junit.Assert.assertNotNull(entryItor1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5544804492206369d), 6.926634720831213E25d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.926634720831213E25d + "'", double2 == 6.926634720831213E25d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        org.apache.commons.math.linear.RealVector realVector3 = openMapRealVector0.mapMultiply(5.298292365610485d);
        double[] doubleArray6 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = openMapRealVector0.outerProduct(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        try {
            double double10 = array2DRowRealMatrix8.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double double27 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix6.getRowMatrix((int) (short) 0);
        double[][] doubleArray34 = null;
        try {
            array2DRowRealMatrix6.copySubMatrix((int) (byte) 10, (-127), 0, 0, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        int int44 = openMapRealVector42.getDimension();
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector42.mapDivideToSelf((double) (-1));
        int int47 = openMapRealVector42.getMinIndex();
        double double48 = openMapRealVector39.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor49 = openMapRealVector39.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector39.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector37.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        org.apache.commons.math.linear.RealVector realVector53 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector52.ebeDivide(realVector53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double double27 = array2DRowRealMatrix6.getFrobeniusNorm();
        double[] doubleArray30 = new double[] { 10.0f };
        double[] doubleArray32 = new double[] { 10.0f };
        double[][] doubleArray33 = new double[][] { doubleArray30, doubleArray32 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray33, false);
        double[] doubleArray38 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix39 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray38);
        double[] doubleArray40 = array2DRowRealMatrix35.preMultiply(doubleArray38);
        double[][] doubleArray41 = array2DRowRealMatrix35.getData();
        double[] doubleArray44 = new double[] { 10.0f };
        double[] doubleArray46 = new double[] { 10.0f };
        double[][] doubleArray47 = new double[][] { doubleArray44, doubleArray46 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47, false);
        double[] doubleArray52 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        double[] doubleArray54 = array2DRowRealMatrix49.preMultiply(doubleArray52);
        array2DRowRealMatrix35.setRow(0, doubleArray54);
        double double56 = array2DRowRealMatrix35.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix58 = array2DRowRealMatrix35.getRowMatrix((int) (short) 0);
        try {
            array2DRowRealMatrix6.setColumnMatrix(100, realMatrix58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 14.142135623730951d + "'", double56 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix58);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 2);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) 'a', (int) '#');
        double[] doubleArray4 = new double[] { 10.0f };
        double[] doubleArray6 = new double[] { 10.0f };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, false);
        double[] doubleArray12 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12);
        double[] doubleArray14 = array2DRowRealMatrix9.preMultiply(doubleArray12);
        double[][] doubleArray15 = array2DRowRealMatrix9.getData();
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        array2DRowRealMatrix9.setRow(0, doubleArray28);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = openMapRealVector2.ebeDivide(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 97 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        double[] doubleArray31 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray31);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix33 = array2DRowRealMatrix6.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder((double) 100, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        int int44 = openMapRealVector42.getDimension();
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector42.mapDivideToSelf((double) (-1));
        int int47 = openMapRealVector42.getMinIndex();
        double double48 = openMapRealVector39.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor49 = openMapRealVector39.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector39.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector37.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        java.lang.Double[] doubleArray59 = new java.lang.Double[] { 2.718281828459045d, 1.4711276743037347d, 0.8813735870195429d, 0.36787944117144233d, 100.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector60 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray59);
        org.apache.commons.math.linear.RealVector realVector62 = openMapRealVector60.mapSubtractToSelf((double) 1.0000001f);
        try {
            openMapRealVector52.setSubVector((int) (byte) -1, (org.apache.commons.math.linear.RealVector) openMapRealVector60);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realVector62);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.scalarAdd(1.3369844095223624d);
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[] doubleArray20 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix17.preMultiply(doubleArray20);
        double[][] doubleArray23 = array2DRowRealMatrix17.getData();
        double[] doubleArray26 = new double[] { 10.0f };
        double[] doubleArray28 = new double[] { 10.0f };
        double[][] doubleArray29 = new double[][] { doubleArray26, doubleArray28 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        double[] doubleArray34 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix31.preMultiply(doubleArray34);
        array2DRowRealMatrix17.setRow(0, doubleArray36);
        double double38 = array2DRowRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix40 = array2DRowRealMatrix17.getRowMatrix((int) (short) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix41 = array2DRowRealMatrix6.preMultiply(realMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 14.142135623730951d + "'", double38 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double34 = array2DRowRealMatrix6.walkInOptimizedOrder(realMatrixPreservingVisitor29, (int) (short) -1, (int) (short) 100, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector4.mapSubtractToSelf((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = openMapRealVector4.mapAddToSelf(0.0d);
        try {
            org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector1.add((org.apache.commons.math.linear.RealVector) openMapRealVector4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(openMapRealVector8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int[] intArray5 = null;
        int[] intArray6 = new int[] {};
        double[] doubleArray8 = new double[] { 10.0f };
        double[] doubleArray10 = new double[] { 10.0f };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11, false);
        try {
            array2DRowRealMatrix3.copySubMatrix(intArray5, intArray6, doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610486d + "'", double1 == 5.298292365610486d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor13 = openMapRealVector11.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int15 = openMapRealVector14.getMinIndex();
        int int16 = openMapRealVector14.getDimension();
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector14.mapDivideToSelf((double) (-1));
        int int19 = openMapRealVector14.getMinIndex();
        double double20 = openMapRealVector11.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector14);
        double[] doubleArray22 = new double[] { 10.0f };
        double[] doubleArray24 = new double[] { 10.0f };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, false);
        double[] doubleArray30 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray30);
        double[] doubleArray32 = array2DRowRealMatrix27.preMultiply(doubleArray30);
        org.apache.commons.math.linear.RealVector realVector33 = openMapRealVector14.add(doubleArray32);
        try {
            double double34 = openMapRealVector5.getLInfDistance(doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(entryItor13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 1.0f);
        double double3 = openIntToDoubleHashMap1.get(0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector7.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector7.unitVector();
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[] doubleArray20 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix17.preMultiply(doubleArray20);
        double[][] doubleArray23 = array2DRowRealMatrix17.getData();
        double[] doubleArray26 = new double[] { 10.0f };
        double[] doubleArray28 = new double[] { 10.0f };
        double[][] doubleArray29 = new double[][] { doubleArray26, doubleArray28 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        double[] doubleArray34 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix31.preMultiply(doubleArray34);
        array2DRowRealMatrix17.setRow(0, doubleArray36);
        try {
            double double38 = openMapRealVector10.getL1Distance(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        double double4 = openMapRealVector1.getL1Norm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double10 = openMapRealVector9.getNorm();
        org.apache.commons.math.linear.RealVector realVector11 = openMapRealVector5.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector9);
        boolean boolean12 = openMapRealVector5.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor15 = openMapRealVector13.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int17 = openMapRealVector16.getMinIndex();
        int int18 = openMapRealVector16.getDimension();
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector16.mapDivideToSelf((double) (-1));
        int int21 = openMapRealVector16.getMinIndex();
        double double22 = openMapRealVector13.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector5.projection((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int25 = openMapRealVector24.getMinIndex();
        int int26 = openMapRealVector24.getDimension();
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector24.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = openMapRealVector5.append((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int31 = openMapRealVector30.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor32 = openMapRealVector30.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int34 = openMapRealVector33.getMinIndex();
        int int35 = openMapRealVector33.getDimension();
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector33.mapDivideToSelf((double) (-1));
        int int38 = openMapRealVector33.getMinIndex();
        double double39 = openMapRealVector30.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor40 = openMapRealVector30.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = openMapRealVector30.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector43 = openMapRealVector5.append(openMapRealVector42);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector1.ebeMultiply((org.apache.commons.math.linear.RealVector) openMapRealVector5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10000.0d + "'", double4 == 10000.0d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(entryItor15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(openMapRealVector29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(entryItor32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor40);
        org.junit.Assert.assertNotNull(openMapRealVector42);
        org.junit.Assert.assertNotNull(openMapRealVector43);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor13 = null;
        try {
            double double18 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor13, (int) (short) 100, (int) (byte) 10, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector0.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix3.walkInOptimizedOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        try {
            iterator2.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(2, (int) (short) 0);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        int[] intArray13 = new int[] { (short) -1 };
        int[] intArray14 = null;
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        java.lang.Class<?> wildcardClass22 = doubleArray19.getClass();
        try {
            array2DRowRealMatrix6.copySubMatrix(intArray13, intArray14, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(wildcardClass22);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) -1, 1.3369844095223624d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        int int5 = openMapRealVector4.getDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix6 = openMapRealVector2.outerProduct((org.apache.commons.math.linear.RealVector) openMapRealVector4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 2.718281828459045d, 1.4711276743037347d, 0.8813735870195429d, 0.36787944117144233d, 100.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        int int9 = openMapRealVector8.getMaxIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 229.1831180523293d + "'", double1 == 229.1831180523293d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 0.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.scalarAdd(1.3369844095223624d);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double16 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor11, 0, (int) ' ', 1, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 2.718281828459045d, 1.4711276743037347d, 0.8813735870195429d, 0.36787944117144233d, 100.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector6 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5);
        org.apache.commons.math.linear.RealVector realVector8 = openMapRealVector6.mapSubtractToSelf((double) 1.0000001f);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int10 = openMapRealVector9.getMinIndex();
        int int11 = openMapRealVector9.getDimension();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector9.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(realVector13);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector14.append(doubleArray17);
        try {
            double double20 = openMapRealVector6.dotProduct(doubleArray17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(openMapRealVector19);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix3.walkInRowOrder(realMatrixPreservingVisitor5, 2, (-1), (int) (byte) 100, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        try {
            org.apache.commons.math.linear.RealVector realVector13 = array2DRowRealMatrix6.getRowVector((-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double16 = openMapRealVector15.getNorm();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector11.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector15);
        boolean boolean18 = openMapRealVector11.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double24 = openMapRealVector23.getNorm();
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector19.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector23);
        boolean boolean26 = openMapRealVector19.isNaN();
        double double27 = openMapRealVector11.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        try {
            org.apache.commons.math.linear.RealVector realVector28 = array2DRowRealMatrix10.operate((org.apache.commons.math.linear.RealVector) openMapRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.scalarAdd(1.3369844095223624d);
        try {
            array2DRowRealMatrix6.setEntry((int) (byte) 100, 97, (double) 2.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int3 = openMapRealMatrix2.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = openMapRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 97 + "'", int3 == 97);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray2 = new double[] { 10.0f };
        double[] doubleArray4 = new double[] { 10.0f };
        double[][] doubleArray5 = new double[][] { doubleArray2, doubleArray4 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5, true);
        int int10 = array2DRowRealMatrix9.getRowDimension();
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[] doubleArray20 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix17.preMultiply(doubleArray20);
        double[] doubleArray23 = array2DRowRealMatrix9.preMultiply(doubleArray20);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix24 = array2DRowRealMatrix0.preMultiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector13.mapSubtractToSelf((double) '#');
        try {
            org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector10.combineToSelf(2.718281828459045d, (double) '4', (org.apache.commons.math.linear.RealVector) openMapRealVector13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 0");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.633123935319537E16d + "'", double1 == 1.633123935319537E16d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        try {
            array2DRowRealMatrix6.copySubMatrix(0, 100, (int) '4', (int) (byte) 1, doubleArray15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double13 = openMapRealVector12.getNorm();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector8.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector12);
        boolean boolean15 = openMapRealVector8.isNaN();
        double double16 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        java.lang.Double[] doubleArray22 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22, 0.0d);
        org.apache.commons.math.linear.RealVector realVector26 = openMapRealVector24.mapMultiply((double) '#');
        try {
            double double27 = openMapRealVector8.dotProduct(openMapRealVector24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector26);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1);
        boolean boolean13 = openMapRealVector12.isNaN();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector12.mapDivideToSelf(20.0d);
        try {
            org.apache.commons.math.linear.RealVector realVector16 = array2DRowRealMatrix10.preMultiply(realVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: -1 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector0.mapMultiply((double) 10.0f);
        try {
            openMapRealVector0.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        try {
            array2DRowRealMatrix8.multiplyEntry((-127), 97, 1.414213562373095d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double double3 = openMapRealVector0.getMaxValue();
        try {
            openMapRealVector0.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        try {
            double double15 = array2DRowRealMatrix6.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011016690305d) + "'", double1 == (-1.1752011016690305d));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) -1, (double) 1L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974483d) + "'", double2 == (-0.7853981633974483d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[] doubleArray17 = new double[] { 10.0f };
        double[] doubleArray19 = new double[] { 10.0f };
        double[][] doubleArray20 = new double[][] { doubleArray17, doubleArray19 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20, false);
        try {
            array2DRowRealMatrix6.copySubMatrix(10, 0, (-1), (int) (short) 1, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        double[] doubleArray3 = new double[] { 10.0f };
        double[] doubleArray5 = new double[] { 10.0f };
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, true);
        int int11 = array2DRowRealMatrix10.getRowDimension();
        double[] doubleArray13 = new double[] { 10.0f };
        double[] doubleArray15 = new double[] { 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray13, doubleArray15 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, false);
        double[] doubleArray21 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray23 = array2DRowRealMatrix18.preMultiply(doubleArray21);
        double[] doubleArray24 = array2DRowRealMatrix10.preMultiply(doubleArray21);
        try {
            double double25 = openMapRealVector1.cosine(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2 + "'", int11 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        try {
            double double10 = array2DRowRealMatrix6.getEntry(100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix3.walkInRowOrder(realMatrixPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        java.lang.Double[] doubleArray5 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray5, 1.5430806348152437d);
        double[] doubleArray13 = new double[] { 2.0f, (byte) 1, (byte) 100 };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = openMapRealVector9.ebeDivide(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.53674316406539E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.536743164066837E-7d + "'", double1 == 9.536743164066837E-7d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        try {
            double double5 = openMapRealMatrix2.getEntry((-1), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080634815244d + "'", double1 == 1.543080634815244d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getNorm();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector7.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double double14 = openMapRealVector4.getL1Distance(openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int16 = openMapRealVector15.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor17 = openMapRealVector15.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int19 = openMapRealVector18.getMinIndex();
        int int20 = openMapRealVector18.getDimension();
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector18.mapDivideToSelf((double) (-1));
        int int23 = openMapRealVector18.getMinIndex();
        double double24 = openMapRealVector15.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector18);
        double[] doubleArray26 = new double[] { 10.0f };
        double[] doubleArray28 = new double[] { 10.0f };
        double[][] doubleArray29 = new double[][] { doubleArray26, doubleArray28 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        double[] doubleArray34 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix35 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34);
        double[] doubleArray36 = array2DRowRealMatrix31.preMultiply(doubleArray34);
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector18.add(doubleArray36);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector4.ebeMultiply(doubleArray36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(entryItor17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double6 = openMapRealVector5.getNorm();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector1.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector5);
        boolean boolean8 = openMapRealVector1.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int10 = openMapRealVector9.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor11 = openMapRealVector9.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        int int14 = openMapRealVector12.getDimension();
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector12.mapDivideToSelf((double) (-1));
        int int17 = openMapRealVector12.getMinIndex();
        double double18 = openMapRealVector9.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector1.projection((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector1.mapMultiply((double) 10.0f);
        double double22 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        double[] doubleArray29 = new double[] { 20.0d, 9.536743164066837E-7d, 0.3806180584914589d, 57.29577951308232d };
        try {
            org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector0.combine((double) 52.0f, (double) (byte) 1, doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 4");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(entryItor11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray14 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix11.preMultiply(doubleArray14);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray14);
        double[] doubleArray18 = array2DRowRealMatrix3.preMultiply(doubleArray14);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor19 = null;
        try {
            double double24 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixChangingVisitor19, 4, (int) (byte) 10, 4, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (4)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        int int3 = openIntToDoubleHashMap1.size();
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[][] doubleArray5 = array2DRowRealMatrix3.getData();
        try {
            double double6 = array2DRowRealMatrix3.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        try {
            openMapRealMatrix2.addToEntry((int) (short) 1, (int) '#', (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double[] doubleArray6 = new double[] { 10.0f };
        double[] doubleArray8 = new double[] { 10.0f };
        double[][] doubleArray9 = new double[][] { doubleArray6, doubleArray8 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9, false);
        double[] doubleArray14 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14);
        double[] doubleArray16 = array2DRowRealMatrix11.preMultiply(doubleArray14);
        try {
            org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector0.combine((double) (byte) 0, 10000.0d, doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int6 = openMapRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix2.add(openMapRealMatrix5);
        double[] doubleArray9 = new double[] { 10.0f };
        double[] doubleArray11 = new double[] { 10.0f };
        double[][] doubleArray12 = new double[][] { doubleArray9, doubleArray11 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray12, false);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double[] doubleArray19 = array2DRowRealMatrix14.preMultiply(doubleArray17);
        double double20 = array2DRowRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix22 = array2DRowRealMatrix14.scalarMultiply(3.141592653589793d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix23 = openMapRealMatrix5.multiply(realMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 14.142135623730951d + "'", double20 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        int int3 = openMapRealVector1.getDimension();
        double double4 = openMapRealVector0.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        boolean boolean5 = openMapRealVector0.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException4 = new org.apache.commons.math.exception.DimensionMismatchException(localizable1, (int) (short) 100, (-127));
        java.lang.Throwable[] throwableArray5 = dimensionMismatchException4.getSuppressed();
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException(localizable0, (java.lang.Object[]) throwableArray5);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException6.getContext();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.000004f + "'", float1 == 32.000004f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) 10, 1.1102230246251565E-16d);
        double[] doubleArray5 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray5);
        try {
            double double7 = openMapRealVector2.getLInfDistance(doubleArray5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 10 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        try {
            array2DRowRealMatrix3.setSubMatrix(doubleArray10, 1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor45 = null;
        try {
            double double50 = array2DRowRealMatrix23.walkInColumnOrder(realMatrixPreservingVisitor45, 97, (-17), (int) (short) 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 2.0f, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0000000000000004d + "'", double2 == 2.0000000000000004d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        float float1 = org.apache.commons.math.util.FastMath.ulp(7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.094947E-13f + "'", float1 == 9.094947E-13f);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.asin(57.29577951308232d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        int int5 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector0.map(univariateRealFunction6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        double[] doubleArray13 = new double[] { 10.0f };
        double[] doubleArray15 = new double[] { 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray13, doubleArray15 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, false);
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix19 = openMapRealMatrix11.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 97x32 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double double3 = openMapRealVector0.getMaxValue();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getSparsity();
        double double6 = openMapRealVector4.getL1Norm();
        double double7 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector4);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor8 = openMapRealVector0.sparseIterator();
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[] doubleArray20 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray20);
        double[] doubleArray22 = array2DRowRealMatrix17.preMultiply(doubleArray20);
        try {
            org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector0.combineToSelf(0.0d, 10.0d, doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        org.apache.commons.math.linear.RealVector realVector5 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector1.combineToSelf(52.0d, 0.0d, realVector5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        float float2 = org.apache.commons.math.util.FastMath.copySign(7.6293945E-6f, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.6293945E-6f + "'", float2 == 7.6293945E-6f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double13 = openMapRealVector12.getNorm();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector8.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector12);
        boolean boolean15 = openMapRealVector8.isNaN();
        double double16 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        double double17 = openMapRealVector8.getLInfNorm();
        double[] doubleArray19 = new double[] { 10.0f };
        double[] doubleArray21 = new double[] { 10.0f };
        double[][] doubleArray22 = new double[][] { doubleArray19, doubleArray21 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22, false);
        double[] doubleArray27 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        double[] doubleArray29 = array2DRowRealMatrix24.preMultiply(doubleArray27);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector30 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray27);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix31 = openMapRealVector8.outerProduct(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 100L, 7.6293945E-6f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        int int13 = array2DRowRealMatrix6.getRowDimension();
        int[] intArray15 = new int[] { (-127) };
        int[] intArray16 = new int[] {};
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix17 = array2DRowRealMatrix6.getSubMatrix(intArray15, intArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoDataException; message: empty selected column index array");
        } catch (org.apache.commons.math.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        double double22 = array2DRowRealMatrix21.getNorm();
        double[][] doubleArray23 = array2DRowRealMatrix21.getDataRef();
        try {
            array2DRowRealMatrix12.setSubMatrix(doubleArray23, (-127), (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 20.0d + "'", double22 == 20.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix8.walkInOptimizedOrder(realMatrixPreservingVisitor9, (int) '#', (int) (short) -1, (int) (byte) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.851651944097903E8d, (java.lang.Number) 100.00001f, (java.lang.Number) 100.00001f);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.00001f + "'", number4.equals(100.00001f));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) -1, 1.3369844095223624d);
        int int3 = openMapRealVector2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray21 = new double[] { 2, 2.718281828459045d, 1.102748784455539d, (-0.99999994f), 9.53674316406539E-7d, 52.009614495783374d };
        double[] doubleArray28 = new double[] { 2, 2.718281828459045d, 1.102748784455539d, (-0.99999994f), 9.53674316406539E-7d, 52.009614495783374d };
        double[][] doubleArray29 = new double[][] { doubleArray21, doubleArray28 };
        try {
            array2DRowRealMatrix10.copySubMatrix((-17), (int) (byte) 100, 10, 2, doubleArray29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-17)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix12.getColumnMatrix((int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.4711276743037347d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(35.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.000004f + "'", float1 == 35.000004f);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8414709848078965d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.asinh(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        boolean boolean14 = openMapRealVector11.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int17 = openMapRealVector16.getMinIndex();
        int int18 = openMapRealVector16.getDimension();
        double double19 = openMapRealVector15.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector11.add(openMapRealVector15);
        try {
            double double21 = openMapRealVector10.getDistance(openMapRealVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector20);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix3.walkInColumnOrder(realMatrixPreservingVisitor5, 1, (int) '#', (int) (short) 10, 2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.0d), (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1);
        boolean boolean2 = openMapRealVector1.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor5 = openMapRealVector3.sparseIterator();
        double double6 = openMapRealVector3.getMaxValue();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double8 = openMapRealVector7.getSparsity();
        double double9 = openMapRealVector7.getL1Norm();
        double double10 = openMapRealVector3.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector7);
        try {
            double double11 = openMapRealVector1.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(entryItor5);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double double3 = openMapRealVector0.getMaxValue();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getSparsity();
        double double6 = openMapRealVector4.getL1Norm();
        double double7 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector4);
        double[] doubleArray10 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10);
        double double12 = array2DRowRealMatrix11.getNorm();
        double[] doubleArray14 = new double[] { 10.0f };
        double[] doubleArray16 = new double[] { 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        double[] doubleArray22 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray24 = array2DRowRealMatrix19.preMultiply(doubleArray22);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray22);
        double[] doubleArray26 = array2DRowRealMatrix11.preMultiply(doubleArray22);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector27 = openMapRealVector0.projection(doubleArray26);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        org.apache.commons.math.linear.RealMatrix realMatrix28 = array2DRowRealMatrix6.scalarMultiply((double) (-127));
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor29 = null;
        try {
            double double30 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix28);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixPreservingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        double[][] doubleArray5 = array2DRowRealMatrix3.getData();
        double[][] doubleArray6 = array2DRowRealMatrix3.getDataRef();
        int[] intArray10 = new int[] { (byte) -1, 4, (short) 100 };
        int[] intArray14 = new int[] { '4', (byte) 100, 0 };
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix15 = array2DRowRealMatrix3.getSubMatrix(intArray10, intArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        float float1 = org.apache.commons.math.util.FastMath.ulp(32.000004f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.lang.Double[] doubleArray2 = new java.lang.Double[] { (-0.9999999403953552d), 20.0d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray2, 22026.465794806718d);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-0.99999994f) + "'", float1 == (-0.99999994f));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 10, (-127));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double13 = openMapRealVector12.getNorm();
        org.apache.commons.math.linear.RealVector realVector14 = openMapRealVector8.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector12);
        boolean boolean15 = openMapRealVector8.isNaN();
        double double16 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int18 = openMapRealVector17.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double22 = openMapRealVector21.getNorm();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector17.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector21);
        boolean boolean24 = openMapRealVector17.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.RealVector realVector35 = openMapRealVector17.projection((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int37 = openMapRealVector36.getMinIndex();
        int int38 = openMapRealVector36.getDimension();
        org.apache.commons.math.linear.RealVector realVector40 = openMapRealVector36.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = openMapRealVector17.append((org.apache.commons.math.linear.RealVector) openMapRealVector36);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor44 = openMapRealVector42.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int46 = openMapRealVector45.getMinIndex();
        int int47 = openMapRealVector45.getDimension();
        org.apache.commons.math.linear.RealVector realVector49 = openMapRealVector45.mapDivideToSelf((double) (-1));
        int int50 = openMapRealVector45.getMinIndex();
        double double51 = openMapRealVector42.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor52 = openMapRealVector42.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector54 = openMapRealVector42.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector55 = openMapRealVector17.append(openMapRealVector54);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector56 = openMapRealVector8.append(openMapRealVector54);
        double[] doubleArray57 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector58 = openMapRealVector8.append(doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(openMapRealVector41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(entryItor44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor52);
        org.junit.Assert.assertNotNull(openMapRealVector54);
        org.junit.Assert.assertNotNull(openMapRealVector55);
        org.junit.Assert.assertNotNull(openMapRealVector56);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        try {
            array2DRowRealMatrix8.setEntry(0, 4, (double) 35.000004f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (4)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        double[] doubleArray24 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix21.preMultiply(doubleArray24);
        double double27 = array2DRowRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix21.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix21.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int34 = openMapRealVector33.getMinIndex();
        int int35 = openMapRealVector33.getDimension();
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector33.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(realVector37);
        boolean boolean39 = array2DRowRealMatrix32.equals((java.lang.Object) openMapRealVector38);
        double[] doubleArray41 = new double[] { 10.0f };
        double[] doubleArray43 = new double[] { 10.0f };
        double[][] doubleArray44 = new double[][] { doubleArray41, doubleArray43 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix46 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray44, false);
        java.lang.Class<?> wildcardClass47 = doubleArray44.getClass();
        try {
            array2DRowRealMatrix32.setSubMatrix(doubleArray44, (int) ' ', (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(wildcardClass47);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.7320508075688772d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2609231332651425d + "'", double2 == 0.2609231332651425d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        try {
            org.apache.commons.math.linear.RealVector realVector16 = array2DRowRealMatrix6.getRowVector(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double double19 = array2DRowRealMatrix18.getNorm();
        int int20 = array2DRowRealMatrix18.getColumnDimension();
        double[] doubleArray22 = new double[] { 10.0f };
        double[] doubleArray24 = new double[] { 10.0f };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, false);
        double double28 = array2DRowRealMatrix27.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix18.add(array2DRowRealMatrix27);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix36.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix36);
        try {
            double[] doubleArray50 = array2DRowRealMatrix48.getColumn((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 20.0d + "'", double28 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double double3 = openMapRealVector0.getMaxValue();
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray13);
        try {
            double double17 = openMapRealVector0.cosine(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9999999403953552d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector17 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double18 = openMapRealVector17.getNorm();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector13.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector17);
        boolean boolean20 = openMapRealVector13.isNaN();
        boolean boolean21 = array2DRowRealMatrix6.equals((java.lang.Object) boolean20);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor22 = null;
        try {
            double double23 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        int int3 = openMapRealVector1.getDimension();
        double double4 = openMapRealVector0.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.mapDivide((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        boolean boolean45 = array2DRowRealMatrix23.isSquare();
        org.apache.commons.math.linear.RealMatrix realMatrix47 = null;
        try {
            array2DRowRealMatrix23.setColumnMatrix((int) (byte) 0, realMatrix47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        double[] doubleArray13 = new double[] { 10.0f };
        double[] doubleArray15 = new double[] { 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray13, doubleArray15 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, true);
        int int21 = array2DRowRealMatrix20.getRowDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix22 = openMapRealMatrix5.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2 + "'", int21 == 2);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray3 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getData();
        double[][] doubleArray7 = array2DRowRealMatrix4.getDataRef();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix8 = array2DRowRealMatrix0.add((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 0x0 but expected 2x1");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix6.createMatrix((int) (short) -1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        try {
            double double3 = iterator2.value();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(iterator2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        double[] doubleArray3 = new double[] { 10.0f };
        double[] doubleArray5 = new double[] { 10.0f };
        double[][] doubleArray6 = new double[][] { doubleArray3, doubleArray5 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6, false);
        double[] doubleArray10 = array2DRowRealMatrix8.getRow(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray10, (double) 9.094947E-13f);
        try {
            array2DRowRealMatrix0.setRow((-17), doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-17)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 1L, 2);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.0f + "'", float2 == 4.0f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) ' ', (int) (short) 100);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.power((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.2609231332651425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.949794313422199d + "'", double1 == 14.949794313422199d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (byte) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.mapAddToSelf((double) (byte) 100);
        double[] doubleArray5 = new double[] { 10.0f };
        double[] doubleArray7 = new double[] { 10.0f };
        double[][] doubleArray8 = new double[][] { doubleArray5, doubleArray7 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8, false);
        double[] doubleArray13 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13);
        double[] doubleArray15 = array2DRowRealMatrix10.preMultiply(doubleArray13);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector3.ebeMultiply(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 100 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getNorm();
        org.apache.commons.math.linear.RealVector realVector3 = openMapRealVector0.mapMultiply(5.298292365610485d);
        org.apache.commons.math.linear.RealVector realVector4 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = openMapRealVector0.append(realVector4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(realVector3);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        double[] doubleArray8 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = openMapRealVector5.append(doubleArray8);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = openMapRealVector10.copy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction12 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector10.mapToSelf(univariateRealFunction12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(openMapRealVector10);
        org.junit.Assert.assertNotNull(openMapRealVector11);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double[] doubleArray29 = new double[] { 10.0f };
        double[] doubleArray31 = new double[] { 10.0f };
        double[][] doubleArray32 = new double[][] { doubleArray29, doubleArray31 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray32, true);
        int int37 = array2DRowRealMatrix36.getRowDimension();
        double[] doubleArray39 = new double[] { 10.0f };
        double[] doubleArray41 = new double[] { 10.0f };
        double[][] doubleArray42 = new double[][] { doubleArray39, doubleArray41 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray42, false);
        double[] doubleArray47 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        double[] doubleArray49 = array2DRowRealMatrix44.preMultiply(doubleArray47);
        double[] doubleArray50 = array2DRowRealMatrix36.preMultiply(doubleArray47);
        try {
            array2DRowRealMatrix6.setColumn(2, doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (2)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean3 = openMapRealVector0.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        int int7 = openMapRealVector5.getDimension();
        double double8 = openMapRealVector4.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector0.add(openMapRealVector4);
        org.apache.commons.math.linear.RealVector realVector10 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector11 = openMapRealVector9.add(realVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector9);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.6714254899876612d + "'", double0 == 0.6714254899876612d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        int int5 = openMapRealVector3.getDimension();
        double double6 = openMapRealVector2.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector3);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = openMapRealVector1.append((org.apache.commons.math.linear.RealVector) openMapRealVector2);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = openMapRealVector7.unitVector();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector7);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.0d, (double) (-127));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        double[] doubleArray24 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix21.preMultiply(doubleArray24);
        double double27 = array2DRowRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix21.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix21.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int34 = openMapRealVector33.getMinIndex();
        int int35 = openMapRealVector33.getDimension();
        org.apache.commons.math.linear.RealVector realVector37 = openMapRealVector33.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = new org.apache.commons.math.linear.OpenMapRealVector(realVector37);
        boolean boolean39 = array2DRowRealMatrix32.equals((java.lang.Object) openMapRealVector38);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector40 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int41 = openMapRealVector40.getMinIndex();
        boolean boolean43 = openMapRealVector40.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector45 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int46 = openMapRealVector45.getMinIndex();
        int int47 = openMapRealVector45.getDimension();
        double double48 = openMapRealVector44.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector45);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector49 = openMapRealVector40.add(openMapRealVector44);
        double[] doubleArray52 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray52);
        org.apache.commons.math.linear.RealVector realVector54 = openMapRealVector40.add(doubleArray52);
        try {
            double double55 = openMapRealVector38.getLInfDistance(doubleArray52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector54);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        double double3 = openIntToDoubleHashMap1.get((int) (short) 0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        try {
            int int5 = iterator4.key();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            double double13 = array2DRowRealMatrix10.getEntry((int) (short) 100, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double6 = openMapRealVector5.getNorm();
        org.apache.commons.math.linear.RealVector realVector7 = openMapRealVector1.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector5);
        boolean boolean8 = openMapRealVector1.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int10 = openMapRealVector9.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor11 = openMapRealVector9.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        int int14 = openMapRealVector12.getDimension();
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector12.mapDivideToSelf((double) (-1));
        int int17 = openMapRealVector12.getMinIndex();
        double double18 = openMapRealVector9.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector1.projection((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector1.mapMultiply((double) 10.0f);
        double double22 = openMapRealVector0.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        int int23 = openMapRealVector0.getMaxIndex();
        try {
            openMapRealVector0.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(entryItor11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix9 = array2DRowRealMatrix6.copy();
        double[] doubleArray11 = new double[] { 10.0f };
        double[] doubleArray13 = new double[] { 10.0f };
        double[][] doubleArray14 = new double[][] { doubleArray11, doubleArray13 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray14, false);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        double[] doubleArray21 = array2DRowRealMatrix16.preMultiply(doubleArray19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray19);
        try {
            double[] doubleArray23 = array2DRowRealMatrix6.operate(doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 2 != 1");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 127.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.scalarMultiply(0.8813735870195429d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix3.walkInRowOrder(realMatrixPreservingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-17), 3.8146973E-6f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-17.0f) + "'", float2 == (-17.0f));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double double27 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix6.getRowMatrix((int) (short) 0);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix6.power(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.append((double) 1L);
        double[] doubleArray4 = null;
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix5 = openMapRealVector1.outerProduct(doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int20 = openMapRealVector19.getMinIndex();
        int int21 = openMapRealVector19.getDimension();
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector19.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = openMapRealVector0.append((org.apache.commons.math.linear.RealVector) openMapRealVector19);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor27 = openMapRealVector25.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int29 = openMapRealVector28.getMinIndex();
        int int30 = openMapRealVector28.getDimension();
        org.apache.commons.math.linear.RealVector realVector32 = openMapRealVector28.mapDivideToSelf((double) (-1));
        int int33 = openMapRealVector28.getMinIndex();
        double double34 = openMapRealVector25.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector28);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor35 = openMapRealVector25.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector37 = openMapRealVector25.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector0.append(openMapRealVector37);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int40 = openMapRealVector39.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor41 = openMapRealVector39.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector42 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int43 = openMapRealVector42.getMinIndex();
        int int44 = openMapRealVector42.getDimension();
        org.apache.commons.math.linear.RealVector realVector46 = openMapRealVector42.mapDivideToSelf((double) (-1));
        int int47 = openMapRealVector42.getMinIndex();
        double double48 = openMapRealVector39.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector42);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor49 = openMapRealVector39.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector51 = openMapRealVector39.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector52 = openMapRealVector37.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector39);
        double[] doubleArray56 = new double[] { 10.0f };
        double[] doubleArray58 = new double[] { 10.0f };
        double[][] doubleArray59 = new double[][] { doubleArray56, doubleArray58 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix61 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix63 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray59, true);
        int int64 = array2DRowRealMatrix63.getRowDimension();
        double[] doubleArray66 = new double[] { 10.0f };
        double[] doubleArray68 = new double[] { 10.0f };
        double[][] doubleArray69 = new double[][] { doubleArray66, doubleArray68 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix71 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray69, false);
        double[] doubleArray74 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix75 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray74);
        double[] doubleArray76 = array2DRowRealMatrix71.preMultiply(doubleArray74);
        double[] doubleArray77 = array2DRowRealMatrix63.preMultiply(doubleArray74);
        try {
            org.apache.commons.math.linear.RealVector realVector78 = openMapRealVector37.combineToSelf((double) 97, 0.0d, doubleArray74);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(openMapRealVector24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(entryItor27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor35);
        org.junit.Assert.assertNotNull(openMapRealVector37);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(entryItor41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor49);
        org.junit.Assert.assertNotNull(openMapRealVector51);
        org.junit.Assert.assertNotNull(openMapRealVector52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 2 + "'", int64 == 2);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray77);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.9999999403953552d), (double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999940395531084d + "'", double2 == 0.9999940395531084d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 9.5367431640625E-7d, number1, number2);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        int int3 = openMapRealVector1.getDimension();
        double double4 = openMapRealVector0.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        boolean boolean10 = openMapRealVector7.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int13 = openMapRealVector12.getMinIndex();
        int int14 = openMapRealVector12.getDimension();
        double double15 = openMapRealVector11.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector12);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = openMapRealVector7.add(openMapRealVector11);
        double[] doubleArray19 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math.linear.RealVector realVector21 = openMapRealVector7.add(doubleArray19);
        try {
            org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector1.combineToSelf(0.9999940395531084d, (-0.7853981633974483d), doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean3 = openMapRealVector0.equals((java.lang.Object) 0.8342233605065102d);
        double[] doubleArray6 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getNorm();
        double[] doubleArray10 = new double[] { 10.0f };
        double[] doubleArray12 = new double[] { 10.0f };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray20 = array2DRowRealMatrix15.preMultiply(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray22 = array2DRowRealMatrix7.preMultiply(doubleArray18);
        try {
            double double23 = openMapRealVector0.getLInfDistance(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            double[] doubleArray2 = array2DRowRealMatrix0.getColumn((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (0)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int8 = openMapRealVector7.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double12 = openMapRealVector11.getNorm();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector7.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector11);
        double double14 = openMapRealVector4.getL1Distance(openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor16 = openMapRealVector15.sparseIterator();
        boolean boolean17 = openMapRealVector15.isNaN();
        org.apache.commons.math.linear.RealVector realVector19 = openMapRealVector15.mapMultiplyToSelf(1.4711276743037347d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector15.copy();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector7.ebeDivide((org.apache.commons.math.linear.RealVector) openMapRealVector20);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction22 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector20.mapToSelf(univariateRealFunction22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertNotNull(openMapRealVector21);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double double27 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int30 = openMapRealVector29.getMinIndex();
        boolean boolean32 = openMapRealVector29.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector34 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int35 = openMapRealVector34.getMinIndex();
        int int36 = openMapRealVector34.getDimension();
        double double37 = openMapRealVector33.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector34);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector29.add(openMapRealVector33);
        try {
            array2DRowRealMatrix6.setColumnVector((int) '#', (org.apache.commons.math.linear.RealVector) openMapRealVector29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector38);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getFrobeniusNorm();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int15 = openMapRealMatrix14.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix16 = openMapRealMatrix11.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = openMapRealMatrix8.add(openMapRealMatrix11);
        try {
            array2DRowRealMatrix3.setColumnMatrix((int) ' ', (org.apache.commons.math.linear.RealMatrix) openMapRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 97 + "'", int15 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix16);
        org.junit.Assert.assertNotNull(openMapRealMatrix17);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double double7 = array2DRowRealMatrix6.getNorm();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix6.walkInRowOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 20.0d + "'", double7 == 20.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1);
        boolean boolean2 = openMapRealVector1.isNaN();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector1.mapDivideToSelf(20.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double10 = openMapRealVector9.getNorm();
        org.apache.commons.math.linear.RealVector realVector11 = openMapRealVector5.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector9);
        boolean boolean12 = openMapRealVector5.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor15 = openMapRealVector13.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int17 = openMapRealVector16.getMinIndex();
        int int18 = openMapRealVector16.getDimension();
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector16.mapDivideToSelf((double) (-1));
        int int21 = openMapRealVector16.getMinIndex();
        double double22 = openMapRealVector13.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.RealVector realVector23 = openMapRealVector5.projection((org.apache.commons.math.linear.RealVector) openMapRealVector16);
        org.apache.commons.math.linear.RealVector realVector25 = openMapRealVector5.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector5.mapMultiplyToSelf(97.0d);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix28 = openMapRealVector1.outerProduct(realVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(entryItor15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(3.8146973E-6f, 57.29577951308232d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.8146977E-6f + "'", float2 == 3.8146977E-6f);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double14 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixChangingVisitor9, (int) (short) -1, (int) (short) 10, (-17), (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap((double) 'a');
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        boolean boolean3 = iterator2.hasNext();
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        double[] doubleArray27 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix28 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray27);
        double double29 = array2DRowRealMatrix28.getFrobeniusNorm();
        double[][] doubleArray30 = array2DRowRealMatrix28.getData();
        try {
            openMapRealMatrix14.setSubMatrix(doubleArray30, (int) (short) 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.0000001f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix0 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor1 = null;
        try {
            double double2 = array2DRowRealMatrix0.walkInColumnOrder(realMatrixChangingVisitor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        double[] doubleArray26 = new double[] { 10.0f };
        double[] doubleArray28 = new double[] { 10.0f };
        double[][] doubleArray29 = new double[][] { doubleArray26, doubleArray28 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix31 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray29, false);
        double double32 = array2DRowRealMatrix31.getNorm();
        double[][] doubleArray33 = array2DRowRealMatrix31.getDataRef();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix34 = openMapRealMatrix5.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 20.0d + "'", double32 == 20.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        try {
            array2DRowRealMatrix14.setEntry((int) '4', (int) '4', (double) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector((int) (short) -1);
        boolean boolean2 = openMapRealVector1.isNaN();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector1.mapDivideToSelf(20.0d);
        try {
            double[] doubleArray5 = openMapRealVector1.getData();
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 0, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        try {
            openMapRealMatrix30.setEntry(97, (-17), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray16 = new double[] { 10.0f };
        double[] doubleArray18 = new double[] { 10.0f };
        double[][] doubleArray19 = new double[][] { doubleArray16, doubleArray18 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray19, false);
        double[] doubleArray24 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray24);
        double[] doubleArray26 = array2DRowRealMatrix21.preMultiply(doubleArray24);
        double double27 = array2DRowRealMatrix21.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix21.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix31 = array2DRowRealMatrix21.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix21);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor33 = null;
        try {
            double double34 = array2DRowRealMatrix32.walkInColumnOrder(realMatrixPreservingVisitor33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix32);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix7 = array2DRowRealMatrix3.subtract((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 0x0");
        } catch (org.apache.commons.math.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int6 = openMapRealMatrix5.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix7 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = openMapRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 97 + "'", int6 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix7);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double56 = openMapRealMatrix50.walkInOptimizedOrder(realMatrixChangingVisitor51, 0, (int) (short) -1, 97, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        boolean boolean6 = openMapRealVector3.equals((java.lang.Object) 0.8342233605065102d);
        double double7 = openMapRealVector0.getL1Distance(openMapRealVector3);
        double[] doubleArray8 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector0.subtract(doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        double[] doubleArray13 = new double[] { 10.0f };
        double[] doubleArray15 = new double[] { 10.0f };
        double[][] doubleArray16 = new double[][] { doubleArray13, doubleArray15 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16, false);
        double[] doubleArray21 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray23 = array2DRowRealMatrix18.preMultiply(doubleArray21);
        double double24 = array2DRowRealMatrix18.getFrobeniusNorm();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix25 = openMapRealMatrix5.multiply((org.apache.commons.math.linear.RealMatrix) array2DRowRealMatrix18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 14.142135623730951d + "'", double24 == 14.142135623730951d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.tanh(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        double double13 = array2DRowRealMatrix12.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = array2DRowRealMatrix3.add(array2DRowRealMatrix12);
        double[] doubleArray17 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17);
        double double19 = array2DRowRealMatrix18.getNorm();
        int int20 = array2DRowRealMatrix18.getColumnDimension();
        double[] doubleArray22 = new double[] { 10.0f };
        double[] doubleArray24 = new double[] { 10.0f };
        double[][] doubleArray25 = new double[][] { doubleArray22, doubleArray24 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray25, false);
        double double28 = array2DRowRealMatrix27.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = array2DRowRealMatrix18.add(array2DRowRealMatrix27);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[] doubleArray39 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray39);
        double[] doubleArray41 = array2DRowRealMatrix36.preMultiply(doubleArray39);
        double double42 = array2DRowRealMatrix36.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix44 = array2DRowRealMatrix36.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix36.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix47 = array2DRowRealMatrix29.subtract(array2DRowRealMatrix36);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = array2DRowRealMatrix14.subtract(array2DRowRealMatrix36);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix53 = array2DRowRealMatrix48.getSubMatrix((int) '4', (int) '#', 2, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 20.0d + "'", double13 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 20.0d + "'", double28 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 14.142135623730951d + "'", double42 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(realMatrix46);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix47);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix48);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.543080634815244d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.232630319679133d + "'", double1 == 2.232630319679133d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        double[] doubleArray47 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        double double49 = array2DRowRealMatrix48.getNorm();
        int int50 = array2DRowRealMatrix48.getColumnDimension();
        double[] doubleArray52 = new double[] { 10.0f };
        double[] doubleArray54 = new double[] { 10.0f };
        double[][] doubleArray55 = new double[][] { doubleArray52, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double double58 = array2DRowRealMatrix57.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = array2DRowRealMatrix48.add(array2DRowRealMatrix57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = array2DRowRealMatrix23.add(array2DRowRealMatrix48);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix63 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix66 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix69 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int70 = openMapRealMatrix69.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix71 = openMapRealMatrix66.add(openMapRealMatrix69);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix72 = openMapRealMatrix63.add(openMapRealMatrix66);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix75 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix78 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix81 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int82 = openMapRealMatrix81.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix83 = openMapRealMatrix78.add(openMapRealMatrix81);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix84 = openMapRealMatrix75.add(openMapRealMatrix78);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix85 = openMapRealMatrix66.add(openMapRealMatrix75);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix86 = array2DRowRealMatrix23.preMultiply((org.apache.commons.math.linear.RealMatrix) openMapRealMatrix75);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 32 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20.0d + "'", double58 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix59);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix60);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 97 + "'", int70 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix71);
        org.junit.Assert.assertNotNull(openMapRealMatrix72);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 97 + "'", int82 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix83);
        org.junit.Assert.assertNotNull(openMapRealMatrix84);
        org.junit.Assert.assertNotNull(openMapRealMatrix85);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException(localizable0, (int) (short) 100, 4);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.8342233605065102d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5829620509346795E9d + "'", double2 == 3.5829620509346795E9d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.5430806348152437d, (java.lang.Number) 0.5403023058681398d, (java.lang.Number) 2.0000000000000004d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator2 = openIntToDoubleHashMap1.iterator();
        double double4 = openIntToDoubleHashMap1.get(0);
        org.junit.Assert.assertNotNull(iterator2);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix6.getColumnVector(0);
        double[] doubleArray12 = new double[] { 10.0f };
        double[] doubleArray14 = new double[] { 10.0f };
        double[][] doubleArray15 = new double[][] { doubleArray12, doubleArray14 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray15, false);
        double[] doubleArray19 = array2DRowRealMatrix17.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix20 = array2DRowRealMatrix17.copy();
        try {
            array2DRowRealMatrix6.setColumnMatrix((int) '#', realMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((int) (short) 10, 0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        double double3 = openMapRealVector0.getMaxValue();
        double[] doubleArray6 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getNorm();
        double[] doubleArray10 = new double[] { 10.0f };
        double[] doubleArray12 = new double[] { 10.0f };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray20 = array2DRowRealMatrix15.preMultiply(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray22 = array2DRowRealMatrix7.preMultiply(doubleArray18);
        try {
            double double23 = openMapRealVector0.getLInfDistance(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor17 = null;
        try {
            double double22 = array2DRowRealMatrix6.walkInRowOrder(realMatrixChangingVisitor17, (int) '4', 2, 97, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix27 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix30 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix33 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int34 = openMapRealMatrix33.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix35 = openMapRealMatrix30.add(openMapRealMatrix33);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix36 = openMapRealMatrix27.add(openMapRealMatrix30);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix39 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix42 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix45 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int46 = openMapRealMatrix45.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix47 = openMapRealMatrix42.add(openMapRealMatrix45);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix48 = openMapRealMatrix39.add(openMapRealMatrix42);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix49 = openMapRealMatrix30.add(openMapRealMatrix39);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix50 = openMapRealMatrix24.add(openMapRealMatrix30);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor51 = null;
        try {
            double double56 = openMapRealMatrix50.walkInColumnOrder(realMatrixChangingVisitor51, (int) (short) 100, (int) '#', (int) (short) -1, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 97 + "'", int34 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix35);
        org.junit.Assert.assertNotNull(openMapRealMatrix36);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 97 + "'", int46 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix47);
        org.junit.Assert.assertNotNull(openMapRealMatrix48);
        org.junit.Assert.assertNotNull(openMapRealMatrix49);
        org.junit.Assert.assertNotNull(openMapRealMatrix50);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        org.apache.commons.math.linear.RealMatrix realMatrix25 = null;
        try {
            org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix26 = openMapRealMatrix14.subtract(realMatrix25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getSparsity();
        double double2 = openMapRealVector0.getL1Norm();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.map(univariateRealFunction3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        double double3 = openIntToDoubleHashMap1.get((int) (short) 0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        try {
            iterator4.advance();
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.util.NoSuchElementException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        double[] doubleArray47 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray47);
        double double49 = array2DRowRealMatrix48.getNorm();
        int int50 = array2DRowRealMatrix48.getColumnDimension();
        double[] doubleArray52 = new double[] { 10.0f };
        double[] doubleArray54 = new double[] { 10.0f };
        double[][] doubleArray55 = new double[][] { doubleArray52, doubleArray54 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix57 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray55, false);
        double double58 = array2DRowRealMatrix57.getNorm();
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix59 = array2DRowRealMatrix48.add(array2DRowRealMatrix57);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix60 = array2DRowRealMatrix23.add(array2DRowRealMatrix48);
        try {
            org.apache.commons.math.linear.RealVector realVector62 = array2DRowRealMatrix23.getRowVector((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 20.0d + "'", double58 == 20.0d);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix59);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix60);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        int int6 = openMapRealVector5.getMinIndex();
        double[] doubleArray8 = new double[] { 10.0f };
        double[] doubleArray10 = new double[] { 10.0f };
        double[][] doubleArray11 = new double[][] { doubleArray8, doubleArray10 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray11, false);
        double[] doubleArray16 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray16);
        double[] doubleArray18 = array2DRowRealMatrix13.preMultiply(doubleArray16);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray16);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector5.subtract(openMapRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean3 = openMapRealVector0.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        int int7 = openMapRealVector5.getDimension();
        double double8 = openMapRealVector4.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector0.add(openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor12 = openMapRealVector10.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        int int15 = openMapRealVector13.getDimension();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapDivideToSelf((double) (-1));
        int int18 = openMapRealVector13.getMinIndex();
        double double19 = openMapRealVector10.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor20 = openMapRealVector10.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector10.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        int int27 = openMapRealVector25.getDimension();
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector25.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector22.combineToSelf((double) (byte) 1, (double) (byte) 10, realVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector0.ebeMultiply(realVector30);
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39, 0.0d);
        org.apache.commons.math.linear.RealVector realVector43 = openMapRealVector41.mapMultiply((double) '#');
        try {
            org.apache.commons.math.linear.RealVector realVector44 = openMapRealVector31.combineToSelf(9.53674316406539E-7d, 0.0d, realVector43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(entryItor12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector43);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray3);
        double double5 = array2DRowRealMatrix4.getFrobeniusNorm();
        double[][] doubleArray6 = array2DRowRealMatrix4.getData();
        double[][] doubleArray7 = array2DRowRealMatrix4.getDataRef();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException8.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double1 = openMapRealVector0.getSparsity();
        boolean boolean2 = openMapRealVector0.isInfinite();
        double[] doubleArray4 = new double[] { 10.0f };
        double[] doubleArray6 = new double[] { 10.0f };
        double[][] doubleArray7 = new double[][] { doubleArray4, doubleArray6 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray7, true);
        int int12 = array2DRowRealMatrix11.getRowDimension();
        double[] doubleArray14 = new double[] { 10.0f };
        double[] doubleArray16 = new double[] { 10.0f };
        double[][] doubleArray17 = new double[][] { doubleArray14, doubleArray16 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray17, false);
        double[] doubleArray22 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray22);
        double[] doubleArray24 = array2DRowRealMatrix19.preMultiply(doubleArray22);
        double[] doubleArray25 = array2DRowRealMatrix11.preMultiply(doubleArray22);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector26 = openMapRealVector0.projection(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double2 = org.apache.commons.math.util.FastMath.hypot(1.5707963267948966d, 9.536743164063946E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796326795186d + "'", double2 == 1.570796326795186d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        try {
            org.apache.commons.math.linear.RealVector realVector8 = array2DRowRealMatrix6.getRowVector((int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.scalarMultiply((-0.6193819415085411d));
        org.apache.commons.math.linear.RealMatrix realMatrix6 = array2DRowRealMatrix3.copy();
        try {
            double double7 = array2DRowRealMatrix3.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (2x1) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        try {
            double[] doubleArray18 = array2DRowRealMatrix6.getColumn((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 0.8342233605065102d, (java.lang.Number) 1L, (java.lang.Number) (short) -1);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = outOfRangeException4.getContext();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8342233605065102d + "'", number5.equals(0.8342233605065102d));
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        int int2 = openMapRealVector0.getDimension();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector(realVector4);
        int int6 = openMapRealVector5.getMinIndex();
        java.lang.Double[] doubleArray12 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12, 0.0d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector16 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12, 1.5430806348152437d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector18 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray12, (double) 9.536743E-7f);
        try {
            org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = openMapRealVector5.subtract((org.apache.commons.math.linear.RealVector) openMapRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.atanh(52.009614495783374d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray8 = array2DRowRealMatrix6.getRow(0);
        org.apache.commons.math.linear.RealMatrix realMatrix10 = array2DRowRealMatrix6.scalarAdd(1.3369844095223624d);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor11 = null;
        try {
            double double12 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix10);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        double double4 = array2DRowRealMatrix3.getNorm();
        int int5 = array2DRowRealMatrix3.getColumnDimension();
        double[] doubleArray7 = new double[] { 10.0f };
        double[] doubleArray9 = new double[] { 10.0f };
        double[][] doubleArray10 = new double[][] { doubleArray7, doubleArray9 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray10, false);
        try {
            array2DRowRealMatrix3.setSubMatrix(doubleArray10, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        try {
            double double12 = openMapRealMatrix5.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (97x32) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int2 = openMapRealVector1.getMinIndex();
        int int3 = openMapRealVector1.getDimension();
        double double4 = openMapRealVector0.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        try {
            double double6 = openMapRealVector1.getEntry((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-17));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-17.0d) + "'", double1 == (-17.0d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean2 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.RealVector realVector4 = openMapRealVector0.mapMultiplyToSelf(5.885277250018028d);
        openMapRealVector0.set(1.570796326795186d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int5 = openMapRealVector4.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double9 = openMapRealVector8.getNorm();
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector4.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector8);
        boolean boolean11 = openMapRealVector4.isNaN();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector4.mapMultiply((double) (short) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector1.append((org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.RealVector realVector16 = openMapRealVector1.mapMultiplyToSelf(3.5829620509346795E9d);
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8551464208140986d + "'", double1 == 3.8551464208140986d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        try {
            org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix6.getColumnVector(32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double double1 = org.apache.commons.math.util.FastMath.tanh(229.1831180523293d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        int int9 = array2DRowRealMatrix8.getRowDimension();
        try {
            array2DRowRealMatrix8.multiplyEntry((int) (short) -1, (-1), (double) 1.0000001f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor45 = null;
        try {
            double double50 = array2DRowRealMatrix6.walkInColumnOrder(realMatrixPreservingVisitor45, (int) '4', (int) (short) 0, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealVector realVector16 = array2DRowRealMatrix6.getColumnVector((int) (short) 0);
        try {
            double double19 = array2DRowRealMatrix6.getEntry(35, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4012984643248174E-45d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray2 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray2);
        org.apache.commons.math.linear.RealMatrix realMatrix5 = array2DRowRealMatrix3.scalarMultiply((-0.6193819415085411d));
        boolean boolean7 = array2DRowRealMatrix3.equals((java.lang.Object) 1.0E-12d);
        org.apache.commons.math.linear.RealVector realVector9 = null;
        try {
            array2DRowRealMatrix3.setColumnVector((-127), realVector9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-127)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        int int7 = array2DRowRealMatrix6.getColumnDimension();
        org.apache.commons.math.linear.RealVector realVector9 = array2DRowRealMatrix6.getColumnVector(0);
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = array2DRowRealMatrix6.walkInRowOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(realVector9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix46 = array2DRowRealMatrix23.getColumnMatrix((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        long long1 = org.apache.commons.math.util.FastMath.round(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix5 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int9 = openMapRealMatrix8.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix10 = openMapRealMatrix5.add(openMapRealMatrix8);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix11 = openMapRealMatrix2.add(openMapRealMatrix5);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix14 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix17 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix20 = new org.apache.commons.math.linear.OpenMapRealMatrix((int) 'a', (int) ' ');
        int int21 = openMapRealMatrix20.getRowDimension();
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix22 = openMapRealMatrix17.add(openMapRealMatrix20);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix23 = openMapRealMatrix14.add(openMapRealMatrix17);
        org.apache.commons.math.linear.OpenMapRealMatrix openMapRealMatrix24 = openMapRealMatrix5.add(openMapRealMatrix14);
        boolean boolean25 = openMapRealMatrix14.isSquare();
        try {
            double double26 = openMapRealMatrix14.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.linear.NonSquareMatrixException; message: non square (97x32) matrix");
        } catch (org.apache.commons.math.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 97 + "'", int9 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix10);
        org.junit.Assert.assertNotNull(openMapRealMatrix11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 97 + "'", int21 == 97);
        org.junit.Assert.assertNotNull(openMapRealMatrix22);
        org.junit.Assert.assertNotNull(openMapRealMatrix23);
        org.junit.Assert.assertNotNull(openMapRealMatrix24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double double27 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor28 = null;
        try {
            double double33 = array2DRowRealMatrix6.walkInRowOrder(realMatrixPreservingVisitor28, (int) (byte) -1, (int) (short) 10, 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter(9.094947E-13f, (-1.0d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.0949465E-13f + "'", float2 == 9.0949465E-13f);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        try {
            double[] doubleArray46 = array2DRowRealMatrix44.getColumn((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double double12 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix14 = array2DRowRealMatrix6.scalarMultiply(3.141592653589793d);
        org.apache.commons.math.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.scalarAdd((double) (short) 100);
        double[] doubleArray18 = new double[] { 10.0f };
        double[] doubleArray20 = new double[] { 10.0f };
        double[][] doubleArray21 = new double[][] { doubleArray18, doubleArray20 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray21, false);
        double[] doubleArray26 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray26);
        double[] doubleArray28 = array2DRowRealMatrix23.preMultiply(doubleArray26);
        double[][] doubleArray29 = array2DRowRealMatrix23.getData();
        double[] doubleArray32 = new double[] { 10.0f };
        double[] doubleArray34 = new double[] { 10.0f };
        double[][] doubleArray35 = new double[][] { doubleArray32, doubleArray34 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray35, false);
        double[] doubleArray40 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix41 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray40);
        double[] doubleArray42 = array2DRowRealMatrix37.preMultiply(doubleArray40);
        array2DRowRealMatrix23.setRow(0, doubleArray42);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix44 = array2DRowRealMatrix6.subtract(array2DRowRealMatrix23);
        boolean boolean45 = array2DRowRealMatrix23.isSquare();
        java.lang.String str46 = array2DRowRealMatrix23.toString();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 14.142135623730951d + "'", double12 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(array2DRowRealMatrix44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str46.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.543080634815244d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        double[] doubleArray9 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray9);
        double[] doubleArray11 = array2DRowRealMatrix6.preMultiply(doubleArray9);
        double[][] doubleArray12 = array2DRowRealMatrix6.getData();
        double[] doubleArray15 = new double[] { 10.0f };
        double[] doubleArray17 = new double[] { 10.0f };
        double[][] doubleArray18 = new double[][] { doubleArray15, doubleArray17 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18, false);
        double[] doubleArray23 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray23);
        double[] doubleArray25 = array2DRowRealMatrix20.preMultiply(doubleArray23);
        array2DRowRealMatrix6.setRow(0, doubleArray25);
        double double27 = array2DRowRealMatrix6.getFrobeniusNorm();
        org.apache.commons.math.linear.RealMatrix realMatrix29 = array2DRowRealMatrix6.getRowMatrix((int) (short) 0);
        double[] doubleArray31 = new double[] { 10.0f };
        double[] doubleArray33 = new double[] { 10.0f };
        double[][] doubleArray34 = new double[][] { doubleArray31, doubleArray33 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix36 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix38 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray34, false);
        double[][] doubleArray41 = array2DRowRealMatrix40.getData();
        try {
            array2DRowRealMatrix6.setSubMatrix(doubleArray41, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 14.142135623730951d + "'", double27 == 14.142135623730951d);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        boolean boolean3 = openMapRealVector0.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector5 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int6 = openMapRealVector5.getMinIndex();
        int int7 = openMapRealVector5.getDimension();
        double double8 = openMapRealVector4.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector5);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector9 = openMapRealVector0.add(openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector10 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int11 = openMapRealVector10.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor12 = openMapRealVector10.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector13 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int14 = openMapRealVector13.getMinIndex();
        int int15 = openMapRealVector13.getDimension();
        org.apache.commons.math.linear.RealVector realVector17 = openMapRealVector13.mapDivideToSelf((double) (-1));
        int int18 = openMapRealVector13.getMinIndex();
        double double19 = openMapRealVector10.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector13);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor20 = openMapRealVector10.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector10.mapAddToSelf((double) (-127));
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector25 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int26 = openMapRealVector25.getMinIndex();
        int int27 = openMapRealVector25.getDimension();
        org.apache.commons.math.linear.RealVector realVector29 = openMapRealVector25.mapDivideToSelf((double) (-1));
        org.apache.commons.math.linear.RealVector realVector30 = openMapRealVector22.combineToSelf((double) (byte) 1, (double) (byte) 10, realVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector31 = openMapRealVector0.ebeMultiply(realVector30);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector32 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double33 = openMapRealVector32.getSparsity();
        boolean boolean34 = openMapRealVector32.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector36 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector38 = openMapRealVector36.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector39 = openMapRealVector32.append(openMapRealVector38);
        try {
            double double40 = openMapRealVector31.cosine((org.apache.commons.math.linear.RealVector) openMapRealVector32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(entryItor12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor20);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(openMapRealVector31);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(openMapRealVector38);
        org.junit.Assert.assertNotNull(openMapRealVector39);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector((int) ' ', (int) (byte) 10, (double) 9.536743E-7f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double2 = org.apache.commons.math.util.FastMath.min(3.141592653589793d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.util.OpenIntToDoubleHashMap openIntToDoubleHashMap1 = new org.apache.commons.math.util.OpenIntToDoubleHashMap(10);
        double double3 = openIntToDoubleHashMap1.get((int) (short) 0);
        org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator iterator4 = openIntToDoubleHashMap1.iterator();
        double double7 = openIntToDoubleHashMap1.put((int) ' ', (double) 3.8146973E-6f);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertNotNull(iterator4);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(1);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector2 = new org.apache.commons.math.linear.OpenMapRealVector((org.apache.commons.math.linear.RealVector) openMapRealVector1);
        double[] doubleArray6 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray6);
        double double8 = array2DRowRealMatrix7.getNorm();
        double[] doubleArray10 = new double[] { 10.0f };
        double[] doubleArray12 = new double[] { 10.0f };
        double[][] doubleArray13 = new double[][] { doubleArray10, doubleArray12 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray13, false);
        double[] doubleArray18 = new double[] { (byte) 0, 1 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray18);
        double[] doubleArray20 = array2DRowRealMatrix15.preMultiply(doubleArray18);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray18);
        double[] doubleArray22 = array2DRowRealMatrix7.preMultiply(doubleArray18);
        try {
            openMapRealVector1.setSubVector((int) '4', doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector20 = openMapRealVector11.mapAdd(6.926634720831213E25d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int22 = openMapRealVector21.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor23 = openMapRealVector21.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int25 = openMapRealVector24.getMinIndex();
        int int26 = openMapRealVector24.getDimension();
        org.apache.commons.math.linear.RealVector realVector28 = openMapRealVector24.mapDivideToSelf((double) (-1));
        int int29 = openMapRealVector24.getMinIndex();
        double double30 = openMapRealVector21.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector24);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor31 = openMapRealVector21.iterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector21.mapAddToSelf((double) (-127));
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 100.0d, 1.7724538509055159d, 1.7724538509055159d, 6.691673596021348E41d, 0.36787944117144233d };
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector41 = new org.apache.commons.math.linear.OpenMapRealVector(doubleArray39, 0.0d);
        org.apache.commons.math.linear.RealVector realVector43 = openMapRealVector41.mapMultiply((double) '#');
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector44 = openMapRealVector21.append((org.apache.commons.math.linear.RealVector) openMapRealVector41);
        double[] doubleArray45 = openMapRealVector41.toArray();
        try {
            org.apache.commons.math.linear.RealMatrix realMatrix46 = openMapRealVector20.outerProduct(doubleArray45);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(openMapRealVector20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(entryItor23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(entryItor31);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(openMapRealVector44);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) 3L, 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3072.0f + "'", float2 == 3072.0f);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector1 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = openMapRealVector1.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int5 = openMapRealVector4.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double9 = openMapRealVector8.getNorm();
        org.apache.commons.math.linear.RealVector realVector10 = openMapRealVector4.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector8);
        boolean boolean11 = openMapRealVector4.isNaN();
        org.apache.commons.math.linear.RealVector realVector13 = openMapRealVector4.mapMultiply((double) (short) 100);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector14 = openMapRealVector1.append((org.apache.commons.math.linear.RealVector) openMapRealVector4);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector15 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double16 = openMapRealVector15.getSparsity();
        boolean boolean17 = openMapRealVector15.isInfinite();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector19 = new org.apache.commons.math.linear.OpenMapRealVector(0);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector21 = openMapRealVector19.append((double) 1L);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector22 = openMapRealVector15.append(openMapRealVector21);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector23 = openMapRealVector4.append((org.apache.commons.math.linear.RealVector) openMapRealVector22);
        org.apache.commons.math.linear.RealVector realVector26 = null;
        try {
            org.apache.commons.math.linear.RealVector realVector27 = openMapRealVector4.combine(1.543080634815244d, 1.2089258196146292E24d, realVector26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealVector3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(openMapRealVector14);
        org.junit.Assert.assertEquals((double) double16, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(openMapRealVector21);
        org.junit.Assert.assertNotNull(openMapRealVector22);
        org.junit.Assert.assertNotNull(openMapRealVector23);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        java.lang.String str12 = array2DRowRealMatrix11.toString();
        double[] doubleArray14 = null;
        try {
            array2DRowRealMatrix11.setRow((int) (short) 10, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Array2DRowRealMatrix{{10.0},{10.0}}" + "'", str12.equals("Array2DRowRealMatrix{{10.0},{10.0}}"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int1 = openMapRealVector0.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector4 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double5 = openMapRealVector4.getNorm();
        org.apache.commons.math.linear.RealVector realVector6 = openMapRealVector0.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector4);
        boolean boolean7 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector8 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int9 = openMapRealVector8.getMinIndex();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor10 = openMapRealVector8.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector11 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int12 = openMapRealVector11.getMinIndex();
        int int13 = openMapRealVector11.getDimension();
        org.apache.commons.math.linear.RealVector realVector15 = openMapRealVector11.mapDivideToSelf((double) (-1));
        int int16 = openMapRealVector11.getMinIndex();
        double double17 = openMapRealVector8.getL1Distance((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector18 = openMapRealVector0.projection((org.apache.commons.math.linear.RealVector) openMapRealVector11);
        org.apache.commons.math.linear.RealVector realVector20 = openMapRealVector0.mapMultiply((double) 10.0f);
        org.apache.commons.math.linear.RealVector realVector22 = openMapRealVector0.mapMultiplyToSelf(97.0d);
        boolean boolean23 = openMapRealVector0.isNaN();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector24 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int25 = openMapRealVector24.getMinIndex();
        boolean boolean27 = openMapRealVector24.equals((java.lang.Object) 0.8342233605065102d);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector28 = new org.apache.commons.math.linear.OpenMapRealVector();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector29 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int30 = openMapRealVector29.getMinIndex();
        int int31 = openMapRealVector29.getDimension();
        double double32 = openMapRealVector28.getLInfDistance((org.apache.commons.math.linear.RealVector) openMapRealVector29);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector33 = openMapRealVector24.add(openMapRealVector28);
        double double34 = openMapRealVector0.getDistance((org.apache.commons.math.linear.RealVector) openMapRealVector33);
        int int35 = openMapRealVector33.getMinIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(entryItor10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(openMapRealVector33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double[] doubleArray1 = new double[] { 10.0f };
        double[] doubleArray3 = new double[] { 10.0f };
        double[][] doubleArray4 = new double[][] { doubleArray1, doubleArray3 };
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, true);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4, false);
        org.apache.commons.math.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math.linear.RealMatrix realMatrix12 = array2DRowRealMatrix11.copy();
        org.apache.commons.math.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double14 = array2DRowRealMatrix11.walkInOptimizedOrder(realMatrixChangingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) 4, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.123105625617661d + "'", double2 == 4.123105625617661d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.acos(10000.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector0 = new org.apache.commons.math.linear.OpenMapRealVector();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor1 = openMapRealVector0.sparseIterator();
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor2 = openMapRealVector0.sparseIterator();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector3 = new org.apache.commons.math.linear.OpenMapRealVector();
        int int4 = openMapRealVector3.getMinIndex();
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector7 = new org.apache.commons.math.linear.OpenMapRealVector();
        double double8 = openMapRealVector7.getNorm();
        org.apache.commons.math.linear.RealVector realVector9 = openMapRealVector3.combine((double) '#', (double) 100L, (org.apache.commons.math.linear.RealVector) openMapRealVector7);
        boolean boolean10 = openMapRealVector0.equals((java.lang.Object) openMapRealVector7);
        org.apache.commons.math.linear.OpenMapRealVector openMapRealVector12 = openMapRealVector0.mapAdd(0.0d);
        java.util.Iterator<org.apache.commons.math.linear.RealVector.Entry> entryItor13 = openMapRealVector0.iterator();
        try {
            openMapRealVector0.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(entryItor1);
        org.junit.Assert.assertNotNull(entryItor2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(openMapRealVector12);
        org.junit.Assert.assertNotNull(entryItor13);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }
}

