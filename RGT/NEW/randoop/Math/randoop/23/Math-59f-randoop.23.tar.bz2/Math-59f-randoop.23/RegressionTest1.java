import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.6132200034871594d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-6435806226174469347L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode21 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode21 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode21.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        double double14 = mersenneTwister1.nextGaussian();
        org.apache.commons.math.random.MersenneTwister mersenneTwister16 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean17 = mersenneTwister16.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean20 = mersenneTwister19.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray29 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister22.nextBytes(byteArray29);
        mersenneTwister19.nextBytes(byteArray29);
        mersenneTwister16.nextBytes(byteArray29);
        mersenneTwister1.nextBytes(byteArray29);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.5542431572290581d) + "'", double14 == (-0.5542431572290581d));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(byteArray29);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4711276743037347d + "'", double2 == 1.4711276743037347d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException1 = new org.apache.commons.math.exception.MathRuntimeException(throwable0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.multiply(dfp13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15014728900887858d + "'", double1 == 0.15014728900887858d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getPi();
        int int14 = dfp13.intValue();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(10);
        int int25 = dfpField24.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp22.newInstance(dfp28);
        boolean boolean30 = dfp13.lessThan(dfp29);
        boolean boolean31 = dfp6.greaterThan(dfp13);
        boolean boolean32 = dfp13.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32760);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-8390142257432030400L) + "'", long2 == (-8390142257432030400L));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        boolean boolean2 = mersenneTwister1.nextBoolean();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.8404462775768939d) + "'", double3 == (-0.8404462775768939d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance(dfp21);
        boolean boolean23 = dfp9.greaterThan(dfp22);
        int int24 = dfp9.intValue();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp9.newInstance((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp9.getZero();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        int int30 = dfpField29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp33.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp37.newInstance();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp38.getZero();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp38.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfp41.getTwo();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp27.divide(dfp42);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 50 + "'", int24 == 50);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField4.newDfp((byte) 1, (byte) 0);
        java.lang.String str15 = dfp14.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0." + "'", str15.equals("0."));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.FastMath.min(1.4711276743037347d, 0.01468312461911342d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01468312461911342d + "'", double2 == 0.01468312461911342d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        dfpField1.setIEEEFlagsBits((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.getPi();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode28 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField21.setRoundingMode(roundingMode28);
        dfpField1.setRoundingMode(roundingMode28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + roundingMode28 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode28.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.5595356486071132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8353335930927298d) + "'", double1 == (-0.8353335930927298d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1), 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((byte) 3, (byte) 0);
        try {
            org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.newDfp(3850396226921085255L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5421596452126096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7363149089979162d + "'", double1 == 0.7363149089979162d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp6);
        int int10 = dfp9.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.newInstance(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.sqrt();
        double double19 = dfp17.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 3.14159265359d + "'", double19 == 3.14159265359d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField(10);
        int int5 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp8.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField14.getPi();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField24 = dfp23.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode25 = dfpField24.getRoundingMode();
        int int26 = dfpField24.getIEEEFlags();
        int int27 = dfpField24.getIEEEFlags();
        boolean boolean28 = dfp19.equals((java.lang.Object) int27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp8.divide(dfp19);
        int int30 = dfp8.log10K();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField32.newDfp(0.8414709848078964d);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(10);
        int int42 = dfpField41.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField44 = dfp43.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode45 = dfpField44.getRoundingMode();
        int int46 = dfpField44.getIEEEFlags();
        int int47 = dfpField44.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField44.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField44.getLn2();
        org.apache.commons.math.dfp.Dfp dfp51 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp39, dfp50);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(10);
        int int54 = dfpField53.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.getPi();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField53.newDfp(3);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField53.newDfp((double) 97L);
        boolean boolean61 = dfp60.isNaN();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp8.multiply(dfp60);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp2.subtract(dfp60);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpField24);
        org.junit.Assert.assertTrue("'" + roundingMode25 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode25.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 16 + "'", int26 == 16);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 16 + "'", int27 == 16);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfpField44);
        org.junit.Assert.assertTrue("'" + roundingMode45 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode45.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 16 + "'", int46 == 16);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 16 + "'", int47 == 16);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 4 + "'", int54 == 4);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4711276743037345d, 0.027737378443016106d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0107649686729185d + "'", double2 == 1.0107649686729185d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14254654307427736d) + "'", double1 == (-0.14254654307427736d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField21.getRoundingMode();
        int int23 = dfpField21.getIEEEFlags();
        int int24 = dfpField21.getIEEEFlags();
        boolean boolean25 = dfp16.equals((java.lang.Object) int24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp16);
        int int27 = dfp5.log10K();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.newDfp(0.8414709848078964d);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp40.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField41.getRoundingMode();
        int int43 = dfpField41.getIEEEFlags();
        int int44 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField41.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField41.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp36, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getPi();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp(3);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField50.newDfp((double) 97L);
        boolean boolean58 = dfp57.isNaN();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp5.multiply(dfp57);
        int int60 = dfp57.log10K();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpField41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1992523.6030499784d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3283064365386963E-10d + "'", double1 == 2.3283064365386963E-10d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.newInstance();
        int int9 = dfp8.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double1 = org.apache.commons.math.util.FastMath.tanh(49.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp6.divide(dfp19);
        boolean boolean22 = dfp21.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.3108324944320862d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("org.apache.commons.math.exception.NumberIsTooSmallException: -1 is smaller than, or equal to, the minimum (0)");
        try {
            org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(1985106079124746103L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField21.getRoundingMode();
        int int23 = dfpField21.getIEEEFlags();
        int int24 = dfpField21.getIEEEFlags();
        boolean boolean25 = dfp16.equals((java.lang.Object) int24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp16);
        int int27 = dfp5.log10K();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.newDfp(0.8414709848078964d);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp40.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField41.getRoundingMode();
        int int43 = dfpField41.getIEEEFlags();
        int int44 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField41.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField41.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp36, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getPi();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp(3);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField50.newDfp((double) 97L);
        boolean boolean58 = dfp57.isNaN();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp5.multiply(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpField41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dfp59);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException(throwable2, localizable3, localizable4, objArray11);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException12);
        java.lang.String str14 = mathRuntimeException13.toString();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) mathRuntimeException13);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str14.equals("org.apache.commons.math.exception.MathRuntimeException: "));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.1688976178093215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4109715535281262d + "'", double1 == 0.4109715535281262d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.7320508075688772d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField25 = dfp24.getField();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfpField25);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((byte) 3, (byte) 0);
        int int15 = dfp14.getRadixDigits();
        try {
            org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance(518826280430750969L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.sqrt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2626272556789118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) (byte) 100);
        boolean boolean15 = dfp12.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField4.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        float float2 = mersenneTwister0.nextFloat();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6459390728573390473L + "'", long1 == 6459390728573390473L);
//        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.71597457f + "'", float2 == 0.71597457f);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.7182818284590453d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long2 = org.apache.commons.math.util.FastMath.max(50L, 811257654569713386L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 811257654569713386L + "'", long2 == 811257654569713386L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        java.lang.Number number11 = numberIsTooSmallException10.getArgument();
        java.lang.Class<?> wildcardClass12 = numberIsTooSmallException10.getClass();
        java.lang.Object[] objArray13 = numberIsTooSmallException10.getArguments();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-0.8390715290764524d) + "'", number11.equals((-0.8390715290764524d)));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(objArray13);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) 10);
//        mersenneTwister4.setSeed(0L);
//        mersenneTwister4.setSeed(0);
//        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister((int) '#');
//        byte[] byteArray17 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
//        mersenneTwister10.nextBytes(byteArray17);
//        mersenneTwister4.nextBytes(byteArray17);
//        mersenneTwister0.nextBytes(byteArray17);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8703267376611990405L + "'", long1 == 8703267376611990405L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7058613994717777027L) + "'", long2 == (-7058613994717777027L));
//        org.junit.Assert.assertNotNull(byteArray17);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(10);
        int int3 = dfpField2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getPi();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) (short) 1);
        boolean boolean15 = dfp14.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField2.newDfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField2.getLn5();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField2.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField2.newDfp((byte) -1);
        dfpField2.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField2.setRoundingMode(roundingMode24);
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField2.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField2.newDfp((byte) 2);
        try {
            org.apache.commons.math.dfp.Dfp dfp29 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        int int5 = mersenneTwister1.nextInt(52);
        double double6 = mersenneTwister1.nextDouble();
        double double7 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7910618197763358337L) + "'", long2 == (-7910618197763358337L));
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.54060876f + "'", float3 == 0.54060876f);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 41 + "'", int5 == 41);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.20873039717178554d + "'", double6 == 0.20873039717178554d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.43948469167762516d + "'", double7 == 0.43948469167762516d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.getPi();
        int int14 = dfp13.intValue();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.multiply(16);
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField22.getRoundingMode();
        int int24 = dfpField22.getIEEEFlags();
        int int25 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField22.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField22.getLn2();
        int int29 = dfp28.classify();
        boolean boolean30 = dfp16.lessThan(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getPi();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(10);
        int int38 = dfpField37.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField37.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance((int) (short) 1);
        boolean boolean45 = dfp44.isNaN();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField32.newDfp(dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp28.divide(dfp44);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-4), (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '4', (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.8404462775768939d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.698921421520885d) + "'", double1 == (-0.698921421520885d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.dfp.DfpField dfpField3 = new org.apache.commons.math.dfp.DfpField(10);
        int int4 = dfpField3.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField3.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = dfpField6.getRoundingMode();
        java.lang.Object[] objArray8 = new java.lang.Object[] { dfpField6 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray8);
        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException9.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathIllegalArgumentException9.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertTrue("'" + roundingMode7 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode7.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathRuntimeException10.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathRuntimeException13.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8412810707398334d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6994104478184103d + "'", double1 == 0.6994104478184103d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        int int5 = dfpField1.getIEEEFlags();
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp33.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField34.getRoundingMode();
        int int36 = dfpField34.getIEEEFlags();
        int int37 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable29, (java.lang.Object[]) dfpArray38);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField54 = dfp53.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = dfpField54.getRoundingMode();
        int int56 = dfpField54.getIEEEFlags();
        int int57 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField54.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable49, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable29, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 32768);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpField54);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 16 + "'", int57 == 16);
        org.junit.Assert.assertNotNull(dfpArray58);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        boolean boolean11 = numberIsTooSmallException10.getBoundIsAllowed();
        java.lang.Number number12 = numberIsTooSmallException10.getArgument();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        boolean boolean24 = numberIsTooSmallException23.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException28 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException10, localizable25, localizable26, objArray27);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-0.8390715290764524d) + "'", number12.equals((-0.8390715290764524d)));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        java.lang.String str6 = dfp5.toString();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.floor();
        int int8 = dfp7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1." + "'", str6.equals("1."));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn2();
        java.lang.Class<?> wildcardClass10 = dfp9.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.multiply(100);
        java.lang.String str15 = dfp14.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "271.8281828459" + "'", str15.equals("271.8281828459"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.6536436208636119d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.47985289899508826d) + "'", double1 == (-0.47985289899508826d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField21.getRoundingMode();
        int int23 = dfpField21.getIEEEFlags();
        int int24 = dfpField21.getIEEEFlags();
        boolean boolean25 = dfp16.equals((java.lang.Object) int24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp16);
        int int27 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp5.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        float float2 = org.apache.commons.math.util.FastMath.max(0.27742445f, (float) 50L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 50.0f + "'", float2 == 50.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(97);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-4));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01831563888873418d + "'", double1 == 0.01831563888873418d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.185039863261519d) + "'", double1 == (-2.185039863261519d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.697783723013431d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.457072629302081d + "'", double1 == 7.457072629302081d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 97L, (float) (-8390142257432030400L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.multiply(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.newInstance((int) (short) 1);
        double double24 = dfp21.toDouble();
        boolean boolean25 = dfp14.unequal(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((byte) 1);
        int int30 = dfp29.classify();
        boolean boolean31 = dfp29.isNaN();
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp29);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + Double.NEGATIVE_INFINITY + "'", double24 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp12.newInstance((long) (-1));
        int int17 = dfp12.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 10);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (short) 10 + "'", number2.equals((short) 10));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0.54060876f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5406087636947631d + "'", double2 == 0.5406087636947631d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp5.newInstance(dfp11);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.getTwo();
        boolean boolean14 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray8);
        double double10 = mersenneTwister1.nextGaussian();
        float float11 = mersenneTwister1.nextFloat();
        double double12 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((long) 97);
        int[] intArray16 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister(intArray16);
        mersenneTwister1.setSeed(intArray16);
        mersenneTwister1.setSeed(0L);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.6132200034871594d) + "'", double10 == (-0.6132200034871594d));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.27742445f + "'", float11 == 0.27742445f);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.028125641006749857d + "'", double12 == 0.028125641006749857d);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        int int19 = dfp18.classify();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        int int1 = org.apache.commons.math.util.FastMath.round(0.20873034f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3850396226921085255L);
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.06432763482145239d) + "'", double2 == (-0.06432763482145239d));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7852853041876612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1930325328522464d + "'", double1 == 1.1930325328522464d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        mersenneTwister1.setSeed((long) (byte) 2);
        double double16 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.866531296165219d + "'", double16 == 0.866531296165219d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.3083496045548233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.26876649909134087d + "'", double1 == 0.26876649909134087d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        int int8 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance("1.");
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.floor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.017453292519943295d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4, (java.lang.Number) (byte) 2, false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField14.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((int) (short) 100);
        double double19 = dfp18.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField21.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp10.dotrap(10000, "", dfp18, dfp26);
        boolean boolean29 = dfp26.equals((java.lang.Object) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 9.999999999997595E99d + "'", double19 == 9.999999999997595E99d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.397318034091222d) + "'", double1 == (-0.397318034091222d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp33.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField34.getRoundingMode();
        int int36 = dfpField34.getIEEEFlags();
        int int37 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable29, (java.lang.Object[]) dfpArray38);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField54 = dfp53.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = dfpField54.getRoundingMode();
        int int56 = dfpField54.getIEEEFlags();
        int int57 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField54.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable49, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable29, (java.lang.Object[]) dfpArray58);
        java.lang.Number number61 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number61, (java.lang.Number) 1.717051822897322d, true);
        java.lang.Number number65 = numberIsTooSmallException64.getMin();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpField54);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 16 + "'", int57 == 16);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 1.717051822897322d + "'", number65.equals(1.717051822897322d));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 0.20873034f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2057758512625357d + "'", double1 == 0.2057758512625357d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        boolean boolean5 = dfp4.isInfinite();
        int int6 = dfp4.classify();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance((long) (-4));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        int int11 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getLn5();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp8.nextAfter(dfp15);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.5707963118937354d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        double double2 = mersenneTwister1.nextDouble();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7830674438602419d + "'", double2 == 0.7830674438602419d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.71518934f + "'", float3 == 0.71518934f);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        double double14 = mersenneTwister1.nextGaussian();
        int int15 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.5542431572290581d) + "'", double14 == (-0.5542431572290581d));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1734632850 + "'", int15 == 1734632850);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getPi();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.newInstance((int) (short) 1);
        boolean boolean20 = dfp19.isNaN();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField7.newDfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField7.getLn5();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField7.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField7.newDfp((byte) -1);
        dfpField7.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField7.newDfp(0.3083496045548233d);
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField7.getLn2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp33.floor();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField36.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField36.getPi();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField36.newDfp((double) 32768);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp34, dfp45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double2 = org.apache.commons.math.util.FastMath.max(0.4109715535281262d, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField21.getRoundingMode();
        int int23 = dfpField21.getIEEEFlags();
        int int24 = dfpField21.getIEEEFlags();
        boolean boolean25 = dfp16.equals((java.lang.Object) int24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp16);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.getOne();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getZero();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp32.getField();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(10);
        int int36 = dfpField35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp32.newInstance(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = org.apache.commons.math.dfp.Dfp.copysign(dfp28, dfp40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpField33);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException3.getSpecificPattern();
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException10);
        java.lang.String str12 = mathRuntimeException11.toString();
        java.lang.String str13 = mathRuntimeException11.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(10);
        int int27 = dfpField26.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField29 = dfp28.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode30 = dfpField29.getRoundingMode();
        int int31 = dfpField29.getIEEEFlags();
        int int32 = dfpField29.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField29.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable24, (java.lang.Object[]) dfpArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable19, (java.lang.Number) 1.718281828459045d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException40 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooSmallException40.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooSmallException45.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(10);
        int int49 = dfpField48.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField51 = dfp50.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode52 = dfpField51.getRoundingMode();
        int int53 = dfpField51.getIEEEFlags();
        int int54 = dfpField51.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField51.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable46, (java.lang.Object[]) dfpArray55);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException58 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable46, (java.lang.Number) 100.0f);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException62 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable63 = numberIsTooSmallException62.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException67 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable68 = numberIsTooSmallException67.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Throwable throwable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable71 = null;
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray79 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException80 = new org.apache.commons.math.exception.MathRuntimeException(throwable70, localizable71, localizable72, objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable68, objArray79);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException83 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException11, localizable19, localizable46, objArray79);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str12.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathRuntimeException: " + "'", str13.equals("org.apache.commons.math.exception.MathRuntimeException: "));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfpField29);
        org.junit.Assert.assertTrue("'" + roundingMode30 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode30.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 16 + "'", int32 == 16);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpField51);
        org.junit.Assert.assertTrue("'" + roundingMode52 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode52.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 16 + "'", int53 == 16);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 16 + "'", int54 == 16);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        double double12 = dfp11.toDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.power10K(32760);
        boolean boolean15 = dfp7.lessThan(dfp14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.732050807569d + "'", double12 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getLn10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.sin((-48.07525732566926d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8142102082694508d + "'", double1 == 0.8142102082694508d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        int[] intArray1 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        boolean boolean3 = mersenneTwister2.nextBoolean();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.2626272556789118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.262627255678912d + "'", double1 == 1.262627255678912d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField8.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField4.newDfp(dfp20);
        try {
            org.apache.commons.math.dfp.Dfp dfp23 = dfpField4.newDfp(8098045977194093303L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0986122886681098d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4160734237838899d) + "'", double1 == (-0.4160734237838899d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.multiply((int) '4');
        double[] doubleArray8 = dfp7.toSplitDouble();
        java.lang.Class<?> wildcardClass9 = dfp7.getClass();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        mersenneTwister1.setSeed((long) (byte) 2);
        float float16 = mersenneTwister1.nextFloat();
        byte[] byteArray23 = new byte[] { (byte) 2, (byte) 2, (byte) 100, (byte) 1, (byte) 3, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray23);
        long long25 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.011451006f + "'", float16 == 0.011451006f);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 6055211826408817467L + "'", long25 == 6055211826408817467L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000142d + "'", double1 == 1.0000000000000142d);
    }

//    @Test
//    public void test147() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test147");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        long long2 = mersenneTwister0.nextLong();
//        boolean boolean3 = mersenneTwister0.nextBoolean();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-870835591897652727L) + "'", long1 == (-870835591897652727L));
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1276500887693107077L + "'", long2 == 1276500887693107077L);
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp33.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField34.getRoundingMode();
        int int36 = dfpField34.getIEEEFlags();
        int int37 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable29, (java.lang.Object[]) dfpArray38);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField54 = dfp53.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = dfpField54.getRoundingMode();
        int int56 = dfpField54.getIEEEFlags();
        int int57 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField54.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable49, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable29, (java.lang.Object[]) dfpArray58);
        java.lang.Throwable[] throwableArray61 = mathIllegalArgumentException60.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpField54);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 16 + "'", int57 == 16);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertNotNull(throwableArray61);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField4.getLn5();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField4.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        boolean boolean11 = numberIsTooSmallException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException10.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 2979.3805346802806d, (java.lang.Number) 2, true);
        java.lang.Number number17 = numberIsTooSmallException16.getMin();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2 + "'", number17.equals(2));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) -1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.8342233605065122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2018675485198727d + "'", double1 == 1.2018675485198727d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        int int16 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getPi();
        int int24 = dfp23.intValue();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp32.newInstance(dfp38);
        boolean boolean40 = dfp23.lessThan(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField1.newDfp(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 3);
        int int7 = dfp3.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.732050807569d + "'", double4 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        int[] intArray1 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        int int5 = mersenneTwister3.nextInt((int) (byte) 3);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0.43899584f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.76001144844555d + "'", double1 == 0.76001144844555d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 10);
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        int int8 = dfp7.log10K();
        try {
            org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance(3714922229009598539L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7764722807237177d + "'", double1 == 2.7764722807237177d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1), (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField4.getLn2();
        int int13 = dfp12.log10K();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        int int16 = dfpField15.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp20.sqrt();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp12.multiply(dfp20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1885473257, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.885473257E9d + "'", double2 == 1.885473257E9d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7363149089979162d, 8.000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7363149089979163d + "'", double2 == 0.7363149089979163d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 100);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.4711276743037345d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.7585966211538528d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits(50);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.698921421520885d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException(throwable11, localizable12, localizable13, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 52.0d, (java.lang.Number) 5.298292365610485d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        dfpField1.setIEEEFlags(3);
        int int21 = dfpField1.getRadixDigits();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField1.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(dfpArray23);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(3L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        int int10 = dfp8.intValue();
        int int11 = dfp8.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 50L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6050701709847575d + "'", double1 == 4.6050701709847575d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        int int16 = dfpField1.getRadixDigits();
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.newDfp((double) 2);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.FastMath.min(2, 1827195186);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((int) '#');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField14.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getOne();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10((int) (short) 100);
        double double19 = dfp18.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        int int22 = dfpField21.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField21.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp(100);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp10.dotrap(10000, "", dfp18, dfp26);
        boolean boolean28 = dfp18.isNaN();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp18.multiply(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 9.999999999997595E99d + "'", double19 == 9.999999999997595E99d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.4342944819032518d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField2.clearIEEEFlags();
        dfpField2.setIEEEFlagsBits((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField2.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp14.getOne();
        try {
            org.apache.commons.math.dfp.Dfp dfp16 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp7, dfp15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32768);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.newInstance(dfp10);
        int int12 = dfp10.classify();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.ceil();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 1.718281828459045d);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.getPi();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField23.getPi();
        dfpField23.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField23.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray33);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number35, (java.lang.Number) 1.4426924270692643d, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException38);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfpArray33);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.power10((int) ' ');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        long long1 = org.apache.commons.math.util.FastMath.round(0.8342233605065122d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((double) 97L);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray8 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray8);
        double double10 = mersenneTwister1.nextGaussian();
        float float11 = mersenneTwister1.nextFloat();
        float float12 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.6132200034871594d) + "'", double10 == (-0.6132200034871594d));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.27742445f + "'", float11 == 0.27742445f);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.028125525f + "'", float12 == 0.028125525f);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.457072629302081d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp(3.466711037884725d);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.732050807569d + "'", double4 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.6050701709847575d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08037363676906226d + "'", double1 == 0.08037363676906226d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1985106079124746103L, (java.lang.Number) 0.8414709848078964d, false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        mersenneTwister1.setSeed((long) (-32767));
        mersenneTwister1.setSeed((long) (short) 10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode23);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField1.newDfp();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp(1);
        java.lang.String str13 = dfp12.toString();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.power10K((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance("0.0e0");
        boolean boolean18 = dfp5.unequal(dfp12);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.multiply((int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "1." + "'", str13.equals("1."));
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double2 = org.apache.commons.math.util.FastMath.max(11.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.log(50.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.912023005428146d + "'", double1 == 3.912023005428146d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(10.067661995777767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1592828834995985d + "'", double1 == 2.1592828834995985d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3678794411714424d + "'", double1 == 0.3678794411714424d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(10.000000000000002d);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        java.lang.Class<?> wildcardClass7 = dfpArray6.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.getLn2();
        int int11 = dfp10.classify();
        int int12 = dfp10.intValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        int int8 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((byte) 0, (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 100.0f);
        java.lang.Number number22 = notStrictlyPositiveException21.getMin();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0 + "'", number22.equals(0));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.add(dfp12);
        boolean boolean14 = dfp7.isNaN();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.141592653589793d + "'", double1 == 3.141592653589793d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.power10K(32760);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.getZero();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 1);
        int int13 = dfp12.classify();
        boolean boolean14 = dfp12.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.multiply(dfp12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.732050807569d + "'", double4 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 3, 0.6968571139373588d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.9088028108306494d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8449867046751653d) + "'", double1 == (-2.8449867046751653d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 2.768659383313574d, (java.lang.Number) (-7.9106181977633587E18d), false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.add(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getPi();
        int int21 = dfp20.intValue();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.newInstance(dfp35);
        boolean boolean37 = dfp23.greaterThan(dfp36);
        int int38 = dfp23.intValue();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp23.getOne();
        boolean boolean40 = dfp13.unequal(dfp23);
        double double41 = dfp13.toDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 50 + "'", int38 == 50);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 4.141592653592d + "'", double41 == 4.141592653592d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2626272556789115d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 52, (java.lang.Number) 0.8623188722876839d, false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        mersenneTwister1.setSeed((long) (byte) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int[] intArray21 = new int[] { (-1), '4', (byte) -1 };
        mersenneTwister17.setSeed(intArray21);
        mersenneTwister1.setSeed(intArray21);
        mersenneTwister1.setSeed((long) '4');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.asinh(50.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605270170991424d + "'", double1 == 4.605270170991424d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp13.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.newInstance(dfp29);
        boolean boolean31 = dfp13.greaterThan(dfp23);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp7.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.getPi();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField34.getPi();
        dfpField34.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField34.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp32.nextAfter(dfp44);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.asinh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        mersenneTwister1.setSeed(0L);
        mersenneTwister1.setSeed((long) 52);
        mersenneTwister1.setSeed(35);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.add(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField15.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField15.getPi();
        int int21 = dfp20.intValue();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp29.newInstance(dfp35);
        boolean boolean37 = dfp23.greaterThan(dfp36);
        int int38 = dfp23.intValue();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp23.getOne();
        boolean boolean40 = dfp13.unequal(dfp23);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp13.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 50 + "'", int38 == 50);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) 32768);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getPi();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.newInstance(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = new org.apache.commons.math.dfp.Dfp(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp17.divide(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField1.newDfp(dfp30);
        dfpField1.setIEEEFlags(10);
        dfpField1.setIEEEFlagsBits(0);
        dfpField1.setIEEEFlagsBits((-1));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.5542431572290581d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1575650081021094d + "'", double1 == 1.1575650081021094d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance(dfp21);
        boolean boolean23 = dfp6.lessThan(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.floor();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp24.newInstance(0L);
        org.apache.commons.math.dfp.Dfp dfp29 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp30 = dfp28.add(dfp29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '4');
        double double2 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.823110339393827d + "'", double2 == 0.823110339393827d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int2 = org.apache.commons.math.util.FastMath.min((-1), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 1);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance(dfp21);
        boolean boolean23 = dfp5.greaterThan(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr3();
        double double28 = dfp27.toDouble();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32760);
        boolean boolean31 = dfp15.lessThan(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField33.getPi();
        int int39 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp38.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField43.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(10);
        int int50 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp47.newInstance(dfp53);
        boolean boolean55 = dfp38.lessThan(dfp54);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.floor();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp15.newInstance(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.newInstance((double) 50L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.732050807569d + "'", double28 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 3 + "'", int39 == 3);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        java.lang.String str8 = dfp7.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "1.414213562373" + "'", str8.equals("1.414213562373"));
    }

//    @Test
//    public void test247() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test247");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        double double1 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed(1);
//        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.306206778236924d) + "'", double1 == (-1.306206778236924d));
//    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance((long) 'a');
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        boolean boolean18 = dfp16.isNaN();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp16.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0);
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp7.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = dfpField8.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getOne();
        int int18 = dfpField10.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode19 = dfpField10.getRoundingMode();
        dfpField1.setRoundingMode(roundingMode19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode19 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode19.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.getPi();
        int int15 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp7.newInstance(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(10.000000000000002d);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp16.add(dfp22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        int[] intArray1 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        long long3 = mersenneTwister2.nextLong();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-7906226569145254223L) + "'", long3 == (-7906226569145254223L));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField4.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField4.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfpArray11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getSqr2Split();
        dfpField1.setIEEEFlags((int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long2 = org.apache.commons.math.util.FastMath.min(3850396226921085255L, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp10.newInstance((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.newInstance((long) (-32767));
        java.lang.String str17 = dfp13.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "32." + "'", str17.equals("32."));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 6459390728573390473L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7009582697318914E20d + "'", double1 == 3.7009582697318914E20d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(11.090354888726294d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2300528109062983d + "'", double1 == 2.2300528109062983d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getESplit();
        int int14 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance(dfp21);
        boolean boolean23 = dfp9.greaterThan(dfp22);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp9.power10(32768);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.negate();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getPi();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField48 = dfp47.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode49 = dfpField48.getRoundingMode();
        int int50 = dfpField48.getIEEEFlags();
        int int51 = dfpField48.getIEEEFlags();
        boolean boolean52 = dfp43.equals((java.lang.Object) int51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp32.divide(dfp43);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp32.getOne();
        boolean boolean55 = dfp26.unequal(dfp32);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpField48);
        org.junit.Assert.assertTrue("'" + roundingMode49 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode49.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 16 + "'", int50 == 16);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 16 + "'", int51 == 16);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        int[] intArray1 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        mersenneTwister4.setSeed((int) '4');
        float float7 = mersenneTwister4.nextFloat();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8231102f + "'", float7 == 0.8231102f);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9999999958776927d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField12.getRoundingMode();
        int int14 = dfpField12.getIEEEFlags();
        int int15 = dfpField12.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp(10);
        int int18 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp7.nextAfter(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = null;
        try {
            boolean boolean22 = dfp19.unequal(dfp21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 518826280430750969L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 6459390728573390473L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.00521385333707d + "'", double1 == 44.00521385333707d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8745129512124437d + "'", double1 == 0.8745129512124437d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1276500887693107077L, (double) (-1841834327));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963282377742d + "'", double2 == 1.5707963282377742d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((long) 10000);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.0d);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 5 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 5 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.14254654307427736d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14254654307427736d + "'", double1 == 0.14254654307427736d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 3714922229009598539L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(50);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.newInstance(dfp8);
        double double10 = dfp3.toDouble();
        int int11 = dfp3.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5773502691895d + "'", double10 == 0.5773502691895d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        int int19 = dfp18.classify();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.getPi();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.getPi();
        int int34 = dfp33.intValue();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.multiply(16);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp26, dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp37.multiply(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp18.subtract(dfp39);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 3 + "'", int34 == 3);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.4685363946133843d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.76001144844555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6498777062466391d + "'", double1 == 0.6498777062466391d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9092974268256817d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField17.getRoundingMode();
        int int19 = dfpField17.getIEEEFlags();
        int int20 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField17.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable12, (java.lang.Object[]) dfpArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException(throwable24, localizable25, localizable26, objArray33);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException34);
        java.lang.Throwable[] throwableArray36 = mathRuntimeException34.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable7, localizable23, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooSmallException41.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getSpecificPattern();
        java.lang.Object[] objArray50 = numberIsTooSmallException48.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray50);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.9092974268256817d + "'", number2.equals(0.9092974268256817d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        int int8 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((long) (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField11.clearIEEEFlags();
        dfpField11.setIEEEFlagsBits((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.newDfp((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp17 = org.apache.commons.math.dfp.DfpField.computeExp(dfp6, dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField19.getPi();
        int int25 = dfp24.intValue();
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp24);
        double[] doubleArray27 = dfp24.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance("org.apache.commons.math.exception.MathRuntimeException: ");
        int int30 = dfp24.classify();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp16.subtract(dfp24);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance(dfp21);
        boolean boolean23 = dfp9.greaterThan(dfp22);
        int int24 = dfp9.intValue();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp9.newInstance((byte) 3);
        int int27 = dfp9.classify();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp9.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 50 + "'", int24 == 50);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        org.apache.commons.math.dfp.Dfp dfp7 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp6, dfp7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        dfpField1.setIEEEFlags(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.7830674438602419d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-4));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        dfpField1.setIEEEFlags(4);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.newDfp((byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed(1985106079124746103L);
        try {
            int int6 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5711645232847797d + "'", double2 == 0.5711645232847797d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.167018102622959d + "'", double1 == 1.167018102622959d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9262160379374064d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1842485417082624d + "'", double1 == 1.1842485417082624d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999998d) + "'", double1 == (-0.9999999999999998d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.getTwo();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.sqrt();
        int int19 = dfp18.log10K();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10K(1885473257);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp2.power10K(52);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        mersenneTwister1.setSeed((long) (byte) 2);
        float float16 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean19 = mersenneTwister18.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray28 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister21.nextBytes(byteArray28);
        mersenneTwister18.nextBytes(byteArray28);
        mersenneTwister18.setSeed((long) (byte) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister34 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int[] intArray38 = new int[] { (-1), '4', (byte) -1 };
        mersenneTwister34.setSeed(intArray38);
        mersenneTwister18.setSeed(intArray38);
        mersenneTwister1.setSeed(intArray38);
        int int42 = mersenneTwister1.nextInt();
        long long43 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.011451006f + "'", float16 == 0.011451006f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1827195186 + "'", int42 == 1827195186);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 4770089855421144657L + "'", long43 == 4770089855421144657L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8342233605065122d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6066211551353755d + "'", double1 == 0.6066211551353755d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField22.getRoundingMode();
        int int24 = dfpField22.getIEEEFlags();
        int int25 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField22.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable17, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException36.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(10);
        int int40 = dfpField39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = dfp41.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = dfpField42.getRoundingMode();
        int int44 = dfpField42.getIEEEFlags();
        int int45 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField42.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable37, (java.lang.Object[]) dfpArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException51.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(10);
        int int60 = dfpField59.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp61.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode63 = dfpField62.getRoundingMode();
        int int64 = dfpField62.getIEEEFlags();
        int int65 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField62.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable57, (java.lang.Object[]) dfpArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable37, (java.lang.Object[]) dfpArray66);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException72 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 10.000000000000002d, (java.lang.Number) (-0.653643620863612d), false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable77 = numberIsTooSmallException76.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable77, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException83 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable77, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        boolean boolean84 = numberIsTooSmallException83.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable85 = numberIsTooSmallException83.getGeneralPattern();
        java.lang.Object[] objArray86 = null;
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException87 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3, localizable37, localizable85, objArray86);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpField42);
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 16 + "'", int45 == 16);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertTrue("'" + roundingMode63 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode63.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 16 + "'", int64 == 16);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + localizable85 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable85.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999958776927d + "'", double1 == 0.9999999958776927d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode13 = dfpField12.getRoundingMode();
        int int14 = dfpField12.getIEEEFlags();
        int int15 = dfpField12.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp(10);
        int int18 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp7.nextAfter(dfp19);
        int int21 = dfp7.log10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
        org.junit.Assert.assertTrue("'" + roundingMode13 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode13.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 16 + "'", int14 == 16);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 16 + "'", int15 == 16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.getLn10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray7 = notStrictlyPositiveException6.getArguments();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        boolean boolean10 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp5.newInstance(dfp14);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.sqrt();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.power10(35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (short) 1 + "'", number2.equals((short) 1));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.5242652888812924d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5028093737846485d + "'", double1 == 0.5028093737846485d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        int[] intArray1 = new int[] { (short) 10 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.junit.Assert.assertNotNull(intArray1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfp5.add(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.3283064365386963E-10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.063661331297666E-12d + "'", double1 == 4.063661331297666E-12d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField4.getLn2();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField4.getSqr2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode4);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(0.9262160379374064d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.floor();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(10);
        int int10 = dfpField9.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp7.add(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.floor();
        boolean boolean15 = dfp14.isInfinite();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.397318034091222d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.log(0.15071724896777527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8923497209230051d) + "'", double1 == (-1.8923497209230051d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.log(2.8738416883730777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.05564970206626d + "'", double1 == 1.05564970206626d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.newDfp((double) 0.43899584f);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getOne();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.divide((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField(10);
        int int3 = dfpField2.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getPi();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(10);
        int int8 = dfpField7.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((int) (short) 1);
        boolean boolean15 = dfp14.isNaN();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField2.newDfp(dfp14);
        int int17 = dfpField2.getRadixDigits();
        dfpField2.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField2.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray20);
        java.lang.String str22 = mathIllegalArgumentException21.toString();
        java.lang.Throwable throwable23 = null;
        try {
            mathIllegalArgumentException21.addSuppressed(throwable23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str22.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 7.457072629302081d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.5595356486071132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40816118267920876d + "'", double1 == 0.40816118267920876d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.912023005428146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5756767737916322d + "'", double1 == 1.5756767737916322d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 4770089855421144657L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1683354.250832541d + "'", double1 == 1683354.250832541d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K(50);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField12.newDfp((long) (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp10.multiply(dfp19);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((long) (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        long long1 = org.apache.commons.math.util.FastMath.round(1.2626272556789115d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 1, (java.lang.Number) 0.3083495f, true);
        java.lang.Number number11 = numberIsTooSmallException10.getArgument();
        boolean boolean12 = numberIsTooSmallException10.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooSmallException10.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 1 + "'", number11.equals((short) 1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3776033183918697E14d + "'", double1 == 2.3776033183918697E14d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.log(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.242924991852436d + "'", double1 == 1.242924991852436d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.multiply((int) '4');
        int int8 = dfp3.classify();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp3.negate();
        boolean boolean10 = dfp9.isNaN();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField12.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.getPi();
        int int18 = dfp17.intValue();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp17.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField22.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        int int29 = dfpField28.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp26.newInstance(dfp32);
        boolean boolean34 = dfp17.lessThan(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getZero();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp36.getOne();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp9.divide(dfp36);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray24 = dfpField1.getPiSplit();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfpArray24);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Throwable[] throwableArray4 = notStrictlyPositiveException1.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        java.lang.String str8 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((long) 3);
        java.lang.Class<?> wildcardClass10 = dfp9.getClass();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.ceil();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed((long) 32768);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-0.5063656411097588d), (java.lang.Number) 97.0f, false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp8 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp6);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.5773502691895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((long) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp6.multiply(97);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        java.lang.Number number11 = numberIsTooSmallException10.getMin();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooSmallException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable16, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 0.9092974268256817d);
        numberIsTooSmallException10.addSuppressed((java.lang.Throwable) notStrictlyPositiveException25);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 50 + "'", number11.equals(50));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 0, (byte) -1);
        java.lang.String str8 = dfp7.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "NaN" + "'", str8.equals("NaN"));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(10000);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp7.floor();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp7.newInstance("2.");
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance((double) (-1L));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.8414709848078965d), 2.7764722807237177d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8414709848078964d) + "'", double2 == (-0.8414709848078964d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException23.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooSmallException28.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField34 = dfp33.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode35 = dfpField34.getRoundingMode();
        int int36 = dfpField34.getIEEEFlags();
        int int37 = dfpField34.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray38 = dfpField34.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable29, (java.lang.Object[]) dfpArray38);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooSmallException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField(10);
        int int52 = dfpField51.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField54 = dfp53.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode55 = dfpField54.getRoundingMode();
        int int56 = dfpField54.getIEEEFlags();
        int int57 = dfpField54.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField54.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable44, localizable49, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable29, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) (-0.6132200034871594d), (java.lang.Number) 0.5242652888812924d, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpField34);
        org.junit.Assert.assertTrue("'" + roundingMode35 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode35.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 16 + "'", int36 == 16);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 16 + "'", int37 == 16);
        org.junit.Assert.assertNotNull(dfpArray38);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpField54);
        org.junit.Assert.assertTrue("'" + roundingMode55 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode55.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 16 + "'", int57 == 16);
        org.junit.Assert.assertNotNull(dfpArray58);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField21.getRoundingMode();
        int int23 = dfpField21.getIEEEFlags();
        int int24 = dfpField21.getIEEEFlags();
        boolean boolean25 = dfp16.equals((java.lang.Object) int24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp16);
        int int27 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.power10K((int) 'a');
        java.lang.String str30 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(10);
        int int33 = dfpField32.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField42.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField(10);
        int int49 = dfpField48.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp46.newInstance(dfp52);
        boolean boolean54 = dfp36.greaterThan(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(10);
        int int57 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getSqr3();
        double double59 = dfp58.toDouble();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp58.power10K(32760);
        boolean boolean62 = dfp46.lessThan(dfp61);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp5.nextAfter(dfp61);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "1." + "'", str30.equals("1."));
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.732050807569d + "'", double59 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(dfp63);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("hi!");
        double double9 = dfp8.toDouble();
        java.lang.String str10 = dfp8.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + Double.NEGATIVE_INFINITY + "'", double9 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0." + "'", str10.equals("0."));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.asin((-3.5069021104278923d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException(throwable11, localizable12, localizable13, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray20);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooSmallException27.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooSmallException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Throwable throwable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException45 = new org.apache.commons.math.exception.MathRuntimeException(throwable35, localizable36, localizable37, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable33, objArray44);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(10);
        int int50 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getPi();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField(10);
        int int55 = dfpField54.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField54.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.newInstance((int) (short) 1);
        boolean boolean62 = dfp61.isNaN();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField49.newDfp(dfp61);
        int int64 = dfpField49.getRadixDigits();
        dfpField49.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray67 = dfpField49.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, (java.lang.Object[]) dfpArray67);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException70 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray71 = notStrictlyPositiveException70.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable28, objArray71);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 1.2626272556789115d, (java.lang.Number) 1.1102230246251565E-16d, false);
        org.apache.commons.math.dfp.DfpField dfpField78 = new org.apache.commons.math.dfp.DfpField(10);
        int int79 = dfpField78.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField78.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField78.getPi();
        org.apache.commons.math.dfp.DfpField dfpField83 = new org.apache.commons.math.dfp.DfpField(10);
        int int84 = dfpField83.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField83.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp88 = dfpField83.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp88.newInstance((int) (short) 1);
        boolean boolean91 = dfp90.isNaN();
        org.apache.commons.math.dfp.Dfp dfp92 = dfpField78.newDfp(dfp90);
        int int93 = dfpField78.getRadixDigits();
        dfpField78.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray96 = dfpField78.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray97 = dfpField78.getESplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray97);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 4 + "'", int64 == 4);
        org.junit.Assert.assertNotNull(dfpArray67);
        org.junit.Assert.assertNotNull(objArray71);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 4 + "'", int79 == 4);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 4 + "'", int84 == 4);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 4 + "'", int93 == 4);
        org.junit.Assert.assertNotNull(dfpArray96);
        org.junit.Assert.assertNotNull(dfpArray97);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8142102082694508d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9337820351479189d + "'", double1 == 0.9337820351479189d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        int int16 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField18.getPi();
        int int24 = dfp23.intValue();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField28.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField(10);
        int int35 = dfpField34.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp32.newInstance(dfp38);
        boolean boolean40 = dfp23.lessThan(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField1.newDfp(dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField(10);
        int int45 = dfpField44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.getPi();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(10);
        int int50 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField49.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp54.newInstance((int) (short) 1);
        boolean boolean57 = dfp56.isNaN();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField44.newDfp(dfp56);
        int int59 = dfpField44.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray60 = dfpField44.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField44.newDfp((byte) 3);
        boolean boolean63 = dfp42.lessThan(dfp62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 3 + "'", int24 == 3);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 4 + "'", int50 == 4);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(dfpArray60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray11 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray11);
        mersenneTwister1.nextBytes(byteArray11);
        mersenneTwister1.setSeed((long) (byte) 2);
        float float16 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister18 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean19 = mersenneTwister18.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray28 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister21.nextBytes(byteArray28);
        mersenneTwister18.nextBytes(byteArray28);
        mersenneTwister18.setSeed((long) (byte) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister34 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int[] intArray38 = new int[] { (-1), '4', (byte) -1 };
        mersenneTwister34.setSeed(intArray38);
        mersenneTwister18.setSeed(intArray38);
        mersenneTwister1.setSeed(intArray38);
        org.apache.commons.math.random.MersenneTwister mersenneTwister42 = new org.apache.commons.math.random.MersenneTwister(intArray38);
        org.apache.commons.math.random.MersenneTwister mersenneTwister43 = new org.apache.commons.math.random.MersenneTwister(intArray38);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(byteArray11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.011451006f + "'", float16 == 0.011451006f);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(byteArray28);
        org.junit.Assert.assertNotNull(intArray38);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double2 = org.apache.commons.math.util.FastMath.max(Double.NaN, 1.1575650081021094d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField21.clearIEEEFlags();
        dfpField21.setIEEEFlagsBits((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp((byte) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode27 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField21.setRoundingMode(roundingMode27);
        dfpField1.setRoundingMode(roundingMode27);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + roundingMode27 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode27.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        double double4 = dfp3.toDouble();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 3);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp6.getField();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getPi();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.732050807569d + "'", double4 == 1.732050807569d);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getTwo();
        dfpField1.setIEEEFlagsBits(100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn5();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.expm1(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        int int16 = dfpField1.getRadixDigits();
        dfpField1.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray19 = dfpField1.getSqr2Split();
        int int20 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(dfpArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.3108324944320862d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-8390142257432030400L), (float) 16);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 16.0f + "'", float2 == 16.0f);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.88547328E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.275420382177447d + "'", double1 == 9.275420382177447d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(50);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int1 = org.apache.commons.math.util.FastMath.abs(1885473257);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1885473257 + "'", int1 == 1885473257);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        dfpField1.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField(10);
        int int24 = dfpField23.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp29 = dfp27.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(10);
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getPi();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.add(dfp34);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.DfpField.computeExp(dfp21, dfp35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 4 + "'", int32 == 4);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        long long1 = org.apache.commons.math.util.FastMath.round(0.014686439244896978d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 0.71597457f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, 8.0980461E18f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0980461E18f + "'", float2 == 8.0980461E18f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        int int7 = dfp6.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.multiply(16);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(10);
        int int18 = dfpField17.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp15.newInstance(dfp21);
        boolean boolean23 = dfp6.lessThan(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField25.getZero();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getTwo();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp22, dfp27);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NaN, (-1.0d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.8142102082694508d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08926345689729727d) + "'", double1 == (-0.08926345689729727d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 10000, (java.lang.Number) 0, true);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1985106079124746103L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        int int8 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.power10K(0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10000, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        long long3 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean6 = mersenneTwister5.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean9 = mersenneTwister8.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray18 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister11.nextBytes(byteArray18);
        mersenneTwister8.nextBytes(byteArray18);
        mersenneTwister5.nextBytes(byteArray18);
        mersenneTwister1.nextBytes(byteArray18);
        long long23 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 5805985991905072931L + "'", long3 == 5805985991905072931L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(byteArray18);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + (-3016645083903422023L) + "'", long23 == (-3016645083903422023L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 6055211826408817467L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField7.getLn2Split();
        int int9 = dfpField7.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(0.047442967903742035d);
        double[] doubleArray13 = dfp12.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.multiply((int) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.rint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.469446951953614E-18d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.358358837614592E-18d + "'", double2 == 2.358358837614592E-18d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance((byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(10);
        int int13 = dfpField12.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.multiply((int) '4');
        java.lang.Class<?> wildcardClass17 = dfp14.getClass();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp10.remainder(dfp14);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) -1);
        double double2 = mersenneTwister1.nextGaussian();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1688976178093215d + "'", double2 == 0.1688976178093215d);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.6027633f + "'", float3 == 0.6027633f);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.multiply(100);
        try {
            org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((-7906226569145254223L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp3.newInstance(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((byte) 3);
        int int17 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField13.getLn2();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.getLn10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp3.add(dfp21);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 100, (-0.397318034091222d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5747694862289174d + "'", double2 == 1.5747694862289174d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32768);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 1);
        java.lang.Object[] objArray2 = notStrictlyPositiveException1.getArguments();
        java.lang.Object[] objArray3 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-870835591897652727L));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode23);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.newInstance();
        int int10 = dfp8.intValue();
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp8.getField();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        int int14 = dfpField13.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField16.getRoundingMode();
        int int18 = dfpField16.getIEEEFlags();
        int int19 = dfpField16.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField16.newDfp(10);
        int int22 = dfpField16.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField16.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode24 = dfpField16.getRoundingMode();
        dfpField11.setRoundingMode(roundingMode24);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 16 + "'", int18 == 16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertTrue("'" + roundingMode24 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode24.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp10 = dfp6.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 100.0f);
        boolean boolean22 = notStrictlyPositiveException21.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.26876649909134087d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.26247668770207966d + "'", double1 == 0.26247668770207966d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2213400826700138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.391729887954656d + "'", double1 == 3.391729887954656d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray26);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(3850396226921085255L);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int[] intArray7 = new int[] { (-1), '4', (byte) -1 };
        mersenneTwister3.setSeed(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister1.setSeed(intArray7);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K((int) (short) 0);
        int int8 = dfp7.intValue();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.divide(0);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.newInstance((long) 100);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp9.remainder(dfp17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        double double2 = mersenneTwister1.nextGaussian();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0000679992263888d) + "'", double2 == (-1.0000679992263888d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.47956503276562257d) + "'", double3 == (-0.47956503276562257d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.823110339393827d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01436598552963027d + "'", double1 == 0.01436598552963027d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp16.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp12.newInstance(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = new org.apache.commons.math.dfp.Dfp(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp6.divide(dfp19);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp21.newInstance();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance((-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Throwable throwable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException21 = new org.apache.commons.math.exception.MathRuntimeException(throwable11, localizable12, localizable13, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray20);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField(10);
        int int26 = dfpField25.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField25.getPi();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(10);
        int int31 = dfpField30.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField30.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp35.newInstance((int) (short) 1);
        boolean boolean38 = dfp37.isNaN();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField25.newDfp(dfp37);
        int int40 = dfpField25.getRadixDigits();
        dfpField25.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray43 = dfpField25.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray43);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException48 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooSmallException48.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(10);
        int int57 = dfpField56.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField59 = dfp58.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode60 = dfpField59.getRoundingMode();
        int int61 = dfpField59.getIEEEFlags();
        int int62 = dfpField59.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray63 = dfpField59.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, localizable54, (java.lang.Object[]) dfpArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray63);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Throwable throwable67 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException(throwable67, localizable68, localizable69, objArray76);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, objArray76);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray76);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfpArray43);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfpField59);
        org.junit.Assert.assertTrue("'" + roundingMode60 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode60.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 16 + "'", int61 == 16);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 16 + "'", int62 == 16);
        org.junit.Assert.assertNotNull(dfpArray63);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        int int12 = dfpField11.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField14 = dfp13.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = dfpField14.getRoundingMode();
        int int16 = dfpField14.getIEEEFlags();
        int int17 = dfpField14.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField14.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 1.718281828459045d);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, number22);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0.4714832047780071d, (java.lang.Number) 4L, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooSmallException31.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooSmallException36.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(10);
        int int40 = dfpField39.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField42 = dfp41.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode43 = dfpField42.getRoundingMode();
        int int44 = dfpField42.getIEEEFlags();
        int int45 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray46 = dfpField42.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable37, (java.lang.Object[]) dfpArray46);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException51 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooSmallException51.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField59 = new org.apache.commons.math.dfp.DfpField(10);
        int int60 = dfpField59.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField59.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField62 = dfp61.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode63 = dfpField62.getRoundingMode();
        int int64 = dfpField62.getIEEEFlags();
        int int65 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray66 = dfpField62.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable57, (java.lang.Object[]) dfpArray66);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable72 = numberIsTooSmallException71.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException76 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable77 = numberIsTooSmallException76.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField(10);
        int int80 = dfpField79.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField79.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField82 = dfp81.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode83 = dfpField82.getRoundingMode();
        int int84 = dfpField82.getIEEEFlags();
        int int85 = dfpField82.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray86 = dfpField82.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable77, (java.lang.Object[]) dfpArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable57, (java.lang.Object[]) dfpArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray86);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfpField14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 16 + "'", int17 == 16);
        org.junit.Assert.assertNotNull(dfpArray18);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfpField42);
        org.junit.Assert.assertTrue("'" + roundingMode43 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode43.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 16 + "'", int45 == 16);
        org.junit.Assert.assertNotNull(dfpArray46);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfpField62);
        org.junit.Assert.assertTrue("'" + roundingMode63 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode63.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 16 + "'", int64 == 16);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertNotNull(dfpArray66);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable77.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 4 + "'", int80 == 4);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfpField82);
        org.junit.Assert.assertTrue("'" + roundingMode83 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode83.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 16 + "'", int84 == 16);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 16 + "'", int85 == 16);
        org.junit.Assert.assertNotNull(dfpArray86);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 52, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9030899869919435d + "'", double1 == 0.9030899869919435d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.getSqr2();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.88547328E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.357444703254927d + "'", double1 == 21.357444703254927d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.0000000000000142d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((byte) 3);
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(10.000000000000002d);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp("org.apache.commons.math.exception.MathRuntimeException: ");
        org.apache.commons.math.dfp.Dfp dfp9 = new org.apache.commons.math.dfp.Dfp(dfp8);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, (float) 32768);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean5 = mersenneTwister4.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray14 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister7.nextBytes(byteArray14);
        mersenneTwister4.nextBytes(byteArray14);
        mersenneTwister1.nextBytes(byteArray14);
        long long18 = mersenneTwister1.nextLong();
        long long19 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 8098045977194093303L + "'", long18 == 8098045977194093303L);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + (-3016645083903422023L) + "'", long19 == (-3016645083903422023L));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        dfpField1.setRoundingMode(roundingMode23);
        org.apache.commons.math.dfp.Dfp[] dfpArray25 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp((byte) 2);
        int int28 = dfp27.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
        org.junit.Assert.assertNotNull(dfpArray25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        int int10 = dfpField4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.getZero();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 8, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.701192981665102d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8696435482323601d) + "'", double1 == (-0.8696435482323601d));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField4.getRoundingMode();
        int int6 = dfpField4.getIEEEFlags();
        int int7 = dfpField4.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField4.newDfp(10);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField4.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField4.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp11.sqrt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        float float2 = org.apache.commons.math.util.FastMath.max(8.0980461E18f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 8.0980461E18f + "'", float2 == 8.0980461E18f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.9440892412430647d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7370954055267233d + "'", double1 == 0.7370954055267233d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.8414709848078964d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6865874069985795d + "'", double1 == 0.6865874069985795d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) 2, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7852853041876612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071865801956573d + "'", double1 == 0.7071865801956573d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) (short) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (short) 1, (java.lang.Number) 0.3083495f, true);
        java.lang.Number number11 = numberIsTooSmallException10.getArgument();
        boolean boolean12 = numberIsTooSmallException10.getBoundIsAllowed();
        java.lang.Number number13 = numberIsTooSmallException10.getMin();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (short) 1 + "'", number11.equals((short) 1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.3083495f + "'", number13.equals(0.3083495f));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((byte) 3, (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10K(0);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((int) (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getPi();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField(10);
        int int19 = dfpField18.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField21 = dfp20.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField21.getRoundingMode();
        int int23 = dfpField21.getIEEEFlags();
        int int24 = dfpField21.getIEEEFlags();
        boolean boolean25 = dfp16.equals((java.lang.Object) int24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp5.divide(dfp16);
        int int27 = dfp5.log10K();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField29.newDfp(0.8414709848078964d);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(10);
        int int39 = dfpField38.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField41 = dfp40.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode42 = dfpField41.getRoundingMode();
        int int43 = dfpField41.getIEEEFlags();
        int int44 = dfpField41.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField41.newDfp(10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField41.getLn2();
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeLn(dfp5, dfp36, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField(10);
        int int51 = dfpField50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getPi();
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField50.newDfp(3);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField50.newDfp((double) 97L);
        boolean boolean58 = dfp57.isNaN();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp5.multiply(dfp57);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField(10);
        int int62 = dfpField61.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField61.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField67.newDfp((double) ' ');
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.getPi();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField67.newDfp();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField67.getPi();
        org.apache.commons.math.dfp.Dfp dfp76 = dfp74.power10((int) '#');
        org.apache.commons.math.dfp.Dfp dfp77 = dfp65.newInstance(dfp74);
        int int78 = dfp74.intValue();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp5.add(dfp74);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpField21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 16 + "'", int23 == 16);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfpField41);
        org.junit.Assert.assertTrue("'" + roundingMode42 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode42.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 16 + "'", int43 == 16);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 16 + "'", int44 == 16);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 4 + "'", int62 == 4);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 3 + "'", int78 == 3);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        dfpField1.setIEEEFlags(3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 8098045977194093303L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0980459771940946E18d + "'", double1 == 8.0980459771940946E18d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((-0.9999999999999999d));
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((int) 'a');
        int int12 = dfp9.log10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp9.sqrt();
        org.apache.commons.math.dfp.Dfp dfp14 = new org.apache.commons.math.dfp.Dfp(dfp13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0000000000000142d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(10.000000000000002d);
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getZero();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((long) (byte) 10);
        int int9 = dfp8.classify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) '4', (double) (-3016645083903422023L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9092974268256817d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = dfpField17.getRoundingMode();
        int int19 = dfpField17.getIEEEFlags();
        int int20 = dfpField17.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField17.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable12, (java.lang.Object[]) dfpArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException34 = new org.apache.commons.math.exception.MathRuntimeException(throwable24, localizable25, localizable26, objArray33);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException34);
        java.lang.Throwable[] throwableArray36 = mathRuntimeException34.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException37 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable7, localizable23, (java.lang.Object[]) throwableArray36);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField(10);
        int int41 = dfpField40.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getPi();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(10);
        int int46 = dfpField45.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((int) (short) 1);
        boolean boolean53 = dfp52.isNaN();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField40.newDfp(dfp52);
        int int55 = dfpField40.getRadixDigits();
        dfpField40.setIEEEFlags(2);
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField40.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable38, (java.lang.Object[]) dfpArray58);
        java.lang.String str60 = mathIllegalArgumentException59.toString();
        mathRuntimeException37.addSuppressed((java.lang.Throwable) mathIllegalArgumentException59);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.9092974268256817d + "'", number2.equals(0.9092974268256817d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 16 + "'", int19 == 16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 16 + "'", int20 == 16);
        org.junit.Assert.assertNotNull(dfpArray21);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(throwableArray36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str60.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
        mersenneTwister0.setSeed(32768);
        mersenneTwister0.setSeed(16);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.power10((int) (short) 100);
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        int int9 = dfpField8.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance("hi!");
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.power10K((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(10);
        int int17 = dfpField16.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getPi();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.add(dfp19);
        org.apache.commons.math.dfp.Dfp dfp21 = org.apache.commons.math.dfp.Dfp.copysign(dfp5, dfp14);
        int int22 = dfp21.classify();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField24.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField24.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField24.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField24.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField24.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField24.getE();
        boolean boolean32 = dfp21.lessThan(dfp31);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.999999999997595E99d + "'", double6 == 9.999999999997595E99d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + roundingMode26 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode26.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField4 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField4.getLn5();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField(10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp((double) ' ');
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField(10);
        int int15 = dfpField14.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = dfpField14.getRoundingMode();
        dfpField8.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField8.newDfp((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField4.newDfp(dfp20);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode22 = dfpField4.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField4.getPi();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpField4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + roundingMode22 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode22.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(10);
        int int7 = dfpField6.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp((byte) 100, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((int) (short) 1);
        boolean boolean14 = dfp13.isNaN();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.newDfp((double) 4);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits((int) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray23 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField1.newDfp((double) 0.43899584f);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField1.newDfp("271.8281828459");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfpArray23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean5 = mersenneTwister4.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray14 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister7.nextBytes(byteArray14);
        mersenneTwister4.nextBytes(byteArray14);
        mersenneTwister1.nextBytes(byteArray14);
        org.apache.commons.math.random.MersenneTwister mersenneTwister19 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean20 = mersenneTwister19.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister22 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray29 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister22.nextBytes(byteArray29);
        mersenneTwister19.nextBytes(byteArray29);
        mersenneTwister19.setSeed((long) (byte) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister35 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int[] intArray39 = new int[] { (-1), '4', (byte) -1 };
        mersenneTwister35.setSeed(intArray39);
        mersenneTwister19.setSeed(intArray39);
        org.apache.commons.math.random.MersenneTwister mersenneTwister43 = new org.apache.commons.math.random.MersenneTwister((long) 10);
        boolean boolean44 = mersenneTwister43.nextBoolean();
        org.apache.commons.math.random.MersenneTwister mersenneTwister46 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        byte[] byteArray53 = new byte[] { (byte) 10, (byte) 10, (byte) 3, (byte) 3, (byte) 1, (byte) 100 };
        mersenneTwister46.nextBytes(byteArray53);
        mersenneTwister43.nextBytes(byteArray53);
        mersenneTwister43.setSeed((long) (byte) 2);
        float float58 = mersenneTwister43.nextFloat();
        byte[] byteArray65 = new byte[] { (byte) 2, (byte) 2, (byte) 100, (byte) 1, (byte) 3, (byte) 100 };
        mersenneTwister43.nextBytes(byteArray65);
        mersenneTwister19.nextBytes(byteArray65);
        mersenneTwister1.nextBytes(byteArray65);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(byteArray29);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(byteArray53);
        org.junit.Assert.assertTrue("'" + float58 + "' != '" + 0.011451006f + "'", float58 == 0.011451006f);
        org.junit.Assert.assertNotNull(byteArray65);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 2L, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5430806348152437d + "'", double2 == 1.5430806348152437d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3282.8063500117437d + "'", double1 == 3282.8063500117437d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getSpecificPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) (-6435806226174469347L), (java.lang.Number) 518826280430750969L, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 0.71597457f);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-7906226569145254223L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(10);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode3);
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags(1734632850);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 4);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) (-0.8390715290764524d), (java.lang.Number) 50, false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooSmallException10.getSpecificPattern();
        java.lang.Number number12 = numberIsTooSmallException10.getMin();
        java.lang.Number number13 = numberIsTooSmallException10.getMin();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 50 + "'", number12.equals(50));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 50 + "'", number13.equals(50));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 32768);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9092974268256817d);
        java.lang.Number number7 = notStrictlyPositiveException6.getArgument();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooSmallException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1L), (java.lang.Number) (byte) 0, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(10);
        int int20 = dfpField19.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField22 = dfp21.getField();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode23 = dfpField22.getRoundingMode();
        int int24 = dfpField22.getIEEEFlags();
        int int25 = dfpField22.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray26 = dfpField22.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable17, (java.lang.Object[]) dfpArray26);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        java.lang.Throwable throwable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] { "hi!", (short) -1, (byte) 1, '#', (byte) 10, 1L };
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException(throwable29, localizable30, localizable31, objArray38);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException40 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException39);
        java.lang.Throwable[] throwableArray41 = mathRuntimeException39.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException42 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException6, localizable12, localizable28, (java.lang.Object[]) throwableArray41);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, (java.lang.Object[]) throwableArray41);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.9092974268256817d + "'", number7.equals(0.9092974268256817d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfpField22);
        org.junit.Assert.assertTrue("'" + roundingMode23 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode23.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 16 + "'", int24 == 16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 16 + "'", int25 == 16);
        org.junit.Assert.assertNotNull(dfpArray26);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(throwableArray41);
    }
}

