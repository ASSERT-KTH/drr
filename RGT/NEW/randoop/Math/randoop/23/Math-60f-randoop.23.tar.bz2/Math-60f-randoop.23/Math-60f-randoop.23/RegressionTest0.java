import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.158638853279167d + "'", double1 == 4.158638853279167d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) '#', (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999993939677d + "'", double2 == 0.9999999993939677d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (-1), (double) (byte) 100, 0.0d, (-1));
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 100, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        try {
            double[] doubleArray5 = normalDistributionImpl3.sample((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int2 = org.apache.commons.math.util.FastMath.max((int) '4', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1), (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextInt((int) (byte) 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19068994544354323d + "'", double1 == 0.19068994544354323d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5772156677920679d) + "'", double1 == (-0.5772156677920679d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.00000000000001d + "'", double1 == 100.00000000000001d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 100, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.9812808189568596E-159d + "'", double2 == 3.9812808189568596E-159d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.609680117110225d + "'", double1 == 9.609680117110225d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876839d + "'", double1 == 0.8623188722876839d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test030");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            long long6 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6971182376266226d + "'", double3 == 0.6971182376266226d);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int4 = randomDataImpl1.nextPascal((int) (short) -1, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15865525393145702d + "'", double1 == 0.15865525393145702d);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        try {
//            int int11 = randomDataImpl1.nextInt((int) (byte) 100, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7219280156805428d + "'", double3 == 0.7219280156805428d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.8561976104521474d + "'", double8 == 2.8561976104521474d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7068861518200754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012337490786012824d + "'", double1 == 0.012337490786012824d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math.special.Erf.erf(0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18749269135908855d + "'", double1 == 0.18749269135908855d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.0d, 0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6922006275553464d + "'", double2 == 0.6922006275553464d);
    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test040");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            int int8 = randomDataImpl1.nextPascal((int) ' ', (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5802476739557471d + "'", double3 == 0.5802476739557471d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "7" + "'", str5.equals("7"));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5596708127998578d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8474299248014396d + "'", double1 == 0.8474299248014396d);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test042");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        try {
//            double double9 = randomDataImpl1.nextCauchy((double) 10, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6165555383009114d + "'", double3 == 0.6165555383009114d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.373277726166554d + "'", double6 == 12.373277726166554d);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(100.00000000000001d, 1.4210854715202004E-14d, 3.9812808189568596E-159d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0L, 0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextBeta(0.0d, 100.00000000000001d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.377");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

//    @Test
//    public void test050() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test050");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        try {
//            long long12 = randomDataImpl1.nextLong((long) 100, 10L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.26507934230320473d + "'", double3 == 0.26507934230320473d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6528822335098494d + "'", double6 == 1.6528822335098494d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 99.96509427043036d + "'", double9 == 99.96509427043036d);
//    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.6897131082148451d, 4.158638853279167d, 4.158638853279167d, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 4.159 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 0L);
        double double7 = normalDistributionImpl3.cumulativeProbability(0.36787944117144233d);
        double double8 = normalDistributionImpl3.getStandardDeviation();
        double double10 = normalDistributionImpl3.density((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.15865525393145702d + "'", double5 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1677205581070077d + "'", double7 == 0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0279773571668917E-19d + "'", double10 == 1.0279773571668917E-19d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test056");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.011455570056802866d + "'", double0 == 0.011455570056802866d);
//    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test057");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        try {
//            long long11 = randomDataImpl1.nextLong((long) 'a', 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (0): lower bound (97) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.13302694907497006d + "'", double3 == 0.13302694907497006d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3803298289565022d + "'", double8 == 1.3803298289565022d);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.801827480081469d + "'", double1 == 12.801827480081469d);
    }

//    @Test
//    public void test060() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test060");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            long long8 = randomDataImpl1.nextSecureLong(100L, (long) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (100): lower bound (100) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6738201981503958d + "'", double3 == 0.6738201981503958d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "3" + "'", str5.equals("3"));
//    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            int int3 = randomDataImpl0.nextPascal(0, 0.6897131082148451d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
        } catch (org.apache.commons.math.MathException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8155384116340332d, 83.76375854688544d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8155384116340332d + "'", double2 == 0.8155384116340332d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.2416106283173886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24402531179839718d + "'", double1 == 0.24402531179839718d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5920004022855877d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5920004022855877d + "'", double1 == 0.5920004022855877d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.special.Erf.erf(0.6676479662289435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6549309142919097d + "'", double1 == 0.6549309142919097d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) ' ', 0.9999999993939677d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.999999932788864d + "'", double2 == 31.999999932788864d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) 'a', (int) (byte) 10, (int) (short) 1);
        try {
            double double8 = randomDataImpl1.nextWeibull((-0.5596708127998578d), 0.17453292519943295d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.56 is smaller than, or equal to, the minimum (0): shape (-0.56)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(100.00000000000001d, (double) 1.0f, Double.NaN);
        try {
            double double5 = normalDistributionImpl3.inverseCumulativeProbability(100.00000000000001d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double2 = org.apache.commons.math.util.FastMath.max(0.3167021056424843d, 0.041514507862774525d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3167021056424843d + "'", double2 == 0.3167021056424843d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.5440680443502757d, 1.1547828563656484d, 1.3436158727078784d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        try {
//            int int13 = randomDataImpl1.nextBinomial(4, (double) 100L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5029832761080576d + "'", double3 == 0.5029832761080576d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3973140187952727d + "'", double8 == 0.3973140187952727d);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 0, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.max(0.36787944117144233d, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 52.0f, 4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 100, (double) (byte) 10, 3.2473571906248826d, 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test083");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        try {
//            int int13 = randomDataImpl1.nextBinomial((int) (short) 100, (double) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.38406688341102174d + "'", double3 == 0.38406688341102174d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.384063643016578d + "'", double8 == 2.384063643016578d);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray21);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray29 = numberIsTooLargeException28.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException30 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable4, (java.lang.Object[]) throwableArray29);
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray32);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 0L);
        double double7 = normalDistributionImpl3.cumulativeProbability(0.36787944117144233d);
        try {
            double double10 = normalDistributionImpl3.cumulativeProbability(99.61380843711527d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.15865525393145702d + "'", double5 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1677205581070077d + "'", double7 == 0.1677205581070077d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.5596708127998578d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.17453292519943295d + "'", number6.equals(0.17453292519943295d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5596708127998578d), 0.18749269135908855d, 14.0d, (int) (byte) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException21);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(3.2473571906248826d, 0.44705317267240163d, (double) (byte) 0, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (1) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            long long13 = randomDataImpl1.nextLong((long) (short) 10, 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (1): lower bound (10) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8981332726359501d + "'", double3 == 0.8981332726359501d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.490094808498093d + "'", double6 == 9.490094808498093d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0999828980973d + "'", double9 == 100.0999828980973d);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17632698070846498d + "'", double1 == 0.17632698070846498d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 4, 0.44705317267240163d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0011670527851042202d + "'", double2 == 0.0011670527851042202d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        double double1 = org.apache.commons.math.util.FastMath.sinh(390.04434745413175d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2390185292981617E169d + "'", double1 == 1.2390185292981617E169d);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double6 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.1114178866720175d + "'", double3 == 2.1114178866720175d);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test101");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            int[] intArray25 = randomDataImpl1.nextPermutation((int) '#', (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.9624319824029823d + "'", double3 == 1.9624319824029823d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.040982702496685584d + "'", double8 == 0.040982702496685584d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 152.64869304646822d + "'", double10 == 152.64869304646822d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "d" + "'", str12.equals("d"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 20.0d + "'", double22 == 20.0d);
//    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test102");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        try {
//            int int13 = randomDataImpl1.nextPascal((int) (short) 10, 2.7092983232354384d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.709 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0606931728612956d + "'", double3 == 1.0606931728612956d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.455166558486006d + "'", double8 == 9.455166558486006d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        double double2 = org.apache.commons.math.util.FastMath.min(0.8155384116340332d, 0.6897131082148451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6897131082148451d + "'", double2 == 0.6897131082148451d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15505360758556497d + "'", double1 == 0.15505360758556497d);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test107");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        try {
//            randomDataImpl1.setSecureAlgorithm("hi!", "8");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 8");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6473356179057257d + "'", double3 == 1.6473356179057257d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.917191775332905d + "'", double6 == 5.917191775332905d);
//    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(99.61380843711527d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.special.Erf.erf(2.0757486181300626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.996670450360643d + "'", double1 == 0.996670450360643d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 4);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3258176636680326d + "'", double1 == 1.3258176636680326d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
        double[] doubleArray4 = normalDistributionImpl2.sample(100);
        double double5 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.19068994544354323d + "'", double5 == 0.19068994544354323d);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            double double17 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.86854929983144d + "'", double3 == 1.86854929983144d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0657697627306084d + "'", double8 == 1.0657697627306084d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.3167021056424843d, (java.lang.Number) 2.18659846443041d, false);
    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        long long8 = randomDataImpl1.nextPoisson(2.4633218980879183d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("e", "e");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: e");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.8262737605884638d + "'", double3 == 1.8262737605884638d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getSpecificPattern();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.junit.Assert.assertNull(localizable1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test120");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        try {
//            int[] intArray11 = randomDataImpl1.nextPermutation((-1), (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.541654970555646d + "'", double3 == 1.541654970555646d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9772818233691938d + "'", double8 == 0.9772818233691938d);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 2.6121810351099137d, 0.957982976278873d, (int) (byte) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.0757486181300626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable10, objArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray48);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(83.76375854688544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 285.84813418891974d + "'", double1 == 285.84813418891974d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test127");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        try {
//            double double17 = randomDataImpl1.nextBeta(Double.NEGATIVE_INFINITY, 0.13006970684777322d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.258");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8049407975198686d + "'", double3 == 2.8049407975198686d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1091474794240661d + "'", double8 == 0.1091474794240661d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6638204538120072d + "'", double14 == 1.6638204538120072d);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(152.851579751457d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.006563741652264791d + "'", double1 == 0.006563741652264791d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0011670527851042202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0011670530500277384d + "'", double1 == 0.0011670530500277384d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.3258176636680326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Number number42 = outOfRangeException41.getHi();
        java.lang.Number number43 = outOfRangeException41.getLo();
        java.lang.String str44 = outOfRangeException41.toString();
        org.apache.commons.math.exception.util.Localizable localizable45 = outOfRangeException41.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.18749269135908855d + "'", number42.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 10.0d + "'", number43.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)" + "'", str44.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)"));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double1 = org.apache.commons.math.util.FastMath.log10(100.38235421017255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.001657376726572d + "'", double1 == 2.001657376726572d);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test133");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        try {
//            long long27 = randomDataImpl1.nextSecureLong((long) 100, (long) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (-1): lower bound (100) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07653289201475165d + "'", double3 == 0.07653289201475165d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.1121582718767153d + "'", double8 == 2.1121582718767153d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 87.23583586403576d + "'", double10 == 87.23583586403576d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9" + "'", str12.equals("9"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 3.0d + "'", double22 == 3.0d);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.13006970684777322d, (double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): standard deviation (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int[] intArray4 = randomDataImpl1.nextPermutation((int) '#', (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.06303136834378237d, (java.lang.Number) 0.7151568462037634d, true);
    }

//    @Test
//    public void test137() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test137");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        try {
//            java.lang.String str14 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08800125332762102d + "'", double3 == 0.08800125332762102d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.219908292252071d + "'", double8 == 3.219908292252071d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.util.Localizable localizable1 = convergenceException0.getSpecificPattern();
        org.junit.Assert.assertNull(localizable1);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test139");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        try {
//            double double7 = normalDistributionImpl2.inverseCumulativeProbability(1.4766507257954695d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 1.477 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.749116399024764d) + "'", double3 == (-11.749116399024764d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4920840976514603d + "'", double5 == 0.4920840976514603d);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(13.968734023107451d, 0.957982976278873d, (double) (byte) 1, (int) '4');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.626855756736301E-12d + "'", double4 == 2.626855756736301E-12d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.signum(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 10, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test144");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            randomDataImpl1.setSecureAlgorithm("2492c08a14640aeabdbe2b1a70973d592f9711ef0ea54852cfc1", "9");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 9");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05398293536026058d + "'", double3 == 0.05398293536026058d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.025736770973946645d + "'", double8 == 0.025736770973946645d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.5403023058681398d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double7 = normalDistributionImpl3.cumulativeProbability(13.274948879489813d, 0.8474299248014396d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double2 = org.apache.commons.math.util.FastMath.pow(14.0d, 0.4920840976514603d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.664303017570078d + "'", double2 == 3.664303017570078d);
    }

//    @Test
//    public void test148() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test148");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
//        double double3 = normalDistributionImpl2.sample();
//        try {
//            double[] doubleArray5 = normalDistributionImpl2.sample((int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-8.860319298497537d) + "'", double3 == (-8.860319298497537d));
//    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test149");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        try {
//            double double6 = randomDataImpl1.nextCauchy(3.9812808189568596E-159d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05758170396775991d + "'", double3 == 0.05758170396775991d);
//    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray4 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable11, objArray22);
        java.lang.Class<?> wildcardClass24 = localizable11.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 10L, (java.lang.Number) 100, true);
        java.lang.Throwable throwable29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(throwable29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException34 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable35 = notStrictlyPositiveException34.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooLargeException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray56 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException(localizable45, objArray56);
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException34, localizable38, objArray56);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable63 = notStrictlyPositiveException62.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException68 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable64, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable69 = numberIsTooLargeException68.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException74 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable70, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray80 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException(localizable69, objArray80);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray80);
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException87 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable83, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray88 = numberIsTooLargeException87.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException89 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable63, (java.lang.Object[]) throwableArray88);
        java.lang.Object[] objArray91 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray91);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException93 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, objArray91);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException31, localizable38, objArray91);
        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException(localizable11, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException96 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "", objArray91);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(throwableArray88);
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(27.0d, 2.718281828459045d);
        try {
            double double4 = normalDistributionImpl2.inverseCumulativeProbability(2.18659846443041d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.187 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        double double12 = randomDataImpl1.nextChiSquare(0.5722984289556622d);
//        try {
//            long long15 = randomDataImpl1.nextLong((long) '4', (long) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (0): lower bound (52) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.5147275420100264d + "'", double3 == 3.5147275420100264d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7755978846293553d + "'", double8 == 0.7755978846293553d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.09924817786691255d + "'", double12 == 0.09924817786691255d);
//    }

//    @Test
//    public void test153() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test153");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            int int18 = randomDataImpl1.nextBinomial(1, (double) 10.0f);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9029663325624004d + "'", double3 == 2.9029663325624004d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2636087942990923d + "'", double8 == 0.2636087942990923d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.4633218980879183d, 4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8653450264627532d + "'", double2 == 0.8653450264627532d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 0L);
        double double8 = normalDistributionImpl3.cumulativeProbability(31.999999932788864d, 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.15865525393145702d + "'", double5 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.013890102002911409d + "'", double8 == 0.013890102002911409d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        try {
            double double7 = normalDistributionImpl3.cumulativeProbability(0.17453292519943295d, 1.0279773571668917E-19d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
    }

//    @Test
//    public void test162() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test162");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            int int18 = randomDataImpl1.nextPascal(0, 0.013890102002911409d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MathException; message: Discrete cumulative probability function returned NaN for argument 1,073,741,822");
//        } catch (org.apache.commons.math.MathException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0613462750780505d + "'", double3 == 3.0613462750780505d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.2009398778547316d + "'", double8 == 1.2009398778547316d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.acos(76.44167018429083d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) '#');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            double double4 = randomDataImpl1.nextUniform((double) '#', 0.19068994544354323d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (0.191): lower bound (35) must be strictly less than upper bound (0.191)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(99.61380843711527d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.61380843711525d + "'", double2 == 99.61380843711525d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.asin(367.93118819388314d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test174");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double7 = randomDataImpl1.nextBeta((double) 0L, (double) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.598");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.03613618115159978d + "'", double3 == 0.03613618115159978d);
//    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test175");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.cumulativeProbability(0.0d);
//        try {
//            double[] doubleArray7 = normalDistributionImpl2.sample((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 30.65593204688231d + "'", double3 == 30.65593204688231d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.4920840976514603d + "'", double5 == 0.4920840976514603d);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        try {
//            int int13 = randomDataImpl1.nextZipf((-1), (double) (-1.0f));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.03454654705935814d + "'", double3 == 0.03454654705935814d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.046259763763148d + "'", double8 == 1.046259763763148d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8" + "'", str10.equals("8"));
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        long long1 = org.apache.commons.math.util.FastMath.round(0.6431783081104894d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        long long1 = org.apache.commons.math.util.FastMath.round(1.8914054949584744d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

//    @Test
//    public void test184() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test184");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        double double13 = randomDataImpl1.nextGaussian(0.15865525393145702d, 0.5702569604914122d);
//        try {
//            double double16 = randomDataImpl1.nextUniform(3.7634044916862806d, 0.5087419900842157d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3.763 is larger than, or equal to, the maximum (0.509): lower bound (3.763) must be strictly less than upper bound (0.509)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.007126345138515114d + "'", double3 == 0.007126345138515114d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5253379197289025d + "'", double8 == 0.5253379197289025d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 21.68390679178852d + "'", double10 == 21.68390679178852d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.016399075379186667d) + "'", double13 == (-0.016399075379186667d));
//    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test185");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential(1.2390185292981617E169d);
//        double double20 = randomDataImpl1.nextGaussian(0.17632698070846498d, (double) 100L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.007453440659489257d + "'", double3 == 0.007453440659489257d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.10948085450959576d + "'", double8 == 0.10948085450959576d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.679564408431606E169d + "'", double17 == 1.679564408431606E169d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 113.47554190921028d + "'", double20 == 113.47554190921028d);
//    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test186");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        java.lang.String str26 = randomDataImpl1.nextHexString((int) '4');
//        try {
//            java.lang.String str28 = randomDataImpl1.nextSecureHexString((int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.006974978477976724d + "'", double3 == 0.006974978477976724d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.8725257687474386d + "'", double8 == 1.8725257687474386d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 275.9873009699221d + "'", double10 == 275.9873009699221d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "e" + "'", str12.equals("e"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-6.0d) + "'", double22 == (-6.0d));
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "a5b7f4fa53f7004da8b4d85df6f5ef51b96e7ee836f97037a8a6" + "'", str26.equals("a5b7f4fa53f7004da8b4d85df6f5ef51b96e7ee836f97037a8a6"));
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math.util.FastMath.asinh(182.17140371275474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.898102736199621d + "'", double1 == 5.898102736199621d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("f", objArray1);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.9366706971532035d, (java.lang.Number) 0.8623188722876839d, true);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test190");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        try {
//            double double20 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.009395709941372798d + "'", double3 == 0.009395709941372798d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.5568064307171665d + "'", double8 == 1.5568064307171665d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.019619975073424587d + "'", double15 == 0.019619975073424587d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 6.65267121423053d + "'", double18 == 6.65267121423053d);
//    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            int int25 = randomDataImpl1.nextSecureInt((int) 'a', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (0): lower bound (97) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.01428468613917773d + "'", double3 == 0.01428468613917773d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4746560770247843d + "'", double8 == 1.4746560770247843d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 66.17114580040413d + "'", double10 == 66.17114580040413d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f" + "'", str12.equals("f"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-4.0d) + "'", double22 == (-4.0d));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(76.44167018429083d, 0.6037152825988136d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 76.44167018429081d + "'", double2 == 76.44167018429081d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.8485191778040397d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9467178249468372d + "'", double1 == 0.9467178249468372d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5920004022855877d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5920004022855878d + "'", double1 == 0.5920004022855878d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 54.598150033144236d + "'", double1 == 54.598150033144236d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        long long1 = org.apache.commons.math.util.FastMath.round(4.35838798317602d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.exp(113.47554190921028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9133819916233718E49d + "'", double1 == 1.9133819916233718E49d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.24402531179839718d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(throwable4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5);
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable13, objArray24);
        java.lang.Class<?> wildcardClass26 = localizable13.getClass();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooLargeException31.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray43 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable32, objArray43);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable13, objArray43);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException(localizable13, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7, localizable13, objArray51);
        java.lang.Throwable throwable55 = null;
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(throwable55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException56);
        java.lang.String str58 = mathException56.toString();
        java.lang.Object[] objArray59 = mathException56.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException60 = new org.apache.commons.math.ConvergenceException("0", objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable13, objArray59);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass26);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "org.apache.commons.math.MathException: " + "'", str58.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray59);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1L, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test200() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test200");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric((int) (short) -1, (int) (short) 1, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.60067848819946E-4d + "'", double3 == 3.60067848819946E-4d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.441489078366084d + "'", double6 == 12.441489078366084d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.00187802895141d + "'", double9 == 100.00187802895141d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.3714360416014004d) + "'", double12 == (-0.3714360416014004d));
//    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.20587690404625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2816170601433924d) + "'", double1 == (-0.2816170601433924d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 367.93118819388314d, (java.lang.Number) 2.0d, (java.lang.Number) 100L);
        org.apache.commons.math.exception.util.Localizable localizable4 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        double double2 = org.apache.commons.math.util.FastMath.min(0.2416106283173886d, 73.74085758741803d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2416106283173886d + "'", double2 == 0.2416106283173886d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.6431783081104894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6054957989154771d + "'", double1 == 0.6054957989154771d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.879564722215355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.5506528878586385d + "'", double1 == 6.5506528878586385d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16087055809932455d + "'", double1 == 0.16087055809932455d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable21, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException10, localizable14, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooLargeException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable46, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable60, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray65 = numberIsTooLargeException64.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable40, (java.lang.Object[]) throwableArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35, "5", (java.lang.Object[]) throwableArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable8, (java.lang.Object[]) throwableArray65);
        java.lang.Throwable[] throwableArray69 = mathException1.getSuppressed();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(throwableArray69);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray21);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("4", objArray21);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("1", objArray21);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double1 = org.apache.commons.math.util.FastMath.cos(99.61380843711527d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6080800152832633d + "'", double1 == 0.6080800152832633d);
    }

//    @Test
//    public void test211() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test211");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            randomDataImpl1.setSecureAlgorithm("", "1");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4567417142512103d + "'", double3 == 0.4567417142512103d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0445914775870149d + "'", double8 == 1.0445914775870149d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 56.26926814198791d + "'", double10 == 56.26926814198791d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 10.0d + "'", double22 == 10.0d);
//    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double1 = org.apache.commons.math.util.FastMath.ulp(83.76375854688544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Number number6 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.7068861518200754d + "'", number5.equals(0.7068861518200754d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.1677205581070077d + "'", number6.equals(0.1677205581070077d));
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test214");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        try {
//            double double14 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.49525440718901287d + "'", double3 == 0.49525440718901287d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.3855191159108253d + "'", double6 == 2.3855191159108253d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.08291077901568d + "'", double9 == 100.08291077901568d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.813983934309667d) + "'", double12 == (-0.813983934309667d));
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, number1, false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(51.99999999999999d, 0.6897131082148451d, (-0.5772156677920679d), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson(1.3258176636680326d);
//        double double9 = randomDataImpl1.nextWeibull(2.7912452447092146d, 0.04690181386892998d);
//        int int12 = randomDataImpl1.nextBinomial(1, 2.626855756736301E-12d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.39205572927448146d + "'", double3 == 0.39205572927448146d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05315015091559d + "'", double9 == 0.05315015091559d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(6.5506528878586385d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11433046104840812d + "'", double1 == 0.11433046104840812d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.5772156677920679d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double double1 = org.apache.commons.math.util.FastMath.expm1(152.851579751457d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4132240024472974E66d + "'", double1 == 2.4132240024472974E66d);
    }

//    @Test
//    public void test222() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test222");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        double double14 = randomDataImpl1.nextT(0.5722984289556622d);
//        try {
//            long long16 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.388985269895301d + "'", double3 == 0.388985269895301d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.65056673988896d + "'", double6 == 2.65056673988896d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.18315589038036d + "'", double9 == 100.18315589038036d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.7747450779384757d + "'", double12 == 0.7747450779384757d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.29072438253629657d) + "'", double14 == (-0.29072438253629657d));
//    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.957982976278873d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.03625982264712382d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03692522815132798d + "'", double1 == 0.03692522815132798d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.11771304448374612d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11771304448374612d + "'", double1 == 0.11771304448374612d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable14, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, localizable7, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooLargeException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable34, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(throwable1, localizable7, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray45);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number8 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.15865525393145702d + "'", number6.equals(0.15865525393145702d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1L) + "'", number8.equals((-1L)));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.sinh(4.612717022673806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.37380688370831d + "'", double1 == 50.37380688370831d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        org.apache.commons.math.exception.util.Localizable localizable67 = mathException66.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.17453292519943295d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.062051165024389884d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06201141410693407d + "'", double1 == 0.06201141410693407d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
        double double4 = normalDistributionImpl2.density(0.1677205581070077d);
        try {
            double double7 = normalDistributionImpl2.cumulativeProbability(2.0757486181300626d, 0.0010537829590105158d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.041514507862774525d + "'", double4 == 0.041514507862774525d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable7, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable1, objArray18);
        int int21 = maxIterationsExceededException20.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.ConvergenceException convergenceException1 = new org.apache.commons.math.ConvergenceException(throwable0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(8.0d, 1.0909874692696686d, 0.0010537829590105158d, 52);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.8991486712299178E-5d + "'", double4 == 1.8991486712299178E-5d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 100, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.8653450264627532d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        java.lang.Object[] objArray17 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
//        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable6, objArray17);
//        java.lang.Class<?> wildcardClass19 = localizable6.getClass();
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable20, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooLargeException24.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable25, objArray36);
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable6, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooLargeException45.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable47 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        java.lang.Object[] objArray57 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
//        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable46, objArray57);
//        java.lang.Object[] objArray59 = convergenceException58.getArguments();
//        org.apache.commons.math.random.RandomGenerator randomGenerator61 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl62 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator61);
//        double double64 = randomDataImpl62.nextChiSquare((double) 1.0f);
//        double double67 = randomDataImpl62.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double69 = randomDataImpl62.nextExponential((double) (short) 1);
//        double double71 = randomDataImpl62.nextExponential((double) 100L);
//        java.lang.String str73 = randomDataImpl62.nextHexString((int) (byte) 1);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { "org.apache.commons.math.MathException: ", 295.0471450458558d, convergenceException58, 182.17140371275474d, (byte) 1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray74);
//        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("e", objArray74);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray17);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNotNull(objArray59);
//        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.246755651793597d + "'", double64 == 0.246755651793597d);
//        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.3696514018909034d + "'", double69 == 0.3696514018909034d);
//        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 94.2930559097118d + "'", double71 == 94.2930559097118d);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "b" + "'", str73.equals("b"));
//        org.junit.Assert.assertNotNull(objArray74);
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.24402531179839718d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Throwable[] throwableArray4 = numberIsTooLargeException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Number number42 = outOfRangeException41.getHi();
        java.lang.Number number43 = outOfRangeException41.getLo();
        java.lang.String str44 = outOfRangeException41.toString();
        java.lang.Number number45 = outOfRangeException41.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.18749269135908855d + "'", number42.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 10.0d + "'", number43.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)" + "'", str44.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)"));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 10.0d + "'", number45.equals(10.0d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double double1 = org.apache.commons.math.util.FastMath.sinh(113.47554190921028d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.566909958116859E48d + "'", double1 == 9.566909958116859E48d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.8414709848078965d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double2 = org.apache.commons.math.util.FastMath.max(0.5087419900842157d, 0.7425393557279393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7425393557279393d + "'", double2 == 0.7425393557279393d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        try {
//            int[] intArray11 = randomDataImpl1.nextPermutation((int) (byte) 10, (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (10): permutation size (100) exceeds permuation domain (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.232726193279181d + "'", double3 == 5.232726193279181d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4750799860275787d + "'", double6 == 0.4750799860275787d);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double2 = org.apache.commons.math.util.FastMath.min(285.84813418891974d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.013890102002911409d, 2.0608723157869d);
    }

//    @Test
//    public void test251() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test251");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        long long8 = randomDataImpl1.nextPoisson(2.4633218980879183d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("7", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.021645768046986d + "'", double3 == 5.021645768046986d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.05516890583768806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0551969296588712d + "'", double1 == 0.0551969296588712d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException(throwable3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.toString();
        java.lang.Object[] objArray7 = mathException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("0", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        int int11 = maxIterationsExceededException9.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: " + "'", str6.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 100 + "'", int11 == 100);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.3032904173475307d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.String str4 = outOfRangeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 14 out of [0.168, 0.707] range" + "'", str4.equals("org.apache.commons.math.exception.OutOfRangeException: 14 out of [0.168, 0.707] range"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.5772156677920679d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5491895727074129d) + "'", double1 == (-0.5491895727074129d));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable21, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException("", objArray32);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException10, localizable14, objArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable46 = numberIsTooLargeException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray57 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException58 = new org.apache.commons.math.ConvergenceException(localizable46, objArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, objArray57);
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable60, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray65 = numberIsTooLargeException64.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable40, (java.lang.Object[]) throwableArray65);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException35, "5", (java.lang.Object[]) throwableArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable8, (java.lang.Object[]) throwableArray65);
        java.lang.Throwable[] throwableArray69 = mathException1.getSuppressed();
        java.lang.Class<?> wildcardClass70 = mathException1.getClass();
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException1.getSpecificPattern();
        java.lang.String str72 = mathException1.getPattern();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(throwableArray65);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertNull(localizable71);
        org.junit.Assert.assertTrue("'" + str72 + "' != '" + "{0}" + "'", str72.equals("{0}"));
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test261");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        int int13 = randomDataImpl1.nextPascal((int) ' ', 0.8623188722876839d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl1.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2456183283913376d + "'", double3 == 3.2456183283913376d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.8592871401953546d + "'", double8 == 3.8592871401953546d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 19.07382155319155d + "'", double10 == 19.07382155319155d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 10, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.8384513112557077d), 1.065251648652951E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963255243975d) + "'", double2 == (-1.5707963255243975d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.10948085450959576d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
//        double double3 = normalDistributionImpl2.sample();
//        double double4 = normalDistributionImpl2.getStandardDeviation();
//        double double5 = normalDistributionImpl2.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.352938723585865d + "'", double3 == 5.352938723585865d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.609680117110225d + "'", double4 == 9.609680117110225d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.354918830330839d + "'", double5 == 3.354918830330839d);
//    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test266");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        java.lang.String str17 = randomDataImpl1.nextHexString((int) (byte) 100);
//        long long19 = randomDataImpl1.nextPoisson(4.193457026379115d);
//        try {
//            double double22 = randomDataImpl1.nextUniform(0.3495787551717202d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0.35 is larger than, or equal to, the maximum (0): lower bound (0.35) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.521768708574261d + "'", double3 == 2.521768708574261d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.06601975365849878d + "'", double8 == 0.06601975365849878d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.8687142673606563d + "'", double10 == 1.8687142673606563d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "9" + "'", str12.equals("9"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "d1a24bf508a436e9fbf1ba1ed267de80e68972e2c85aadd2dd466e9dec22fb921be6e61f9b1579328fb064a637277c67eb07" + "'", str17.equals("d1a24bf508a436e9fbf1ba1ed267de80e68972e2c85aadd2dd466e9dec22fb921be6e61f9b1579328fb064a637277c67eb07"));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 9L + "'", long19 == 9L);
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.001657376726572d, 1.0E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test268");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            int int25 = randomDataImpl1.nextInt((int) (byte) 10, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than, or equal to, the maximum (0): lower bound (10) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.386245797452604d + "'", double3 == 2.386245797452604d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9683185410878505d + "'", double8 == 0.9683185410878505d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 96.98742548859165d + "'", double10 == 96.98742548859165d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 22.0d + "'", double22 == 22.0d);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test270");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        randomDataImpl1.reSeed();
//        double double20 = randomDataImpl1.nextT(1.6165918884611694d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6696019009736127d + "'", double3 == 1.6696019009736127d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.13342428043896845d + "'", double8 == 0.13342428043896845d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.1502738554141714d + "'", double20 == 1.1502738554141714d);
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable9, objArray20);
        java.lang.Class<?> wildcardClass22 = localizable9.getClass();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray39 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable28, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable9, objArray39);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable9, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Object[] objArray47 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray47);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, localizable9, objArray47);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 54.598150033144236d, (java.lang.Number) 0.0551969296588712d, false);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.397900466381943d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0655995280502544d + "'", double1 == 3.0655995280502544d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.19068994544354323d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2100842017898131d + "'", double1 == 0.2100842017898131d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.17075767871726785d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5547876023202449d + "'", double1 == 0.5547876023202449d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable13, objArray24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray24);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException2, localizable6, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooLargeException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray44 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable33, objArray44);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(throwable0, localizable6, objArray44);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 2.626855756736301E-12d);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray44);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.8736512055789858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3378959960905843d + "'", double1 == 0.3378959960905843d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable12, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable5, objArray23);
        boolean boolean27 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Number number28 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0 + "'", number28.equals(0));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.879193721524136d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9861203161417466d) + "'", double1 == (-0.9861203161417466d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable14, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, localizable7, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooLargeException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable34, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(throwable1, localizable7, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooLargeException56.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable58, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable57, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable7, objArray68);
        java.lang.Throwable[] throwableArray73 = maxIterationsExceededException72.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(throwableArray73);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.613635339438126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5466810445366503d + "'", double1 == 0.5466810445366503d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.3436158727078784d, (double) 4L, (double) 1);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 0.613635339438126d, true);
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, number22);
        java.lang.Number number24 = notStrictlyPositiveException23.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1763382298382675d + "'", double1 == 0.1763382298382675d);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        try {
//            int int13 = randomDataImpl1.nextSecureInt((int) ' ', 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (0): lower bound (32) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.008203205266719459d + "'", double3 == 0.008203205266719459d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.07921907187437016d + "'", double8 == 0.07921907187437016d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 15.203633737572392d + "'", double10 == 15.203633737572392d);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.12519917548959106d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.12455110098820214d) + "'", double1 == (-0.12455110098820214d));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22025.465794806718d + "'", double1 == 22025.465794806718d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.622112081245469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.622112081245469d + "'", double1 == 2.622112081245469d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.7912452447092146d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.301306283752982d + "'", double1 == 16.301306283752982d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(94.2930559097118d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 333.0482237879423d + "'", double1 == 333.0482237879423d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.2390185292981617E169d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.String str1 = convergenceException0.getPattern();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "convergence failed" + "'", str1.equals("convergence failed"));
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test302");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        randomDataImpl1.reSeed();
//        try {
//            int int19 = randomDataImpl1.nextSecureInt((int) (byte) 1, (int) (short) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (1): lower bound (1) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.27450795131873285d + "'", double3 == 0.27450795131873285d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 7.057830230907837d + "'", double8 == 7.057830230907837d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0070503379782805905d + "'", double15 == 0.0070503379782805905d);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 3.0f, (java.lang.Number) 1.0713600329447577d, false);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.2735701380514667d, number20, false);
        java.lang.Number number23 = numberIsTooSmallException22.getMin();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        java.lang.Class<?> wildcardClass42 = localizable29.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) (-0.7321877967059738d), (java.lang.Number) (-0.5772156677920679d), true);
        numberIsTooSmallException22.addSuppressed((java.lang.Throwable) numberIsTooLargeException46);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.065251648652951E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        long long1 = org.apache.commons.math.util.FastMath.round(2.7755575615628914E-17d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException(localizable10, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Object[] objArray48 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray48);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable10, objArray48);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException("7", objArray48);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray48);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 4.641588833612779d, (java.lang.Number) 44.657407416241625d, (java.lang.Number) 1.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.1146044433347386d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4405326238677501d + "'", double1 == 0.4405326238677501d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 100, 12.801827480081469d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test312");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        try {
//            long long20 = randomDataImpl1.nextSecureLong((long) 4, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than, or equal to, the maximum (0): lower bound (4) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14807058360270264d + "'", double3 == 0.14807058360270264d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.06327597243916977d + "'", double8 == 0.06327597243916977d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double2 = org.apache.commons.math.util.FastMath.pow(16.301306283752982d, 100.33776512254933d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.282399617536073E121d + "'", double2 == 4.282399617536073E121d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893698d) + "'", double1 == (-0.5440211108893698d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) -1, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.6111752143882816d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(5.352938723585865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7230614508084154d + "'", double1 == 3.7230614508084154d);
    }

//    @Test
//    public void test319() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test319");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential(1.2390185292981617E169d);
//        randomDataImpl1.reSeed((long) '4');
//        java.lang.String str21 = randomDataImpl1.nextHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3999169005490095d + "'", double3 == 0.3999169005490095d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.5437100504730836d + "'", double8 == 1.5437100504730836d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.679564408431606E169d + "'", double17 == 1.679564408431606E169d);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "5ec92b3a37" + "'", str21.equals("5ec92b3a37"));
//    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.413588051684717d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        double double2 = org.apache.commons.math.util.FastMath.min(1.065251648652951E-9d, 1.2849710637703233d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.065251648652951E-9d + "'", double2 == 1.065251648652951E-9d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable6, objArray17);
        java.lang.Class<?> wildcardClass19 = localizable6.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 10L, (java.lang.Number) 100, true);
        java.lang.Throwable throwable24 = null;
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(throwable24);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable33 = notStrictlyPositiveException32.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable40, objArray51);
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException("", objArray51);
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException29, localizable33, objArray51);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable58 = notStrictlyPositiveException57.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException63 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable59, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable64 = numberIsTooLargeException63.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable65, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray75 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable64, objArray75);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException77 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray75);
        org.apache.commons.math.exception.util.Localizable localizable78 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable78, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray83 = numberIsTooLargeException82.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException84 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable58, (java.lang.Object[]) throwableArray83);
        java.lang.Object[] objArray86 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray86);
        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException26, localizable33, objArray86);
        org.apache.commons.math.MathException mathException90 = new org.apache.commons.math.MathException(localizable6, objArray86);
        java.lang.Throwable throwable91 = null;
        org.apache.commons.math.MathException mathException92 = new org.apache.commons.math.MathException(throwable91);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException92);
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException93);
        java.lang.Throwable[] throwableArray95 = mathException94.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable6, (java.lang.Object[]) throwableArray95);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray75);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNotNull(throwableArray95);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.9366706971532035d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5437100504730836d, (double) 4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5437100504730839d + "'", double2 == 1.5437100504730839d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.0d, 13.274948879489813d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeed();
//        try {
//            double double10 = randomDataImpl1.nextBeta(0.13006970684777322d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.693");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0437917293434666d + "'", double3 == 1.0437917293434666d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.810080188344195d + "'", double6 == 5.810080188344195d);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-2.0430440645569212d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9669457838813199d) + "'", double1 == (-0.9669457838813199d));
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0155777782103645d + "'", double3 == 1.0155777782103645d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 22.479116174716726d + "'", double6 == 22.479116174716726d);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.7321877967059738d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.865014521633602E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0685746082021557E-7d + "'", double1 == 1.0685746082021557E-7d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.24402531179839718d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Throwable throwable4 = null;
        try {
            numberIsTooLargeException3.addSuppressed(throwable4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        try {
//            double double17 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5373587052559525d + "'", double3 == 0.5373587052559525d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.62128208646772d + "'", double8 == 1.62128208646772d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c" + "'", str10.equals("c"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.009645839635282821d + "'", double15 == 0.009645839635282821d);
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.05315015091559d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0545879805828058d + "'", double1 == 1.0545879805828058d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double16 = randomDataImpl1.nextT(1.4766507257954695d);
//        try {
//            long long19 = randomDataImpl1.nextSecureLong((long) '4', 3L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (3): lower bound (52) must be strictly less than upper bound (3)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5792701267594244d + "'", double3 == 0.5792701267594244d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.661250723358431d + "'", double8 == 0.661250723358431d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6638204538120072d + "'", double14 == 1.6638204538120072d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.8384513112557077d) + "'", double16 == (-0.8384513112557077d));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math.util.FastMath.rint((-2.282752375752627d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.18749269135908855d, 0.0d, 0.6582213442590702d, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.11433046104840812d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1082537411850834d + "'", double1 == 0.1082537411850834d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.4405326238677501d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41408583590433945d + "'", double1 == 0.41408583590433945d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int2 = org.apache.commons.math.util.FastMath.max(52, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.4054450323054039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3851915392854273d + "'", double1 == 0.3851915392854273d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5052570263122942d, 5.898102736199621d, 0.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double1 = org.apache.commons.math.util.FastMath.cos(29.823427584010098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.021700921462752897d) + "'", double1 == (-0.021700921462752897d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable12, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException30.getGeneralPattern();
        java.lang.Object[] objArray33 = null;
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("0", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable36, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable41 = numberIsTooLargeException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray52 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException53 = new org.apache.commons.math.ConvergenceException(localizable41, objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException34, "", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable31, objArray52);
        java.lang.Throwable throwable59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(throwable59);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60);
        java.lang.String str62 = mathException60.toString();
        java.lang.Object[] objArray63 = mathException60.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("0", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray63);
        java.lang.Object[] objArray66 = maxIterationsExceededException65.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException2, localizable6, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable68 = convergenceException67.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.MathException: " + "'", str62.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertTrue("'" + localizable68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable68.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.6897131082148451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.247431811219271d + "'", double1 == 1.247431811219271d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("83787dab8cdfe5fc24912111bc8ea8d317387b47914109c2c6c67f64a0c09f40513cf092fa9f8e82cb6797bacb30873e628a", objArray1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.3495787551717202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.9749676083448766d) + "'", double1 == (-2.9749676083448766d));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.06303136834378237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06307311341695959d + "'", double1 == 0.06307311341695959d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray19);
        java.lang.Class<?> wildcardClass22 = mathIllegalArgumentException21.getClass();
        java.lang.String str23 = mathIllegalArgumentException21.toString();
        org.apache.commons.math.exception.util.Localizable localizable24 = mathIllegalArgumentException21.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 0.159 is smaller than, or equal to, the minimum ()" + "'", str23.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 0.159 is smaller than, or equal to, the minimum ()"));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.2416106283173886d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.2416106283173886d + "'", number2.equals(0.2416106283173886d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

//    @Test
//    public void test356() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test356");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        double double11 = randomDataImpl1.nextGaussian(1.2677454753774682d, 1.5440680443502757d);
//        double double14 = randomDataImpl1.nextWeibull(0.4822760881655018d, 4.193457026379115d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0574132468294104d + "'", double3 == 1.0574132468294104d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.403789128831426d + "'", double8 == 2.403789128831426d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.4695614587186627d + "'", double11 == 2.4695614587186627d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 9.535603772908695d + "'", double14 == 9.535603772908695d);
//    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5722984289556622d, (java.lang.Number) 0.0017544283570953923d, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable18, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException7, localizable11, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable42, objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray53);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray61 = numberIsTooLargeException60.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable36, (java.lang.Object[]) throwableArray61);
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, localizable11, objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "4", objArray64);
        int int69 = maxIterationsExceededException68.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable70 = maxIterationsExceededException68.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(localizable70);
    }

//    @Test
//    public void test360() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test360");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        try {
//            double[] doubleArray7 = normalDistributionImpl3.sample((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.220608863950338d + "'", double4 == 1.220608863950338d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.10202284476925438d + "'", double5 == 0.10202284476925438d);
//    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test361");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        try {
//            double double18 = randomDataImpl1.nextCauchy(0.23294588431686317d, (-0.021700921462752897d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.022 is smaller than, or equal to, the minimum (0): scale (-0.022)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.4233035094680382E-5d + "'", double3 == 1.4233035094680382E-5d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.6427522330699373d + "'", double8 == 1.6427522330699373d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 24.95557901274715d + "'", double10 == 24.95557901274715d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f" + "'", str12.equals("f"));
//        org.junit.Assert.assertNotNull(intArray15);
//    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test362");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        double double18 = randomDataImpl1.nextF(0.07196148855387847d, 99.61380843711527d);
//        try {
//            java.lang.String str20 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 9.328131282317557E-7d + "'", double3 == 9.328131282317557E-7d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7965486253162068d + "'", double8 == 0.7965486253162068d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.865014521633602E-9d + "'", double18 == 1.865014521633602E-9d);
//    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        double double11 = randomDataImpl1.nextGaussian(1.2677454753774682d, 1.5440680443502757d);
//        try {
//            double double14 = randomDataImpl1.nextBeta(Double.NaN, 1.9366706971532035d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.925");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.669264202534149E-4d + "'", double3 == 3.669264202534149E-4d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5032341400722992d + "'", double8 == 0.5032341400722992d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.7782761103321627d + "'", double11 == 1.7782761103321627d);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4221817809573358E-5d + "'", double1 == 2.4221817809573358E-5d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.03484675901210895d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.457837608056949d) + "'", double1 == (-1.457837608056949d));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double double1 = org.apache.commons.math.util.FastMath.rint(5.086871406959743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.tan(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.622112081245469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.3851915392854273d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.7068861518200754d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.10948085450959576d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test373() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test373");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        double double27 = randomDataImpl1.nextWeibull(2.874453119022657E-4d, 0.613635339438126d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.439930969018485d + "'", double3 == 3.439930969018485d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7037461827048661d + "'", double8 == 0.7037461827048661d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 22.879012190636995d + "'", double10 == 22.879012190636995d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 26.0d + "'", double22 == 26.0d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + Double.POSITIVE_INFINITY + "'", double27 == Double.POSITIVE_INFINITY);
//    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test374");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson(1.3258176636680326d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("4", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3234931123637237d + "'", double3 == 3.3234931123637237d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.3258176636680326d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.log(0.2252805000650775d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.490408986265822d) + "'", double1 == (-1.490408986265822d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 0, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1693111278598329d + "'", double1 == 0.1693111278598329d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 100, (java.lang.Number) 0.1677205581070077d, false);
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException77 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable73, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable78 = numberIsTooLargeException77.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException83 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable79, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray89 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable78, objArray89);
        java.lang.Object[] objArray91 = convergenceException90.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException92 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "e", objArray91);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable10, objArray91);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray89);
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        double double6 = normalDistributionImpl3.cumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 10.0d + "'", double4 == 10.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.15865525393145702d + "'", double6 == 0.15865525393145702d);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test381");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        try {
//            double double11 = randomDataImpl1.nextBeta(0.0d, 1.0E-9d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.753");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.40010541423375d + "'", double3 == 1.40010541423375d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6171815211553956d + "'", double8 == 0.6171815211553956d);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        double double2 = org.apache.commons.math.util.FastMath.min(121.57441238385887d, 1.2390185292981617E169d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 121.57441238385887d + "'", double2 == 121.57441238385887d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5655388359762742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5146948958912102d + "'", double1 == 0.5146948958912102d);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextF(83.76375854688544d, 182.17140371275474d);
//        try {
//            double double9 = randomDataImpl1.nextBeta(2.871550268396571d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.886");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0261763840821228d + "'", double3 == 1.0261763840821228d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.4650127676650189d + "'", double6 == 1.4650127676650189d);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.sin(100.3629944746982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16718169875287917d) + "'", double1 == (-0.16718169875287917d));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
        double[] doubleArray4 = normalDistributionImpl2.sample(100);
        double double6 = normalDistributionImpl2.cumulativeProbability(2.220446049250313E-16d);
        double double8 = normalDistributionImpl2.density((-0.9861203161417466d));
        double double9 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.4920840976514603d + "'", double6 == 0.4920840976514603d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.041204499906751145d + "'", double8 == 0.041204499906751145d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.609680117110225d + "'", double9 == 9.609680117110225d);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        randomDataImpl1.reSeedSecure((-1L));
//        try {
//            long long22 = randomDataImpl1.nextLong((long) 1, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0969619810376527d + "'", double3 == 1.0969619810376527d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4576325827330112d + "'", double8 == 1.4576325827330112d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        long long1 = org.apache.commons.math.util.FastMath.round(1.3213757317992672d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5491895727074129d), Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5491895727074129d) + "'", double2 == (-0.5491895727074129d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        int int13 = randomDataImpl1.nextPascal((int) ' ', 0.8623188722876839d);
//        double double15 = randomDataImpl1.nextChiSquare(0.4920840976514603d);
//        try {
//            double double17 = randomDataImpl1.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0760093381080822d + "'", double3 == 1.0760093381080822d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.11849907281001174d + "'", double8 == 0.11849907281001174d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 9.081462658727474d + "'", double10 == 9.081462658727474d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.45588012386587745d + "'", double15 == 0.45588012386587745d);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test393");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double11 = normalDistributionImpl9.density(1.0d);
//        double double12 = normalDistributionImpl9.getStandardDeviation();
//        double double13 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        normalDistributionImpl9.reseedRandomGenerator((long) (short) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1646115256221823d + "'", double3 == 1.1646115256221823d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 17.847859038424843d + "'", double6 == 17.847859038424843d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.13755308766604668d + "'", double11 == 0.13755308766604668d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.7092983232354384d + "'", double12 == 2.7092983232354384d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.5823726270206241d) + "'", double13 == (-0.5823726270206241d));
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        int int1 = org.apache.commons.math.util.FastMath.abs(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(100.08134634042824d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.004066490204282d + "'", double1 == 10.004066490204282d);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test396");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution19 = null;
//        try {
//            int int20 = randomDataImpl1.nextInversionDeviate(integerDistribution19);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1581240967440982d + "'", double3 == 1.1581240967440982d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.348713743845508d + "'", double8 == 9.348713743845508d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c" + "'", str10.equals("c"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.2692186688179925E-7d + "'", double15 == 1.2692186688179925E-7d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.9338315672596078d + "'", double18 == 1.9338315672596078d);
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        long long13 = randomDataImpl1.nextSecureLong((long) (short) -1, 0L);
//        try {
//            randomDataImpl1.setSecureAlgorithm("a", "a");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: a");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.143563132854424d + "'", double3 == 1.143563132854424d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.8883096855042687d + "'", double8 == 1.8883096855042687d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
//    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        double double2 = org.apache.commons.math.util.FastMath.pow(83.76375854688544d, 2.403789128831426d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 41939.329458453634d + "'", double2 == 41939.329458453634d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable11, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray22);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("4", objArray22);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException26 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 100, "", objArray22);
        java.lang.Object[] objArray27 = maxIterationsExceededException26.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000001d + "'", double1 == 52.00000000000001d);
    }

//    @Test
//    public void test401() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test401");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double16 = randomDataImpl1.nextF(0.0d, 0.4112205328795488d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8643128215043114d + "'", double3 == 0.8643128215043114d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.307917244926311d + "'", double6 == 7.307917244926311d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.16971945770415d + "'", double9 == 100.16971945770415d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.14063002497396118d + "'", double12 == 0.14063002497396118d);
//    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.014042461610231188d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        double double2 = org.apache.commons.math.util.FastMath.max(2.6121810351099137d, 13.968734023107451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.968734023107451d + "'", double2 == 13.968734023107451d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(83.76375854688544d, 3.451550725171284E-4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.log(0.9000634551020215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.10529001247432142d) + "'", double1 == (-0.10529001247432142d));
    }

//    @Test
//    public void test406() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test406");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        double double24 = normalDistributionImpl20.cumulativeProbability(1.4210854715202004E-14d);
//        double double27 = normalDistributionImpl20.cumulativeProbability(0.5124039897084515d, 9.535603772908695d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7120667373468131d + "'", double3 == 0.7120667373468131d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.5726325369464977d + "'", double8 == 1.5726325369464977d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.8488042171974d + "'", double10 == 10.8488042171974d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 12.0d + "'", double22 == 12.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.15865525393145735d + "'", double24 == 0.15865525393145735d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.31010848153803755d + "'", double27 == 0.31010848153803755d);
//    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test407");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        try {
//            int int26 = randomDataImpl1.nextHypergeometric((int) (short) 0, 100, (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7104452673018941d + "'", double3 == 0.7104452673018941d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.46317458996955974d + "'", double8 == 0.46317458996955974d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 52.615949946874565d + "'", double10 == 52.615949946874565d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "e" + "'", str12.equals("e"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 12.0d + "'", double22 == 12.0d);
//    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 0, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2.5356762196273004d, 4.828586601323504d, 2.114720051539204d, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 4.829 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.15865525393145735d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15799049295540568d + "'", double1 == 0.15799049295540568d);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        long long11 = randomDataImpl1.nextPoisson(1.0279773571668917E-19d);
//        try {
//            double double13 = randomDataImpl1.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7590713014185123d + "'", double3 == 0.7590713014185123d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.601693364606607d + "'", double6 == 11.601693364606607d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.17290292766373d + "'", double9 == 100.17290292766373d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999999999999d) + "'", double1 == (-0.9999999999999999d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 'a', (double) (short) 100, (double) 0L);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        java.lang.Class<?> wildcardClass5 = normalDistributionImpl3.getClass();
        double double6 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Throwable throwable4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException(throwable4);
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.toString();
        java.lang.Object[] objArray8 = mathException5.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException("0", objArray8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable2, objArray8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.MathException: " + "'", str7.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray8);
    }

//    @Test
//    public void test415() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test415");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double15 = normalDistributionImpl13.getMean();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1835150154184904d + "'", double3 == 3.1835150154184904d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.8292430188255302d + "'", double8 == 1.8292430188255302d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6638204538120072d + "'", double14 == 1.6638204538120072d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.9812808189568596E-159d + "'", double15 == 3.9812808189568596E-159d);
//    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.12455110098820214d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.03484675901210895d, 0.3268459902590384d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.03484675901210896d + "'", double2 == 0.03484675901210896d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.10529001247432142d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10529001247432142d + "'", double1 == 0.10529001247432142d);
    }

//    @Test
//    public void test420() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test420");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeed((long) (byte) 0);
//        randomDataImpl1.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.055260867833113d + "'", double3 == 3.055260867833113d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.530442378712815d + "'", double6 == 5.530442378712815d);
//    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.38235421017255d, (java.lang.Number) (-0.5596708127998578d), false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.2710663101885897d, 0.2616136473987553d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2710663101885893d + "'", double2 == 3.2710663101885893d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.5651173151377204E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.476974284907021E-6d + "'", double1 == 4.476974284907021E-6d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.special.Erf.erf(0.44705317267240163d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4727625276820187d + "'", double1 == 0.4727625276820187d);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson(1.3258176636680326d);
//        double double9 = randomDataImpl1.nextWeibull(2.7912452447092146d, 0.04690181386892998d);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution10 = null;
//        try {
//            double double11 = randomDataImpl1.nextInversionDeviate(continuousDistribution10);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.3606888232841112d + "'", double3 == 3.3606888232841112d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05072648840108437d + "'", double9 == 0.05072648840108437d);
//    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test427");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double5 = normalDistributionImpl3.cumulativeProbability((double) 0L);
//        double double7 = normalDistributionImpl3.cumulativeProbability(0.36787944117144233d);
//        double double8 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.15865525393145702d + "'", double5 == 0.15865525393145702d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1677205581070077d + "'", double7 == 0.1677205581070077d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 12.540561974353833d + "'", double8 == 12.540561974353833d);
//    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.7585440704003819d, 54.598150033144236d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4261311892234523E13d + "'", double2 == 2.4261311892234523E13d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.679564408431606E169d, 0.6080800152832633d, 14.0d, 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.1835150154184904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9965713841081946d + "'", double1 == 0.9965713841081946d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0545879805828058d, (java.lang.Number) 76.44167018429081d, true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10L, (java.lang.Number) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 1.9613858336011536d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test433");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        java.lang.String str5 = randomDataImpl1.nextSecureHexString(1);
//        try {
//            int int8 = randomDataImpl1.nextZipf(0, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): dimension (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.374944885427171d + "'", double3 == 2.374944885427171d);
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2" + "'", str5.equals("2"));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.957982976278873d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.29091099706948986d + "'", double1 == 0.29091099706948986d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.atan(26.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5323537367737086d + "'", double1 == 1.5323537367737086d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Number number8 = numberIsTooLargeException6.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable20 = numberIsTooLargeException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray31 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException(localizable20, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException33 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray31);
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException38 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable34, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray39 = numberIsTooLargeException38.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException40 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable14, (java.lang.Object[]) throwableArray39);
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException44 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException("9", objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable9, objArray42);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray42);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.15865525393145702d + "'", number8.equals(0.15865525393145702d));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable22, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11, localizable15, objArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable47, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable61, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray66 = numberIsTooLargeException65.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable41, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "5", (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, localizable9, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray66);
        java.lang.Throwable throwable72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException73);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException74);
        java.lang.Throwable[] throwableArray76 = mathException75.getSuppressed();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException70, "cede62d4d2633857158d51440035feb628dd7167ca46d5dcb0ed59f29b3d245c4dde2153382880a9ae916e196467030f5421", (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = mathException77.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertNull(localizable78);
    }

//    @Test
//    public void test438() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test438");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson(1.3258176636680326d);
//        try {
//            long long9 = randomDataImpl1.nextLong(0L, (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (-1): lower bound (0) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0018859762125415088d + "'", double3 == 0.0018859762125415088d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//    }

//    @Test
//    public void test439() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test439");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        long long12 = randomDataImpl1.nextPoisson(0.8951071437047435d);
//        int int15 = randomDataImpl1.nextBinomial(14, 5.40010943881366E-5d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0017612234763298446d + "'", double3 == 0.0017612234763298446d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2842804566121364d + "'", double8 == 0.2842804566121364d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
//    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.abs(15.788907518582304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.788907518582304d + "'", double1 == 15.788907518582304d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 6.413588051684717d, (java.lang.Number) 2.114720051539204d, (java.lang.Number) 0.07196148855387847d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.114720051539204d + "'", number4.equals(2.114720051539204d));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test442");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        double double11 = randomDataImpl1.nextGaussian(3.1881641653104413d, 0.39205572927448146d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.382537675423824d + "'", double3 == 4.382537675423824d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.879161065628896d + "'", double6 == 4.879161065628896d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.160862282201176d + "'", double11 == 3.160862282201176d);
//    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution25 = null;
//        try {
//            int int26 = randomDataImpl1.nextInversionDeviate(integerDistribution25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.203524005070772d + "'", double3 == 4.203524005070772d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.3891525841459801d + "'", double8 == 0.3891525841459801d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 53.30277385295757d + "'", double10 == 53.30277385295757d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 28.0d + "'", double22 == 28.0d);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        long long8 = randomDataImpl1.nextPoisson(2.4633218980879183d);
//        randomDataImpl1.reSeed();
//        double double12 = randomDataImpl1.nextF(2.0608723157869d, 0.9999999993939677d);
//        randomDataImpl1.reSeedSecure((long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.09784446777929d + "'", double3 == 4.09784446777929d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 271.3998509425464d + "'", double12 == 271.3998509425464d);
//    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test445");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        double double13 = randomDataImpl1.nextGaussian(0.15865525393145702d, 0.5702569604914122d);
//        double double16 = randomDataImpl1.nextUniform(0.05315015091559d, (double) '#');
//        try {
//            randomDataImpl1.setSecureAlgorithm("5", "1");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 1");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.147997474098734d + "'", double3 == 4.147997474098734d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4606206573585148d + "'", double8 == 1.4606206573585148d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 113.62328297003448d + "'", double10 == 113.62328297003448d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.0017308042511191002d) + "'", double13 == (-0.0017308042511191002d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 13.835296911544365d + "'", double16 == 13.835296911544365d);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test449");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double20 = normalDistributionImpl19.getStandardDeviation();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution22 = null;
//        try {
//            int int23 = randomDataImpl1.nextInversionDeviate(integerDistribution22);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.2214564545027895d + "'", double3 == 3.2214564545027895d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5887871478096416d + "'", double8 == 0.5887871478096416d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.405288431728507d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.1646115256221823d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.07434067853644732d) + "'", double1 == (-0.07434067853644732d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooLargeException4.getArgument();
        java.lang.Object[] objArray7 = numberIsTooLargeException4.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.15865525393145702d + "'", number6.equals(0.15865525393145702d));
        org.junit.Assert.assertNotNull(objArray7);
    }

//    @Test
//    public void test453() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test453");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextF(83.76375854688544d, 182.17140371275474d);
//        long long8 = randomDataImpl1.nextPoisson(2.626855756736301E-12d);
//        long long11 = randomDataImpl1.nextSecureLong(0L, (long) 35);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0571423145426215d + "'", double3 == 3.0571423145426215d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.6937007953430917d + "'", double6 == 0.6937007953430917d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
//    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.970291913552122d + "'", double1 == 3.970291913552122d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.530442378712815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09652442860036578d + "'", double1 == 0.09652442860036578d);
    }

//    @Test
//    public void test457() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test457");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        double double13 = randomDataImpl1.nextGaussian(0.15865525393145702d, 0.5702569604914122d);
//        double double16 = randomDataImpl1.nextUniform(0.05315015091559d, (double) '#');
//        randomDataImpl1.reSeedSecure();
//        try {
//            double double20 = randomDataImpl1.nextGamma(2.114720051539204d, (-57.29577951308232d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -57.296 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.57361862232518d + "'", double3 == 3.57361862232518d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5300045855512203d + "'", double8 == 0.5300045855512203d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.684697044787661d + "'", double10 == 4.684697044787661d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.04805706769871759d) + "'", double13 == (-0.04805706769871759d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 12.995368214922241d + "'", double16 == 12.995368214922241d);
//    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, (double) (-1), 1.0545879805828058d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test459() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test459");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextBeta(0.9941201416988211d, 76.44167018429081d);
//        double double15 = randomDataImpl1.nextF(0.11422710742226455d, 0.8474299248014396d);
//        long long18 = randomDataImpl1.nextSecureLong((long) 4, (long) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.496968886880088d + "'", double3 == 3.496968886880088d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 13.630477372253738d + "'", double6 == 13.630477372253738d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 99.87378981428581d + "'", double9 == 99.87378981428581d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.017610834678975965d + "'", double12 == 0.017610834678975965d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.19888438619467214d + "'", double15 == 0.19888438619467214d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 19L + "'", long18 == 19L);
//    }

//    @Test
//    public void test460() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test460");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str15 = randomDataImpl1.nextSecureHexString((int) (short) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.385275858407617d + "'", double3 == 3.385275858407617d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.313770544260198d + "'", double6 == 9.313770544260198d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.13669133606832d + "'", double9 == 100.13669133606832d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.1912001831072971d + "'", double12 == 1.1912001831072971d);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "6c24a0ba7c78036d12c24f186898e7f8178800b1090bac423613a9e332253d3914843d9a4f160f4ce6fa723a393007deb2f2" + "'", str15.equals("6c24a0ba7c78036d12c24f186898e7f8178800b1090bac423613a9e332253d3914843d9a4f160f4ce6fa723a393007deb2f2"));
//    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(390.04434745413175d, 0.22917883241056564d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 390.0443474541317d + "'", double2 == 390.0443474541317d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.405288431728507d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException(throwable3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.toString();
        java.lang.Object[] objArray7 = mathException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("0", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException9.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: " + "'", str6.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNull(localizable10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(27.0d, 2.718281828459045d);
        normalDistributionImpl2.reseedRandomGenerator((long) 12);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.957982976278873d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(12, "{0}", objArray2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable9, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable40, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray59 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable34, (java.lang.Object[]) throwableArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number70 = outOfRangeException69.getArgument();
        convergenceException2.addSuppressed((java.lang.Throwable) outOfRangeException69);
        java.lang.Number number72 = outOfRangeException69.getHi();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 14.0d + "'", number70.equals(14.0d));
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + 0.7068861518200754d + "'", number72.equals(0.7068861518200754d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.4496569512695104d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test469() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test469");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        try {
//            int int16 = randomDataImpl1.nextHypergeometric((int) (byte) 0, 0, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.01637574532061791d + "'", double3 == 0.01637574532061791d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.3249202167591076d + "'", double8 == 3.3249202167591076d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 100, (java.lang.Number) 0.1677205581070077d, false);
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooLargeException70.getSpecificPattern();
        java.lang.Object[] objArray72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(localizable71, objArray72);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        long long2 = org.apache.commons.math.util.FastMath.max(2L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test472");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        long long13 = randomDataImpl1.nextSecureLong((long) (short) -1, 0L);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (short) 1);
//        org.apache.commons.math.random.RandomGenerator randomGenerator16 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl17 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator16);
//        double double19 = randomDataImpl17.nextChiSquare((double) 1.0f);
//        randomDataImpl17.reSeedSecure();
//        double double22 = randomDataImpl17.nextExponential((double) 10.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl25 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double27 = normalDistributionImpl25.density(1.0d);
//        double double28 = normalDistributionImpl25.getStandardDeviation();
//        double double29 = randomDataImpl17.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl25);
//        double double30 = normalDistributionImpl25.getMean();
//        double double31 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl25);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.02144516057984949d + "'", double3 == 0.02144516057984949d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.624577858233646d + "'", double8 == 3.624577858233646d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3" + "'", str10.equals("3"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3" + "'", str15.equals("3"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.021246213383395378d + "'", double19 == 0.021246213383395378d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.834409427327101d + "'", double22 == 5.834409427327101d);
//        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.13755308766604668d + "'", double27 == 0.13755308766604668d);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.7092983232354384d + "'", double28 == 2.7092983232354384d);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-3.826397832750743d) + "'", double29 == (-3.826397832750743d));
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.9812808189568596E-159d + "'", double30 == 3.9812808189568596E-159d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.586006756302883d + "'", double31 == 4.586006756302883d);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double double1 = org.apache.commons.math.special.Erf.erf(2.4695614587186627d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9995214556628339d + "'", double1 == 0.9995214556628339d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable9, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable40, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray59 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable34, (java.lang.Object[]) throwableArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number70 = outOfRangeException69.getArgument();
        convergenceException2.addSuppressed((java.lang.Throwable) outOfRangeException69);
        java.lang.Throwable[] throwableArray72 = outOfRangeException69.getSuppressed();
        java.lang.Number number73 = outOfRangeException69.getHi();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 14.0d + "'", number70.equals(14.0d));
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 0.7068861518200754d + "'", number73.equals(0.7068861518200754d));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.cos(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964139d) + "'", double1 == (-0.9251475365964139d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.log(26.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.258096538021482d + "'", double1 == 3.258096538021482d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(throwable5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooLargeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable26, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException15, localizable19, objArray37);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray62);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable65, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray70 = numberIsTooLargeException69.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable45, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "5", (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6, localizable13, (java.lang.Object[]) throwableArray70);
        java.lang.Object[] objArray74 = new java.lang.Object[] { localizable13 };
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, "", objArray74);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.4261311892234523E13d, 0.40611766574501407d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.426131189223452E13d + "'", double2 == 2.426131189223452E13d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4142135623730951d + "'", double1 == 1.4142135623730951d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.special.Erf.erf(1.6696019009736127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9817828020109759d + "'", double1 == 0.9817828020109759d);
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test483");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        double double18 = randomDataImpl1.nextGamma(1.9927170506183471d, 1.1502738554141714d);
//        int int21 = randomDataImpl1.nextBinomial((int) '#', 0.3032904173475307d);
//        try {
//            int[] intArray24 = randomDataImpl1.nextPermutation((int) (byte) 1, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than the maximum (1): permutation size (52) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1744441839033365d + "'", double3 == 0.1744441839033365d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.870809489869167d + "'", double8 == 0.870809489869167d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 48.05083171686035d + "'", double10 == 48.05083171686035d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.9934410069752556d + "'", double18 == 0.9934410069752556d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 8 + "'", int21 == 8);
//    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        double double11 = randomDataImpl1.nextGaussian(1.2677454753774682d, 1.5440680443502757d);
//        try {
//            long long13 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.13099813806717414d + "'", double3 == 0.13099813806717414d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.48330221507071d + "'", double8 == 4.48330221507071d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.9699180962865059d + "'", double11 == 0.9699180962865059d);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5440680443502757d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.5596708127998578d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-32.06677549008822d) + "'", double1 == (-32.06677549008822d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException(throwable3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable30, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException19, localizable23, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable49 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable50, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException54.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable55, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException73 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable69, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray74 = numberIsTooLargeException73.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable49, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, "5", (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10, localizable17, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.ConvergenceException convergenceException79 = new org.apache.commons.math.ConvergenceException(localizable7, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "1", (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("9", (java.lang.Object[]) throwableArray74);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray74);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("convergence failed", objArray1);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test489");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        int int13 = randomDataImpl1.nextPascal((int) ' ', 0.8623188722876839d);
//        java.lang.Class<?> wildcardClass14 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed((long) (short) 0);
//        java.lang.String str18 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.09443997014316403d + "'", double3 == 0.09443997014316403d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.383358165009458d + "'", double8 == 2.383358165009458d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 115.16828406312467d + "'", double10 == 115.16828406312467d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2 + "'", int13 == 2);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "bf45a4b8d1" + "'", str18.equals("bf45a4b8d1"));
//    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int int16 = randomDataImpl1.nextHypergeometric(4, 4, 0);
//        int int19 = randomDataImpl1.nextZipf((int) (short) 10, 1.3436158727078784d);
//        double double22 = randomDataImpl1.nextBeta(13.555603638817171d, 0.246755651793597d);
//        try {
//            int int25 = randomDataImpl1.nextZipf((int) (byte) 1, (-3.826397832750743d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.826 is smaller than, or equal to, the minimum (0): exponent (-3.826)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.11054373332752161d + "'", double3 == 0.11054373332752161d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.47982847620060814d + "'", double8 == 0.47982847620060814d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 37.04027961403323d + "'", double10 == 37.04027961403323d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f" + "'", str12.equals("f"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2 + "'", int19 == 2);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.9988693176594444d + "'", double22 == 0.9988693176594444d);
//    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray19);
        java.lang.Class<?> wildcardClass22 = mathIllegalArgumentException21.getClass();
        org.apache.commons.math.exception.util.Localizable localizable23 = mathIllegalArgumentException21.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNull(localizable23);
    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test493");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        java.lang.String str17 = randomDataImpl1.nextHexString((int) (byte) 100);
//        try {
//            double double19 = randomDataImpl1.nextChiSquare((double) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.10648309050367973d + "'", double3 == 0.10648309050367973d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.293330750505243d + "'", double8 == 1.293330750505243d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.69093692979733d + "'", double10 == 99.69093692979733d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "c" + "'", str12.equals("c"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "9c4aa6c9cfa035b37c0d628788acb31a1307ac4b137cf3063f921432cea38725b078a18df1230d08b5e502d2bbb26a7cc0e3" + "'", str17.equals("9c4aa6c9cfa035b37c0d628788acb31a1307ac4b137cf3063f921432cea38725b078a18df1230d08b5e502d2bbb26a7cc0e3"));
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        int int1 = org.apache.commons.math.util.FastMath.round(32.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test495");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) (byte) 100);
//        double double16 = randomDataImpl1.nextExponential(2.0608723157869d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.10425497267768559d + "'", double3 == 0.10425497267768559d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.20704793755122253d + "'", double8 == 0.20704793755122253d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 289.78929065558816d + "'", double10 == 289.78929065558816d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "f" + "'", str12.equals("f"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "9701b3dd6d73ab582cebf4e2f4061b7a00bdea61a288ccccef1aa7dc2e09e0fff2fd9df27fff97060acd5192d3516a9349f7" + "'", str14.equals("9701b3dd6d73ab582cebf4e2f4061b7a00bdea61a288ccccef1aa7dc2e09e0fff2fd9df27fff97060acd5192d3516a9349f7"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.297626997111132d + "'", double16 == 2.297626997111132d);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 3.8689523563986046d, (java.lang.Number) 29.823427584010098d, true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 3.8689523563986046d + "'", number5.equals(3.8689523563986046d));
    }

//    @Test
//    public void test497() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test497");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        java.lang.String str26 = randomDataImpl1.nextHexString((int) '4');
//        try {
//            double double29 = randomDataImpl1.nextUniform(7.480949275546874d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 7.481 is larger than, or equal to, the maximum (0): lower bound (7.481) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6247008167297098d + "'", double3 == 0.6247008167297098d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.38725352427350435d + "'", double8 == 0.38725352427350435d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 42.36044993870537d + "'", double10 == 42.36044993870537d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4" + "'", str12.equals("4"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 11.0d + "'", double22 == 11.0d);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1485a6f1561dd6c9341b4f092b4745923ac792971740039818c3" + "'", str26.equals("1485a6f1561dd6c9341b4f092b4745923ac792971740039818c3"));
//    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.7425393557279393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6306769296482175d + "'", double1 == 0.6306769296482175d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        java.lang.Number number67 = outOfRangeException3.getHi();
        java.lang.Class<?> wildcardClass68 = outOfRangeException3.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + number67 + "' != '" + 0.7068861518200754d + "'", number67.equals(0.7068861518200754d));
        org.junit.Assert.assertNotNull(wildcardClass68);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException3);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable13, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray24);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooLargeException31.getGeneralPattern();
        java.lang.Object[] objArray34 = null;
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("0", objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable42, objArray53);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35, "", objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable32, objArray53);
        java.lang.Throwable throwable60 = null;
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(throwable60);
        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61);
        java.lang.String str63 = mathException61.toString();
        java.lang.Object[] objArray64 = mathException61.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("0", objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray64);
        java.lang.Object[] objArray67 = maxIterationsExceededException66.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException3, localizable7, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException("e", objArray67);
        org.apache.commons.math.exception.util.Localizable localizable70 = convergenceException69.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "org.apache.commons.math.MathException: " + "'", str63.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNull(localizable70);
    }
}

