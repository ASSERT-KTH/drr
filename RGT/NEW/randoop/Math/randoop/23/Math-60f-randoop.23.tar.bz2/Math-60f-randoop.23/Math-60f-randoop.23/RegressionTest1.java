import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.3254238456923668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8681264365830231d + "'", double1 == 0.8681264365830231d);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        try {
//            int int14 = randomDataImpl1.nextHypergeometric((int) (byte) -1, 0, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): population size (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.46088976492680334d + "'", double3 == 0.46088976492680334d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.008019815312613d + "'", double8 == 9.008019815312613d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a" + "'", str10.equals("a"));
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) (byte) 100);
//        double double16 = randomDataImpl1.nextChiSquare(0.15865525393145702d);
//        long long18 = randomDataImpl1.nextPoisson(39.179573587676906d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.45250023718314386d + "'", double3 == 0.45250023718314386d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.8568232874763564d + "'", double8 == 2.8568232874763564d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 314.02112850354956d + "'", double10 == 314.02112850354956d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "1c4664fb89690541b21c36310aebe8306f2774c2029ee41f7f349c7cde0f7081bb1072683e6ba6735561a082da21967381c3" + "'", str14.equals("1c4664fb89690541b21c36310aebe8306f2774c2029ee41f7f349c7cde0f7081bb1072683e6ba6735561a082da21967381c3"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.2272484746453115d + "'", double16 == 0.2272484746453115d);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 36L + "'", long18 == 36L);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.10495250262690155d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.FastMath.cos(367.93118819388314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9341781051887746d) + "'", double1 == (-0.9341781051887746d));
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        double double18 = randomDataImpl1.nextGamma(1.9927170506183471d, 1.1502738554141714d);
//        int int21 = randomDataImpl1.nextBinomial((int) '#', 0.3032904173475307d);
//        randomDataImpl1.reSeedSecure(19L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.44105334143992775d + "'", double3 == 0.44105334143992775d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.16771632164748393d + "'", double8 == 0.16771632164748393d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 27.13416274713309d + "'", double10 == 27.13416274713309d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.281967552693515d + "'", double18 == 2.281967552693515d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 11 + "'", int21 == 11);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Number number42 = outOfRangeException41.getHi();
        java.lang.Number number43 = outOfRangeException41.getLo();
        java.lang.Number number44 = outOfRangeException41.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.18749269135908855d + "'", number42.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 10.0d + "'", number43.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 10.0d + "'", number44.equals(10.0d));
    }

//    @Test
//    public void test009() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test009");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double16 = randomDataImpl1.nextT(1.4766507257954695d);
//        try {
//            int[] intArray19 = randomDataImpl1.nextPermutation(0, (-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2956686605401332d + "'", double3 == 0.2956686605401332d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.110386958064631d + "'", double8 == 2.110386958064631d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6638204538120072d + "'", double14 == 1.6638204538120072d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.8384513112557077d) + "'", double16 == (-0.8384513112557077d));
//    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8623188722876839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7116024720019101d + "'", double1 == 0.7116024720019101d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.03484675901210896d, 1.5437100504730839d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02256955054451861d + "'", double2 == 0.02256955054451861d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.41408583590433945d, 0.45344795329738596d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7400568289645066d + "'", double2 == 0.7400568289645066d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(25.635136273949016d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.82452806708709d + "'", double1 == 56.82452806708709d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 39L, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(333.0482237879423d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003007080401952606d + "'", double1 == 0.003007080401952606d);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        double double6 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.inverseCumulativeProbability(0.013890102002911409d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.44359074869610227d) + "'", double4 == (-0.44359074869610227d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.6162258702055494d) + "'", double5 == (-2.6162258702055494d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.7961017916614805d + "'", double6 == 2.7961017916614805d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-7.69592510051079d) + "'", double8 == (-7.69592510051079d));
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.9580487262493174d, 0.0011670530500277384d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5702002982608854d + "'", double2 == 1.5702002982608854d);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test018");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        int[] intArray21 = randomDataImpl1.nextPermutation((int) '#', (int) '#');
//        int int24 = randomDataImpl1.nextPascal(32, 0.17075767871726785d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3138563388683991d + "'", double3 == 0.3138563388683991d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.444951002148959d + "'", double8 == 1.444951002148959d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "f" + "'", str10.equals("f"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.004742744243396794d + "'", double15 == 0.004742744243396794d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.9069831426557704d + "'", double18 == 0.9069831426557704d);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 166 + "'", int24 == 166);
//    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test019");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        int int19 = randomDataImpl1.nextSecureInt((int) (byte) -1, (int) (short) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3356789975799492d + "'", double3 == 0.3356789975799492d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5610846350856726d + "'", double8 == 0.5610846350856726d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 107.72227605541221d + "'", double10 == 107.72227605541221d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "a" + "'", str12.equals("a"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 100, (java.lang.Number) 0.1677205581070077d, false);
        org.apache.commons.math.exception.util.Localizable localizable71 = numberIsTooLargeException70.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable71, (java.lang.Number) 1.7525335428452429d);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + localizable71 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable71.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(throwable8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, localizable22, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable49, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable55, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable54, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray65);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable68, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray73 = numberIsTooLargeException72.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable48, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "5", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, localizable16, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable6, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "1", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.exception.util.Localizable localizable80 = maxIterationsExceededException79.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertNotNull(localizable80);
    }

//    @Test
//    public void test022() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test022");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        long long13 = randomDataImpl1.nextSecureLong((long) (short) -1, 0L);
//        java.lang.String str15 = randomDataImpl1.nextHexString((int) (short) 1);
//        int int18 = randomDataImpl1.nextSecureInt(5, 11);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.10502341260776125d + "'", double3 == 0.10502341260776125d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.7965584242991823d + "'", double8 == 1.7965584242991823d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "3" + "'", str15.equals("3"));
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
//    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.24402531179839718d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(throwable6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7);
        java.lang.String str9 = mathException7.toString();
        java.lang.Object[] objArray10 = mathException7.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException("0", objArray10);
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "", objArray10);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.MathException: " + "'", str9.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long1 = org.apache.commons.math.util.FastMath.round(3.970291913552122d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) -1, (java.lang.Number) 0.1677205581070077d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        java.lang.Object[] objArray6 = null;
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "2", objArray6);
        org.junit.Assert.assertNull(localizable4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        randomDataImpl1.reSeed();
//        double double19 = randomDataImpl1.nextF(5.840853025906053E-7d, (double) '4');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05090884793564899d + "'", double3 == 0.05090884793564899d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.39876833423087177d + "'", double8 == 0.39876833423087177d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        long long8 = randomDataImpl1.nextPoisson(2.4633218980879183d);
//        long long10 = randomDataImpl1.nextPoisson(0.26416163312575686d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.04859833764390029d + "'", double3 == 0.04859833764390029d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1L + "'", long10 == 1L);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.1763382298382675d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0155879153363478d + "'", double1 == 1.0155879153363478d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.26416163312575686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2673345749290213d + "'", double1 == 0.2673345749290213d);
    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double11 = normalDistributionImpl9.density(1.0d);
//        double double12 = normalDistributionImpl9.getStandardDeviation();
//        double double13 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double14 = normalDistributionImpl9.getMean();
//        double double16 = normalDistributionImpl9.inverseCumulativeProbability(0.03692522815132798d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.06014907374735436d + "'", double3 == 0.06014907374735436d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.6488598006011077d + "'", double6 == 1.6488598006011077d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.13755308766604668d + "'", double11 == 0.13755308766604668d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.7092983232354384d + "'", double12 == 2.7092983232354384d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.5837982104922825d + "'", double13 == 1.5837982104922825d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.9812808189568596E-159d + "'", double14 == 3.9812808189568596E-159d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-4.842975715531536d) + "'", double16 == (-4.842975715531536d));
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.021700921462752897d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.021700921462752893d) + "'", double1 == (-0.021700921462752893d));
    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05823588258779492d + "'", double3 == 0.05823588258779492d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7469855756263192d + "'", double8 == 0.7469855756263192d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
//    }

//    @Test
//    public void test038() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test038");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double14 = randomDataImpl1.nextT(97.70870524046074d);
//        try {
//            long long16 = randomDataImpl1.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.059357327873334455d + "'", double3 == 0.059357327873334455d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.00895071698527d + "'", double8 == 4.00895071698527d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "f" + "'", str10.equals("f"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.858203212677484d) + "'", double14 == (-1.858203212677484d));
//    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        randomDataImpl1.reSeed();
//        try {
//            double double21 = randomDataImpl1.nextUniform(3.4713071809033917d, 0.7120667373468131d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3.471 is larger than, or equal to, the maximum (0.712): lower bound (3.471) must be strictly less than upper bound (0.712)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.057015365908078035d + "'", double3 == 0.057015365908078035d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.41970584828349367d + "'", double8 == 0.41970584828349367d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//    }

//    @Test
//    public void test040() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test040");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        try {
//            double double15 = randomDataImpl1.nextGamma(2.874453119022657E-4d, 2.5651173151377204E-4d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NoBracketingException; message: function values at endpoints do not have different signs, endpoints: [0, 0], values: [0.474, 0.662]: number of iterations=1, maximum iterations=2,147,483,647, initial=0, lower bound=0, upper bound=0, final a value=0, final b value=0, f(a)=0.474, f(b)=0.662");
//        } catch (org.apache.commons.math.exception.NoBracketingException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05762391081788172d + "'", double3 == 0.05762391081788172d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 7.392157725100215d + "'", double6 == 7.392157725100215d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 99.84787772585301d + "'", double9 == 99.84787772585301d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.7896743484749423d) + "'", double12 == (-0.7896743484749423d));
//    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5679426215091478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-0.5772156677920679d), (java.lang.Number) 0.613635339438126d, true);
        java.lang.Number number22 = numberIsTooLargeException21.getMax();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.613635339438126d + "'", number22.equals(0.613635339438126d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray4 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) 31.999999932788864d, false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooLargeException9);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.2272484746453115d, (-2.7994340487660896d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 63.304280328409845d + "'", double2 == 63.304280328409845d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.7755575615628914E-17d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.acosh(6.413588051684717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5454322047749787d + "'", double1 == 2.5454322047749787d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.0007776603995886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3864887573236213d + "'", double1 == 1.3864887573236213d);
    }

//    @Test
//    public void test052() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test052");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        double double10 = randomDataImpl1.nextChiSquare(3.406911371409484d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.06296406579359577d + "'", double3 == 0.06296406579359577d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.156030476558962d + "'", double6 == 6.156030476558962d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.912291920165859d + "'", double10 == 4.912291920165859d);
//    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.03625982264712382d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03626776875261199d + "'", double1 == 0.03626776875261199d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(throwable5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooLargeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable26, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException15, localizable19, objArray37);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray62);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable65, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray70 = numberIsTooLargeException69.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable45, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "5", (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6, localizable13, (java.lang.Object[]) throwableArray70);
        java.lang.Throwable[] throwableArray74 = mathException6.getSuppressed();
        java.lang.Class<?> wildcardClass75 = mathException6.getClass();
        org.apache.commons.math.exception.util.Localizable localizable76 = mathException6.getSpecificPattern();
        java.lang.String str77 = mathException6.toString();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) mathException6);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNull(localizable76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.MathException: " + "'", str77.equals("org.apache.commons.math.MathException: "));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.2416106283173886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.24648388642979502d + "'", double1 == 0.24648388642979502d);
    }

//    @Test
//    public void test056() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test056");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextF(83.76375854688544d, 182.17140371275474d);
//        long long8 = randomDataImpl1.nextPoisson(2.626855756736301E-12d);
//        try {
//            long long11 = randomDataImpl1.nextSecureLong(100L, 1L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.04728901642439613d + "'", double3 == 0.04728901642439613d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.1025741284793142d + "'", double6 == 1.1025741284793142d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.03692522815132798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1156597306287486d + "'", double1 == 2.1156597306287486d);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextExponential(0.16087055809932455d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0462451523474614d + "'", double3 == 0.0462451523474614d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8783382953228702d + "'", double8 == 0.8783382953228702d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4" + "'", str10.equals("4"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.501754128684845E-7d + "'", double15 == 6.501754128684845E-7d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.28463194376572204d + "'", double18 == 0.28463194376572204d);
//    }

//    @Test
//    public void test059() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test059");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) (byte) 100);
//        double double16 = randomDataImpl1.nextChiSquare(0.15865525393145702d);
//        double double18 = randomDataImpl1.nextExponential(0.3554995468632081d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.04565413340205397d + "'", double3 == 0.04565413340205397d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.01808455323051053d + "'", double8 == 0.01808455323051053d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 85.35848709938048d + "'", double10 == 85.35848709938048d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "e" + "'", str12.equals("e"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ec1ffb2c36123617a356864d5f343418c935401606992e8a40ce8e97cdf77c0312abcf0bd741b599305f1252fbb981913a6b" + "'", str14.equals("ec1ffb2c36123617a356864d5f343418c935401606992e8a40ce8e97cdf77c0312abcf0bd741b599305f1252fbb981913a6b"));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.19310408199859513d + "'", double16 == 0.19310408199859513d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.09886627840501833d + "'", double18 == 0.09886627840501833d);
//    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.25710464730999916d, 0.9965713841081946d, 1.5702002982608854d, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4075479284384708d + "'", double4 == 0.4075479284384708d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.8653450264627532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6234460367695621d + "'", double1 == 0.6234460367695621d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) '4');
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable12, objArray23);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray23);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray31 = numberIsTooLargeException30.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException32 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable6, (java.lang.Object[]) throwableArray31);
        java.lang.Object[] objArray34 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray34);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray34);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException40 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.24402531179839718d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Object[] objArray41 = numberIsTooLargeException40.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray41);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "org.apache.commons.math.exception.MathIllegalArgumentException: 0.159 is smaller than, or equal to, the minimum ()", objArray41);
        org.apache.commons.math.exception.util.Localizable localizable44 = maxIterationsExceededException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = maxIterationsExceededException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNull(localizable44);
        org.junit.Assert.assertNull(localizable45);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

//    @Test
//    public void test064() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test064");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl13 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.9812808189568596E-159d, 2.7092983232354384d);
//        double double14 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl13);
//        double double17 = randomDataImpl1.nextCauchy(3.439930969018485d, 0.1772977640467847d);
//        try {
//            double double20 = randomDataImpl1.nextWeibull(0.0d, 76.44167018429083d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): shape (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3930351673663615d + "'", double3 == 0.3930351673663615d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.722131118129936d + "'", double8 == 0.722131118129936d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.6638204538120072d + "'", double14 == 1.6638204538120072d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.271119154491997d + "'", double17 == 3.271119154491997d);
//    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.ceil(3.1835150154184904d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.asin(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.special.Gamma.digamma(3.439930969018485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0831145746332316d + "'", double1 == 1.0831145746332316d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5722984289556622d, (java.lang.Number) 0.0017544283570953923d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0017544283570953923d + "'", number5.equals(0.0017544283570953923d));
    }

//    @Test
//    public void test069() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test069");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        double double11 = randomDataImpl1.nextGaussian(1.2677454753774682d, 1.5440680443502757d);
//        try {
//            java.lang.String str13 = randomDataImpl1.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3835210319446257d + "'", double3 == 0.3835210319446257d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.197489471879699d + "'", double8 == 2.197489471879699d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.0776905837380557d + "'", double11 == 3.0776905837380557d);
//    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.cosh(390.0443474541317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2390185292980913E169d + "'", double1 == 1.2390185292980913E169d);
    }

//    @Test
//    public void test071() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test071");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        try {
//            randomDataImpl1.setSecureAlgorithm("0", "d");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: d");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3799947336465772d + "'", double3 == 0.3799947336465772d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0785069432062464d + "'", double8 == 2.0785069432062464d);
//    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.5655388359762742d, number1, (java.lang.Number) 0.35932095629328176d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.35126798438961054d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.126172983591967d + "'", double1 == 20.126172983591967d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.158638853279167d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test076");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential(1.2390185292981617E169d);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4111392582676734d + "'", double3 == 0.4111392582676734d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.7442031636233744d + "'", double8 == 1.7442031636233744d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.679564408431606E169d + "'", double17 == 1.679564408431606E169d);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable7, objArray18);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(throwable0, localizable1, objArray18);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.626855756736301E-12d, 12.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.6268557567363016E-12d + "'", double2 == 2.6268557567363016E-12d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.FastMath.min(1.8614849631051733d, 0.07313187804841101d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.07313187804841101d + "'", double2 == 0.07313187804841101d);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        double double13 = randomDataImpl1.nextGaussian(0.15865525393145702d, 0.5702569604914122d);
//        double double16 = randomDataImpl1.nextUniform(0.05315015091559d, (double) '#');
//        randomDataImpl1.reSeedSecure();
//        int int20 = randomDataImpl1.nextZipf((int) (short) 100, 0.10425497267768559d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.3981989750006367d + "'", double3 == 0.3981989750006367d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9760582755807474d + "'", double8 == 0.9760582755807474d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 114.14512033183865d + "'", double10 == 114.14512033183865d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.47175442574665516d + "'", double13 == 0.47175442574665516d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 7.521174815586791d + "'", double16 == 7.521174815586791d);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 5 + "'", int20 == 5);
//    }

//    @Test
//    public void test082() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test082");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        int int13 = randomDataImpl1.nextZipf((int) (short) 1, 63.304280328409845d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.40201576122816307d + "'", double3 == 0.40201576122816307d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18602827307190342d + "'", double8 == 0.18602827307190342d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 221.4625630039584d + "'", double10 == 221.4625630039584d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 11);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 11.0f + "'", float1 == 11.0f);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 10, 1.2390185292981617E169d);
        double double4 = normalDistributionImpl2.density(0.613635339438126d);
        double double5 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.2198249741060155E-170d + "'", double4 == 3.2198249741060155E-170d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            int int19 = randomDataImpl1.nextHypergeometric(100, (-1), 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.34312560713652085d + "'", double3 == 0.34312560713652085d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8523080242449463d + "'", double8 == 0.8523080242449463d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        int[] intArray21 = randomDataImpl1.nextPermutation((int) '#', (int) '#');
//        double double24 = randomDataImpl1.nextGamma(1.5440680443502757d, 0.957982976278873d);
//        long long27 = randomDataImpl1.nextSecureLong((long) 14, (long) '4');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.33645508549999215d + "'", double3 == 0.33645508549999215d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.203968706696877d + "'", double8 == 8.203968706696877d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.1828587918213517E-7d + "'", double15 == 1.1828587918213517E-7d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.488072066616485d + "'", double18 == 1.488072066616485d);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.079813899582517d + "'", double24 == 0.079813899582517d);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 22L + "'", long27 == 22L);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Number number42 = outOfRangeException41.getHi();
        java.lang.Number number43 = outOfRangeException41.getHi();
        java.lang.Number number44 = outOfRangeException41.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.18749269135908855d + "'", number42.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.18749269135908855d + "'", number43.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.18749269135908855d + "'", number44.equals(0.18749269135908855d));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.4713071809033917d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9578079307415936d + "'", double1 == 1.9578079307415936d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        int int3 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5323537367737086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

//    @Test
//    public void test091() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test091");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        java.lang.String str14 = randomDataImpl1.nextHexString((int) (byte) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("4", "606121f5bc004b817a8b99c0199819611a236f0c19e8f235de90b83373f6f2b0c92d8d97e3ac37891b9c3126e933428b369c");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 606121f5bc004b817a8b99c0199819611a236f0c19e8f235de90b83373f6f2b0c92d8d97e3ac37891b9c3126e933428b369c");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.24546070505895143d + "'", double3 == 0.24546070505895143d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2444469638155509d + "'", double8 == 0.2444469638155509d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 269.1267980038202d + "'", double10 == 269.1267980038202d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "4" + "'", str12.equals("4"));
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "efe4418a62344dc72a6f926530493495c87a67b67f83d43c2d37df25b90f3a2f4d8c098d41049964606cf336225fbb5952a4" + "'", str14.equals("efe4418a62344dc72a6f926530493495c87a67b67f83d43c2d37df25b90f3a2f4d8c098d41049964606cf336225fbb5952a4"));
//    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double16 = randomDataImpl1.nextGaussian(2.5356762196273004d, 0.05315015091559d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.24395428740325092d + "'", double3 == 0.24395428740325092d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.46727683351869126d + "'", double8 == 0.46727683351869126d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.5821655349867285d + "'", double16 == 2.5821655349867285d);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable9, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable40, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray59 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable34, (java.lang.Object[]) throwableArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray62);
        java.lang.String str66 = mathException65.toString();
        java.lang.String str67 = mathException65.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "org.apache.commons.math.MathException: {0} is smaller than, or equal to, the minimum ({1})" + "'", str66.equals("org.apache.commons.math.MathException: {0} is smaller than, or equal to, the minimum ({1})"));
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "{0} is smaller than, or equal to, the minimum ({1})" + "'", str67.equals("{0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.5651173151377204E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5647883800449705E-4d + "'", double1 == 2.5647883800449705E-4d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable9, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        java.lang.Class<?> wildcardClass42 = localizable29.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) (-0.7321877967059738d), (java.lang.Number) (-0.5772156677920679d), true);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException23, localizable29, objArray47);
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 367.93118819388314d, (java.lang.Number) 11.77352792708925d, number51);
        java.lang.Number number53 = outOfRangeException52.getLo();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 11.77352792708925d + "'", number53.equals(11.77352792708925d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.tan(83.76375854688544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7812621030612283d) + "'", double1 == (-1.7812621030612283d));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException(number0, (java.lang.Number) 13.274948879489813d, (java.lang.Number) (-7.048335655632335d));
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) (byte) 10, 0.07196148855387847d, 0.7068861518200754d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.612088359279078E-19d + "'", double4 == 9.612088359279078E-19d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) 0L);
        double double7 = normalDistributionImpl3.cumulativeProbability(0.36787944117144233d);
        double double8 = normalDistributionImpl3.getStandardDeviation();
        double double10 = normalDistributionImpl3.cumulativeProbability(5.834409427327101d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.15865525393145702d + "'", double5 == 0.15865525393145702d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1677205581070077d + "'", double7 == 0.1677205581070077d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.3385004809376946d + "'", double10 == 0.3385004809376946d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.2655760834989819d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2595035930275952d + "'", double1 == 0.2595035930275952d);
    }

//    @Test
//    public void test101() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test101");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) 4);
//        long long8 = randomDataImpl1.nextPoisson(4.09784446777929d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8163927408070395d + "'", double3 == 0.8163927408070395d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1L + "'", long6 == 1L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9965713841081946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017393451883845088d + "'", double1 == 0.017393451883845088d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable11, objArray22);
        java.lang.Class<?> wildcardClass24 = localizable11.getClass();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable30, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable11, objArray41);
        java.lang.Throwable throwable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooLargeException51.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable52, objArray63);
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException("", objArray63);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(throwable44, "hi!", objArray63);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, localizable11, objArray63);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException71 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 100, (java.lang.Number) 0.1677205581070077d, false);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException75 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable76 = notStrictlyPositiveException75.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException81 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable77, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable82 = numberIsTooLargeException81.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException87 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable83, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray93 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException(localizable82, objArray93);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable76, objArray93);
        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException("4", objArray93);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException97 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray93);
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException0, localizable11, objArray93);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 14.0d + "'", number5.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray93);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException(throwable3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.toString();
        java.lang.Object[] objArray7 = mathException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("0", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable10 = maxIterationsExceededException9.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: " + "'", str6.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable10);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        int int2 = org.apache.commons.math.util.FastMath.max(32, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long1 = org.apache.commons.math.util.FastMath.round(3.7230614508084154d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

//    @Test
//    public void test107() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test107");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        long long13 = randomDataImpl1.nextSecureLong((long) (short) -1, 0L);
//        try {
//            int int16 = randomDataImpl1.nextInt(1, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5884782724885395d + "'", double3 == 0.5884782724885395d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.9980018002751624d + "'", double8 == 0.9980018002751624d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + (-1L) + "'", long13 == (-1L));
//    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        double double18 = randomDataImpl1.nextExponential(0.8951071437047435d);
//        int int21 = randomDataImpl1.nextZipf((int) '#', 4.09784446777929d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.5788317944192077d + "'", double3 == 0.5788317944192077d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.145306817808254d + "'", double8 == 2.145306817808254d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 23.400191772351928d + "'", double10 == 23.400191772351928d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "3" + "'", str12.equals("3"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5307578367776149d + "'", double18 == 0.5307578367776149d);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double5 = normalDistributionImpl3.cumulativeProbability((double) 0L);
//        double double7 = normalDistributionImpl3.cumulativeProbability(0.36787944117144233d);
//        double double8 = normalDistributionImpl3.getStandardDeviation();
//        double double9 = normalDistributionImpl3.sample();
//        double double11 = normalDistributionImpl3.inverseCumulativeProbability(0.2595035930275952d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.15865525393145702d + "'", double5 == 0.15865525393145702d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1677205581070077d + "'", double7 == 0.1677205581070077d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 13.41317512860881d + "'", double9 == 13.41317512860881d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
//    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        long long11 = randomDataImpl1.nextPoisson(1.0279773571668917E-19d);
//        double double14 = randomDataImpl1.nextCauchy(0.246755651793597d, 1.488072066616485d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6312872889326853d + "'", double3 == 0.6312872889326853d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.8937981168300015d + "'", double6 == 1.8937981168300015d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.00600414069905d + "'", double9 == 100.00600414069905d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.2093657177244722d + "'", double14 == 0.2093657177244722d);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 39L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

//    @Test
//    public void test113() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test113");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        java.lang.String str8 = randomDataImpl1.nextSecureHexString(166);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6320214789954228d + "'", double3 == 0.6320214789954228d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5e727ed763fc6527d928010de5dd01dded0ed088545e0f53e259b3c305e805911bc060211ef3e2187e2faba7d460a70eb703d64718e8bf74f154151d898f0bbeb3d44d978a1bc4399a7768212946e1b185fa37" + "'", str8.equals("5e727ed763fc6527d928010de5dd01dded0ed088545e0f53e259b3c305e805911bc060211ef3e2187e2faba7d460a70eb703d64718e8bf74f154151d898f0bbeb3d44d978a1bc4399a7768212946e1b185fa37"));
//    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8207504124421311d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray22 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException(localizable11, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray22);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray30 = numberIsTooLargeException29.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable5, (java.lang.Object[]) throwableArray30);
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray33);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException36 = new org.apache.commons.math.MaxIterationsExceededException(0, "org.apache.commons.math.exception.OutOfRangeException: 14 out of [0.168, 0.707] range", objArray33);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(throwableArray30);
        org.junit.Assert.assertNotNull(objArray33);
    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test116");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double20 = normalDistributionImpl19.getStandardDeviation();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        randomDataImpl1.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6576581813429226d + "'", double3 == 0.6576581813429226d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.8221509464989576d + "'", double8 == 2.8221509464989576d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
//    }

//    @Test
//    public void test117() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test117");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        try {
//            randomDataImpl1.setSecureAlgorithm("6c24a0ba7c78036d12c24f186898e7f8178800b1090bac423613a9e332253d3914843d9a4f160f4ce6fa723a393007deb2f2", "5");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 5");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6456066558460395d + "'", double3 == 0.6456066558460395d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8352775167964006d + "'", double8 == 0.8352775167964006d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        try {
//            int int19 = randomDataImpl1.nextHypergeometric((int) ' ', 35, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than the maximum (32): number of successes (35) must be less than or equal to population size (32)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.6488524853035116d + "'", double3 == 0.6488524853035116d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.917657670212211d + "'", double8 == 3.917657670212211d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) 10, 1.2390185292981617E169d);
        double double5 = normalDistributionImpl2.cumulativeProbability(0.35932095629328176d, 0.5610846350856726d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 0, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.acosh(57.933951980514756d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7523762891111305d + "'", double1 == 4.7523762891111305d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double2 = org.apache.commons.math.util.FastMath.min(0.10529001247432142d, (-2.282752375752627d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.282752375752627d) + "'", double2 == (-2.282752375752627d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.4210854715202004E-14d, (-1.3286196444902505d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.329 is smaller than, or equal to, the minimum (0): standard deviation (-1.329)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException(throwable3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable11 = numberIsTooLargeException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("", objArray35);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException13, localizable17, objArray35);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable43 = notStrictlyPositiveException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooLargeException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable50, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray60 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable49, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable43, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException67 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable63, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray68 = numberIsTooLargeException67.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException69 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable43, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException38, "5", (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4, localizable11, (java.lang.Object[]) throwableArray68);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray68);
        java.lang.Object[] objArray73 = mathException72.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("e", objArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException("3", objArray73);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(throwableArray68);
        org.junit.Assert.assertNotNull(objArray73);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.4920840976514603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5880639150119724d + "'", double1 == 0.5880639150119724d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.log(1.8991486712299178E-5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-10.871519746983921d) + "'", double1 == (-10.871519746983921d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        java.lang.Throwable[] throwableArray67 = mathException66.getSuppressed();
        java.lang.Object[] objArray68 = mathException66.getArguments();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.2735701380514667d, number20, false);
        java.lang.Number number23 = numberIsTooSmallException22.getMin();
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooSmallException22.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNull(number23);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable8, objArray19);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException("", objArray19);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(throwable0, "hi!", objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray39 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable28, objArray39);
        java.lang.Class<?> wildcardClass41 = localizable28.getClass();
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable28, (java.lang.Number) 0.2735701380514667d, number43, false);
        java.lang.Object[] objArray46 = null;
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(localizable28, objArray46);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number52 = outOfRangeException51.getArgument();
        java.lang.Object[] objArray53 = outOfRangeException51.getArguments();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(throwable0, localizable28, objArray53);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + number52 + "' != '" + 14.0d + "'", number52.equals(14.0d));
        org.junit.Assert.assertNotNull(objArray53);
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test131");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextF(83.76375854688544d, 182.17140371275474d);
//        long long8 = randomDataImpl1.nextPoisson(2.626855756736301E-12d);
//        try {
//            int int11 = randomDataImpl1.nextSecureInt((int) 'a', (int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (10): lower bound (97) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3041637009970957d + "'", double3 == 1.3041637009970957d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0386643307371652d + "'", double6 == 1.0386643307371652d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
//    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test132");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        int int13 = randomDataImpl1.nextPascal((int) ' ', 0.8623188722876839d);
//        try {
//            double double16 = randomDataImpl1.nextGaussian(76.38241083804157d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2992521241427755d + "'", double3 == 1.2992521241427755d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.1356244005809475d + "'", double8 == 2.1356244005809475d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 79.00159546755805d + "'", double10 == 79.00159546755805d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 7 + "'", int13 == 7);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7469855756263192d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6907338962202332d + "'", double1 == 0.6907338962202332d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Number number5 = numberIsTooLargeException4.getMax();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) 31.999999932788864d, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 31.999999932788864d + "'", number4.equals(31.999999932788864d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.6488598006011077d, 2.4132240024472974E66d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.4011955617701017d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4120451084673449d + "'", double1 == 0.4120451084673449d);
    }

//    @Test
//    public void test139() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test139");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure((long) 2);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2479985818232375d + "'", double3 == 1.2479985818232375d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 8.528105884467477d + "'", double6 == 8.528105884467477d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 99.9774800249407d + "'", double9 == 99.9774800249407d);
//    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(52);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-0.7321877967059738d), (java.lang.Number) (-0.5772156677920679d), true);
        boolean boolean23 = numberIsTooLargeException22.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException22);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

//    @Test
//    public void test143() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test143");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        int int13 = randomDataImpl1.nextPascal((int) ' ', 0.8623188722876839d);
//        java.lang.Class<?> wildcardClass14 = randomDataImpl1.getClass();
//        randomDataImpl1.reSeed((long) (short) 0);
//        try {
//            double double19 = randomDataImpl1.nextGamma(0.0d, 0.09886627840501833d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3503749350742995d + "'", double3 == 1.3503749350742995d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05357612194406071d + "'", double8 == 0.05357612194406071d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 41.35875758885009d + "'", double10 == 41.35875758885009d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(wildcardClass14);
//    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 'a', (double) (short) 100, (double) 0L);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.density(0.29802717539028206d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 97.0d + "'", double4 == 97.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0024994806802126797d + "'", double6 == 0.0024994806802126797d);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        int[] intArray21 = randomDataImpl1.nextPermutation((int) '#', (int) '#');
//        try {
//            int int24 = randomDataImpl1.nextPascal(32, 85.35848709938048d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 85.358 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.8878869133165823d + "'", double3 == 2.8878869133165823d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.5650143149170797d + "'", double8 == 1.5650143149170797d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8" + "'", str10.equals("8"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.431683178600326E-4d + "'", double15 == 2.431683178600326E-4d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.1336893662204128d) + "'", double18 == (-1.1336893662204128d));
//        org.junit.Assert.assertNotNull(intArray21);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        long long8 = randomDataImpl1.nextPoisson(2.4633218980879183d);
//        randomDataImpl1.reSeed();
//        int int12 = randomDataImpl1.nextInt(11, (int) '#');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.909057289136766d + "'", double3 == 2.909057289136766d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 33 + "'", int12 == 33);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.rint(7.521174815586791d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        int int1 = org.apache.commons.math.util.FastMath.abs(14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 14 + "'", int1 == 14);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 0.17794392589248942d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooLargeException4.getMax();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        java.lang.Number number8 = numberIsTooLargeException4.getMax();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (-1L) + "'", number6.equals((-1L)));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (-1L) + "'", number8.equals((-1L)));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.24402531179839718d, (java.lang.Number) (-0.5772156677920679d), false);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException(throwable13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14);
        java.lang.String str16 = mathException14.toString();
        java.lang.Object[] objArray17 = mathException14.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException("0", objArray17);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException19 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray17);
        java.lang.Object[] objArray20 = maxIterationsExceededException19.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException21 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, "", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(throwable6, localizable7, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, "748db3748a10e0821af86044de4cce131479e1897f8aa7d5753705cd39d7114991009be1ff34a8d47c3be53240910053c844", objArray20);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.MathException: " + "'", str16.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray20);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test152");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        double double11 = randomDataImpl1.nextGaussian(1.2677454753774682d, 1.5440680443502757d);
//        java.lang.String str13 = randomDataImpl1.nextSecureHexString((int) 'a');
//        int[] intArray16 = randomDataImpl1.nextPermutation(32, 12);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.5787971379015318d + "'", double3 == 3.5787971379015318d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.787891473524783d + "'", double8 == 3.787891473524783d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 3.719677202182918d + "'", double11 == 3.719677202182918d);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "5f395cb6830485d8de8196ca9065e4af8a38fd90f7e8ef76d7ee7ca6d896ce8314c98375768aa867ce1d150d5dcac6140" + "'", str13.equals("5f395cb6830485d8de8196ca9065e4af8a38fd90f7e8ef76d7ee7ca6d896ce8314c98375768aa867ce1d150d5dcac6140"));
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.7151568462037634d, (double) 33, 2.1156597306287486d);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        randomDataImpl1.reSeed(22L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.4946538625211505d + "'", double3 == 3.4946538625211505d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.684786899118404d + "'", double8 == 2.684786899118404d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.624577858233646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.6245778582336463d + "'", double1 == 3.6245778582336463d);
    }

//    @Test
//    public void test157() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test157");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl1.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.4378846156933904d + "'", double3 == 3.4378846156933904d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.28054250554675525d + "'", double8 == 0.28054250554675525d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 103.84990051420024d + "'", double10 == 103.84990051420024d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "8" + "'", str12.equals("8"));
//    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Number number5 = outOfRangeException3.getHi();
        java.lang.Throwable throwable8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(throwable8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, localizable22, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable49, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable55, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable54, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray65);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable68, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray73 = numberIsTooLargeException72.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable48, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "5", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, localizable16, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", (java.lang.Object[]) throwableArray73);
        java.lang.Number number79 = outOfRangeException3.getHi();
        java.lang.Number number80 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.7068861518200754d + "'", number5.equals(0.7068861518200754d));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.7068861518200754d + "'", number79.equals(0.7068861518200754d));
        org.junit.Assert.assertTrue("'" + number80 + "' != '" + 0.7068861518200754d + "'", number80.equals(0.7068861518200754d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, objArray21);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException("5f395cb6830485d8de8196ca9065e4af8a38fd90f7e8ef76d7ee7ca6d896ce8314c98375768aa867ce1d150d5dcac6140", objArray21);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.385275858407617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable22, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11, localizable15, objArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable47, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable61, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray66 = numberIsTooLargeException65.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable41, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "5", (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, localizable9, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray66);
        java.lang.Throwable throwable72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException73);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException74);
        java.lang.Throwable[] throwableArray76 = mathException75.getSuppressed();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException70, "cede62d4d2633857158d51440035feb628dd7167ca46d5dcb0ed59f29b3d245c4dde2153382880a9ae916e196467030f5421", (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = mathException70.getGeneralPattern();
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException70);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertNotNull(localizable78);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.3554995468632081d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3480587202085134d + "'", double1 == 0.3480587202085134d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6320214789954228d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooLargeException4.getSuppressed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean7 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
        java.lang.Throwable[] throwableArray1 = convergenceException0.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 11.77352792708925d, number1, false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.expm1(56.82452806708709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.770665606107903E24d + "'", double1 == 4.770665606107903E24d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Throwable throwable7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(throwable7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException14.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException20 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException20.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable28 = numberIsTooLargeException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray39 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException(localizable28, objArray39);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException17, localizable21, objArray39);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable47 = notStrictlyPositiveException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooLargeException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray64 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable53, objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException71 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable67, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray72 = numberIsTooLargeException71.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable47, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException42, "5", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8, localizable15, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable5, (java.lang.Object[]) throwableArray72);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException77);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(throwableArray72);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.014618650053075126d, number1, true);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test171");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        try {
//            long long12 = randomDataImpl1.nextSecureLong((long) 5, (long) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (1): lower bound (5) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.020073650489836968d + "'", double3 == 0.020073650489836968d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 12.529214062541135d + "'", double6 == 12.529214062541135d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.11666792157395d + "'", double9 == 100.11666792157395d);
//    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        double double6 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.cumulativeProbability(1.1502738554141714d);
//        double double10 = normalDistributionImpl3.density(0.8207504124421311d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.7189993983895302d) + "'", double4 == (-1.7189993983895302d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0810047924427055d + "'", double5 == 1.0810047924427055d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.7038874322864803d + "'", double6 == 2.7038874322864803d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6248420117881944d + "'", double8 == 0.6248420117881944d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.10766999788076125d + "'", double10 == 0.10766999788076125d);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 3L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9999999999999996d + "'", double2 == 2.9999999999999996d);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test175");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        try {
//            long long16 = randomDataImpl1.nextSecureLong((long) 4, (long) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 4 is larger than, or equal to, the maximum (0): lower bound (4) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.01896497591674677d + "'", double3 == 0.01896497591674677d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.22294269565311883d + "'", double8 == 0.22294269565311883d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable9, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable40, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray59 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable34, (java.lang.Object[]) throwableArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray62);
        java.lang.String str66 = mathException65.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "{0} is smaller than, or equal to, the minimum ({1})" + "'", str66.equals("{0} is smaller than, or equal to, the minimum ({1})"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(221.4625630039584d, 10.0d, 2.5782261737836363d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException10.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable18 = numberIsTooLargeException17.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray29 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException(localizable18, objArray29);
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException("", objArray29);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException7, localizable11, objArray29);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException47 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable43, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray53 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable42, objArray53);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray53);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray61 = numberIsTooLargeException60.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable36, (java.lang.Object[]) throwableArray61);
        java.lang.Object[] objArray64 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4, localizable11, objArray64);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException68 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, "4", objArray64);
        int int69 = maxIterationsExceededException68.getMaxIterations();
        int int70 = maxIterationsExceededException68.getMaxIterations();
        int int71 = maxIterationsExceededException68.getMaxIterations();
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(throwableArray61);
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1 + "'", int71 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.9995214556628339d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1744628956793266d + "'", double1 == 1.1744628956793266d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 1.3213757317992672d, (java.lang.Number) 1.0279773571668917E-19d, number8);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 8.406038449720212d, (java.lang.Number) 2.7961017916614805d, true);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.6929693744344998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.144346427974586d) + "'", double1 == (-8.144346427974586d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        java.lang.Throwable[] throwableArray4 = mathException3.getSuppressed();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(throwable6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray38 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable27, objArray38);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException16, localizable20, objArray38);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException45 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException45.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException51 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable47, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable52 = numberIsTooLargeException51.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray63 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException(localizable52, objArray63);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, objArray63);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable66, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray71 = numberIsTooLargeException70.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable46, (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException41, "5", (java.lang.Object[]) throwableArray71);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7, localizable14, (java.lang.Object[]) throwableArray71);
        java.lang.Throwable[] throwableArray75 = mathException7.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, "cede62d4d2633857158d51440035feb628dd7167ca46d5dcb0ed59f29b3d245c4dde2153382880a9ae916e196467030f5421", (java.lang.Object[]) throwableArray75);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(throwableArray71);
        org.junit.Assert.assertNotNull(throwableArray75);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        int[] intArray21 = randomDataImpl1.nextPermutation((int) '#', (int) '#');
//        double double24 = randomDataImpl1.nextGaussian(0.06303136834378237d, 0.06303136834378237d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.39961595421147d + "'", double3 == 4.39961595421147d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.933718141606251d + "'", double8 == 8.933718141606251d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c" + "'", str10.equals("c"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.007218397667247743d + "'", double15 == 0.007218397667247743d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.493871368639326d + "'", double18 == 3.493871368639326d);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.1347224462902223d + "'", double24 == 0.1347224462902223d);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.1331863625592726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

//    @Test
//    public void test189() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test189");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed((long) 33);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.25339536028062d + "'", double3 == 4.25339536028062d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7054619817508715d + "'", double8 == 0.7054619817508715d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
        double double4 = normalDistributionImpl2.density(1.9366706971532035d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.04083502708618442d + "'", double4 == 0.04083502708618442d);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure(4L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.052770250397338d + "'", double3 == 4.052770250397338d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1505455461807411d + "'", double8 == 0.1505455461807411d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Number number42 = outOfRangeException41.getLo();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 10.0d + "'", number42.equals(10.0d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(100.05137929764108d, 0.35126798438961054d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0729616115695262E-204d + "'", double2 == 2.0729616115695262E-204d);
    }

//    @Test
//    public void test194() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test194");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextF(83.76375854688544d, 182.17140371275474d);
//        long long9 = randomDataImpl1.nextLong(10L, (long) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.603011575881557d + "'", double3 == 4.603011575881557d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.307455038407187d + "'", double6 == 1.307455038407187d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 37L + "'", long9 == 37L);
//    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(32);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 100L, (double) ' ', 52.00000000000001d);
    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt((int) (byte) 1, 14);
//        double double16 = randomDataImpl1.nextF(1.4210854715202004E-14d, 5.840853025906053E-7d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.280413761637239d + "'", double3 == 6.280413761637239d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.18109450997105114d + "'", double8 == 0.18109450997105114d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.3605324821825365E-9d + "'", double16 == 1.3605324821825365E-9d);
//    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test198");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        double double12 = randomDataImpl1.nextChiSquare(0.5722984289556622d);
//        double double15 = randomDataImpl1.nextWeibull(1.0713600329447577d, 367.93118819388314d);
//        double double18 = randomDataImpl1.nextUniform(0.17632698070846498d, 0.9760582755807474d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.415608378160237d + "'", double3 == 6.415608378160237d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8451021510036018d + "'", double8 == 0.8451021510036018d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.5354977600742357d + "'", double12 == 0.5354977600742357d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 39.798693862083105d + "'", double15 == 39.798693862083105d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.5631436575493867d + "'", double18 == 0.5631436575493867d);
//    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        java.lang.String str6 = randomDataImpl1.nextHexString(11);
//        try {
//            long long9 = randomDataImpl1.nextSecureLong(100L, (long) 35);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (35): lower bound (100) must be strictly less than upper bound (35)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.179399469501152d + "'", double3 == 6.179399469501152d);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "62cd267cf1b" + "'", str6.equals("62cd267cf1b"));
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.613635339438126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6528774887016565d + "'", double1 == 0.6528774887016565d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        long long2 = org.apache.commons.math.util.FastMath.min(36L, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1744628956793266d, 4.912291920165859d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.912291920165859d + "'", double2 == 4.912291920165859d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.021246213383395378d, 1.036472457656468d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0184617721063847d + "'", double2 == 0.0184617721063847d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5920004022855878d, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException(throwable6);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8);
        java.lang.Throwable[] throwableArray10 = mathException9.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "convergence failed", (java.lang.Object[]) throwableArray10);
        java.lang.Number number12 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(number12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.ulp(20.126172983591967d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(27.0d, 2.718281828459045d);
        double double4 = normalDistributionImpl2.density(2.114720051539204d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.278858465648986E-20d + "'", double4 == 9.278858465648986E-20d);
    }

//    @Test
//    public void test208() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test208");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed((long) (byte) 1);
//        long long21 = randomDataImpl1.nextLong((long) (byte) -1, (long) (byte) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7084400080863742d + "'", double3 == 1.7084400080863742d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6563899077768772d + "'", double8 == 0.6563899077768772d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 203.59954352547524d + "'", double10 == 203.59954352547524d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "b" + "'", str12.equals("b"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
//    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test210() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test210");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextBeta(0.9941201416988211d, 76.44167018429081d);
//        double double15 = randomDataImpl1.nextF(0.11422710742226455d, 0.8474299248014396d);
//        double double17 = randomDataImpl1.nextChiSquare(0.8155384116340332d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6704037742132465d + "'", double3 == 1.6704037742132465d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.954637947054784d + "'", double6 == 6.954637947054784d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 99.9862478951393d + "'", double9 == 99.9862478951393d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.02564797400490929d + "'", double12 == 0.02564797400490929d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 15.676948837928538d + "'", double15 == 15.676948837928538d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.10315772146506443d + "'", double17 == 0.10315772146506443d);
//    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.8614849631051733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable9, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray20);
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        java.lang.Class<?> wildcardClass42 = localizable29.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) (-0.7321877967059738d), (java.lang.Number) (-0.5772156677920679d), true);
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathIllegalArgumentException23, localizable29, objArray47);
        java.lang.Number number51 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException(localizable29, (java.lang.Number) 367.93118819388314d, (java.lang.Number) 11.77352792708925d, number51);
        org.apache.commons.math.exception.util.Localizable localizable53 = outOfRangeException52.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 100, (float) 5L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

//    @Test
//    public void test214() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test214");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Number number6 = numberIsTooLargeException4.getArgument();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException18 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable14, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        java.lang.Object[] objArray24 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
//        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable13, objArray24);
//        java.lang.Class<?> wildcardClass26 = localizable13.getClass();
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable32 = numberIsTooLargeException31.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        java.lang.Object[] objArray43 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable32, objArray43);
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException(localizable13, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooLargeException52.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable54 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
//        java.lang.Object[] objArray64 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable53, objArray64);
//        java.lang.Object[] objArray66 = convergenceException65.getArguments();
//        org.apache.commons.math.random.RandomGenerator randomGenerator68 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl69 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator68);
//        double double71 = randomDataImpl69.nextChiSquare((double) 1.0f);
//        double double74 = randomDataImpl69.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double76 = randomDataImpl69.nextExponential((double) (short) 1);
//        double double78 = randomDataImpl69.nextExponential((double) 100L);
//        java.lang.String str80 = randomDataImpl69.nextHexString((int) (byte) 1);
//        java.lang.Object[] objArray81 = new java.lang.Object[] { "org.apache.commons.math.MathException: ", 295.0471450458558d, convergenceException65, 182.17140371275474d, (byte) 1 };
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, objArray81);
//        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException(localizable7, objArray81);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException87 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 0.6922006275553464d, (java.lang.Number) 0.04083502708618442d, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.15865525393145702d + "'", number6.equals(0.15865525393145702d));
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray24);
//        org.junit.Assert.assertNotNull(wildcardClass26);
//        org.junit.Assert.assertTrue("'" + localizable32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable32.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray64);
//        org.junit.Assert.assertNotNull(objArray66);
//        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 1.8536350014650336d + "'", double71 == 1.8536350014650336d);
//        org.junit.Assert.assertEquals((double) double74, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 3.522222993937599d + "'", double76 == 3.522222993937599d);
//        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 78.34597323815338d + "'", double78 == 78.34597323815338d);
//        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "d" + "'", str80.equals("d"));
//        org.junit.Assert.assertNotNull(objArray81);
//    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 35, 0.03692522815132798d, 2.626855756736301E-12d);
        double double4 = normalDistributionImpl3.getMean();
        double double6 = normalDistributionImpl3.density(3.7230614508084154d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.0d + "'", double4 == 35.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 33);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 33.0f + "'", float1 == 33.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.978588058361467d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(182.17140371275474d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 764.3382057683243d + "'", double1 == 764.3382057683243d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 14, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.0017612234763298446d, (java.lang.Number) 2.1156597306287486d, true);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.lang.Number number0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, number1, true);
    }

//    @Test
//    public void test223() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test223");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        try {
//            int int7 = randomDataImpl1.nextPascal(0, (-2.0d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -2 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2093909456804095d + "'", double3 == 1.2093909456804095d);
//    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        long long6 = randomDataImpl1.nextSecureLong((long) (-1), (long) 4);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl1.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.2044294064080878d + "'", double3 == 1.2044294064080878d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        double double20 = randomDataImpl1.nextWeibull(22025.465794806718d, 4.879193721524136d);
//        randomDataImpl1.reSeed(19L);
//        long long24 = randomDataImpl1.nextPoisson(0.3981989750006367d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1848060595939032d + "'", double3 == 1.1848060595939032d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.1374609027834234d + "'", double8 == 0.1374609027834234d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.878574278659854d + "'", double20 == 4.878574278659854d);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1L + "'", long24 == 1L);
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.4112205328795488d, 2.626855756736301E-12d, 2.0757486181300626d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.9999804991824669d + "'", double4 == 0.9999804991824669d);
    }

//    @Test
//    public void test227() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test227");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        long long21 = randomDataImpl1.nextLong(0L, 100L);
//        try {
//            int int25 = randomDataImpl1.nextHypergeometric(0, (int) (short) 0, (int) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.1733749108563643d + "'", double3 == 1.1733749108563643d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.962350306826942d + "'", double8 == 3.962350306826942d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3" + "'", str10.equals("3"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.23388157217518E-4d + "'", double15 == 6.23388157217518E-4d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.207947123103314d + "'", double18 == 2.207947123103314d);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 66L + "'", long21 == 66L);
//    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.7016028981264102d, 0.40611766574501407d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.70160289812641d + "'", double2 == 1.70160289812641d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        long long2 = org.apache.commons.math.util.FastMath.max((-1L), (-1L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) (byte) 10, (java.lang.Number) 10.0d, (java.lang.Number) 0.18749269135908855d);
        java.lang.Number number42 = outOfRangeException41.getHi();
        java.lang.Number number43 = outOfRangeException41.getLo();
        java.lang.String str44 = outOfRangeException41.toString();
        java.lang.Number number45 = outOfRangeException41.getHi();
        java.lang.Number number46 = outOfRangeException41.getHi();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.18749269135908855d + "'", number42.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 10.0d + "'", number43.equals(10.0d));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)" + "'", str44.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)"));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0.18749269135908855d + "'", number45.equals(0.18749269135908855d));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.18749269135908855d + "'", number46.equals(0.18749269135908855d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 6.413588051684717d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(throwable5);
        org.apache.commons.math.ConvergenceException convergenceException7 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException15 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable16 = notStrictlyPositiveException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable21, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable26 = numberIsTooLargeException25.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException31 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable27, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray37 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable26, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException("", objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException15, localizable19, objArray37);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, objArray62);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException69 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable65, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray70 = numberIsTooLargeException69.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable45, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException40, "5", (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6, localizable13, (java.lang.Object[]) throwableArray70);
        java.lang.Throwable[] throwableArray74 = mathException6.getSuppressed();
        java.lang.Class<?> wildcardClass75 = mathException6.getClass();
        org.apache.commons.math.exception.util.Localizable localizable76 = mathException6.getSpecificPattern();
        java.lang.String str77 = mathException6.toString();
        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) mathException6);
        java.lang.Number number79 = numberIsTooLargeException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(throwableArray74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNull(localizable76);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.MathException: " + "'", str77.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 4.158638853279167d + "'", number79.equals(4.158638853279167d));
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test234");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        double double6 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.density(0.24402531179839718d);
//        try {
//            double double10 = normalDistributionImpl3.inverseCumulativeProbability((-3.826397832750743d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -3.826 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.36976771151210935d + "'", double4 == 0.36976771151210935d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.9157251175846115d) + "'", double5 == (-0.9157251175846115d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-5.290535237999898d) + "'", double6 == (-5.290535237999898d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.11022971680989722d + "'", double8 == 0.11022971680989722d);
//    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        randomDataImpl1.reSeedSecure((long) (byte) 10);
//        try {
//            int int12 = randomDataImpl1.nextHypergeometric(0, 0, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0077719473732976d + "'", double3 == 1.0077719473732976d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 18.174805469003278d + "'", double6 == 18.174805469003278d);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.18749269135908855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18859312813538756d + "'", double1 == 0.18859312813538756d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.6638204538120072d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        double double14 = randomDataImpl1.nextExponential(0.5403023058681398d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0937594433626445d + "'", double3 == 1.0937594433626445d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.7225470859257106d + "'", double8 == 0.7225470859257106d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 131.2763770305428d + "'", double10 == 131.2763770305428d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2" + "'", str12.equals("2"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.82845966681488d + "'", double14 == 1.82845966681488d);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.7965584242991823d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 97.0d, (java.lang.Number) 99.9774800249407d, true);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.521174815586791d, 5.352938723585865d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.52117481558679d + "'", double2 == 7.52117481558679d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(73.74085758741803d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(24.631041330572494d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.962966988664391d + "'", double1 == 4.962966988664391d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0810047924427055d, (java.lang.Number) 2.5821655349867285d, (java.lang.Number) (-0.6283442197494351d));
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 2.5821655349867285d + "'", number4.equals(2.5821655349867285d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.util.FastMath.log1p(100.38235421017255d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6188990544176365d + "'", double1 == 4.6188990544176365d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.7092983232354384d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double2 = org.apache.commons.math.util.FastMath.min(1.1851358505060419d, 333.0482237879423d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1851358505060419d + "'", double2 == 1.1851358505060419d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test248");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long6 = randomDataImpl1.nextPoisson(1.3258176636680326d);
//        double double9 = randomDataImpl1.nextWeibull(2.7912452447092146d, 0.04690181386892998d);
//        randomDataImpl1.reSeedSecure(100L);
//        try {
//            int int15 = randomDataImpl1.nextHypergeometric((int) (short) 1, 0, 3);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3 is larger than the maximum (1): sample size (3) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.9563139114691985d + "'", double3 == 6.9563139114691985d);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2L + "'", long6 == 2L);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.04251271430987883d + "'", double9 == 0.04251271430987883d);
//    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.003710975163223448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.003704106482649751d + "'", double1 == 0.003704106482649751d);
    }

//    @Test
//    public void test250() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test250");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential(1.2390185292981617E169d);
//        randomDataImpl1.reSeed((long) '4');
//        double double21 = randomDataImpl1.nextT(0.2842804566121364d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.15552633759541d + "'", double3 == 6.15552633759541d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.264686257860288d + "'", double8 == 0.264686257860288d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.679564408431606E169d + "'", double17 == 1.679564408431606E169d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.507573088229938d + "'", double21 == 2.507573088229938d);
//    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5041035434581398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.88300547774109d + "'", double1 == 28.88300547774109d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.012337490786012824d, (-0.12519917548959106d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0433668739655864d + "'", double2 == 3.0433668739655864d);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double20 = normalDistributionImpl19.getStandardDeviation();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        try {
//            int int25 = randomDataImpl1.nextHypergeometric((int) (byte) 10, (int) (short) 100, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (10): number of successes (100) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0161946718631825d + "'", double3 == 6.0161946718631825d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.49263255304639403d + "'", double8 == 0.49263255304639403d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        float float2 = org.apache.commons.math.util.FastMath.min(32.0f, (float) 36L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.4920840976514603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49208409765146033d + "'", double1 == 0.49208409765146033d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0831145746332316d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7338641653908271d + "'", double1 == 0.7338641653908271d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.81572948486401d, 0.0017544283570953923d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.826911512097305E-6d + "'", double2 == 5.826911512097305E-6d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.special.Erf.erf(0.6528774887016565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6441533837006393d + "'", double1 == 0.6441533837006393d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long1 = org.apache.commons.math.util.FastMath.round(2.383358165009458d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1848060595939032d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0581545138764603d + "'", double1 == 1.0581545138764603d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException(throwable1);
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException14.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable23, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable22, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException11, localizable15, objArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable42, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooLargeException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray58 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException(localizable47, objArray58);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, objArray58);
        org.apache.commons.math.exception.util.Localizable localizable61 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable61, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray66 = numberIsTooLargeException65.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException67 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable41, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.ConvergenceException convergenceException68 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException36, "5", (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2, localizable9, (java.lang.Object[]) throwableArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray66);
        java.lang.Throwable throwable72 = null;
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException73);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException74);
        java.lang.Throwable[] throwableArray76 = mathException75.getSuppressed();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException70, "cede62d4d2633857158d51440035feb628dd7167ca46d5dcb0ed59f29b3d245c4dde2153382880a9ae916e196467030f5421", (java.lang.Object[]) throwableArray76);
        org.apache.commons.math.exception.util.Localizable localizable78 = mathException70.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable78, (java.lang.Number) 4.879193721524136d, (java.lang.Number) 2.533712596379886d, false);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray58);
        org.junit.Assert.assertNotNull(throwableArray66);
        org.junit.Assert.assertNotNull(throwableArray76);
        org.junit.Assert.assertNotNull(localizable78);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7442031636233744d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0502197278905878d + "'", double1 == 1.0502197278905878d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        long long1 = org.apache.commons.math.util.FastMath.abs(22L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 22L + "'", long1 == 22L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.4075479284384708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test267");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        long long21 = randomDataImpl1.nextLong(0L, 100L);
//        org.apache.commons.math.random.RandomGenerator randomGenerator22 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator22);
//        double double25 = randomDataImpl23.nextChiSquare((double) 1.0f);
//        double double28 = randomDataImpl23.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double30 = randomDataImpl23.nextExponential((double) (short) 1);
//        double double32 = randomDataImpl23.nextExponential((double) 100L);
//        java.lang.String str34 = randomDataImpl23.nextHexString((int) (byte) 1);
//        java.lang.String str36 = randomDataImpl23.nextHexString((int) (byte) 100);
//        double double38 = randomDataImpl23.nextChiSquare(0.15865525393145702d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl41 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
//        double[] doubleArray43 = normalDistributionImpl41.sample(100);
//        double double45 = normalDistributionImpl41.cumulativeProbability(2.220446049250313E-16d);
//        double double46 = randomDataImpl23.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl41);
//        double double47 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl41);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.518778812701478d + "'", double3 == 4.518778812701478d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.922899209992095d + "'", double8 == 4.922899209992095d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.770144314981061E-4d + "'", double15 == 2.770144314981061E-4d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.7362300145655409d + "'", double18 == 0.7362300145655409d);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 94L + "'", long21 == 94L);
//        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 4.491576963585758d + "'", double25 == 4.491576963585758d);
//        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.527658297786792d + "'", double30 == 1.527658297786792d);
//        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 447.7402206293d + "'", double32 == 447.7402206293d);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "0" + "'", str34.equals("0"));
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "5e73db414feb9878b771e0909af167b7c0a03a3e67e2926c6a07d9a83b775d8e9872cfe5c670f7a0ab7466285bdf783a3f83" + "'", str36.equals("5e73db414feb9878b771e0909af167b7c0a03a3e67e2926c6a07d9a83b775d8e9872cfe5c670f7a0ab7466285bdf783a3f83"));
//        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 5.127994215157668E-6d + "'", double38 == 5.127994215157668E-6d);
//        org.junit.Assert.assertNotNull(doubleArray43);
//        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.4920840976514603d + "'", double45 == 0.4920840976514603d);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-2.7976879764125635d) + "'", double46 == (-2.7976879764125635d));
//        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 6.590348380993508d + "'", double47 == 6.590348380993508d);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0227623331541273d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0113171278852777d + "'", double1 == 1.0113171278852777d);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        randomDataImpl1.reSeed((long) 5);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.378671346907289d + "'", double3 == 4.378671346907289d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.1060769096518253d + "'", double8 == 3.1060769096518253d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(2.145306817808254d, 0.0462451523474614d, 3.1835150154184904d);
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability(0.5631436575493867d, 0.003704106482649751d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        java.lang.String str3 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str3.equals("maximal number of iterations ({0}) exceeded"));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.atan(16.29428970105942d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5095020099849352d + "'", double1 == 1.5095020099849352d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.264686257860288d, (java.lang.Number) 4.691997338543945d, (java.lang.Number) 0.36787944117144233d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray4 = notStrictlyPositiveException1.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        java.lang.Object[] objArray42 = convergenceException41.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable10, objArray42);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable6, objArray17);
        java.lang.Class<?> wildcardClass19 = localizable6.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 10L, (java.lang.Number) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 2.4633218980879183d);
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10, localizable6, objArray26);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double2 = org.apache.commons.math.util.FastMath.min(8.0d, (double) 36L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.0d + "'", double2 == 8.0d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        java.lang.Object[] objArray1 = mathException0.getArguments();
        java.lang.Class<?> wildcardClass2 = mathException0.getClass();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10L, (java.lang.Number) 100, true);
        java.lang.Number number23 = numberIsTooLargeException22.getMax();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable29, (java.lang.Number) 5.352938723585865d, (java.lang.Number) 32.0f, true);
        numberIsTooLargeException22.addSuppressed((java.lang.Throwable) numberIsTooSmallException45);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 100 + "'", number23.equals(100));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double2 = org.apache.commons.math.util.FastMath.min(20.126172983591967d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        int[] intArray21 = randomDataImpl1.nextPermutation((int) '#', (int) '#');
//        double double24 = randomDataImpl1.nextGamma(1.5440680443502757d, 0.957982976278873d);
//        double double26 = randomDataImpl1.nextExponential((double) (byte) 100);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.1258162476472733d + "'", double3 == 3.1258162476472733d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 8.735667133905002d + "'", double8 == 8.735667133905002d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0011125250552662292d + "'", double15 == 0.0011125250552662292d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.4898323238423469d + "'", double18 == 0.4898323238423469d);
//        org.junit.Assert.assertNotNull(intArray21);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.8882018013972943d + "'", double24 == 0.8882018013972943d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 338.13128769611114d + "'", double26 == 338.13128769611114d);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable12, objArray23);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException("", objArray23);
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException1, localizable5, objArray23);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException30 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 100.33776512254933d, (java.lang.Number) 10.0f, false);
        java.lang.Number number31 = numberIsTooSmallException30.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 10.0f + "'", number31.equals(10.0f));
    }

//    @Test
//    public void test283() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test283");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextBeta(0.9941201416988211d, 76.44167018429081d);
//        double double15 = randomDataImpl1.nextF(0.11422710742226455d, 0.8474299248014396d);
//        randomDataImpl1.reSeed((long) (byte) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.347750587627996d + "'", double3 == 3.347750587627996d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 6.4539223412732785d + "'", double6 == 6.4539223412732785d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.13739822585758d + "'", double9 == 100.13739822585758d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0018071513858268428d + "'", double12 == 0.0018071513858268428d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.008005387080214227d + "'", double15 == 0.008005387080214227d);
//    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5920004022855878d, number1, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.592 is smaller than, or equal to, the minimum (null)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.592 is smaller than, or equal to, the minimum (null)"));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) 31.999999932788864d, false);
        java.lang.String str4 = numberIsTooLargeException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 5,729.578 is larger than, or equal to, the maximum (32)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 5,729.578 is larger than, or equal to, the maximum (32)"));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.1505455461807411d, 14.0d, 22025.465794806718d, 11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.3490848217717219E-8d + "'", double4 == 1.3490848217717219E-8d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.acos((-6.063493002968778d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable10, objArray21);
        java.lang.Class<?> wildcardClass23 = localizable10.getClass();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable10, objArray40);
        java.lang.Throwable throwable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray62 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable51, objArray62);
        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException("", objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable43, "hi!", objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable10, objArray62);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException70 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 100, (java.lang.Number) 0.1677205581070077d, false);
        java.lang.Number number71 = numberIsTooLargeException70.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 14.0d + "'", number4.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 0.1677205581070077d + "'", number71.equals(0.1677205581070077d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5437100504730836d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5437100504730839d + "'", double1 == 1.5437100504730839d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0024994806802126797d, 1.8176421626644307E-9d, 1.247431811219271d, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (0) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable9, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray20);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("4", objArray20);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray20);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.19068994544354323d, 9.609680117110225d);
//        double double3 = normalDistributionImpl2.sample();
//        normalDistributionImpl2.reseedRandomGenerator(22L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.643845467012197d + "'", double3 == 10.643845467012197d);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.3981989750006367d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.551115123125783E-17d + "'", double1 == 5.551115123125783E-17d);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 'a', (double) (short) 100, (double) 0L);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 205.14550127640987d + "'", double4 == 205.14550127640987d);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.10502341260776125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.017398292485759d + "'", double1 == 6.017398292485759d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int5 = randomDataImpl1.nextHypergeometric((int) 'a', (int) (byte) 10, (int) (short) 1);
        randomDataImpl1.reSeed();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.special.Erf.erf(3.719677202182918d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999998562716685d + "'", double1 == 0.9999998562716685d);
    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test298");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double4 = normalDistributionImpl3.sample();
//        double double6 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
//        double double7 = normalDistributionImpl3.sample();
//        double double8 = normalDistributionImpl3.sample();
//        double double9 = normalDistributionImpl3.getMean();
//        double double11 = normalDistributionImpl3.cumulativeProbability((-0.6200024177183507d));
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.4536684729505875d + "'", double4 == 1.4536684729505875d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + Double.NEGATIVE_INFINITY + "'", double6 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-2.662614377144246d) + "'", double7 == (-2.662614377144246d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5031228551019533d + "'", double8 == 0.5031228551019533d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0011670527851042202d + "'", double9 == 0.0011670527851042202d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4317105930954295d + "'", double11 == 0.4317105930954295d);
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.lang.Throwable throwable3 = null;
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException(throwable3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.toString();
        java.lang.Object[] objArray7 = mathException4.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("0", objArray7);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException9 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)", objArray7);
        java.lang.Object[] objArray10 = maxIterationsExceededException9.getArguments();
        java.lang.String str11 = maxIterationsExceededException9.getPattern();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.MathException: " + "'", str6.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)" + "'", str11.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, 0.187] range: 10 is larger than, or equal to, the maximum (10)"));
    }

//    @Test
//    public void test300() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test300");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl19 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double20 = normalDistributionImpl19.getStandardDeviation();
//        double double21 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl19);
//        try {
//            double double23 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5270618977248147d + "'", double3 == 2.5270618977248147d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.21628887873145683d + "'", double8 == 0.21628887873145683d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 10.0d + "'", double20 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
//    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6999820591541253d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8366493047592434d + "'", double1 == 0.8366493047592434d);
    }

//    @Test
//    public void test302() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test302");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        int int11 = randomDataImpl1.nextBinomial(35, 0.264686257860288d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.4835303878991892d + "'", double3 == 2.4835303878991892d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.592339694753103d + "'", double8 == 4.592339694753103d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 7 + "'", int11 == 7);
//    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException26 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable22, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooLargeException26.getGeneralPattern();
        java.lang.Object[] objArray29 = null;
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException("0", objArray29);
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException36.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray48 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable37, objArray48);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30, "", objArray48);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException51 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable27, objArray48);
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooLargeException56.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable58, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable57, objArray68);
        java.lang.Throwable throwable70 = null;
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(throwable70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException71);
        java.lang.String str73 = mathException71.toString();
        java.lang.Object[] objArray74 = mathException71.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException75 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable57, objArray74);
        org.apache.commons.math.exception.util.Localizable localizable76 = mathIllegalArgumentException75.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException78 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable76, (java.lang.Number) 2.1985675918388914E-5d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException82 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable76, (java.lang.Number) 0.5772156649015329d, (java.lang.Number) 1.8176421626644307E-9d, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "org.apache.commons.math.MathException: " + "'", str73.equals("org.apache.commons.math.MathException: "));
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + localizable76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable76.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test304");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        int int7 = randomDataImpl1.nextInt(10, 12);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.06996592524743388d + "'", double3 == 0.06996592524743388d);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.07313187804841101d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.577527440992047d + "'", double1 == 2.577527440992047d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException23 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable19, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable24 = numberIsTooLargeException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray35 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException(localizable24, objArray35);
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException(localizable5, objArray35);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 4.052770250397338d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + localizable24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable24.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray35);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.4946538625211505d, 3.708403105893581d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.494653862521151d + "'", double2 == 3.494653862521151d);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test308");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 35, 0.03692522815132798d, 2.626855756736301E-12d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 35.016705570174864d + "'", double4 == 35.016705570174864d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 35.00214512648642d + "'", double5 == 35.00214512648642d);
//    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.0f, (java.lang.Number) 0.05090884793564899d, true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.6897131082148451d, 271.3998509425464d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException1.getGeneralPattern();
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException(localizable3, (java.lang.Number) 0.07313187804841101d, number5, (java.lang.Number) 0.07196148855387847d);
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.05315015091559d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        double double12 = randomDataImpl1.nextChiSquare(0.5722984289556622d);
//        double double15 = randomDataImpl1.nextWeibull(1.0713600329447577d, 367.93118819388314d);
//        double double18 = randomDataImpl1.nextGamma(1.552081707287882d, 0.3385004809376946d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.023804066949501202d + "'", double3 == 0.023804066949501202d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.602337130451261d + "'", double8 == 4.602337130451261d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.8863292029074882d + "'", double12 == 0.8863292029074882d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 132.47097153427606d + "'", double15 == 132.47097153427606d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.08178617201594224d + "'", double18 == 0.08178617201594224d);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.3378959960905843d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2261158164819381d + "'", double1 == 1.2261158164819381d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8845841392092296d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7242324719331428d + "'", double1 == 0.7242324719331428d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 'a', (double) (short) 100, (double) 0L);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        java.lang.Class<?> wildcardClass5 = normalDistributionImpl3.getClass();
        double double6 = normalDistributionImpl3.getMean();
        java.lang.Class<?> wildcardClass7 = normalDistributionImpl3.getClass();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 97.0d + "'", double6 == 97.0d);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.8680140174326465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9534137366263864d + "'", double1 == 0.9534137366263864d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.1851358505060419d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.271131176107971d + "'", double1 == 2.271131176107971d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(27.0d, 2.1156597306287486d);
    }

//    @Test
//    public void test320() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test320");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        double double12 = randomDataImpl1.nextChiSquare(0.5722984289556622d);
//        double double14 = randomDataImpl1.nextT(0.957982976278873d);
//        long long17 = randomDataImpl1.nextLong((long) 3, (long) ' ');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.03171165476586057d + "'", double3 == 0.03171165476586057d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.054675144406667d + "'", double8 == 3.054675144406667d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3" + "'", str10.equals("3"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.022506784104545593d + "'", double12 == 0.022506784104545593d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.6430694876637775d + "'", double14 == 3.6430694876637775d);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 15L + "'", long17 == 15L);
//    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException(number0, (java.lang.Number) 7, false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.abs(13.274948879489813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.274948879489813d + "'", double1 == 13.274948879489813d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        long long1 = org.apache.commons.math.util.FastMath.round(0.06014907374735436d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5722984289556622d, 2.18659846443041d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable7 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable14, objArray25);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException3, localizable7, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException33 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable29, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable34 = numberIsTooLargeException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray45 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable34, objArray45);
        org.apache.commons.math.ConvergenceException convergenceException47 = new org.apache.commons.math.ConvergenceException(throwable1, localizable7, objArray45);
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException50 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable51 = notStrictlyPositiveException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException56 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable52, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooLargeException56.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException62 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable58, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray68 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable57, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable7, objArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) (-2.6407021381136597d));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray68);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) 31.999999932788864d, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable14, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray25);
        java.lang.Class<?> wildcardClass28 = mathIllegalArgumentException27.getClass();
        java.lang.String str29 = mathIllegalArgumentException27.toString();
        java.lang.Throwable[] throwableArray30 = mathIllegalArgumentException27.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "e", (java.lang.Object[]) throwableArray30);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: 0.159 is smaller than, or equal to, the minimum ()" + "'", str29.equals("org.apache.commons.math.exception.MathIllegalArgumentException: 0.159 is smaller than, or equal to, the minimum ()"));
        org.junit.Assert.assertNotNull(throwableArray30);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-2.9601043037147905d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.675899111585668d + "'", double1 == 9.675899111585668d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 12);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20943951023931956d + "'", double1 == 0.20943951023931956d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.special.Erf.erf(0.3480587202085134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.37744279067127584d + "'", double1 == 0.37744279067127584d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.3385004809376946d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.40284242363343986d + "'", double1 == 0.40284242363343986d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test331");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double6 = randomDataImpl1.nextExponential((double) 10.0f);
//        double double9 = randomDataImpl1.nextGaussian((double) (byte) 100, 0.19068994544354323d);
//        double double12 = randomDataImpl1.nextGaussian(0.2735701380514667d, 0.7151568462037634d);
//        randomDataImpl1.reSeedSecure();
//        randomDataImpl1.reSeedSecure(0L);
//        randomDataImpl1.reSeedSecure((long) 1);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.001197791643183598d + "'", double3 == 0.001197791643183598d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.878764180791574d + "'", double6 == 4.878764180791574d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0569939267595d + "'", double9 == 100.0569939267595d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.6863102150806334d + "'", double12 == 0.6863102150806334d);
//    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double4 = normalDistributionImpl3.sample();
//        double double5 = normalDistributionImpl3.getMean();
//        double double8 = normalDistributionImpl3.cumulativeProbability(0.9565506148514678d, 0.996670450360643d);
//        double double9 = normalDistributionImpl3.getMean();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.699646263618963d + "'", double4 == 3.699646263618963d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0011670527851042202d + "'", double5 == 0.0011670527851042202d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.004273588269784079d + "'", double8 == 0.004273588269784079d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0011670527851042202d + "'", double9 == 0.0011670527851042202d);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(10);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable7, objArray18);
        java.lang.Class<?> wildcardClass20 = localizable7.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 10L, (java.lang.Number) 100, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 2.4633218980879183d);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) 31.999999932788864d, false);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException30.getGeneralPattern();
        java.lang.Object[] objArray32 = numberIsTooLargeException30.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException1, localizable7, objArray32);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.cosh(6.413588051684717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 305.04019593569956d + "'", double1 == 305.04019593569956d);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        double double20 = randomDataImpl1.nextWeibull(22025.465794806718d, 4.879193721524136d);
//        try {
//            long long23 = randomDataImpl1.nextLong((long) '4', (long) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 52 is larger than, or equal to, the maximum (-1): lower bound (52) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.002091530570872293d + "'", double3 == 0.002091530570872293d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.3965657534585516d + "'", double8 == 1.3965657534585516d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.878574278659854d + "'", double20 == 4.878574278659854d);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test337");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double5 = normalDistributionImpl4.sample();
//        double double7 = normalDistributionImpl4.inverseCumulativeProbability(0.0d);
//        double double8 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.9230708934136633d + "'", double5 == 1.9230708934136633d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + Double.NEGATIVE_INFINITY + "'", double7 == Double.NEGATIVE_INFINITY);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-5.695925100510829d) + "'", double8 == (-5.695925100510829d));
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Number number6 = numberIsTooLargeException4.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 2.718281828459045d, (java.lang.Number) 2.4132240024472974E66d, (java.lang.Number) 4.602337130451261d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.15865525393145702d + "'", number6.equals(0.15865525393145702d));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double17 = randomDataImpl1.nextExponential((double) 10);
//        double double20 = randomDataImpl1.nextWeibull(22025.465794806718d, 4.879193721524136d);
//        double double22 = randomDataImpl1.nextChiSquare(26.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.004190842205149219d + "'", double3 == 0.004190842205149219d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.14250749053298592d + "'", double8 == 0.14250749053298592d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 13.555603638817171d + "'", double17 == 13.555603638817171d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.878574278659854d + "'", double20 == 4.878574278659854d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 20.72763345785242d + "'", double22 == 20.72763345785242d);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 166, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 166L + "'", long2 == 166L);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int[] intArray15 = randomDataImpl1.nextPermutation((int) '4', (int) (byte) 1);
//        randomDataImpl1.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl20 = new org.apache.commons.math.distribution.NormalDistributionImpl(10.0d, (double) 10.0f, (double) 10.0f);
//        double double21 = normalDistributionImpl20.getStandardDeviation();
//        double double22 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl20);
//        randomDataImpl1.reSeedSecure((long) (short) 10);
//        int int27 = randomDataImpl1.nextBinomial(12, 0.6306769296482175d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.3519819273110636E-5d + "'", double3 == 2.3519819273110636E-5d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.17947754620351858d + "'", double8 == 0.17947754620351858d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 159.10689137246015d + "'", double10 == 159.10689137246015d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "5" + "'", str12.equals("5"));
//        org.junit.Assert.assertNotNull(intArray15);
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 10.0d + "'", double21 == 10.0d);
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-23.0d) + "'", double22 == (-23.0d));
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 9 + "'", int27 == 9);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        java.lang.Object[] objArray4 = notStrictlyPositiveException1.getArguments();
        boolean boolean5 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6528774887016565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8080083469257335d + "'", double1 == 0.8080083469257335d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException(throwable0);
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException5 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable6 = notStrictlyPositiveException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException21 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable17, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException(localizable16, objArray27);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException5, localizable9, objArray27);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable34 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException39 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable35, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = numberIsTooLargeException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException45 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable41, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray51 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable40, objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray51);
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray59 = numberIsTooLargeException58.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable34, (java.lang.Object[]) throwableArray59);
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("org.apache.commons.math.MathException: ", objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, objArray62);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable9, objArray62);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number70 = outOfRangeException69.getArgument();
        convergenceException2.addSuppressed((java.lang.Throwable) outOfRangeException69);
        java.lang.Throwable[] throwableArray72 = outOfRangeException69.getSuppressed();
        java.lang.Number number73 = outOfRangeException69.getLo();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 14.0d + "'", number70.equals(14.0d));
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 0.1677205581070077d + "'", number73.equals(0.1677205581070077d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5722984289556622d, (java.lang.Number) 0.0017544283570953923d, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.sinh(22.879012190636995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.317166020150119E9d + "'", double1 == 4.317166020150119E9d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.19310408199859513d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 28.095073361914757d + "'", double1 == 28.095073361914757d);
    }

//    @Test
//    public void test348() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test348");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl14 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0011670527851042202d, 3.6110139823248093d, 0.9139218290287433d);
//        double double15 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl14);
//        double double16 = normalDistributionImpl14.sample();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.595682106798316d + "'", double3 == 4.595682106798316d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6444089499349697d + "'", double8 == 0.6444089499349697d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.6121810351099137d + "'", double15 == 2.6121810351099137d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-2.292579170748113d) + "'", double16 == (-2.292579170748113d));
//    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.special.Gamma.digamma(390.0443474541317d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.964977990804193d + "'", double1 == 5.964977990804193d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.cosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 0.0d, 6.017398292485759d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number6 = outOfRangeException5.getArgument();
        java.lang.Object[] objArray7 = outOfRangeException5.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray7);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable0, objArray7);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 14.0d + "'", number6.equals(14.0d));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.cos(99.83734442325613d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.768936387774252d + "'", double1 == 0.768936387774252d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-1.457837608056949d), 1.9133819916233718E49d, 0.3999169005490095d, 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.7912452447092146d, (-1.1146044433347386d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9507177167505854d + "'", double2 == 1.9507177167505854d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(31.999999932788864d, 0.0d, 7.521174815586791d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.log10((-6.063493002968778d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test361() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test361");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        int int13 = randomDataImpl1.nextSecureInt(0, 1);
//        double double15 = randomDataImpl1.nextExponential((double) (byte) 100);
//        try {
//            double double18 = randomDataImpl1.nextWeibull((-0.021700921462752897d), (double) 166L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.022 is smaller than, or equal to, the minimum (0): shape (-0.022)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07507113251513048d + "'", double3 == 0.07507113251513048d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.06005784806131727d + "'", double8 == 0.06005784806131727d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 31.412147090195987d + "'", double15 == 31.412147090195987d);
//    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("0", objArray1);
        java.lang.String str3 = mathException2.getPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.017610834678975965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2601716552800819d + "'", double1 == 0.2601716552800819d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.5920004022855878d, number1, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 5729.5779513082325d, (java.lang.Number) 31.999999932788864d, false);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
        java.lang.Object[] objArray11 = numberIsTooLargeException9.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException12 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, "606121f5bc004b817a8b99c0199819611a236f0c19e8f235de90b83373f6f2b0c92d8d97e3ac37891b9c3126e933428b369c", objArray11);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray11);
    }

//    @Test
//    public void test365() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test365");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        randomDataImpl1.reSeedSecure((long) ' ');
//        double double15 = randomDataImpl1.nextBeta(0.3495787551717202d, 100.00000000000001d);
//        double double18 = randomDataImpl1.nextCauchy(0.5403023058681398d, (double) (byte) 1);
//        long long21 = randomDataImpl1.nextLong(0L, 100L);
//        try {
//            double double24 = randomDataImpl1.nextF(0.35126798438961054d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.07011571214333895d + "'", double3 == 0.07011571214333895d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 13.445925987947463d + "'", double8 == 13.445925987947463d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.5864795684546167E-4d + "'", double15 == 3.5864795684546167E-4d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.11740946444055389d) + "'", double18 == (-0.11740946444055389d));
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 91L + "'", long21 == 91L);
//    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 3.8689523563986046d, (java.lang.Number) 29.823427584010098d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable8 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException19 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable15, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable14, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException32 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable33 = numberIsTooLargeException32.getGeneralPattern();
        java.lang.Object[] objArray35 = null;
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("0", objArray35);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray54 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable43, objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36, "", objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable33, objArray54);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException4, "cede62d4d2633857158d51440035feb628dd7167ca46d5dcb0ed59f29b3d245c4dde2153382880a9ae916e196467030f5421", objArray54);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray54);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.376727508058575d + "'", double1 == 0.376727508058575d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.26416163312575686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2581839112181112d + "'", double1 == 0.2581839112181112d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0010537829590105158d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0010537833490715323d + "'", double1 == 0.0010537833490715323d);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        long long13 = randomDataImpl1.nextSecureLong((long) (short) -1, 0L);
//        int int17 = randomDataImpl1.nextHypergeometric((int) '#', 4, (int) (byte) 0);
//        randomDataImpl1.reSeed(0L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.08512011077589325d + "'", double3 == 0.08512011077589325d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.4123627632659175d + "'", double8 == 1.4123627632659175d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "e" + "'", str10.equals("e"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.36787944117144233d, number1, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 4, 221.4625630039584d, 2.5454322047749787d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test374");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        long long8 = randomDataImpl1.nextPoisson(2.4633218980879183d);
//        randomDataImpl1.reSeed();
//        long long12 = randomDataImpl1.nextSecureLong((long) 1, (long) 3);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.1007375192948636d + "'", double3 == 0.1007375192948636d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 2L + "'", long8 == 2L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 3L + "'", long12 == 3L);
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.258370225278802d, 1.3213757317992672d, 1.81572948486401d);
        double double6 = normalDistributionImpl3.cumulativeProbability(0.6528774887016565d, 1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.016800367504120783d + "'", double6 == 0.016800367504120783d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4436354751788103d + "'", double1 == 1.4436354751788103d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.acos((-2.590558387537526d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test378");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextChiSquare(3.2473571906248826d);
//        java.lang.String str10 = randomDataImpl1.nextSecureHexString((int) (short) 1);
//        double double12 = randomDataImpl1.nextChiSquare(0.5722984289556622d);
//        int int15 = randomDataImpl1.nextZipf((int) (byte) 100, 3.4713071809033917d);
//        java.lang.String str17 = randomDataImpl1.nextHexString((int) (byte) 1);
//        double double19 = randomDataImpl1.nextChiSquare(0.18602827307190342d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0997657545985414d + "'", double3 == 0.0997657545985414d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.8220625784201239d + "'", double8 == 1.8220625784201239d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.014859226842944682d + "'", double12 == 0.014859226842944682d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "3" + "'", str17.equals("3"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.7183792388012401d + "'", double19 == 0.7183792388012401d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 4, 152.851579751457d);
        double double5 = normalDistributionImpl3.inverseCumulativeProbability(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable8 = numberIsTooLargeException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable8, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray19);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.5052570263122942d, (java.lang.Number) 0.8951071437047435d, true);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 3.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.762747174039086d + "'", double1 == 1.762747174039086d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        java.lang.Number number20 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.2735701380514667d, number20, false);
        boolean boolean23 = numberIsTooSmallException22.getBoundIsAllowed();
        boolean boolean24 = numberIsTooSmallException22.getBoundIsAllowed();
        boolean boolean25 = numberIsTooSmallException22.getBoundIsAllowed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException22);
        java.lang.Object[] objArray27 = convergenceException26.getArguments();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException(throwable9);
        org.apache.commons.math.ConvergenceException convergenceException11 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException16.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable23 = notStrictlyPositiveException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException29 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable25, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooLargeException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray41 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException(localizable30, objArray41);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException("", objArray41);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException19, localizable23, objArray41);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException48 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable49 = notStrictlyPositiveException48.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException54 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable50, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooLargeException54.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException60 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable56, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray66 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException(localizable55, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException68 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable49, objArray66);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException73 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable69, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray74 = numberIsTooLargeException73.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable49, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException44, "5", (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10, localizable17, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable7, (java.lang.Object[]) throwableArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(10, "{0}", (java.lang.Object[]) throwableArray74);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(throwableArray74);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 11);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number6 = outOfRangeException5.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException17 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable13, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray23 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException(localizable12, objArray23);
        java.lang.Class<?> wildcardClass25 = localizable12.getClass();
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException30 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable26, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable31 = numberIsTooLargeException30.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray42 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException(localizable31, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException(localizable12, objArray42);
        java.lang.Throwable throwable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooLargeException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable54, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray64 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable53, objArray64);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException("", objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(throwable45, "hi!", objArray64);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException5, localizable12, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable69 = outOfRangeException5.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 14.0d, (java.lang.Number) 0.1677205581070077d, (java.lang.Number) 0.7068861518200754d);
        java.lang.Number number75 = outOfRangeException74.getArgument();
        java.lang.Object[] objArray76 = outOfRangeException74.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: ", objArray76);
        java.lang.Object[] objArray78 = convergenceException77.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, objArray78);
        org.apache.commons.math.ConvergenceException convergenceException80 = new org.apache.commons.math.ConvergenceException("bf45a4b8d1", objArray78);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException("6", objArray78);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 14.0d + "'", number6.equals(14.0d));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + localizable69 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable69.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 14.0d + "'", number75.equals(14.0d));
        org.junit.Assert.assertNotNull(objArray76);
        org.junit.Assert.assertNotNull(objArray78);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray16 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException(localizable5, objArray16);
        java.lang.Class<?> wildcardClass18 = localizable5.getClass();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException22 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) (-0.7321877967059738d), (java.lang.Number) (-0.5772156677920679d), true);
        java.lang.Number number23 = numberIsTooLargeException22.getMax();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + (-0.5772156677920679d) + "'", number23.equals((-0.5772156677920679d)));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 152.851579751457d);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 152.851579751457d + "'", number2.equals(152.851579751457d));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.08178617201594224d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28598281769355d + "'", double1 == 0.28598281769355d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            randomDataImpl1.setSecureAlgorithm("3", "org.apache.commons.math.exception.NumberIsTooSmallException: 0.592 is smaller than, or equal to, the minimum (null)");
            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NumberIsTooSmallException: 0.592 is smaller than, or equal to, the minimum (null)");
        } catch (java.security.NoSuchProviderException e) {
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double1 = org.apache.commons.math.util.FastMath.sin(12.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5365729180004349d) + "'", double1 == (-0.5365729180004349d));
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        double double3 = randomDataImpl1.nextChiSquare((double) 1.0f);
//        double double6 = randomDataImpl1.nextCauchy(0.36787944117144233d, Double.NaN);
//        double double8 = randomDataImpl1.nextExponential((double) (short) 1);
//        double double10 = randomDataImpl1.nextExponential((double) 100L);
//        java.lang.String str12 = randomDataImpl1.nextHexString((int) (byte) 1);
//        int int16 = randomDataImpl1.nextHypergeometric(4, 4, 0);
//        int int19 = randomDataImpl1.nextZipf((int) (short) 10, 1.3436158727078784d);
//        int int22 = randomDataImpl1.nextBinomial(14, 0.6248420117881944d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.012944867171435757d + "'", double3 == 0.012944867171435757d);
//        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.238507579475864d + "'", double8 == 0.238507579475864d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.433811121623356d + "'", double10 == 4.433811121623356d);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1" + "'", str12.equals("1"));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 11 + "'", int22 == 11);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable7, objArray18);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException20 = new org.apache.commons.math.MaxIterationsExceededException(4, localizable1, objArray18);
        java.lang.Object[] objArray21 = maxIterationsExceededException20.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable22 = maxIterationsExceededException20.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNull(localizable22);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException(throwable2);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getGeneralPattern();
        java.lang.Throwable throwable8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(throwable8);
        org.apache.commons.math.ConvergenceException convergenceException10 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException15 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable11, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable16 = numberIsTooLargeException15.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable19 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException28 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable24, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable29 = numberIsTooLargeException28.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException34 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable30, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray40 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException(localizable29, objArray40);
        org.apache.commons.math.ConvergenceException convergenceException42 = new org.apache.commons.math.ConvergenceException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) notStrictlyPositiveException18, localizable22, objArray40);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException47 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.18749269135908855d);
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable49, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException59 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable55, (java.lang.Number) 0.15865525393145702d, (java.lang.Number) (-1L), false);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 0.15865525393145702d, "", (-1.0f), true, (byte) 100, 0.36787944117144233d };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable54, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, objArray65);
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException72 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable68, (java.lang.Number) 4.158638853279167d, (java.lang.Number) 0.17453292519943295d, false);
        java.lang.Throwable[] throwableArray73 = numberIsTooLargeException72.getSuppressed();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException74 = new org.apache.commons.math.MaxIterationsExceededException(10, localizable48, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException43, "5", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9, localizable16, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable6, (java.lang.Object[]) throwableArray73);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException79 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 0, "1", (java.lang.Object[]) throwableArray73);
        java.lang.String str80 = maxIterationsExceededException79.getPattern();
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(throwableArray73);
        org.junit.Assert.assertTrue("'" + str80 + "' != '" + "1" + "'", str80.equals("1"));
    }
}

