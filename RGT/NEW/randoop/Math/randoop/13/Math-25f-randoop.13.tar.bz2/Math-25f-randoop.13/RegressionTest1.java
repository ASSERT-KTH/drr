import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter1.addObservedPoint((double) 100.0f, (double) 10L, (double) 0L);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric19 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer31 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter32 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer31);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double37 = weightedObservedPoint36.getWeight();
        double double38 = weightedObservedPoint36.getWeight();
        harmonicFitter32.addObservedPoint(weightedObservedPoint36);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double44 = weightedObservedPoint43.getY();
        double double45 = weightedObservedPoint43.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint49 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double50 = weightedObservedPoint49.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint54 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double55 = weightedObservedPoint54.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint23, weightedObservedPoint27, weightedObservedPoint36, weightedObservedPoint43, weightedObservedPoint49, weightedObservedPoint54 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser57 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray56);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser58 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray56);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser59 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray56);
        double[] doubleArray60 = parameterGuesser59.guess();
        try {
            double[] doubleArray61 = harmonicFitter1.fit((-1), parametric19, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats6 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException10.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        exceptionContext11.setValue("cannot compute nth root for null or negative n: {0}", (java.lang.Object) localizedFormats13);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats17 };
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.ZeroException zeroException20 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray19);
        exceptionContext11.setValue("", (java.lang.Object) objArray19);
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LIST_OF_CHROMOSOMES_BIGGER_THAN_POPULATION_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint3);
        harmonicFitter2.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter2.clearObservations();
        harmonicFitter2.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter2.addObservedPoint((double) 100.0f, (double) 10L, (double) 0L);
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray19 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) weightedObservedPointArray19);
        org.junit.Assert.assertNotNull(weightedObservedPointArray19);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "overflow: gcd({0}, {1}) is 2^63" + "'", str1.equals("overflow: gcd({0}, {1}) is 2^63"));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 0, (java.lang.Number) 1.0d, true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_FIXED_LENGTH_CHROMOSOME;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_FIXED_LENGTH_CHROMOSOME + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_FIXED_LENGTH_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "one-point crossover only works with fixed-length chromosomes" + "'", str1.equals("one-point crossover only works with fixed-length chromosomes"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray2 = new java.lang.Object[] { localizedFormats1 };
        java.lang.Object[] objArray3 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        java.lang.Object[] objArray4 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray2);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException11.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(exceptionContext12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats11 };
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray12);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray14);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException23 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats17, localizedFormats18, localizedFormats19, true, localizedFormats24, localizedFormats25 };
        java.lang.Object[] objArray27 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray26);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException28 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException9, (org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray27);
        java.lang.String str29 = numberIsTooSmallException9.toString();
        java.lang.Number number30 = numberIsTooSmallException9.getArgument();
        java.lang.Throwable[] throwableArray31 = numberIsTooSmallException9.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        java.lang.Number number33 = numberIsTooSmallException3.getMin();
        java.lang.Number number34 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats24.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)" + "'", str29.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + number30 + "' != '" + 1.0d + "'", number30.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray31);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1 + "'", number33.equals(1));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1 + "'", number34.equals(1));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        exceptionContext10.setValue("cannot compute nth root for null or negative n: {0}", (java.lang.Object) localizedFormats12);
        java.lang.Throwable throwable14 = exceptionContext10.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertNotNull(throwable14);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 100, number1, true);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats9 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException7, (org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray12);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats15, localizedFormats16, localizedFormats17, true, localizedFormats22, localizedFormats23 };
        java.lang.Object[] objArray25 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException7, (org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray25);
        java.lang.String str27 = numberIsTooSmallException7.toString();
        java.lang.Number number28 = numberIsTooSmallException7.getArgument();
        java.lang.Throwable[] throwableArray29 = numberIsTooSmallException7.getSuppressed();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException7);
        java.lang.Number number31 = numberIsTooSmallException3.getArgument();
        java.lang.Number number32 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)" + "'", str27.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertNotNull(throwableArray29);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + (short) 100 + "'", number31.equals((short) 100));
        org.junit.Assert.assertNull(number32);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double6 = weightedObservedPoint5.getWeight();
        double double7 = weightedObservedPoint5.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        harmonicFitter1.addObservedPoint((double) 1L, (double) '#');
        harmonicFitter1.addObservedPoint(100.0d, (double) (short) 0);
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        double double4 = weightedObservedPoint3.getWeight();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 0L, 100.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter15.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        harmonicFitter15.addObservedPoint(weightedObservedPoint27);
        double double32 = weightedObservedPoint27.getX();
        double double33 = weightedObservedPoint27.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint27);
        double double35 = weightedObservedPoint27.getX();
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) 10L, (double) 10);
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 10L);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric17 = null;
        double[] doubleArray23 = new double[] { 'a', (short) 1, 97.0d, (short) 0, (short) 100 };
        try {
            double[] doubleArray24 = harmonicFitter1.fit(0, parametric17, doubleArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0d, (java.lang.Number) 10L, false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) 0L, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUTLINE_BOUNDARY_LOOP_OPEN));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray2 = new java.lang.Object[] { localizedFormats1 };
        java.lang.Object[] objArray3 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray2);
        java.lang.Throwable[] throwableArray5 = mathIllegalArgumentException4.getSuppressed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = mathIllegalArgumentException4.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSUFFICIENT_DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0L, (java.lang.Number) (short) 1, false);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10L, number1, true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (-1.0d), true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Object obj7 = exceptionContext5.getValue("org.apache.commons.math3.exception.NumberIsTooSmallException: unable to solve: singular problem");
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint(100.0d, (double) '4', (double) 100L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 0L, number1, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.clearObservations();
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) (byte) 1, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        java.util.Set<java.lang.String> strSet5 = exceptionContext4.getKeys();
        java.util.Set<java.lang.String> strSet6 = exceptionContext4.getKeys();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertNotNull(strSet5);
        org.junit.Assert.assertNotNull(strSet6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (byte) -1, (java.lang.Number) 100L, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), number2, false);
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException4.getSuppressed();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException7 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray6);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext8 = mathIllegalStateException7.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathIllegalStateException7.getContext();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray16 = new java.lang.Object[] { localizedFormats15 };
        java.lang.Object[] objArray17 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        java.lang.Object[] objArray18 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray16);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException19 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException13, (org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext20 = mathIllegalStateException19.getContext();
        java.lang.Object obj22 = exceptionContext20.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray30 = new java.lang.Object[] { localizedFormats29 };
        java.lang.Object[] objArray31 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray30);
        java.lang.Object[] objArray32 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray30);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException33 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException27, (org.apache.commons.math3.exception.util.Localizable) localizedFormats28, objArray32);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats42 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray44 = new java.lang.Object[] { localizedFormats35, localizedFormats36, localizedFormats37, true, localizedFormats42, localizedFormats43 };
        java.lang.Object[] objArray45 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray44);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException46 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException27, (org.apache.commons.math3.exception.util.Localizable) localizedFormats34, objArray45);
        exceptionContext20.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray45);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats48 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats53 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats54 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray55 = new java.lang.Object[] { localizedFormats54 };
        java.lang.Object[] objArray56 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray55);
        java.lang.Object[] objArray57 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray55);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException58 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException52, (org.apache.commons.math3.exception.util.Localizable) localizedFormats53, objArray57);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException59 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats48, objArray57);
        java.lang.Object[] objArray60 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray57);
        exceptionContext9.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats23, objArray57);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ELEMENT_AT_INDEX));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(exceptionContext20);
        org.junit.Assert.assertNull(obj22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats23.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats29.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats35.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats42 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats42.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats43.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + localizedFormats48 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats48.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats53 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats53.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats54 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats54.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer10 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter11 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = null;
        harmonicFitter11.addObservedPoint(weightedObservedPoint12);
        harmonicFitter11.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter11.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter11.addObservedPoint(weightedObservedPoint22);
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double33 = weightedObservedPoint32.getWeight();
        double double34 = weightedObservedPoint32.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint32);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric36 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint40 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint44 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double45 = weightedObservedPoint44.getWeight();
        double double46 = weightedObservedPoint44.getWeight();
        double double47 = weightedObservedPoint44.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer48 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter49 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer48);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint53 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double54 = weightedObservedPoint53.getWeight();
        double double55 = weightedObservedPoint53.getWeight();
        harmonicFitter49.addObservedPoint(weightedObservedPoint53);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint60 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double61 = weightedObservedPoint60.getY();
        double double62 = weightedObservedPoint60.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint66 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double67 = weightedObservedPoint66.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint71 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double72 = weightedObservedPoint71.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray73 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint40, weightedObservedPoint44, weightedObservedPoint53, weightedObservedPoint60, weightedObservedPoint66, weightedObservedPoint71 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser74 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray73);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser75 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray73);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser76 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray73);
        double[] doubleArray77 = parameterGuesser76.guess();
        double[] doubleArray78 = parameterGuesser76.guess();
        double[] doubleArray79 = parameterGuesser76.guess();
        try {
            double[] doubleArray80 = harmonicFitter1.fit(parametric36, doubleArray79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0d + "'", double54 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.0d + "'", double61 == 100.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.0d + "'", double62 == 100.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0d + "'", double67 == 1.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1), (double) 0.0f, (double) 100.0f);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray6 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) ' ', (double) (-1));
        harmonicFitter1.addObservedPoint((double) (byte) 0, 0.0d, (double) 0L);
        org.junit.Assert.assertNotNull(weightedObservedPointArray6);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double6 = weightedObservedPoint5.getWeight();
        double double7 = weightedObservedPoint5.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        harmonicFitter1.addObservedPoint((double) 1L, (double) '#');
        harmonicFitter1.addObservedPoint(100.0d, (double) (short) 0);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer15 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter16 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer15);
        harmonicFitter16.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter16.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer25 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter26 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = null;
        harmonicFitter26.addObservedPoint(weightedObservedPoint27);
        harmonicFitter26.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter26.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double38 = weightedObservedPoint37.getWeight();
        double double39 = weightedObservedPoint37.getWeight();
        double double40 = weightedObservedPoint37.getX();
        harmonicFitter26.addObservedPoint(weightedObservedPoint37);
        harmonicFitter16.addObservedPoint(weightedObservedPoint37);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray43 = harmonicFitter16.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double48 = weightedObservedPoint47.getWeight();
        double double49 = weightedObservedPoint47.getWeight();
        harmonicFitter16.addObservedPoint(weightedObservedPoint47);
        double double51 = weightedObservedPoint47.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint47);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray53 = harmonicFitter1.getObservations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.0d + "'", double40 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.0d + "'", double51 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray53);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats13, localizedFormats14, localizedFormats15, true, localizedFormats20, localizedFormats21 };
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray23);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException24);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats27 };
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException24, (org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray29);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext32 = mathIllegalStateException31.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(exceptionContext32);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray3 = new java.lang.Object[] { localizedFormats2 };
        java.lang.Object[] objArray4 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray3);
        org.apache.commons.math3.exception.ZeroException zeroException5 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray3);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray3);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.TOO_SMALL_PARAMETERS_RELATIVE_TOLERANCE));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 100, number1, true);
        java.lang.Class<?> wildcardClass4 = numberIsTooSmallException3.getClass();
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 0L, 100.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter15.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        harmonicFitter15.addObservedPoint(weightedObservedPoint27);
        double double32 = weightedObservedPoint27.getX();
        double double33 = weightedObservedPoint27.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint27);
        harmonicFitter1.addObservedPoint((double) (byte) 0, 1.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint41 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint45 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double46 = weightedObservedPoint45.getWeight();
        double double47 = weightedObservedPoint45.getWeight();
        double double48 = weightedObservedPoint45.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer49 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter50 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer49);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint54 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double55 = weightedObservedPoint54.getWeight();
        double double56 = weightedObservedPoint54.getWeight();
        harmonicFitter50.addObservedPoint(weightedObservedPoint54);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint61 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double62 = weightedObservedPoint61.getY();
        double double63 = weightedObservedPoint61.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint67 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double68 = weightedObservedPoint67.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint72 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double73 = weightedObservedPoint72.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray74 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint41, weightedObservedPoint45, weightedObservedPoint54, weightedObservedPoint61, weightedObservedPoint67, weightedObservedPoint72 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser75 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray74);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser76 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray74);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser77 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray74);
        double[] doubleArray78 = parameterGuesser77.guess();
        double[] doubleArray79 = parameterGuesser77.guess();
        double[] doubleArray80 = parameterGuesser77.guess();
        try {
            double[] doubleArray81 = harmonicFitter1.fit(doubleArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.0d + "'", double62 == 100.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 100.0d + "'", double63 == 100.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0d + "'", double68 == 1.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.0d + "'", double73 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter1.addObservedPoint((double) (short) 100, (-1.0d));
        harmonicFitter1.addObservedPoint(1.0d, (double) (short) -1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer10 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter11 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = null;
        harmonicFitter11.addObservedPoint(weightedObservedPoint12);
        harmonicFitter11.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter11.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter11.addObservedPoint(weightedObservedPoint22);
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double33 = weightedObservedPoint32.getWeight();
        double double34 = weightedObservedPoint32.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint32);
        double double36 = weightedObservedPoint32.getY();
        double double37 = weightedObservedPoint32.getY();
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 100.0d + "'", double36 == 100.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 100.0d + "'", double37 == 100.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        harmonicFitter1.addObservedPoint((double) (short) 10, (double) (byte) -1, (double) (short) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray14 = harmonicFitter1.getObservations();
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertNotNull(weightedObservedPointArray14);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double4 = weightedObservedPoint3.getY();
        double double5 = weightedObservedPoint3.getY();
        double double6 = weightedObservedPoint3.getWeight();
        double double7 = weightedObservedPoint3.getY();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_BINARY_CHROMOSOME));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "binary mutation works on BinaryChromosome only" + "'", str1.equals("binary mutation works on BinaryChromosome only"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint4 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint8 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double9 = weightedObservedPoint8.getWeight();
        double double10 = weightedObservedPoint8.getWeight();
        double double11 = weightedObservedPoint8.getWeight();
        double double12 = weightedObservedPoint8.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double21 = weightedObservedPoint20.getWeight();
        double double22 = weightedObservedPoint20.getWeight();
        double double23 = weightedObservedPoint20.getWeight();
        double double24 = weightedObservedPoint20.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint28 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double29 = weightedObservedPoint28.getWeight();
        double double30 = weightedObservedPoint28.getWeight();
        double double31 = weightedObservedPoint28.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint35 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint4, weightedObservedPoint8, weightedObservedPoint16, weightedObservedPoint20, weightedObservedPoint28, weightedObservedPoint35 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser38 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray36);
        java.lang.Object[] objArray40 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray39);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_INCREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter1.addObservedPoint((double) 100.0f, (double) 10L, (double) 0L);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer18 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter19 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer18);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = null;
        harmonicFitter19.addObservedPoint(weightedObservedPoint20);
        harmonicFitter19.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter19.clearObservations();
        harmonicFitter19.addObservedPoint(0.0d, (double) 10L, (double) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0.0f, (double) (short) -1, (double) (short) 100);
        harmonicFitter19.addObservedPoint(weightedObservedPoint34);
        harmonicFitter1.addObservedPoint(weightedObservedPoint34);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats11, localizedFormats12, localizedFormats13, true, localizedFormats18, localizedFormats19 };
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats10, objArray21);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext23 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException22);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE;
        exceptionContext23.setValue("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)", (java.lang.Object) localizedFormats25);
        java.util.Set<java.lang.String> strSet27 = exceptionContext23.getKeys();
        java.lang.Object obj29 = null;
        exceptionContext23.setValue("overflow: gcd({0}, {1}) is 2^63", obj29);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats10.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats18.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_POPULATION_SIZE));
        org.junit.Assert.assertNotNull(strSet27);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats17 };
        java.lang.Object[] objArray19 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        java.lang.Object[] objArray20 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException21 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException15, (org.apache.commons.math3.exception.util.Localizable) localizedFormats16, objArray20);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = mathIllegalStateException21.getContext();
        java.lang.Object obj24 = exceptionContext22.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray32 = new java.lang.Object[] { localizedFormats31 };
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray34);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray46 = new java.lang.Object[] { localizedFormats37, localizedFormats38, localizedFormats39, true, localizedFormats44, localizedFormats45 };
        java.lang.Object[] objArray47 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray46);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException48 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats36, objArray47);
        exceptionContext22.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray47);
        exceptionContext10.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray47);
        java.util.Set<java.lang.String> strSet51 = exceptionContext10.getKeys();
        java.util.Set<java.lang.String> strSet52 = exceptionContext10.getKeys();
        java.lang.Throwable throwable53 = exceptionContext10.getThrowable();
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException58 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats60 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray61 = new java.lang.Object[] { localizedFormats60 };
        java.lang.Object[] objArray62 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray61);
        java.lang.Object[] objArray63 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray61);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException64 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException58, (org.apache.commons.math3.exception.util.Localizable) localizedFormats59, objArray63);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext65 = mathIllegalStateException64.getContext();
        java.lang.Object obj67 = exceptionContext65.getValue("");
        java.lang.Throwable throwable68 = exceptionContext65.getThrowable();
        exceptionContext10.setValue("org.apache.commons.math3.exception.MathIllegalStateException: illegal state", (java.lang.Object) throwable68);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException74 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats70, (java.lang.Number) 0L, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray75 = numberIsTooSmallException74.getSuppressed();
        throwable68.addSuppressed((java.lang.Throwable) numberIsTooSmallException74);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertNull(obj24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats44.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertNotNull(strSet51);
        org.junit.Assert.assertNotNull(strSet52);
        org.junit.Assert.assertNotNull(throwable53);
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats59.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats60 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats60.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(exceptionContext65);
        org.junit.Assert.assertNull(obj67);
        org.junit.Assert.assertNotNull(throwable68);
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats70.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertNotNull(throwableArray75);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "overflow: lcm({0}, {1}) is 2^31" + "'", str1.equals("overflow: lcm({0}, {1}) is 2^31"));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray3 = new java.lang.Object[] { localizedFormats2 };
        java.lang.Object[] objArray4 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray3);
        org.apache.commons.math3.exception.ZeroException zeroException5 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray4);
        java.lang.Object[] objArray6 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray4);
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats9 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        java.lang.Object[] objArray12 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.ZeroException zeroException13 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray10);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.BANDWIDTH));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint4 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint8 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double9 = weightedObservedPoint8.getWeight();
        double double10 = weightedObservedPoint8.getWeight();
        double double11 = weightedObservedPoint8.getWeight();
        double double12 = weightedObservedPoint8.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint16 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double21 = weightedObservedPoint20.getWeight();
        double double22 = weightedObservedPoint20.getWeight();
        double double23 = weightedObservedPoint20.getWeight();
        double double24 = weightedObservedPoint20.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint28 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double29 = weightedObservedPoint28.getWeight();
        double double30 = weightedObservedPoint28.getWeight();
        double double31 = weightedObservedPoint28.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint35 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint4, weightedObservedPoint8, weightedObservedPoint16, weightedObservedPoint20, weightedObservedPoint28, weightedObservedPoint35 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser38 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray36);
        java.lang.Object[] objArray39 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray36);
        java.lang.Object[] objArray40 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math3.exception.ZeroException zeroException41 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray40);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 100.0d + "'", double24 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray36);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray40);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES;
        exceptionContext10.setValue("cannot compute nth root for null or negative n: {0}", (java.lang.Object) localizedFormats12);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats12, (java.lang.Number) 1, (java.lang.Number) (short) -1, false);
        boolean boolean18 = numberIsTooSmallException17.getBoundIsAllowed();
        java.lang.Number number19 = numberIsTooSmallException17.getMin();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_STRICTLY_INCREASING_KNOT_VALUES));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + (short) -1 + "'", number19.equals((short) -1));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1), (double) 0.0f, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) 10L, (double) (short) 0, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint17 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double18 = weightedObservedPoint17.getWeight();
        double double19 = weightedObservedPoint17.getWeight();
        double double20 = weightedObservedPoint17.getWeight();
        double double21 = weightedObservedPoint17.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint25 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint29 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double30 = weightedObservedPoint29.getWeight();
        double double31 = weightedObservedPoint29.getWeight();
        double double32 = weightedObservedPoint29.getWeight();
        double double33 = weightedObservedPoint29.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double38 = weightedObservedPoint37.getWeight();
        double double39 = weightedObservedPoint37.getWeight();
        double double40 = weightedObservedPoint37.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint44 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray45 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint13, weightedObservedPoint17, weightedObservedPoint25, weightedObservedPoint29, weightedObservedPoint37, weightedObservedPoint44 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser46 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray45);
        double[] doubleArray47 = parameterGuesser46.guess();
        try {
            double[] doubleArray48 = harmonicFitter1.fit(doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 100.0d + "'", double21 == 100.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        boolean boolean10 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number11 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = numberIsTooSmallException3.getContext();
        boolean boolean13 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = numberIsTooSmallException3.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0d + "'", number11.equals(1.0d));
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(exceptionContext14);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint7 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double8 = weightedObservedPoint7.getWeight();
        double double9 = weightedObservedPoint7.getWeight();
        double double10 = weightedObservedPoint7.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint7);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double6 = weightedObservedPoint5.getWeight();
        double double7 = weightedObservedPoint5.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        harmonicFitter1.addObservedPoint((double) 1L, (double) '#');
        harmonicFitter1.addObservedPoint(100.0d, (double) (short) 0);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer15 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter16 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer15);
        harmonicFitter16.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter16.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer25 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter26 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer25);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = null;
        harmonicFitter26.addObservedPoint(weightedObservedPoint27);
        harmonicFitter26.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter26.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint37 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double38 = weightedObservedPoint37.getWeight();
        double double39 = weightedObservedPoint37.getWeight();
        double double40 = weightedObservedPoint37.getX();
        harmonicFitter26.addObservedPoint(weightedObservedPoint37);
        harmonicFitter16.addObservedPoint(weightedObservedPoint37);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray43 = harmonicFitter16.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double48 = weightedObservedPoint47.getWeight();
        double double49 = weightedObservedPoint47.getWeight();
        harmonicFitter16.addObservedPoint(weightedObservedPoint47);
        double double51 = weightedObservedPoint47.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint47);
        double double53 = weightedObservedPoint47.getY();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.0d + "'", double40 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray43);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.0d + "'", double51 == 100.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 100.0d + "'", double53 == 100.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) (-1), true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0d, (java.lang.Number) 100, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats1, localizedFormats2, localizedFormats3, true, localizedFormats8, localizedFormats9 };
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray10);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray11);
        java.lang.Object[] objArray13 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.GCD_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats9.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter1.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint13 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double14 = weightedObservedPoint13.getWeight();
        double double15 = weightedObservedPoint13.getWeight();
        double double16 = weightedObservedPoint13.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint13);
        double double18 = weightedObservedPoint13.getY();
        double double19 = weightedObservedPoint13.getY();
        double double20 = weightedObservedPoint13.getY();
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.0d + "'", double19 == 100.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 100.0d + "'", double20 == 100.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION;
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer1 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter2 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer1);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = null;
        harmonicFitter2.addObservedPoint(weightedObservedPoint3);
        harmonicFitter2.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter2.clearObservations();
        harmonicFitter2.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter2.addObservedPoint((double) 100.0f, (double) 10L, (double) 0L);
        harmonicFitter2.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray19 = harmonicFitter2.getObservations();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray19);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_FORMAT_OBJECT_TO_FRACTION));
        org.junit.Assert.assertNotNull(weightedObservedPointArray19);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.START_POSITION;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.START_POSITION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.START_POSITION));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "start position ({0})" + "'", str1.equals("start position ({0})"));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 1L, true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1L) + "'", number5.equals((-1L)));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray10);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats13, localizedFormats14, localizedFormats15, true, localizedFormats20, localizedFormats21 };
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray23);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext25 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException24);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats27 };
        java.lang.Object[] objArray29 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException30 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException24, (org.apache.commons.math3.exception.util.Localizable) localizedFormats26, objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable0, (org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray29);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException36 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray39 = new java.lang.Object[] { localizedFormats38 };
        java.lang.Object[] objArray40 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        java.lang.Object[] objArray41 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray39);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException42 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException36, (org.apache.commons.math3.exception.util.Localizable) localizedFormats37, objArray41);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats32, objArray41);
        java.lang.Object[] objArray44 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray41);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException45 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray41);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizedFormats51 };
        java.lang.Object[] objArray53 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray52);
        java.lang.Object[] objArray54 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray52);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException55 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException49, (org.apache.commons.math3.exception.util.Localizable) localizedFormats50, objArray54);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext56 = mathIllegalStateException55.getContext();
        java.lang.Object obj58 = exceptionContext56.getValue("");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats59 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats64 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray66 = new java.lang.Object[] { localizedFormats65 };
        java.lang.Object[] objArray67 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray66);
        java.lang.Object[] objArray68 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray66);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException69 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException63, (org.apache.commons.math3.exception.util.Localizable) localizedFormats64, objArray68);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats70 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats71 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats72 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats73 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats78 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats79 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray80 = new java.lang.Object[] { localizedFormats71, localizedFormats72, localizedFormats73, true, localizedFormats78, localizedFormats79 };
        java.lang.Object[] objArray81 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray80);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException82 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException63, (org.apache.commons.math3.exception.util.Localizable) localizedFormats70, objArray81);
        exceptionContext56.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats59, objArray81);
        java.lang.Object[] objArray84 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray81);
        org.apache.commons.math3.exception.ZeroException zeroException85 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, objArray84);
        java.lang.Class<?> wildcardClass86 = objArray84.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats32.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats50.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(exceptionContext56);
        org.junit.Assert.assertNull(obj58);
        org.junit.Assert.assertTrue("'" + localizedFormats59 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizedFormats59.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizedFormats64 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats64.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats65.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + localizedFormats70 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats70.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats71 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats71.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats72 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats72.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats73 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats73.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats78 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats78.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats79 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats79.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray81);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertNotNull(wildcardClass86);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 0L, 100.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter15.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        harmonicFitter15.addObservedPoint(weightedObservedPoint27);
        double double32 = weightedObservedPoint27.getX();
        double double33 = weightedObservedPoint27.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint27);
        harmonicFitter1.addObservedPoint((double) (byte) 0, 1.0d);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric39 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double48 = weightedObservedPoint47.getWeight();
        double double49 = weightedObservedPoint47.getWeight();
        double double50 = weightedObservedPoint47.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer51 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter52 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer51);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double57 = weightedObservedPoint56.getWeight();
        double double58 = weightedObservedPoint56.getWeight();
        harmonicFitter52.addObservedPoint(weightedObservedPoint56);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint63 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double64 = weightedObservedPoint63.getY();
        double double65 = weightedObservedPoint63.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint69 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double70 = weightedObservedPoint69.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint74 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double75 = weightedObservedPoint74.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray76 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint43, weightedObservedPoint47, weightedObservedPoint56, weightedObservedPoint63, weightedObservedPoint69, weightedObservedPoint74 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser77 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray76);
        double[] doubleArray78 = parameterGuesser77.guess();
        try {
            double[] doubleArray79 = harmonicFitter1.fit((int) (byte) 10, parametric39, doubleArray78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.0d + "'", double64 == 100.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 100.0d + "'", double65 == 100.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double11 = weightedObservedPoint10.getY();
        double double12 = weightedObservedPoint10.getY();
        double double13 = weightedObservedPoint10.getY();
        double double14 = weightedObservedPoint10.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double24 = weightedObservedPoint23.getWeight();
        double double25 = weightedObservedPoint23.getWeight();
        double double26 = weightedObservedPoint23.getWeight();
        double double27 = weightedObservedPoint23.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint35 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double36 = weightedObservedPoint35.getWeight();
        double double37 = weightedObservedPoint35.getWeight();
        double double38 = weightedObservedPoint35.getWeight();
        double double39 = weightedObservedPoint35.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double44 = weightedObservedPoint43.getWeight();
        double double45 = weightedObservedPoint43.getWeight();
        double double46 = weightedObservedPoint43.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint50 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray51 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint19, weightedObservedPoint23, weightedObservedPoint31, weightedObservedPoint35, weightedObservedPoint43, weightedObservedPoint50 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser52 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray51);
        double[] doubleArray53 = parameterGuesser52.guess();
        try {
            double[] doubleArray54 = harmonicFitter1.fit(doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0d + "'", double46 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) 10L, (double) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray13 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) (byte) 1);
        harmonicFitter1.addObservedPoint((double) 1, (double) ' ', (double) (byte) 10);
        org.junit.Assert.assertNotNull(weightedObservedPointArray13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) 1L, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException4);
        java.lang.Object obj7 = exceptionContext5.getValue("all ordinatae must be finite real numbers, but {0}-th is {1}");
        java.lang.Object obj9 = exceptionContext5.getValue("lower endpoint ({0}) must be less than or equal to upper endpoint ({1})");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_REGRESSION_ARRAY));
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNull(obj9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 0L, 100.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter15.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        harmonicFitter15.addObservedPoint(weightedObservedPoint27);
        double double32 = weightedObservedPoint27.getX();
        double double33 = weightedObservedPoint27.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint27);
        harmonicFitter1.addObservedPoint((double) (byte) 0, 1.0d);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric39 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double48 = weightedObservedPoint47.getWeight();
        double double49 = weightedObservedPoint47.getWeight();
        double double50 = weightedObservedPoint47.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer51 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter52 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer51);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double57 = weightedObservedPoint56.getWeight();
        double double58 = weightedObservedPoint56.getWeight();
        harmonicFitter52.addObservedPoint(weightedObservedPoint56);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint63 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double64 = weightedObservedPoint63.getY();
        double double65 = weightedObservedPoint63.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint69 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double70 = weightedObservedPoint69.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint74 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double75 = weightedObservedPoint74.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray76 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint43, weightedObservedPoint47, weightedObservedPoint56, weightedObservedPoint63, weightedObservedPoint69, weightedObservedPoint74 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser77 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray76);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser78 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray76);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser79 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray76);
        double[] doubleArray80 = parameterGuesser79.guess();
        double[] doubleArray81 = parameterGuesser79.guess();
        try {
            double[] doubleArray82 = harmonicFitter1.fit((-1), parametric39, doubleArray81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.0d + "'", double64 == 100.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 100.0d + "'", double65 == 100.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats6 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats12, localizedFormats13, localizedFormats14, true, localizedFormats19, localizedFormats20 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray22);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext24 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException23);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray32 = new java.lang.Object[] { localizedFormats31 };
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        java.lang.Object[] objArray34 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray32);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException35 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats30, objArray34);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats44 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray46 = new java.lang.Object[] { localizedFormats37, localizedFormats38, localizedFormats39, true, localizedFormats44, localizedFormats45 };
        java.lang.Object[] objArray47 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray46);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException48 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException29, (org.apache.commons.math3.exception.util.Localizable) localizedFormats36, objArray47);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext49 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException48);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizedFormats51 };
        java.lang.Object[] objArray53 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray52);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException54 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException48, (org.apache.commons.math3.exception.util.Localizable) localizedFormats50, objArray53);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException55 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException23, (org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray53);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray53);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException60 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 10, (java.lang.Number) 1L, true);
        java.util.Locale locale61 = null;
        try {
            java.lang.String str62 = localizedFormats0.getLocalizedString(locale61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NAN_ELEMENT_AT_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_ORDER_ABSCISSA_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats30.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats31.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats36.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats37.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats38.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats44 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats44.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray47);
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats50.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray53);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer10 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter11 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = null;
        harmonicFitter11.addObservedPoint(weightedObservedPoint12);
        harmonicFitter11.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter11.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter11.addObservedPoint(weightedObservedPoint22);
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        double double28 = weightedObservedPoint22.getX();
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.0d + "'", double28 == 100.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats12 };
        java.lang.Object[] objArray14 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray13);
        exceptionContext10.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats11, objArray14);
        java.lang.Throwable throwable16 = exceptionContext10.getThrowable();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX;
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats20 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.ZeroException zeroException23 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray22);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable18, objArray22);
        exceptionContext10.addMessage((org.apache.commons.math3.exception.util.Localizable) localizedFormats17, objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE + "'", localizedFormats11.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NEGATIVE_COMPLEX_MODULE));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(throwable16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX + "'", localizedFormats17.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_ORTHOGONOLIZE_MATRIX));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_RIGHT));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = new org.apache.commons.math3.exception.util.ExceptionContext(throwable0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double11 = weightedObservedPoint10.getY();
        double double12 = weightedObservedPoint10.getY();
        double double13 = weightedObservedPoint10.getY();
        double double14 = weightedObservedPoint10.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint10);
        double double16 = weightedObservedPoint10.getY();
        double double17 = weightedObservedPoint10.getX();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray2 = new java.lang.Object[] { localizedFormats1 };
        java.lang.Object[] objArray3 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math3.exception.ZeroException zeroException4 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) zeroException4);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext6 = zeroException4.getContext();
        java.lang.Throwable[] throwableArray7 = zeroException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_DECREASING_NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint7 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double8 = weightedObservedPoint7.getWeight();
        double double9 = weightedObservedPoint7.getWeight();
        double double10 = weightedObservedPoint7.getWeight();
        double double11 = weightedObservedPoint7.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double20 = weightedObservedPoint19.getWeight();
        double double21 = weightedObservedPoint19.getWeight();
        double double22 = weightedObservedPoint19.getWeight();
        double double23 = weightedObservedPoint19.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint34 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray35 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint3, weightedObservedPoint7, weightedObservedPoint15, weightedObservedPoint19, weightedObservedPoint27, weightedObservedPoint34 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser36 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray35);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser37 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray35);
        double[] doubleArray38 = parameterGuesser37.guess();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1, (java.lang.Number) (byte) 1, true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathIllegalStateException9.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathIllegalStateException9.getContext();
        java.lang.Throwable throwable12 = exceptionContext11.getThrowable();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertNotNull(exceptionContext11);
        org.junit.Assert.assertNotNull(throwable12);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) 10, number1, true);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((double) (-1), (double) 0.0f, (double) 100.0f);
        harmonicFitter1.addObservedPoint((double) 10L, (double) (short) 0, 0.0d);
        harmonicFitter1.addObservedPoint((double) (byte) 10, (double) '4', 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double13 = weightedObservedPoint12.getWeight();
        double double14 = weightedObservedPoint12.getWeight();
        double double15 = weightedObservedPoint12.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint12);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint20 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        harmonicFitter1.addObservedPoint(weightedObservedPoint20);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric22 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint26 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint30 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double31 = weightedObservedPoint30.getWeight();
        double double32 = weightedObservedPoint30.getWeight();
        double double33 = weightedObservedPoint30.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer34 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter35 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer34);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint39 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double40 = weightedObservedPoint39.getWeight();
        double double41 = weightedObservedPoint39.getWeight();
        harmonicFitter35.addObservedPoint(weightedObservedPoint39);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint46 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double47 = weightedObservedPoint46.getY();
        double double48 = weightedObservedPoint46.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint52 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double53 = weightedObservedPoint52.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint57 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double58 = weightedObservedPoint57.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray59 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint26, weightedObservedPoint30, weightedObservedPoint39, weightedObservedPoint46, weightedObservedPoint52, weightedObservedPoint57 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser60 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray59);
        double[] doubleArray61 = parameterGuesser60.guess();
        try {
            double[] doubleArray62 = harmonicFitter1.fit(parametric22, doubleArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 100.0d + "'", double47 == 100.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 100.0d + "'", double48 == 100.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray9 = new java.lang.Object[] { localizedFormats8 };
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray9);
        java.lang.Object[] objArray11 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException6, (org.apache.commons.math3.exception.util.Localizable) localizedFormats7, objArray11);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray23 = new java.lang.Object[] { localizedFormats14, localizedFormats15, localizedFormats16, true, localizedFormats21, localizedFormats22 };
        java.lang.Object[] objArray24 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray23);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException25 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException6, (org.apache.commons.math3.exception.util.Localizable) localizedFormats13, objArray24);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext26 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException25);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats28 };
        java.lang.Object[] objArray30 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException31 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException25, (org.apache.commons.math3.exception.util.Localizable) localizedFormats27, objArray30);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException32 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable1, (org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray30);
        java.lang.Object[] objArray33 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray30);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray30);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext35 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException34);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.VALUES_ADDED_BEFORE_CONFIGURING_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats15.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats16.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats21.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats22.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray33);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.FIRST_COLUMNS_NOT_INITIALIZED_YET));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), number1, false);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = numberIsTooSmallException3.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) numberIsTooSmallException3);
        boolean boolean6 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint3 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) 100.0f, (double) 0L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint(0.0d, (double) 10L, (double) 10);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric14 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint18 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer26 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter27 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer26);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double32 = weightedObservedPoint31.getWeight();
        double double33 = weightedObservedPoint31.getWeight();
        harmonicFitter27.addObservedPoint(weightedObservedPoint31);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint38 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double39 = weightedObservedPoint38.getY();
        double double40 = weightedObservedPoint38.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint44 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double45 = weightedObservedPoint44.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint49 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double50 = weightedObservedPoint49.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray51 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint18, weightedObservedPoint22, weightedObservedPoint31, weightedObservedPoint38, weightedObservedPoint44, weightedObservedPoint49 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser52 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray51);
        double[] doubleArray53 = parameterGuesser52.guess();
        double[] doubleArray54 = parameterGuesser52.guess();
        try {
            double[] doubleArray55 = harmonicFitter1.fit((int) (byte) 10, parametric14, doubleArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.0d + "'", double39 == 100.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.0d + "'", double40 == 100.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (byte) 0, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 0 + "'", number5.equals((byte) 0));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, (org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray10);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext12 = mathIllegalStateException11.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext13 = mathIllegalStateException11.getContext();
        java.lang.Throwable[] throwableArray14 = mathIllegalStateException11.getSuppressed();
        org.apache.commons.math3.exception.ZeroException zeroException15 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) throwableArray14);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException16 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray14);
        java.lang.Throwable[] throwableArray17 = mathIllegalStateException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNMATCHED_ODE_IN_EXPANDED_SET));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ILL_CONDITIONED_OPERATOR));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "condition number {1} is too high " + "'", str1.equals("condition number {1} is too high "));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter1.addObservedPoint((double) 100.0f, (double) 10L, (double) 0L);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric19 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint23 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer31 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter32 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer31);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint36 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double37 = weightedObservedPoint36.getWeight();
        double double38 = weightedObservedPoint36.getWeight();
        harmonicFitter32.addObservedPoint(weightedObservedPoint36);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double44 = weightedObservedPoint43.getY();
        double double45 = weightedObservedPoint43.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint49 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double50 = weightedObservedPoint49.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint54 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double55 = weightedObservedPoint54.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint23, weightedObservedPoint27, weightedObservedPoint36, weightedObservedPoint43, weightedObservedPoint49, weightedObservedPoint54 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser57 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray56);
        double[] doubleArray58 = parameterGuesser57.guess();
        try {
            double[] doubleArray59 = harmonicFitter1.fit(100, parametric19, doubleArray58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0d + "'", double37 == 1.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 100.0d + "'", double44 == 100.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 100.0d + "'", double45 == 100.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 1.0d + "'", double55 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer10 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter11 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = null;
        harmonicFitter11.addObservedPoint(weightedObservedPoint12);
        harmonicFitter11.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter11.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter11.addObservedPoint(weightedObservedPoint22);
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double33 = weightedObservedPoint32.getWeight();
        double double34 = weightedObservedPoint32.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint32);
        harmonicFitter1.addObservedPoint((double) 10.0f, 0.0d);
        harmonicFitter1.addObservedPoint(100.0d, 97.0d, (double) 10);
        double[] doubleArray49 = new double[] { 97.0d, 97.0d, (byte) 10, (-1.0f), '4', 100 };
        try {
            double[] doubleArray50 = harmonicFitter1.fit(doubleArray49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats3, localizedFormats4, localizedFormats5, localizedFormats6, localizedFormats7 };
        org.apache.commons.math3.exception.ZeroException zeroException9 = new org.apache.commons.math3.exception.ZeroException((org.apache.commons.math3.exception.util.Localizable) localizedFormats2, objArray8);
        org.apache.commons.math3.exception.ZeroException zeroException10 = new org.apache.commons.math3.exception.ZeroException(localizable1, objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray8);
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats2.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats3.equals(org.apache.commons.math3.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.URL_CONTAINS_NO_DATA));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_BIN_SELECTED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_ROW_DIMENSION));
        org.junit.Assert.assertNotNull(objArray8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_FIXED_LENGTH_CHROMOSOME;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_FIXED_LENGTH_CHROMOSOME + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_FIXED_LENGTH_CHROMOSOME));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0L, (java.lang.Number) 10.0f, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, (java.lang.Number) 0L, (java.lang.Number) 10.0f, true);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException9);
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        java.lang.Number number15 = numberIsTooSmallException14.getArgument();
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext17 = numberIsTooSmallException14.getContext();
        boolean boolean18 = numberIsTooSmallException14.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(exceptionContext17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray9 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (byte) -1, (double) (short) 10, 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer10 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter11 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer10);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = null;
        harmonicFitter11.addObservedPoint(weightedObservedPoint12);
        harmonicFitter11.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter11.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double23 = weightedObservedPoint22.getWeight();
        double double24 = weightedObservedPoint22.getWeight();
        double double25 = weightedObservedPoint22.getX();
        harmonicFitter11.addObservedPoint(weightedObservedPoint22);
        harmonicFitter1.addObservedPoint(weightedObservedPoint22);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray28 = harmonicFitter1.getObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double33 = weightedObservedPoint32.getWeight();
        double double34 = weightedObservedPoint32.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint36 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint36);
        org.apache.commons.math3.analysis.function.HarmonicOscillator.Parametric parametric39 = null;
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint43 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double48 = weightedObservedPoint47.getWeight();
        double double49 = weightedObservedPoint47.getWeight();
        double double50 = weightedObservedPoint47.getWeight();
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer51 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter52 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer51);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint56 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double57 = weightedObservedPoint56.getWeight();
        double double58 = weightedObservedPoint56.getWeight();
        harmonicFitter52.addObservedPoint(weightedObservedPoint56);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint63 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double64 = weightedObservedPoint63.getY();
        double double65 = weightedObservedPoint63.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint69 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double70 = weightedObservedPoint69.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint74 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double75 = weightedObservedPoint74.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray76 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint43, weightedObservedPoint47, weightedObservedPoint56, weightedObservedPoint63, weightedObservedPoint69, weightedObservedPoint74 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser77 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray76);
        double[] doubleArray78 = parameterGuesser77.guess();
        try {
            double[] doubleArray79 = harmonicFitter1.fit(0, parametric39, doubleArray78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 100.0d + "'", double25 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.0d + "'", double50 == 1.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.0d + "'", double57 == 1.0d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0d + "'", double58 == 1.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 100.0d + "'", double64 == 100.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 100.0d + "'", double65 == 100.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.0d + "'", double70 == 1.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0d + "'", double75 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) 1, (java.lang.Number) (byte) 0, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        java.lang.Object[] objArray10 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray8);
        java.lang.Class<?> wildcardClass12 = objArray8.getClass();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray8);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext14 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalArgumentException13);
        numberIsTooSmallException4.addSuppressed((java.lang.Throwable) mathIllegalArgumentException13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_SIMPLE));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, number1, (java.lang.Number) 10.0f, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OVERFLOW_IN_ADDITION));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.Number number5 = numberIsTooSmallException3.getMin();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1 + "'", number5.equals(1));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        java.lang.Object[] objArray7 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats4, objArray8);
        java.lang.String str10 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats4.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)" + "'", str10.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)"));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, (java.lang.Number) 100.0d, true);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 100, 0.0d, (double) (-1.0f));
        harmonicFitter1.addObservedPoint((double) 100.0f, (double) 10L, (double) 0L);
        try {
            double[] doubleArray17 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 2 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 0.0d, (java.lang.Number) 1L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.IMAGINARY_FORMAT));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint5 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double6 = weightedObservedPoint5.getWeight();
        double double7 = weightedObservedPoint5.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint5);
        harmonicFitter1.addObservedPoint((double) 1L, (double) '#');
        harmonicFitter1.addObservedPoint((double) 100, (double) 0.0f);
        harmonicFitter1.clearObservations();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray2 = new java.lang.Object[] { localizedFormats1 };
        java.lang.Object[] objArray3 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        java.lang.Object[] objArray4 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray2);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray2);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats7 };
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray8);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats6, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint15 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint19 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double20 = weightedObservedPoint19.getWeight();
        double double21 = weightedObservedPoint19.getWeight();
        double double22 = weightedObservedPoint19.getWeight();
        double double23 = weightedObservedPoint19.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) 0, (double) (byte) 10, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint31 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double32 = weightedObservedPoint31.getWeight();
        double double33 = weightedObservedPoint31.getWeight();
        double double34 = weightedObservedPoint31.getWeight();
        double double35 = weightedObservedPoint31.getY();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint39 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double40 = weightedObservedPoint39.getWeight();
        double double41 = weightedObservedPoint39.getWeight();
        double double42 = weightedObservedPoint39.getWeight();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint46 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (-1L), 100.0d, 0.0d);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray47 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] { weightedObservedPoint15, weightedObservedPoint19, weightedObservedPoint27, weightedObservedPoint31, weightedObservedPoint39, weightedObservedPoint46 };
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser48 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray47);
        org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser parameterGuesser49 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter.ParameterGuesser(weightedObservedPointArray47);
        java.lang.Object[] objArray50 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) weightedObservedPointArray47);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException51 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) weightedObservedPointArray47);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats52 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS;
        java.lang.Number number54 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (-1), number54, false);
        java.lang.Throwable[] throwableArray57 = numberIsTooSmallException56.getSuppressed();
        java.lang.Throwable[] throwableArray58 = numberIsTooSmallException56.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats52, (java.lang.Object[]) throwableArray58);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException60 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray58);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.POLYNOMIAL_INTERPOLANTS_MISMATCH_SEGMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats1.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_CLEAR_STATISTIC_CONSTRUCTED_FROM_EXTERNAL_MOMENTS));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats7.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.0d + "'", double40 == 1.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray47);
        org.junit.Assert.assertNotNull(objArray50);
        org.junit.Assert.assertTrue("'" + localizedFormats52 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS + "'", localizedFormats52.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_INTERVAL_INITIAL_VALUE_PARAMETERS));
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNotNull(throwableArray58);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.addObservedPoint(100.0d, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        harmonicFitter1.addObservedPoint((double) (short) 0, (double) 0L, 100.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer14 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter15 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer14);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray16 = harmonicFitter15.getObservations();
        harmonicFitter15.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter15.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint27 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double28 = weightedObservedPoint27.getWeight();
        double double29 = weightedObservedPoint27.getWeight();
        double double30 = weightedObservedPoint27.getWeight();
        harmonicFitter15.addObservedPoint(weightedObservedPoint27);
        double double32 = weightedObservedPoint27.getX();
        double double33 = weightedObservedPoint27.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint27);
        double double35 = weightedObservedPoint27.getWeight();
        org.junit.Assert.assertNotNull(weightedObservedPointArray16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.0d + "'", double28 == 1.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0d + "'", double30 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 100.0d + "'", double32 == 100.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        harmonicFitter1.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint10 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double11 = weightedObservedPoint10.getY();
        double double12 = weightedObservedPoint10.getY();
        double double13 = weightedObservedPoint10.getY();
        double double14 = weightedObservedPoint10.getY();
        harmonicFitter1.addObservedPoint(weightedObservedPoint10);
        double double16 = weightedObservedPoint10.getX();
        double double17 = weightedObservedPoint10.getX();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 100.0d + "'", double11 == 100.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 100.0d + "'", double13 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 100.0d + "'", double14 == 100.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 100.0d + "'", double17 == 100.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint2 = null;
        harmonicFitter1.addObservedPoint(weightedObservedPoint2);
        harmonicFitter1.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter1.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint12 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double13 = weightedObservedPoint12.getWeight();
        double double14 = weightedObservedPoint12.getWeight();
        double double15 = weightedObservedPoint12.getX();
        harmonicFitter1.addObservedPoint(weightedObservedPoint12);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer17 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter18 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer17);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray19 = harmonicFitter18.getObservations();
        harmonicFitter18.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter18.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint30 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double31 = weightedObservedPoint30.getWeight();
        double double32 = weightedObservedPoint30.getWeight();
        double double33 = weightedObservedPoint30.getWeight();
        harmonicFitter18.addObservedPoint(weightedObservedPoint30);
        double double35 = weightedObservedPoint30.getX();
        double double36 = weightedObservedPoint30.getWeight();
        harmonicFitter1.addObservedPoint(weightedObservedPoint30);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 100.0d + "'", double15 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray19);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) (short) -1, number1, false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer0 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter1 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer0);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray2 = harmonicFitter1.getObservations();
        harmonicFitter1.addObservedPoint((double) (-1L), 0.0d, (double) '#');
        harmonicFitter1.addObservedPoint((double) (-1L), (double) '#');
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer10 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter11 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer10);
        harmonicFitter11.addObservedPoint((-1.0d), (double) 0, (double) (byte) 10);
        harmonicFitter11.addObservedPoint((double) 1, (double) (short) 1, 10.0d);
        org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer differentiableMultivariateVectorOptimizer20 = null;
        org.apache.commons.math3.optimization.fitting.HarmonicFitter harmonicFitter21 = new org.apache.commons.math3.optimization.fitting.HarmonicFitter(differentiableMultivariateVectorOptimizer20);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint22 = null;
        harmonicFitter21.addObservedPoint(weightedObservedPoint22);
        harmonicFitter21.addObservedPoint(10.0d, (double) 0, (double) 10.0f);
        harmonicFitter21.clearObservations();
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint weightedObservedPoint32 = new org.apache.commons.math3.optimization.fitting.WeightedObservedPoint((double) (short) 1, (double) 100.0f, (double) 100L);
        double double33 = weightedObservedPoint32.getWeight();
        double double34 = weightedObservedPoint32.getWeight();
        double double35 = weightedObservedPoint32.getX();
        harmonicFitter21.addObservedPoint(weightedObservedPoint32);
        harmonicFitter11.addObservedPoint(weightedObservedPoint32);
        harmonicFitter1.addObservedPoint(weightedObservedPoint32);
        org.apache.commons.math3.optimization.fitting.WeightedObservedPoint[] weightedObservedPointArray39 = harmonicFitter1.getObservations();
        try {
            double[] doubleArray40 = harmonicFitter1.fit();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooSmallException; message: sample contains 3 observed points, at least 4 are required");
        } catch (org.apache.commons.math3.exception.NumberIsTooSmallException e) {
        }
        org.junit.Assert.assertNotNull(weightedObservedPointArray2);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.0d + "'", double33 == 1.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.0d + "'", double35 == 100.0d);
        org.junit.Assert.assertNotNull(weightedObservedPointArray39);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException3.getContext();
        java.lang.Number number6 = numberIsTooSmallException3.getArgument();
        java.lang.String str7 = numberIsTooSmallException3.toString();
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats8, (java.lang.Number) (short) 1, (java.lang.Number) 10.0d, true);
        java.lang.Throwable throwable13 = null;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats20 };
        java.lang.Object[] objArray22 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        java.lang.Object[] objArray23 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException24 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException18, (org.apache.commons.math3.exception.util.Localizable) localizedFormats19, objArray23);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException32 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats33 = org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES;
        java.lang.Object[] objArray35 = new java.lang.Object[] { localizedFormats26, localizedFormats27, localizedFormats28, true, localizedFormats33, localizedFormats34 };
        java.lang.Object[] objArray36 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray35);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException18, (org.apache.commons.math3.exception.util.Localizable) localizedFormats25, objArray36);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext38 = new org.apache.commons.math3.exception.util.ExceptionContext((java.lang.Throwable) mathIllegalStateException37);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray41 = new java.lang.Object[] { localizedFormats40 };
        java.lang.Object[] objArray42 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray41);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException43 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException37, (org.apache.commons.math3.exception.util.Localizable) localizedFormats39, objArray42);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException44 = new org.apache.commons.math3.exception.MathIllegalStateException(throwable13, (org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray42);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats45 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats50 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats51 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray52 = new java.lang.Object[] { localizedFormats51 };
        java.lang.Object[] objArray53 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray52);
        java.lang.Object[] objArray54 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray52);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException55 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException49, (org.apache.commons.math3.exception.util.Localizable) localizedFormats50, objArray54);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException56 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats45, objArray54);
        java.lang.Object[] objArray57 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray54);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math3.exception.MathIllegalArgumentException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, objArray54);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException59 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, (org.apache.commons.math3.exception.util.Localizable) localizedFormats8, objArray54);
        boolean boolean60 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.0d + "'", number6.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)" + "'", str7.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: 1 is smaller than the minimum (1)"));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX + "'", localizedFormats8.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EQUAL_VERTICES_IN_SIMPLEX));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats19.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats20.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY + "'", localizedFormats25.equals(org.apache.commons.math3.exception.util.LocalizedFormats.EULER_ANGLES_SINGULARITY));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS + "'", localizedFormats26.equals(org.apache.commons.math3.exception.util.LocalizedFormats.LCM_OVERFLOW_32_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR + "'", localizedFormats27.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INTERNAL_ERROR));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX + "'", localizedFormats28.equals(org.apache.commons.math3.exception.util.LocalizedFormats.OUT_OF_RANGE_ROOT_OF_UNITY_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats33 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM + "'", localizedFormats33.equals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_NORM));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES + "'", localizedFormats34.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INSTANCES_NOT_COMPARABLE_TO_EXISTING_VALUES));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT + "'", localizedFormats39.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NUMERATOR_FORMAT));
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats40.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + localizedFormats45 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats45.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats50 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats50.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats51 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats51.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray53);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1L, (java.lang.Number) 1L, true);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) 1, true);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats6 };
        java.lang.Object[] objArray8 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        java.lang.Object[] objArray9 = org.apache.commons.math3.exception.util.ArgUtils.flatten(objArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, (org.apache.commons.math3.exception.util.Localizable) localizedFormats5, objArray9);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats0, objArray9);
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO;
        org.apache.commons.math3.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math3.exception.NumberIsTooSmallException((org.apache.commons.math3.exception.util.Localizable) localizedFormats14, (java.lang.Number) 0L, (java.lang.Number) 10.0f, true);
        java.lang.Throwable[] throwableArray19 = numberIsTooSmallException18.getSuppressed();
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math3.exception.MathIllegalStateException((org.apache.commons.math3.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) throwableArray19);
        java.lang.Object[] objArray21 = org.apache.commons.math3.exception.util.ArgUtils.flatten((java.lang.Object[]) throwableArray19);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalStateException11, (org.apache.commons.math3.exception.util.Localizable) localizedFormats12, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS + "'", localizedFormats5.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NO_REGRESSORS));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY + "'", localizedFormats6.equals(org.apache.commons.math3.exception.util.LocalizedFormats.CARDAN_ANGLES_SINGULARITY));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats12.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO + "'", localizedFormats13.equals(org.apache.commons.math3.exception.util.LocalizedFormats.NOT_POWER_OF_TWO));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM + "'", localizedFormats14.equals(org.apache.commons.math3.exception.util.LocalizedFormats.UNABLE_TO_SOLVE_SINGULAR_PROBLEM));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(objArray21);
    }
}

